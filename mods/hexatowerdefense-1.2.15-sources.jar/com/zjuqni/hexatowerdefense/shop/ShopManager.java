package com.zjuqni.hexatowerdefense.shop;

import com.zjuqni.hexatowerdefense.arena.ArenaInstance;
import com.zjuqni.hexatowerdefense.arena.ArenaManager;
import com.zjuqni.hexatowerdefense.arena.ArenaState;
import com.zjuqni.hexatowerdefense.config.ConfigManager;
import com.zjuqni.hexatowerdefense.network.OpenShopS2CPayload;
import com.zjuqni.hexatowerdefense.network.ShopEnergyS2CPayload;
import com.zjuqni.hexatowerdefense.player.WeaponManager;
import com.zjuqni.hexatowerdefense.registry.ModBlocks;
import com.zjuqni.hexatowerdefense.registry.ModItems;
import com.zjuqni.hexatowerdefense.tower.TowerManager;
import com.zjuqni.hexatowerdefense.tower.TowerType;
import com.zjuqni.hexatowerdefense.util.HTDText;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import java.util.ArrayList;
import java.util.List;

public final class ShopManager {
    private static final int SET_BLOCK_FLAGS = 2 | 16;
    public static final int ENERGY_CELL_MAX_SAFE_STACK = 99;
    private static final List<ShopEntry> ENTRIES = List.of(
            new ShopEntry("panel_solar", "Panel Solar", 50, ModItems.PANEL_SOLAR_ITEM, 1, 10),
            new ShopEntry("turret", "Torreta", 100, ModItems.TURRET_ITEM, 1, 10),
            new ShopEntry("crossbow_tower", "Ballesta", 140, ModItems.CROSSBOW_TOWER_ITEM, 1, 8),
            new ShopEntry("cannon", "Cañón", 180, ModItems.CANNON_ITEM, 1, 6),
            new ShopEntry("holographic_shield", "Escudo Holográfico", 120, ModItems.HOLOGRAPHIC_SHIELD_ITEM, 1, 8),
            new ShopEntry("ion_battery", "Batería de Iones", 160, ModItems.ION_BATTERY_ITEM, 1, 6),
            new ShopEntry("tesla_tower", "Torre Tesla", 220, ModItems.TESLA_TOWER_ITEM, 1, 3),
            new ShopEntry("blue_upgrade_kit", "Kit de mejora azul", 140, ModItems.BLUE_UPGRADE_KIT, 1, 0),
            new ShopEntry("purple_upgrade_kit", "Kit de mejora morado", 220, ModItems.RED_UPGRADE_KIT, 1, 0),
            new ShopEntry("stone_axe", "Hacha de piedra", 25, class_1802.field_8062, 1, 0),
            new ShopEntry("iron_axe", "Hacha de hierro", 55, class_1802.field_8475, 1, 0),
            new ShopEntry("diamond_axe", "Hacha de diamante", 120, class_1802.field_8556, 1, 0),
            new ShopEntry("netherite_axe", "Hacha de netherite", 220, class_1802.field_22025, 1, 0),
            new ShopEntry("stone_sword", "Espada de piedra", 25, class_1802.field_8528, 1, 0),
            new ShopEntry("iron_sword", "Espada de hierro", 55, class_1802.field_8371, 1, 0),
            new ShopEntry("diamond_sword", "Espada de diamante", 120, class_1802.field_8802, 1, 0),
            new ShopEntry("netherite_sword", "Espada de netherite", 220, class_1802.field_22022, 1, 0),
            new ShopEntry("bow", "Arco con flechas infinitas", 90, class_1802.field_8102, 1, 0),
            new ShopEntry("crossbow", "Ballesta con flechas infinitas", 110, class_1802.field_8399, 1, 0)
    );

    private ShopManager() {
    }

    public static class_2338 placeShop(ArenaInstance arena, class_2338 shopPos) {
        class_3218 world = arena.getWorld();
        if (world == null || shopPos == null) {
            return null;
        }
        class_2680 state = ModBlocks.SHOP_BLOCK.method_9564();
        world.method_8652(shopPos, state, SET_BLOCK_FLAGS);
        arena.trackTemporaryBlock(shopPos);
        return shopPos;
    }

    public static void restoreShop(ArenaInstance arena) {
        class_3218 world = arena.getWorld();
        class_2338 shopPos = arena.shopPosition();
        if (world == null || shopPos == null) {
            return;
        }
        if (!world.method_8320(shopPos).method_27852(ModBlocks.SHOP_BLOCK)) {
            world.method_8652(shopPos, ModBlocks.SHOP_BLOCK.method_9564(), SET_BLOCK_FLAGS);
        }
    }

    public static boolean handleUse(class_3222 player, class_3218 world, class_2338 pos) {
        ArenaInstance arena = ArenaManager.get().getArena(player);
        if (arena == null || !world.method_27983().equals(arena.dimension()) || arena.shopPosition() == null) {
            return false;
        }
        if (!isShopClick(pos, arena.shopPosition())) {
            return false;
        }

        openShop(player, arena);
        return true;
    }

    public static void openShop(class_3222 player, ArenaInstance arena) {
        if (arena == null || arena.shopPosition() == null || !isNearShop(player, arena.shopPosition())) {
            HTDText.sendWarning(player, "Acércate a la tienda para intercambiar.", false);
            return;
        }
        normalizeEnergyCellStacks(player);
        ServerPlayNetworking.send(player, new OpenShopS2CPayload(countEnergyCells(player)));
    }

    public static boolean buy(class_3222 player, String itemId) {
        return buyInternal(player, itemId);
    }

    public static boolean buyFromGui(class_3222 player, String itemId) {
        boolean success = buyInternal(player, itemId);
        int energy = countEnergyCells(player);
        ServerPlayNetworking.send(player, new ShopEnergyS2CPayload(
                energy,
                success,
                ""
        ));
        return success;
    }

    private static boolean buyInternal(class_3222 player, String itemId) {
        normalizeEnergyCellStacks(player);
        ArenaInstance arena = ArenaManager.get().getArena(player);
        if (arena == null) {
            HTDText.sendError(player, "No tienes una arena activa.", false);
            return false;
        }
        if (arena.shopPosition() == null || !isNearShop(player, arena.shopPosition())) {
            HTDText.sendWarning(player, "Acércate a la tienda para intercambiar.", false);
            return false;
        }
        if (arena.state() != ArenaState.PREPARING && arena.state() != ArenaState.RUNNING) {
            HTDText.sendWarning(player, "La tienda solo está disponible durante preparación o partida.", false);
            return false;
        }

        ShopEntry entry = entry(itemId);
        if (entry == null) {
            HTDText.sendError(player, "Intercambio desconocido: " + itemId, false);
            return false;
        }
        if (entry.limit() > 0 && countOwnedEntryItems(arena, entry) >= entry.limit()) {
            HTDText.sendWarning(player, "Límite alcanzado: máximo " + entry.limit() + " de " + entry.display() + " por arena.", false);
            return false;
        }
        if (!removeEnergyCells(player, entry.price())) {
            HTDText.sendEnergy(player, "Células insuficientes. Necesitas " + entry.price() + " Células de Energía.", false);
            return false;
        }

        class_1799 stack = new class_1799(entry.item(), entry.count());
        player.method_31548().method_7398(stack);
        if (WeaponManager.isRangedWeapon(entry.item())) {
            player.method_31548().method_7398(new class_1799(class_1802.field_8107, 1));
        }

        class_3218 world = player.method_51469();
        world.method_8396(null, player.method_24515(), class_3417.field_14627, class_3419.field_15248, 0.55F, 1.35F);
        HTDText.sendEnergy(player, "Intercambiaste " + entry.display() + ". Células restantes: " + countEnergyCells(player) + ".", false);
        return true;
    }

    private static int countOwnedEntryItems(ArenaInstance arena, ShopEntry entry) {
        int count = 0;
        TowerType type = TowerManager.towerTypeFor(entry.item());
        if (type != null) {
            count += arena.towerManager().countTowersOfType(type);
        }
        for (class_3222 member : arena.getPlayers()) {
            for (int i = 0; i < member.method_31548().method_5439(); i++) {
                class_1799 stack = member.method_31548().method_5438(i);
                if (stack.method_31574(entry.item())) {
                    count += stack.method_7947();
                }
            }
        }
        return count;
    }

    public static int limitFor(TowerType type) {
        for (ShopEntry entry : ENTRIES) {
            if (TowerManager.towerTypeFor(entry.item()) == type) {
                return configured(entry).limit();
            }
        }
        return 0;
    }

    public static void giveEnergyCells(class_3222 player, int amount) {
        if (amount <= 0) {
            return;
        }
        int total = countEnergyCells(player) + amount;
        clearEnergyCells(player);
        giveEnergyCellsUnchecked(player, total);
        player.method_31548().method_5431();
        player.field_7512.method_7623();
    }

    private static void giveEnergyCellsUnchecked(class_3222 player, int amount) {
        int remaining = amount;
        while (remaining > 0) {
            int stackSize = Math.min(ENERGY_CELL_MAX_SAFE_STACK, remaining);
            class_1799 stack = new class_1799(ModItems.ENERGY_CELL, stackSize);
            player.method_31548().method_7398(stack);
            remaining -= stackSize;
        }
    }

    public static void normalizeEnergyCellStacks(class_3222 player) {
        int total = 0;
        for (int i = 0; i < player.method_31548().method_5439(); i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (!stack.method_31574(ModItems.ENERGY_CELL)) {
                continue;
            }
            total += stack.method_7947();
        }
        clearEnergyCells(player);
        if (total > 0) {
            giveEnergyCellsUnchecked(player, total);
        }
        player.method_31548().method_5431();
        player.field_7512.method_7623();
    }

    private static void clearEnergyCells(class_3222 player) {
        for (int i = 0; i < player.method_31548().method_5439(); i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (stack.method_31574(ModItems.ENERGY_CELL)) {
                player.method_31548().method_5447(i, class_1799.field_8037);
            }
        }
    }

    public static int countEnergyCells(class_3222 player) {
        int count = 0;
        for (int i = 0; i < player.method_31548().method_5439(); i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (stack.method_31574(ModItems.ENERGY_CELL)) {
                count += stack.method_7947();
            }
        }
        return count;
    }

    private static boolean removeEnergyCells(class_3222 player, int amount) {
        if (amount <= 0) {
            return true;
        }
        if (countEnergyCells(player) < amount) {
            return false;
        }
        int remainingTotal = countEnergyCells(player) - amount;
        clearEnergyCells(player);
        if (remainingTotal > 0) {
            giveEnergyCellsUnchecked(player, remainingTotal);
        }
        player.method_31548().method_5431();
        player.field_7512.method_7623();
        return true;
    }

    public static List<ShopEntry> entries() {
        List<ShopEntry> result = new ArrayList<>();
        for (ShopEntry entry : ENTRIES) {
            result.add(configured(entry));
        }
        return result;
    }

    public static ShopEntry entryById(String id) {
        return entry(id);
    }

    private static ShopEntry entry(String id) {
        for (ShopEntry entry : ENTRIES) {
            if (entry.id().equalsIgnoreCase(id)) {
                return configured(entry);
            }
        }
        return null;
    }

    private static boolean isNearShop(class_3222 player, class_2338 shopPos) {
        double dx = player.method_23317() - (shopPos.method_10263() + 0.5D);
        double dy = player.method_23318() - (shopPos.method_10264() + 0.5D);
        double dz = player.method_23321() - (shopPos.method_10260() + 0.5D);
        double maxDistance = Math.max(8.0D, ConfigManager.general().shopInteractionDistance);
        return dx * dx + dy * dy + dz * dz <= maxDistance * maxDistance;
    }

    private static boolean isShopClick(class_2338 clickedPos, class_2338 shopPos) {
        return Math.abs(clickedPos.method_10263() - shopPos.method_10263()) <= 2
                && Math.abs(clickedPos.method_10264() - shopPos.method_10264()) <= 2
                && Math.abs(clickedPos.method_10260() - shopPos.method_10260()) <= 2;
    }

    private static ShopEntry configured(ShopEntry entry) {
        return new ShopEntry(
                entry.id(),
                ConfigManager.shopDisplay(entry.id(), entry.display()),
                ConfigManager.shopPrice(entry.id(), entry.price()),
                entry.item(),
                entry.count(),
                ConfigManager.shopLimit(entry.id(), entry.limit())
        );
    }
}
