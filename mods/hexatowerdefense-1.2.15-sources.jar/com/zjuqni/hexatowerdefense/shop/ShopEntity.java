package com.zjuqni.hexatowerdefense.shop;

public final class ShopEntity {
}
