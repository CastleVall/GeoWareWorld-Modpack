package com.zjuqni.hexatowerdefense.shop;

import net.minecraft.class_1792;

public record ShopEntry(String id, String display, int price, class_1792 item, int count, int limit) {
}
