package com.zjuqni.hexatowerdefense.player;

import com.zjuqni.hexatowerdefense.arena.ArenaManager;
import com.zjuqni.hexatowerdefense.config.ConfigManager;
import com.zjuqni.hexatowerdefense.registry.ModItems;
import com.zjuqni.hexatowerdefense.util.HTDText;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import net.minecraft.class_9300;
import net.minecraft.class_9334;
import net.minecraft.server.MinecraftServer;

public final class WeaponManager {
    private WeaponManager() {
    }

    public static void tick(MinecraftServer server) {
        for (class_3222 player : server.method_3760().method_14571()) {
            if (ArenaManager.get().getArena(player) == null) {
                continue;
            }
            if (hasRangedWeapon(player.method_31548()) && countArrows(player.method_31548()) <= 0) {
                player.method_31548().method_7398(new class_1799(class_1802.field_8107, 1));
            }
        }
    }

    public static class_1271<class_1799> handleUseItem(class_1657 player, class_1937 world, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (world.method_8608() || !(player instanceof class_3222 serverPlayer) || !isUpgradeKit(stack.method_7909())) {
            return class_1271.method_22430(stack);
        }
        if (ArenaManager.get().getArena(serverPlayer) == null) {
            return class_1271.method_22430(stack);
        }

        boolean upgraded = upgradeFirstMatchingWeapon(serverPlayer, stack.method_7909());
        if (!upgraded) {
            HTDText.sendWarning(serverPlayer, "No tienes un arma compatible para este kit.", true);
            return class_1271.method_22431(stack);
        }
        if (!serverPlayer.method_7337()) {
            stack.method_7934(1);
        }
        return class_1271.method_29237(stack, false);
    }

    public static boolean isRangedWeapon(class_1792 item) {
        return item == class_1802.field_8102 || item == class_1802.field_8399;
    }

    public static void giveStarterWeapon(class_3222 player) {
        if (!ConfigManager.general().giveStarterSword) {
            return;
        }
        class_1799 sword = makeUnbreakable(new class_1799(class_1802.field_8091, 1));
        class_1661 inventory = player.method_31548();
        inventory.method_5447(0, sword);
        inventory.field_7545 = 0;
        inventory.method_5431();
        player.field_7512.method_7623();
    }

    public static class_1799 makeUnbreakable(class_1799 stack) {
        stack.method_57379(class_9334.field_49630, new class_9300(false));
        return stack;
    }

    private static boolean upgradeFirstMatchingWeapon(class_3222 player, class_1792 kit) {
        class_1661 inventory = player.method_31548();
        for (int i = 0; i < inventory.method_5439(); i++) {
            class_1799 current = inventory.method_5438(i);
            if (current.method_7960()) {
                continue;
            }
            class_1792 replacement = upgradedItem(current.method_7909(), kit);
            if (replacement == null) {
                continue;
            }
            class_1799 upgraded = makeUnbreakable(new class_1799(replacement, 1));
            inventory.method_5447(i, upgraded);
            inventory.method_5431();
            HTDText.sendEnergy(player, "Arma mejorada a " + upgraded.method_7964().getString() + ".", false);
            return true;
        }
        return false;
    }

    private static class_1792 upgradedItem(class_1792 current, class_1792 kit) {
        if (kit == ModItems.BLUE_UPGRADE_KIT) {
            if (current == class_1802.field_8091 || current == class_1802.field_8528 || current == class_1802.field_8371) {
                return class_1802.field_8802;
            }
            if (current == class_1802.field_8406 || current == class_1802.field_8062 || current == class_1802.field_8475) {
                return class_1802.field_8556;
            }
            return null;
        }
        if (kit == ModItems.RED_UPGRADE_KIT) {
            if (current == class_1802.field_8802) {
                return class_1802.field_22022;
            }
            if (current == class_1802.field_8556) {
                return class_1802.field_22025;
            }
        }
        return null;
    }

    private static boolean isUpgradeKit(class_1792 item) {
        return item == ModItems.BLUE_UPGRADE_KIT || item == ModItems.RED_UPGRADE_KIT;
    }

    private static boolean hasRangedWeapon(class_1661 inventory) {
        for (int i = 0; i < inventory.method_5439(); i++) {
            class_1792 item = inventory.method_5438(i).method_7909();
            if (isRangedWeapon(item)) {
                return true;
            }
        }
        return false;
    }

    private static int countArrows(class_1661 inventory) {
        int count = 0;
        for (int i = 0; i < inventory.method_5439(); i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_31574(class_1802.field_8107)) {
                count += stack.method_7947();
            }
        }
        return count;
    }
}
