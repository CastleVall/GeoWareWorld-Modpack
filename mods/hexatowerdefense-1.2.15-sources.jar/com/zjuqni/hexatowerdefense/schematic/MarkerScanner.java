package com.zjuqni.hexatowerdefense.schematic;

import com.zjuqni.hexatowerdefense.config.ConfigManager;
import com.zjuqni.hexatowerdefense.config.MarkerConfig;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2338;

public final class MarkerScanner {
    public Path scan(SchematicTemplate template) throws IOException {
        MarkerConfig markerConfig = ConfigManager.markers();
        MarkerReport report = new MarkerReport();
        report.schematicVersion = template.version();
        report.dataVersion = template.dataVersion();
        report.width = template.width();
        report.height = template.height();
        report.length = template.length();
        report.offset = List.of(template.offset().method_10263(), template.offset().method_10264(), template.offset().method_10260());
        report.totalBlocks = template.totalBlocks();
        report.nonAirBlocks = template.nonAirBlockCount();
        report.blockCounts = template.blockCounts();
        report.entries = new ArrayList<>();

        for (Map.Entry<String, String> markerRole : markerConfig.markerRoles.entrySet()) {
            List<class_2338> positions = template.markerBlocks().getOrDefault(markerRole.getKey(), List.of());
            MarkerReportEntry entry = buildEntry(template, markerRole.getKey(), markerRole.getValue(), positions);
            report.entries.add(entry);
        }

        Path output = ConfigManager.markerReportPath();
        ConfigManager.writeJson(output, report);
        return output;
    }

    private static MarkerReportEntry buildEntry(SchematicTemplate template, String blockstate, String role, List<class_2338> positions) {
        MarkerReportEntry entry = new MarkerReportEntry();
        entry.blockstate = blockstate;
        entry.role = role;
        entry.count = positions.size();
        entry.localPositions = new ArrayList<>();
        entry.relativeToAnchorPositions = new ArrayList<>();
        entry.suggestion = suggestRole(blockstate, role);

        BoundsBuilder localBounds = new BoundsBuilder();
        BoundsBuilder relativeBounds = new BoundsBuilder();
        for (class_2338 local : positions) {
            class_2338 relative = template.localToRelative(local.method_10263(), local.method_10264(), local.method_10260());
            entry.localPositions.add(List.of(local.method_10263(), local.method_10264(), local.method_10260()));
            entry.relativeToAnchorPositions.add(List.of(relative.method_10263(), relative.method_10264(), relative.method_10260()));
            localBounds.include(local);
            relativeBounds.include(relative);
        }
        entry.localBounds = localBounds.toMap();
        entry.relativeToAnchorBounds = relativeBounds.toMap();
        return entry;
    }

    private static String suggestRole(String blockstate, String configuredRole) {
        if (configuredRole != null && !configuredRole.isBlank()) {
            return configuredRole;
        }
        if (blockstate.contains("coal_block")) {
            return "PLAYER_SPAWN";
        }
        if (blockstate.contains("netherite_block")) {
            return "SHOP";
        }
        if (blockstate.contains("redstone_block")) {
            return "ENEMY_SPAWN_ZONE";
        }
        if (blockstate.contains("gold_block")) {
            return "CLICKABLE_PLACEMENT";
        }
        if (blockstate.contains("diamond_block")) {
            return "STRUCTURE_ANCHOR";
        }
        if (blockstate.contains("emerald_block")) {
            return "LOCKED_LANE";
        }
        if (blockstate.contains("barrier")) {
            return "BOUNDARY";
        }
        return "UNASSIGNED";
    }

    private static final class BoundsBuilder {
        private boolean empty = true;
        private int minX;
        private int minY;
        private int minZ;
        private int maxX;
        private int maxY;
        private int maxZ;

        void include(class_2338 pos) {
            if (empty) {
                minX = maxX = pos.method_10263();
                minY = maxY = pos.method_10264();
                minZ = maxZ = pos.method_10260();
                empty = false;
                return;
            }
            minX = Math.min(minX, pos.method_10263());
            minY = Math.min(minY, pos.method_10264());
            minZ = Math.min(minZ, pos.method_10260());
            maxX = Math.max(maxX, pos.method_10263());
            maxY = Math.max(maxY, pos.method_10264());
            maxZ = Math.max(maxZ, pos.method_10260());
        }

        Map<String, List<Integer>> toMap() {
            Map<String, List<Integer>> map = new LinkedHashMap<>();
            if (empty) {
                map.put("min", List.of());
                map.put("max", List.of());
                return map;
            }
            map.put("min", List.of(minX, minY, minZ));
            map.put("max", List.of(maxX, maxY, maxZ));
            return map;
        }
    }

    private static final class MarkerReport {
        int schematicVersion;
        int dataVersion;
        int width;
        int height;
        int length;
        List<Integer> offset;
        int totalBlocks;
        int nonAirBlocks;
        Map<String, Integer> blockCounts;
        List<MarkerReportEntry> entries;
    }

    private static final class MarkerReportEntry {
        String blockstate;
        String role;
        int count;
        List<List<Integer>> localPositions;
        List<List<Integer>> relativeToAnchorPositions;
        Map<String, List<Integer>> localBounds;
        Map<String, List<Integer>> relativeToAnchorBounds;
        String suggestion;
    }
}
