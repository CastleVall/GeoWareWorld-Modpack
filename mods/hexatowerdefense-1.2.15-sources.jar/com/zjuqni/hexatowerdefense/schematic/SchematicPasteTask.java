package com.zjuqni.hexatowerdefense.schematic;

import com.zjuqni.hexatowerdefense.arena.ArenaInstance;
import com.zjuqni.hexatowerdefense.config.ConfigManager;
import com.zjuqni.hexatowerdefense.config.MarkerConfig;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

public final class SchematicPasteTask {
    private static final int SET_BLOCK_FLAGS = 2 | 16;

    private final ArenaInstance arena;
    private final SchematicTemplate template;
    private final class_2338 anchor;
    private final int blocksPerTick;
    private final class_3218 world;
    private final Map<String, class_2680> replacementCache = new HashMap<>();
    private int index;
    private int placed;
    private boolean finished;
    private boolean cancelled;

    public SchematicPasteTask(ArenaInstance arena, SchematicTemplate template, class_2338 anchor, class_3218 world, int blocksPerTick) {
        this.arena = arena;
        this.template = template;
        this.anchor = anchor;
        this.world = world;
        this.blocksPerTick = Math.max(1, blocksPerTick);
    }

    public void tick() {
        tick(blocksPerTick);
    }

    public void tick(int budget) {
        if (finished || cancelled) {
            return;
        }

        int allowed = Math.max(1, Math.min(blocksPerTick, budget));
        int placedThisTick = 0;
        while (index < template.nonAirBlocks().size() && placedThisTick < allowed) {
            SchematicBlock block = template.nonAirBlocks().get(index++);
            class_2338 worldPos = template.localToWorld(anchor, block.localX(), block.localY(), block.localZ());
            world.method_8652(worldPos, stateForPaste(block), SET_BLOCK_FLAGS);
            placed++;
            placedThisTick++;
        }

        if (index >= template.nonAirBlocks().size()) {
            finished = true;
            arena.onSchematicPasted(template);
        }
    }

    public void cancel() {
        cancelled = true;
        finished = true;
    }

    public boolean isFinished() {
        return finished;
    }

    public ArenaInstance arena() {
        return arena;
    }

    public int placed() {
        return placed;
    }

    public int total() {
        return template.nonAirBlocks().size();
    }

    private class_2680 stateForPaste(SchematicBlock block) {
        if (block.state().method_27852(class_2246.field_22122)) {
            return class_2246.field_10124.method_9564();
        }
        if (isReferenceGameplayMarker(block.state())) {
            return referenceMarkerReplacement(block.state());
        }

        MarkerConfig markers = ConfigManager.markers();
        if (!markers.enabled || !markers.replaceMarkersOnPaste) {
            return block.state();
        }

        String replacement = markers.replacementBlocks.get(block.rawState());
        if (replacement == null) {
            return block.state();
        }

        return replacementCache.computeIfAbsent(replacement, SchematicLoader::parseBlockState);
    }

    private static boolean isReferenceGameplayMarker(class_2680 state) {
        return state.method_27852(class_2246.field_10381)
                || state.method_27852(class_2246.field_22108)
                || state.method_27852(class_2246.field_10002)
                || state.method_27852(class_2246.field_10205)
                || state.method_27852(class_2246.field_10201)
                || state.method_27852(class_2246.field_10234);
    }

    private static class_2680 referenceMarkerReplacement(class_2680 state) {
        if (state.method_27852(class_2246.field_10002)
                || state.method_27852(class_2246.field_10205)
                || state.method_27852(class_2246.field_10201)
                || state.method_27852(class_2246.field_10234)) {
            return class_2246.field_28896.method_9564();
        }
        return class_2246.field_23873.method_9564();
    }
}
