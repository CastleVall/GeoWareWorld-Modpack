package com.zjuqni.hexatowerdefense.schematic;

import com.zjuqni.hexatowerdefense.arena.ArenaInstance;
import com.zjuqni.hexatowerdefense.util.HTDText;
import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class SchematicCleanupTask {
    private static final int SET_BLOCK_FLAGS = 2 | 16;

    private final ArenaInstance arena;
    private final SchematicTemplate template;
    private final class_2338 anchor;
    private final class_3218 world;
    private final int blocksPerTick;
    private final boolean boundingBoxMode;
    private final List<class_2338> temporaryBlocks;
    private int trackedIndex;
    private int boxIndex;
    private int temporaryIndex;
    private int cleared;
    private boolean finished;

    public SchematicCleanupTask(
            ArenaInstance arena,
            SchematicTemplate template,
            class_2338 anchor,
            class_3218 world,
            int blocksPerTick,
            String clearMode
    ) {
        this.arena = arena;
        this.template = template;
        this.anchor = anchor;
        this.world = world;
        this.blocksPerTick = Math.max(1, blocksPerTick);
        this.boundingBoxMode = "BOUNDING_BOX".equalsIgnoreCase(clearMode);
        this.temporaryBlocks = arena.temporaryBlocks();
    }

    public void tick() {
        if (finished) {
            return;
        }

        if (isPrimaryComplete()) {
            clearTemporaryBlocks();
        } else if (boundingBoxMode) {
            clearBoundingBox();
        } else {
            clearTrackedBlocks();
        }

        sendProgress();
        if (isComplete()) {
            finished = true;
            arena.onCleanupFinished();
        }
    }

    public boolean isFinished() {
        return finished;
    }

    public void cancel() {
        finished = true;
    }

    public ArenaInstance arena() {
        return arena;
    }

    private void clearTrackedBlocks() {
        int clearedThisTick = 0;
        while (trackedIndex < template.nonAirBlocks().size() && clearedThisTick < blocksPerTick) {
            SchematicBlock block = template.nonAirBlocks().get(trackedIndex++);
            class_2338 worldPos = template.localToWorld(anchor, block.localX(), block.localY(), block.localZ());
            world.method_8652(worldPos, class_2246.field_10124.method_9564(), SET_BLOCK_FLAGS);
            cleared++;
            clearedThisTick++;
        }
    }

    private void clearBoundingBox() {
        int total = template.width() * template.height() * template.length();
        int clearedThisTick = 0;
        while (boxIndex < total && clearedThisTick < blocksPerTick) {
            int localX = boxIndex % template.width();
            int localZ = (boxIndex / template.width()) % template.length();
            int localY = boxIndex / (template.width() * template.length());
            class_2338 worldPos = template.localToWorld(anchor, localX, localY, localZ);
            world.method_8652(worldPos, class_2246.field_10124.method_9564(), SET_BLOCK_FLAGS);
            boxIndex++;
            cleared++;
            clearedThisTick++;
        }
    }

    private boolean isComplete() {
        return isPrimaryComplete() && temporaryIndex >= temporaryBlocks.size();
    }

    private boolean isPrimaryComplete() {
        if (boundingBoxMode) {
            return boxIndex >= template.width() * template.height() * template.length();
        }
        return trackedIndex >= template.nonAirBlocks().size();
    }

    private void clearTemporaryBlocks() {
        int clearedThisTick = 0;
        while (temporaryIndex < temporaryBlocks.size() && clearedThisTick < blocksPerTick) {
            world.method_8652(temporaryBlocks.get(temporaryIndex++), class_2246.field_10124.method_9564(), SET_BLOCK_FLAGS);
            cleared++;
            clearedThisTick++;
        }
    }

    private int total() {
        if (boundingBoxMode) {
            return template.width() * template.height() * template.length() + temporaryBlocks.size();
        }
        return template.nonAirBlocks().size() + temporaryBlocks.size();
    }

    private void sendProgress() {
        int percent = (int) Math.floor((cleared * 100.0D) / Math.max(1, total()));
        for (class_3222 player : arena.getPlayers()) {
            HTDText.sendInfo(player, "Limpiando arena... " + percent + "%", true);
        }
    }
}
