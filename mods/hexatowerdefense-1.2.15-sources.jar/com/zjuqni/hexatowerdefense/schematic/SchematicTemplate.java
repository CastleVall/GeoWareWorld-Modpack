package com.zjuqni.hexatowerdefense.schematic;

import java.util.List;
import java.util.Map;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2382;

public final class SchematicTemplate {
    private final int version;
    private final int dataVersion;
    private final int width;
    private final int height;
    private final int length;
    private final class_2382 offset;
    private final int totalBlocks;
    private final int nonAirBlockCount;
    private final Map<String, Integer> palette;
    private final Map<String, Integer> blockCounts;
    private final List<SchematicBlock> nonAirBlocks;
    private final Map<String, List<class_2338>> markerBlocks;
    private final int blockEntityCount;

    public SchematicTemplate(
            int version,
            int dataVersion,
            int width,
            int height,
            int length,
            class_2382 offset,
            int totalBlocks,
            int nonAirBlockCount,
            Map<String, Integer> palette,
            Map<String, Integer> blockCounts,
            List<SchematicBlock> nonAirBlocks,
            Map<String, List<class_2338>> markerBlocks,
            int blockEntityCount
    ) {
        this.version = version;
        this.dataVersion = dataVersion;
        this.width = width;
        this.height = height;
        this.length = length;
        this.offset = offset;
        this.totalBlocks = totalBlocks;
        this.nonAirBlockCount = nonAirBlockCount;
        this.palette = Map.copyOf(palette);
        this.blockCounts = Map.copyOf(blockCounts);
        this.nonAirBlocks = List.copyOf(nonAirBlocks);
        this.markerBlocks = Map.copyOf(markerBlocks);
        this.blockEntityCount = blockEntityCount;
    }

    public int version() {
        return version;
    }

    public int dataVersion() {
        return dataVersion;
    }

    public int width() {
        return width;
    }

    public int height() {
        return height;
    }

    public int length() {
        return length;
    }

    public class_2382 offset() {
        return offset;
    }

    public int totalBlocks() {
        return totalBlocks;
    }

    public int nonAirBlockCount() {
        return nonAirBlockCount;
    }

    public Map<String, Integer> palette() {
        return palette;
    }

    public Map<String, Integer> blockCounts() {
        return blockCounts;
    }

    public List<SchematicBlock> nonAirBlocks() {
        return nonAirBlocks;
    }

    public Map<String, List<class_2338>> markerBlocks() {
        return markerBlocks;
    }

    public int blockEntityCount() {
        return blockEntityCount;
    }

    public class_238 getBoundsAt(class_2338 anchor) {
        class_2338 min = anchor.method_10069(offset.method_10263(), offset.method_10264(), offset.method_10260());
        return new class_238(
                min.method_10263(),
                min.method_10264(),
                min.method_10260(),
                min.method_10263() + width,
                min.method_10264() + height,
                min.method_10260() + length
        );
    }

    public class_2338 localToWorld(class_2338 anchor, int localX, int localY, int localZ) {
        return anchor.method_10069(offset.method_10263() + localX, offset.method_10264() + localY, offset.method_10260() + localZ);
    }

    public class_2338 localToRelative(int localX, int localY, int localZ) {
        return new class_2338(offset.method_10263() + localX, offset.method_10264() + localY, offset.method_10260() + localZ);
    }
}
