package com.zjuqni.hexatowerdefense.schematic;

import net.minecraft.class_2338;
import net.minecraft.class_2680;

public record SchematicBlock(int localX, int localY, int localZ, class_2680 state, String rawState) {
    public class_2338 localPos() {
        return new class_2338(localX, localY, localZ);
    }
}
