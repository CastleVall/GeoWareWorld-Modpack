package com.zjuqni.hexatowerdefense.schematic;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

final class SimpleNbtReader {
    private static final int TAG_END = 0;
    private static final int TAG_BYTE = 1;
    private static final int TAG_SHORT = 2;
    private static final int TAG_INT = 3;
    private static final int TAG_LONG = 4;
    private static final int TAG_FLOAT = 5;
    private static final int TAG_DOUBLE = 6;
    private static final int TAG_BYTE_ARRAY = 7;
    private static final int TAG_STRING = 8;
    private static final int TAG_LIST = 9;
    private static final int TAG_COMPOUND = 10;
    private static final int TAG_INT_ARRAY = 11;
    private static final int TAG_LONG_ARRAY = 12;

    private SimpleNbtReader() {
    }

    static Map<String, Object> readRootCompound(Path path) throws IOException {
        try (InputStream input = openMaybeCompressed(path);
             DataInputStream data = new DataInputStream(input)) {
            int type = data.readUnsignedByte();
            if (type != TAG_COMPOUND) {
                throw new IOException("Root NBT tag is not a compound: " + type);
            }
            data.readUTF();
            return readCompoundPayload(data);
        }
    }

    private static InputStream openMaybeCompressed(Path path) throws IOException {
        BufferedInputStream input = new BufferedInputStream(Files.newInputStream(path));
        input.mark(2);
        int first = input.read();
        int second = input.read();
        input.reset();
        if (first == 0x1f && second == 0x8b) {
            return new GZIPInputStream(input);
        }
        return input;
    }

    private static Object readPayload(DataInputStream data, int type) throws IOException {
        return switch (type) {
            case TAG_BYTE -> data.readByte();
            case TAG_SHORT -> data.readShort();
            case TAG_INT -> data.readInt();
            case TAG_LONG -> data.readLong();
            case TAG_FLOAT -> data.readFloat();
            case TAG_DOUBLE -> data.readDouble();
            case TAG_BYTE_ARRAY -> readByteArray(data);
            case TAG_STRING -> data.readUTF();
            case TAG_LIST -> readList(data);
            case TAG_COMPOUND -> readCompoundPayload(data);
            case TAG_INT_ARRAY -> readIntArray(data);
            case TAG_LONG_ARRAY -> readLongArray(data);
            default -> throw new IOException("Unsupported NBT tag type: " + type);
        };
    }

    private static Map<String, Object> readCompoundPayload(DataInputStream data) throws IOException {
        Map<String, Object> compound = new LinkedHashMap<>();
        while (true) {
            int type;
            try {
                type = data.readUnsignedByte();
            } catch (EOFException e) {
                throw new IOException("Unexpected EOF inside NBT compound", e);
            }
            if (type == TAG_END) {
                return compound;
            }
            String name = data.readUTF();
            compound.put(name, readPayload(data, type));
        }
    }

    private static byte[] readByteArray(DataInputStream data) throws IOException {
        int length = data.readInt();
        byte[] bytes = new byte[length];
        data.readFully(bytes);
        return bytes;
    }

    private static List<Object> readList(DataInputStream data) throws IOException {
        int elementType = data.readUnsignedByte();
        int length = data.readInt();
        List<Object> list = new ArrayList<>(length);
        for (int i = 0; i < length; i++) {
            list.add(readPayload(data, elementType));
        }
        return list;
    }

    private static int[] readIntArray(DataInputStream data) throws IOException {
        int length = data.readInt();
        int[] values = new int[length];
        for (int i = 0; i < length; i++) {
            values[i] = data.readInt();
        }
        return values;
    }

    private static long[] readLongArray(DataInputStream data) throws IOException {
        int length = data.readInt();
        long[] values = new long[length];
        for (int i = 0; i < length; i++) {
            values[i] = data.readLong();
        }
        return values;
    }
}
