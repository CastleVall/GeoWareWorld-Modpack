package com.zjuqni.hexatowerdefense.schematic;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class SchematicLoader {
    public SchematicTemplate load(Path path) throws IOException {
        if (!Files.exists(path)) {
            throw new IOException("No existe el schematic: " + path);
        }

        Map<String, Object> root = SimpleNbtReader.readRootCompound(path);
        Map<String, Object> schematic = compound(root.containsKey("Schematic") ? root.get("Schematic") : root, "Schematic");
        Map<String, Object> blocks = compound(schematic.get("Blocks"), "Schematic.Blocks");
        Map<String, Object> paletteCompound = compound(blocks.get("Palette"), "Schematic.Blocks.Palette");
        byte[] blockData = byteArray(blocks.get("Data"), "Schematic.Blocks.Data");

        int version = intValue(schematic.get("Version"), "Schematic.Version");
        int dataVersion = intValue(schematic.getOrDefault("DataVersion", 0), "Schematic.DataVersion");
        int width = intValue(schematic.get("Width"), "Schematic.Width");
        int height = intValue(schematic.get("Height"), "Schematic.Height");
        int length = intValue(schematic.get("Length"), "Schematic.Length");
        class_2382 offset = readOffset(schematic.get("Offset"));
        int totalBlocks = width * height * length;

        Map<String, Integer> palette = new LinkedHashMap<>();
        Map<Integer, String> byId = new LinkedHashMap<>();
        for (Map.Entry<String, Object> entry : paletteCompound.entrySet()) {
            int value = intValue(entry.getValue(), "Palette." + entry.getKey());
            palette.put(entry.getKey(), value);
            byId.put(value, entry.getKey());
        }

        int[] decoded = decodeVarInts(blockData, totalBlocks);
        Map<String, class_2680> stateCache = new LinkedHashMap<>();
        Map<String, Integer> blockCounts = new LinkedHashMap<>();
        List<SchematicBlock> nonAirBlocks = new ArrayList<>();
        Map<String, List<class_2338>> blocksByRawState = new LinkedHashMap<>();

        for (int index = 0; index < decoded.length; index++) {
            String rawState = byId.get(decoded[index]);
            if (rawState == null) {
                throw new IOException("Palette id sin blockstate: " + decoded[index]);
            }

            blockCounts.merge(rawState, 1, Integer::sum);
            class_2680 state = stateCache.computeIfAbsent(rawState, SchematicLoader::parseBlockStateUnchecked);
            if (state.method_26215()) {
                continue;
            }

            int localX = index % width;
            int localZ = (index / width) % length;
            int localY = index / (width * length);
            SchematicBlock block = new SchematicBlock(localX, localY, localZ, state, rawState);
            nonAirBlocks.add(block);
            blocksByRawState.computeIfAbsent(rawState, ignored -> new ArrayList<>()).add(block.localPos());
        }

        int blockEntityCount = 0;
        Object blockEntities = blocks.get("BlockEntities");
        if (blockEntities instanceof List<?> list) {
            blockEntityCount = list.size();
        }

        SchematicTemplate template = new SchematicTemplate(
                version,
                dataVersion,
                width,
                height,
                length,
                offset,
                totalBlocks,
                nonAirBlocks.size(),
                palette,
                blockCounts,
                nonAirBlocks,
                blocksByRawState,
                blockEntityCount
        );

        HexaTowerDefenseMod.LOGGER.info(
                "Loaded schematic {}: {}x{}x{}, offset [{}, {}, {}], {} total, {} non-air",
                path,
                width,
                height,
                length,
                offset.method_10263(),
                offset.method_10264(),
                offset.method_10260(),
                totalBlocks,
                nonAirBlocks.size()
        );
        return template;
    }

    public static class_2680 parseBlockState(String rawState) {
        return parseBlockStateUnchecked(rawState);
    }

    private static class_2680 parseBlockStateUnchecked(String rawState) {
        try {
            String idPart = rawState;
            String propertiesPart = null;
            int bracketIndex = rawState.indexOf('[');
            if (bracketIndex >= 0) {
                idPart = rawState.substring(0, bracketIndex);
                propertiesPart = rawState.substring(bracketIndex + 1, rawState.length() - 1);
            }

            class_2960 id = class_2960.method_60654(idPart);
            if (!class_7923.field_41175.method_10250(id)) {
                throw new IllegalArgumentException("Bloque desconocido: " + idPart);
            }

            class_2248 block = class_7923.field_41175.method_10223(id);
            class_2680 state = block.method_9564();
            if (propertiesPart == null || propertiesPart.isBlank()) {
                return state;
            }

            for (String assignment : propertiesPart.split(",")) {
                int equals = assignment.indexOf('=');
                if (equals < 1 || equals == assignment.length() - 1) {
                    throw new IllegalArgumentException("Propiedad invalida: " + assignment);
                }
                String propertyName = assignment.substring(0, equals);
                String propertyValue = assignment.substring(equals + 1);
                class_2769<?> property = findProperty(state, propertyName);
                if (property == null) {
                    throw new IllegalArgumentException("Propiedad " + propertyName + " no existe en " + idPart);
                }
                state = withParsedProperty(state, property, propertyValue);
            }
            return state;
        } catch (RuntimeException e) {
            if (rawState.equals("minecraft:air")) {
                return class_2246.field_10124.method_9564();
            }
            throw e;
        }
    }

    private static class_2769<?> findProperty(class_2680 state, String name) {
        for (class_2769<?> property : state.method_28501()) {
            if (property.method_11899().equals(name)) {
                return property;
            }
        }
        return null;
    }

    private static <T extends Comparable<T>> class_2680 withParsedProperty(
            class_2680 state,
            class_2769<T> property,
            String value
    ) {
        Optional<T> parsed = property.method_11900(value);
        if (parsed.isEmpty()) {
            throw new IllegalArgumentException("Valor invalido " + value + " para " + property.method_11899());
        }
        return state.method_11657(property, parsed.get());
    }

    private static class_2382 readOffset(Object value) throws IOException {
        if (value instanceof int[] array && array.length >= 3) {
            return new class_2382(array[0], array[1], array[2]);
        }
        if (value instanceof List<?> list && list.size() >= 3) {
            return new class_2382(intValue(list.get(0), "Offset[0]"), intValue(list.get(1), "Offset[1]"), intValue(list.get(2), "Offset[2]"));
        }
        throw new IOException("Schematic.Offset no es un int array valido");
    }

    private static int[] decodeVarInts(byte[] data, int expectedEntries) throws IOException {
        int[] values = new int[expectedEntries];
        int dataIndex = 0;
        int valueIndex = 0;

        while (dataIndex < data.length && valueIndex < expectedEntries) {
            int value = 0;
            int shift = 0;
            while (true) {
                if (dataIndex >= data.length) {
                    throw new IOException("VarInt incompleto en Blocks.Data");
                }
                int currentByte = data[dataIndex++] & 0xFF;
                value |= (currentByte & 0x7F) << shift;
                if ((currentByte & 0x80) == 0) {
                    break;
                }
                shift += 7;
                if (shift > 35) {
                    throw new IOException("VarInt demasiado largo en Blocks.Data");
                }
            }
            values[valueIndex++] = value;
        }

        if (valueIndex != expectedEntries) {
            throw new IOException("Blocks.Data decodifico " + valueIndex + " entradas; se esperaban " + expectedEntries);
        }
        return values;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> compound(Object value, String name) throws IOException {
        if (value instanceof Map<?, ?> map) {
            return (Map<String, Object>) map;
        }
        throw new IOException(name + " no es compound NBT");
    }

    private static byte[] byteArray(Object value, String name) throws IOException {
        if (value instanceof byte[] bytes) {
            return bytes;
        }
        throw new IOException(name + " no es byte array NBT");
    }

    private static int intValue(Object value, String name) throws IOException {
        if (value instanceof Number number) {
            return number.intValue();
        }
        throw new IOException(name + " no es un numero NBT");
    }
}
