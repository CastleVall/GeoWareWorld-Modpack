package com.zjuqni.hexatowerdefense.mixin;

import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1263.class)
public interface InventoryMaxCountMixin {
    @Inject(method = "getMaxCount(Lnet/minecraft/item/ItemStack;)I", at = @At("HEAD"), cancellable = true)
    private void hexatowerdefense$energyCellInventoryMaxCount(class_1799 stack, CallbackInfoReturnable<Integer> cir) {
        if (!stack.method_7960() && class_7923.field_41178.method_10221(stack.method_7909()).equals(class_2960.method_60655("hexatowerdefense", "energy_cell"))) {
            cir.setReturnValue(99);
        }
    }
}
