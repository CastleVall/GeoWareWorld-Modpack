package com.zjuqni.hexatowerdefense.mixin;

import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1799.class)
public abstract class ItemStackMaxCountMixin {
    private static final class_2960 ENERGY_CELL_ID = class_2960.method_60655("hexatowerdefense", "energy_cell");

    @Inject(method = "getMaxCount", at = @At("HEAD"), cancellable = true)
    private void hexatowerdefense$energyCellMaxCount(CallbackInfoReturnable<Integer> cir) {
        class_1799 stack = (class_1799) (Object) this;
        if (class_7923.field_41178.method_10221(stack.method_7909()).equals(ENERGY_CELL_ID)) {
            cir.setReturnValue(99);
        }
    }
}
