package com.zjuqni.hexatowerdefense.wave;

public final class ScheduledSpawn {
}
