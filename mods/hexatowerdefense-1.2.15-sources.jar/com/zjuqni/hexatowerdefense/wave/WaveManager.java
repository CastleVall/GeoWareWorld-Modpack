package com.zjuqni.hexatowerdefense.wave;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import com.zjuqni.hexatowerdefense.arena.ArenaInstance;
import com.zjuqni.hexatowerdefense.arena.ArenaState;
import com.zjuqni.hexatowerdefense.config.ConfigManager;
import com.zjuqni.hexatowerdefense.enemy.EnemyType;
import com.zjuqni.hexatowerdefense.enemy.HTDEnemyEntity;
import com.zjuqni.hexatowerdefense.util.HTDText;
import java.util.List;
import net.minecraft.class_3222;

public final class WaveManager {
    public static final int FIRST_SPAWN_WARMUP_TICKS = 100;
    private static final int ROTATION_GOLEM_START_SECOND = 900;

    private final ArenaInstance arena;
    private boolean running;
    private int runningTicks;
    private int nextLane;
    private int bossesSpawned;

    public WaveManager(ArenaInstance arena) {
        this.arena = arena;
    }

    public void start() {
        running = true;
        runningTicks = 0;
        nextLane = 0;
        bossesSpawned = 0;
        if (ConfigManager.general().debug) {
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] WaveManager started for arena {}", arena.arenaId());
        }
    }

    public void stop() {
        running = false;
        runningTicks = 0;
        nextLane = 0;
        bossesSpawned = 0;
    }

    public void tick() {
        if (!running || arena.state() != ArenaState.RUNNING || arena.referenceLayout() == null || arena.referenceLayout().lanes.isEmpty()) {
            return;
        }
        runningTicks++;
        int seconds = runningTicks / 20;
        if (runningTicks % 20 == 0) {
            arena.updateLaneUnlocks(seconds);
        }
        int interval = spawnIntervalTicks(seconds);
        if (runningTicks >= FIRST_SPAWN_WARMUP_TICKS && (runningTicks - FIRST_SPAWN_WARMUP_TICKS) % interval == 0 && !isEnemyCapReached()) {
            List<Integer> activeLanes = arena.activeLaneIds();
            if (activeLanes.isEmpty()) {
                HexaTowerDefenseMod.LOGGER.warn("[HexaTowerDefense] WaveManager arena {} has no active lanes", arena.arenaId());
                return;
            }
            int amount = spawnAmount(seconds);
            for (int i = 0; i < amount; i++) {
                int lane = activeLanes.get(nextLane % activeLanes.size());
                EnemyType enemyType = enemyTypeForSpawn(seconds, nextLane);
                nextLane++;
                HTDEnemyEntity spawned = arena.enemyManager().spawnEnemy(enemyType, lane, i * 0.25D);
                if (spawned != null && enemyType == EnemyType.LAVA_GOLEM) {
                    spawned.setBossBarEnabled(false);
                }
            }
        }
        if (seconds >= nextBossSecond() && seconds < ROTATION_GOLEM_START_SECOND && runningTicks % 20 == 0) {
            trySpawnBoss();
        }
    }

    private boolean isEnemyCapReached() {
        int cap = Math.max(10, ConfigManager.general().maxLiveEnemiesPerArena);
        return arena.enemyManager().liveCount() >= cap;
    }

    private int nextBossSecond() {
        int firstBoss = Math.max(30, ConfigManager.general().bossSpawnSecond);
        int repeat = Math.max(30, ConfigManager.general().bossRepeatSeconds);
        return firstBoss + bossesSpawned * repeat;
    }

    private void trySpawnBoss() {
        List<Integer> activeLanes = arena.referenceLayout().activeLaneIds(arena.lockedLanesUnlocked());
        if (activeLanes.isEmpty()) {
            return;
        }
        int lane = activeLanes.get(nextLane % activeLanes.size());
        nextLane++;
        HTDEnemyEntity boss = arena.enemyManager().spawnEnemy(EnemyType.LAVA_GOLEM, lane, 0.0D);
        if (boss == null) {
            HexaTowerDefenseMod.LOGGER.warn("[HexaTowerDefense] Boss spawn failed in arena {}, retrying", arena.arenaId());
            return;
        }
        bossesSpawned++;
        HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] Boss Lava Golem #{} spawned in arena {} lane {}", bossesSpawned, arena.arenaId(), lane);
        String message = bossesSpawned == 1
                ? "¡Apareció el Gólem de Lava! Defiende el núcleo."
                : "¡Apareció otro Gólem de Lava! (boss #" + bossesSpawned + ")";
        for (class_3222 player : arena.getPlayers()) {
            HTDText.sendWarning(player, message, false);
        }
    }

    public boolean isRunning() {
        return running;
    }

    public int runningTicks() {
        return runningTicks;
    }

    public String nextWaveInfo() {
        if (!running) {
            return "stopped";
        }
        int seconds = runningTicks / 20;
        int interval = spawnIntervalTicks(seconds);
        int ticks = runningTicks < FIRST_SPAWN_WARMUP_TICKS
                ? FIRST_SPAWN_WARMUP_TICKS - runningTicks
                : interval - ((runningTicks - FIRST_SPAWN_WARMUP_TICKS) % interval);
        return "next " + enemyTypeForSpawn(seconds, nextLane).name().toLowerCase() + " in " + ticks + " ticks"
                + " | boss #" + (bossesSpawned + 1) + " at " + nextBossSecond() + "s";
    }

    private static int spawnIntervalTicks(int seconds) {
        if (seconds >= 600) {
            return 100;
        }
        if (seconds >= 300) {
            return 120;
        }
        return 150;
    }

    private static int spawnAmount(int seconds) {
        return seconds >= 600 ? 2 : 1;
    }

    private static EnemyType enemyTypeForSpawn(int seconds, int spawnIndex) {
        int minute = seconds / 60;
        if (minute >= 15) {
            if (spawnIndex % 4 == 0) {
                return EnemyType.LAVA_GOLEM;
            }
            return spawnIndex % 5 == 4 ? EnemyType.PURPLE_MINION : EnemyType.PURPLE_KNIGHT_MINION;
        }
        if (minute >= 14) {
            return spawnIndex % 5 == 4 ? EnemyType.PURPLE_MINION : EnemyType.PURPLE_KNIGHT_MINION;
        }
        if (minute >= 12) {
            if (spawnIndex % 2 == 0) {
                return EnemyType.PURPLE_MINION;
            }
            return spawnIndex % 4 == 1 ? EnemyType.BLUE_KNIGHT_MINION : EnemyType.BLUE_MINION;
        }
        if (minute >= 11) {
            if (spawnIndex % 3 == 0) {
                return EnemyType.PURPLE_MINION;
            }
            return spawnIndex % 4 == 1 ? EnemyType.BLUE_KNIGHT_MINION : EnemyType.BLUE_MINION;
        }
        if (minute >= 9) {
            return spawnIndex % 4 == 0 ? EnemyType.BLUE_KNIGHT_MINION : EnemyType.BLUE_MINION;
        }
        if (minute >= 7) {
            return spawnIndex % 2 == 0 ? EnemyType.GREEN_KNIGHT_MINION : EnemyType.BLUE_MINION;
        }
        if (minute >= 6) {
            return spawnIndex % 4 == 0 ? EnemyType.GREEN_KNIGHT_MINION : EnemyType.BLUE_MINION;
        }
        if (minute >= 4) {
            return spawnIndex % 5 < 3 ? EnemyType.BLUE_MINION : EnemyType.GREEN_MINION;
        }
        if (minute >= 3) {
            return spawnIndex % 5 < 2 ? EnemyType.BLUE_MINION : EnemyType.GREEN_MINION;
        }
        if (minute >= 2) {
            return spawnIndex % 5 == 0 ? EnemyType.BLUE_MINION : EnemyType.GREEN_MINION;
        }
        return EnemyType.GREEN_MINION;
    }
}
