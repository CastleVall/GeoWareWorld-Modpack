package com.zjuqni.hexatowerdefense.economy;

public final class EconomyManager {
    private int energy;

    public EconomyManager(int startingEnergy) {
        this.energy = Math.max(0, startingEnergy);
    }

    public int energy() {
        return energy;
    }

    public void reset(int startingEnergy) {
        this.energy = Math.max(0, startingEnergy);
    }

    public void addEnergy(int amount) {
        if (amount > 0) {
            energy += amount;
        }
    }

    public boolean hasEnergy(int amount) {
        return amount <= 0 || energy >= amount;
    }

    public boolean removeEnergy(int amount) {
        if (!hasEnergy(amount)) {
            return false;
        }
        energy -= Math.max(0, amount);
        return true;
    }
}
