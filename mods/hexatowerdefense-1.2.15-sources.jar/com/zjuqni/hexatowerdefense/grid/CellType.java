package com.zjuqni.hexatowerdefense.grid;

public enum CellType {
    PLACEABLE,
    PATH,
    BLOCKED,
    CORE,
    SHOP,
    DECORATION
}
