package com.zjuqni.hexatowerdefense.grid;

import java.util.UUID;
import net.minecraft.class_2338;
import net.minecraft.class_238;

public final class GridCell {
    public int row;
    public int column;
    public int laneId;
    public class_2338 center;
    public class_238 bounds;
    public CellType type = CellType.PLACEABLE;
    public boolean occupied;
    public UUID towerUuid;
}
