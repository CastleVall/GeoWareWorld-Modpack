package com.zjuqni.hexatowerdefense.item;

import net.minecraft.class_1792;
import net.minecraft.class_1799;

public final class EnergyCellItem extends class_1792 {
    public EnergyCellItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return true;
    }
}
