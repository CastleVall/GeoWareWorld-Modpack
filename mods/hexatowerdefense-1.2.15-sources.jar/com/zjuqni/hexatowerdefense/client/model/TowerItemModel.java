package com.zjuqni.hexatowerdefense.client.model;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import com.zjuqni.hexatowerdefense.tower.TowerPlacementItem;
import com.zjuqni.hexatowerdefense.tower.TowerType;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

public final class TowerItemModel extends GeoModel<TowerPlacementItem> {
    @Override
    public class_2960 getModelResource(TowerPlacementItem item) {
        return HexaTowerDefenseMod.id("geo/towers/" + path(item.towerType()) + ".geo.json");
    }

    @Override
    public class_2960 getTextureResource(TowerPlacementItem item) {
        return HexaTowerDefenseMod.id("textures/entity/towers/" + path(item.towerType()) + "_green.png");
    }

    @Override
    public class_2960 getAnimationResource(TowerPlacementItem item) {
        return HexaTowerDefenseMod.id("animations/towers/" + path(item.towerType()) + ".animation.json");
    }

    private static String path(TowerType type) {
        return switch (type) {
            case PANEL_SOLAR -> "panel_solar";
            case TURRET -> "turret";
            case CROSSBOW_TOWER -> "crossbow_tower";
            case CANNON -> "cannon";
            case HOLOGRAPHIC_SHIELD -> "holographic_shield";
            case ION_BATTERY -> "ion_battery";
            case TESLA_TOWER -> "tesla_tower";
        };
    }
}
