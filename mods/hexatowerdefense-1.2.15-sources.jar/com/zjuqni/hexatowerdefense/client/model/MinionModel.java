package com.zjuqni.hexatowerdefense.client.model;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import com.zjuqni.hexatowerdefense.enemy.HTDEnemyEntity;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

public final class MinionModel extends GeoModel<HTDEnemyEntity> {
    @Override
    public class_2960 getModelResource(HTDEnemyEntity enemy) {
        return HexaTowerDefenseMod.id("geo/enemies/minion.geo.json");
    }

    @Override
    public class_2960 getTextureResource(HTDEnemyEntity enemy) {
        return switch (enemy.enemyType()) {
            case GREEN_MINION -> HexaTowerDefenseMod.id("textures/entity/enemies/minion_green.png");
            case BLUE_MINION -> HexaTowerDefenseMod.id("textures/entity/enemies/minion_blue.png");
            case PURPLE_MINION -> HexaTowerDefenseMod.id("textures/entity/enemies/minion_purple.png");
            default -> HexaTowerDefenseMod.id("textures/entity/enemies/minion_green.png");
        };
    }

    @Override
    public class_2960 getAnimationResource(HTDEnemyEntity enemy) {
        return HexaTowerDefenseMod.id("animations/enemies/minion.animation.json");
    }
}
