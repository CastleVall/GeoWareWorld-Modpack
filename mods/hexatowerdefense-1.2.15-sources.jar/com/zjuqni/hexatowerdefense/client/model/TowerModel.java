package com.zjuqni.hexatowerdefense.client.model;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import com.zjuqni.hexatowerdefense.tower.HTDTowerEntity;
import com.zjuqni.hexatowerdefense.tower.TextureVariant;
import com.zjuqni.hexatowerdefense.tower.TowerType;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

public class TowerModel extends GeoModel<HTDTowerEntity> {
    @Override
    public class_2960 getModelResource(HTDTowerEntity tower) {
        return HexaTowerDefenseMod.id("geo/towers/" + path(tower.towerType()) + ".geo.json");
    }

    @Override
    public class_2960 getTextureResource(HTDTowerEntity tower) {
        return HexaTowerDefenseMod.id("textures/entity/towers/" + path(tower.towerType()) + "_" + variant(tower.textureVariant()) + ".png");
    }

    @Override
    public class_2960 getAnimationResource(HTDTowerEntity tower) {
        return HexaTowerDefenseMod.id("animations/towers/" + path(tower.towerType()) + ".animation.json");
    }

    private static String path(TowerType type) {
        return switch (type) {
            case PANEL_SOLAR -> "panel_solar";
            case TURRET -> "turret";
            case CROSSBOW_TOWER -> "crossbow_tower";
            case CANNON -> "cannon";
            case HOLOGRAPHIC_SHIELD -> "holographic_shield";
            case ION_BATTERY -> "ion_battery";
            case TESLA_TOWER -> "tesla_tower";
        };
    }

    private static String variant(TextureVariant variant) {
        return switch (variant) {
            case GREEN -> "green";
            case BLUE -> "blue";
            case PURPLE -> "purple";
        };
    }
}
