package com.zjuqni.hexatowerdefense.client.model;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import com.zjuqni.hexatowerdefense.enemy.HTDEnemyEntity;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

public final class LavaGolemModel extends GeoModel<HTDEnemyEntity> {
    @Override
    public class_2960 getModelResource(HTDEnemyEntity enemy) {
        return HexaTowerDefenseMod.id("geo/enemies/lava_golem.geo.json");
    }

    @Override
    public class_2960 getTextureResource(HTDEnemyEntity enemy) {
        return HexaTowerDefenseMod.id("textures/entity/enemies/lava_golem.png");
    }

    @Override
    public class_2960 getAnimationResource(HTDEnemyEntity enemy) {
        return HexaTowerDefenseMod.id("animations/enemies/lava_golem.animation.json");
    }
}
