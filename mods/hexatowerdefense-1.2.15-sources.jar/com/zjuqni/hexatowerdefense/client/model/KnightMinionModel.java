package com.zjuqni.hexatowerdefense.client.model;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import com.zjuqni.hexatowerdefense.enemy.HTDEnemyEntity;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

public final class KnightMinionModel extends GeoModel<HTDEnemyEntity> {
    @Override
    public class_2960 getModelResource(HTDEnemyEntity enemy) {
        return HexaTowerDefenseMod.id("geo/enemies/knight_minion.geo.json");
    }

    @Override
    public class_2960 getTextureResource(HTDEnemyEntity enemy) {
        return switch (enemy.enemyType()) {
            case BLUE_KNIGHT_MINION -> HexaTowerDefenseMod.id("textures/entity/enemies/knight_minion_blue.png");
            case PURPLE_KNIGHT_MINION -> HexaTowerDefenseMod.id("textures/entity/enemies/knight_minion_purple.png");
            default -> HexaTowerDefenseMod.id("textures/entity/enemies/knight_minion_green.png");
        };
    }

    @Override
    public class_2960 getAnimationResource(HTDEnemyEntity enemy) {
        return HexaTowerDefenseMod.id("animations/enemies/knight_minion.animation.json");
    }
}
