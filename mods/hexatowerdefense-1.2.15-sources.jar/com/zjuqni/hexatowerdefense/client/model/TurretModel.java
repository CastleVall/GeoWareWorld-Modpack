package com.zjuqni.hexatowerdefense.client.model;

public final class TurretModel {
}
