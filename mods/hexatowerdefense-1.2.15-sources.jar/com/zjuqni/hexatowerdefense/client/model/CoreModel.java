package com.zjuqni.hexatowerdefense.client.model;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import com.zjuqni.hexatowerdefense.core.CoreEntity;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

public final class CoreModel extends GeoModel<CoreEntity> {
    @Override
    public class_2960 getModelResource(CoreEntity animatable) {
        return HexaTowerDefenseMod.id("geo/core/geothermal_core.geo.json");
    }

    @Override
    public class_2960 getTextureResource(CoreEntity animatable) {
        return HexaTowerDefenseMod.id("textures/entity/core/geothermal_core.png");
    }

    @Override
    public class_2960 getAnimationResource(CoreEntity animatable) {
        return HexaTowerDefenseMod.id("animations/core/geothermal_core.animation.json");
    }
}
