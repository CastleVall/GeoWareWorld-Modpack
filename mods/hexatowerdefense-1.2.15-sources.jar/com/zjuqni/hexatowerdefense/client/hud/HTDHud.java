package com.zjuqni.hexatowerdefense.client.hud;

import com.zjuqni.hexatowerdefense.core.CoreEntity;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_238;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_898;

public final class HTDHud {
    private HTDHud() {
    }

    public static void init() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> renderCoreHud(context));
    }

    private static void renderCoreHud(class_332 context) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null || client.field_1690.field_1842) {
            return;
        }

        CoreEntity core = nearestCore(client);
        if (core == null || !core.hudVisible() || core.maxHealth() <= 0) {
            return;
        }

        int width = 220;
        int height = 50;
        int x = context.method_51421() - width - 12;
        int y = 12;
        int health = Math.max(0, Math.min(core.maxHealth(), core.health()));
        float percent = health / (float) core.maxHealth();

        context.method_25294(x, y, x + width, y + height, 0xC80B0705);
        context.method_25294(x + 1, y + 1, x + width - 1, y + 2, 0xFFFF6A00);
        context.method_25294(x + 1, y + height - 2, x + width - 1, y + height - 1, 0xFF5B1A00);
        context.method_25294(x + 1, y + 1, x + 2, y + height - 1, 0xFFB83A00);
        context.method_25294(x + width - 2, y + 1, x + width - 1, y + height - 1, 0xFFB83A00);

        renderCoreModel(context, client, core, x + 22, y + 37, 2.6F);
        context.method_51433(client.field_1772, "Nucleo Geotermico", x + 42, y + 7, 0xFFFFD47A, false);
        String value = health + "/" + core.maxHealth();
        context.method_51433(client.field_1772, value, x + width - 10 - client.field_1772.method_1727(value), y + 7, 0xFF00D9FF, false);

        int barX = x + 42;
        int barY = y + 27;
        int barW = width - 56;
        int barH = 14;
        context.method_25294(barX - 2, barY - 2, barX + barW + 2, barY + barH + 2, 0xFF050505);
        context.method_25294(barX, barY, barX + barW, barY + barH, 0xFF1B1B1B);
        int fill = Math.max(0, Math.round((barW - 2) * percent));
        context.method_25294(barX + 1, barY + 1, barX + 1 + fill, barY + barH - 1, 0xFFFF6A00);
        context.method_25294(barX + 2, barY + 1, barX + Math.max(2, fill - 2), barY + 3, 0xFFFFC400);
    }

    private static void renderCoreModel(class_332 context, class_310 client, CoreEntity core, int x, int y, float scale) {
        class_898 dispatcher = client.method_1561();
        context.method_51448().method_22903();
        context.method_51448().method_46416(x, y, 120.0F);
        context.method_51448().method_22905(scale, scale, -scale);
        context.method_51448().method_22907(class_7833.field_40718.rotationDegrees(180.0F));
        context.method_51448().method_22907(class_7833.field_40714.rotationDegrees(8.0F));
        context.method_51448().method_22907(class_7833.field_40716.rotationDegrees(14.0F));
        boolean shadows = dispatcher.field_4692 != null && dispatcher.field_4692.method_31044().method_31034();
        dispatcher.method_3948(false);
        dispatcher.method_3954(core, 0.0D, 0.0D, 0.0D, 180.0F, 1.0F,
                context.method_51448(), context.method_51450(), class_765.field_32767);
        dispatcher.method_3948(shadows);
        context.method_51452();
        context.method_51448().method_22909();
    }

    private static CoreEntity nearestCore(class_310 client) {
        class_238 search = client.field_1724.method_5829().method_1014(512.0D);
        CoreEntity nearest = null;
        double nearestDistance = Double.MAX_VALUE;
        for (CoreEntity core : client.field_1687.method_8390(CoreEntity.class, search, entity -> !entity.method_31481())) {
            double distance = core.method_5858(client.field_1724);
            if (distance < nearestDistance) {
                nearestDistance = distance;
                nearest = core;
            }
        }
        return nearest;
    }
}
