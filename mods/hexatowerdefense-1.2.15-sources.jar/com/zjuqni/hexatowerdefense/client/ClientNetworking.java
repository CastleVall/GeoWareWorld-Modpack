package com.zjuqni.hexatowerdefense.client;

import com.zjuqni.hexatowerdefense.client.gui.HexaTowerShopScreen;
import com.zjuqni.hexatowerdefense.network.OpenShopS2CPayload;
import com.zjuqni.hexatowerdefense.network.ShopEnergyS2CPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_2561;

public final class ClientNetworking {
    private ClientNetworking() {
    }

    public static void init() {
        ClientPlayNetworking.registerGlobalReceiver(OpenShopS2CPayload.ID, (payload, context) ->
                context.client().execute(() -> context.client().method_1507(new HexaTowerShopScreen(payload.energy()))));

        ClientPlayNetworking.registerGlobalReceiver(ShopEnergyS2CPayload.ID, (payload, context) ->
                context.client().execute(() -> {
                    if (context.client().field_1755 instanceof HexaTowerShopScreen screen) {
                        screen.updateEnergy(payload.energy(), payload.success(), payload.message());
                    }
                    if (context.client().field_1724 != null && payload.message() != null && !payload.message().isBlank()) {
                        context.client().field_1724.method_7353(
                                class_2561.method_43470("")
                                        .method_10852(class_2561.method_43470("[Celula] ").method_27695(class_124.field_1075, class_124.field_1067))
                                        .method_10852(class_2561.method_43470("ENERGIA ").method_27695(class_124.field_1075, class_124.field_1067))
                                        .method_10852(class_2561.method_43470(payload.message()).method_27692(payload.success() ? class_124.field_1065 : class_124.field_1061)),
                                false
                        );
                    }
                }));
    }
}
