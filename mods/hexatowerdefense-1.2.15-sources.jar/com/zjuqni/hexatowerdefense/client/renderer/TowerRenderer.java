package com.zjuqni.hexatowerdefense.client.renderer;

import com.zjuqni.hexatowerdefense.client.model.TowerModel;
import com.zjuqni.hexatowerdefense.tower.HTDTowerEntity;
import com.zjuqni.hexatowerdefense.tower.TextureVariant;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public final class TowerRenderer extends GeoEntityRenderer<HTDTowerEntity> {
    public TowerRenderer(class_5617.class_5618 context) {
        super(context, new TowerModel());
        this.field_4673 = 0.35F;
    }

    @Override
    public boolean hasLabel(HTDTowerEntity entity) {
        return false;
    }

    @Override
    public void render(HTDTowerEntity entity, float entityYaw, float partialTick, class_4587 poseStack,
                       class_4597 bufferSource, int packedLight) {
        super.method_3936(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
        renderHealthBar(entity, poseStack, bufferSource, partialTick);
    }

    @Override
    public void preRender(class_4587 poseStack, HTDTowerEntity animatable, BakedGeoModel model,
                          @Nullable class_4597 bufferSource, @Nullable class_4588 buffer,
                          boolean isReRender, float partialTick, int packedLight, int packedOverlay, int colour) {
        super.preRender(poseStack, animatable, model, bufferSource, buffer, isReRender, partialTick, packedLight, packedOverlay, colour);
        TowerRenderOffset.Offset offset = TowerRenderOffset.forPlacedEntity(animatable.towerType(), animatable.method_36454());
        poseStack.method_46416(offset.x(), offset.y(), offset.z());
    }

    private void renderHealthBar(HTDTowerEntity entity, class_4587 matrices, class_4597 consumers, float tickDelta) {
        if (entity.method_31481() || entity.maxHealth() <= 0) {
            return;
        }
        FloatingHealthBarRenderer.render(matrices, consumers, this.field_4676,
                healthBarYOffset(entity),
                entity.health(), entity.maxHealth(), 0.023F, false, healthColor(entity.textureVariant()));
    }

    private static int healthColor(TextureVariant variant) {
        return switch (variant) {
            case GREEN -> 0xFF43D94F;
            case BLUE -> 0xFF2CA8FF;
            case PURPLE -> 0xFFB84CFF;
        };
    }

    private static double healthBarYOffset(HTDTowerEntity entity) {
        return switch (entity.towerType()) {
            case PANEL_SOLAR -> 1.5D;
            case TURRET -> 1.25D;
            case CROSSBOW_TOWER -> 1.42D;
            case CANNON -> 1.55D;
            case HOLOGRAPHIC_SHIELD -> 1.72D;
            case ION_BATTERY -> 1.55D;
            case TESLA_TOWER -> 3.2D;
        };
    }
}
