package com.zjuqni.hexatowerdefense.client.renderer;

import com.zjuqni.hexatowerdefense.client.model.CoreModel;
import com.zjuqni.hexatowerdefense.core.CoreEntity;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public final class CoreRenderer extends GeoEntityRenderer<CoreEntity> {
    public CoreRenderer(class_5617.class_5618 context) {
        super(context, new CoreModel());
        this.field_4673 = 0.55F;
    }

    @Override
    public boolean hasLabel(CoreEntity entity) {
        return false;
    }

    @Override
    public void render(CoreEntity entity, float entityYaw, float partialTick, class_4587 poseStack,
                       class_4597 bufferSource, int packedLight) {
        poseStack.method_22903();
        poseStack.method_22905(2.2F, 2.2F, 2.2F);
        super.method_3936(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
        poseStack.method_22909();
    }
}
