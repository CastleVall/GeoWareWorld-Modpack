package com.zjuqni.hexatowerdefense.client.renderer;

import com.zjuqni.hexatowerdefense.client.model.KnightMinionModel;
import com.zjuqni.hexatowerdefense.enemy.HTDEnemyEntity;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public final class KnightMinionRenderer extends GeoEntityRenderer<HTDEnemyEntity> {
    public KnightMinionRenderer(class_5617.class_5618 context) {
        super(context, new KnightMinionModel());
        this.field_4673 = 0.55F;
    }

    @Override
    public boolean hasLabel(HTDEnemyEntity entity) {
        return false;
    }

    @Override
    public void render(HTDEnemyEntity entity, float entityYaw, float partialTick, class_4587 poseStack,
                       class_4597 bufferSource, int packedLight) {
        super.method_3936(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
        FloatingHealthBarRenderer.render(poseStack, bufferSource, this.field_4676,
                entity.method_5829().method_17940() + 0.26D,
                Math.round(entity.method_6032()), Math.round(entity.method_6063()), 0.025F, entity.isShinyMob());
    }
}
