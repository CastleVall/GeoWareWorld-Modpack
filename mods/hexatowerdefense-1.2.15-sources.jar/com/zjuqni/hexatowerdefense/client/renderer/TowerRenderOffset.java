package com.zjuqni.hexatowerdefense.client.renderer;

import com.zjuqni.hexatowerdefense.tower.TowerType;

final class TowerRenderOffset {
    private TowerRenderOffset() {
    }

    static Offset forType(TowerType type) {
        return switch (type) {
            case PANEL_SOLAR -> new Offset(0.65625F, 0.0F, -0.4375F);
            case TURRET -> new Offset(0.46875F, 0.0F, 0.28125F);
            case CROSSBOW_TOWER -> new Offset(0.5F, 0.0F, -0.484375F);
            case CANNON -> new Offset(0.5F, 0.0F, 0.4375F);
            case HOLOGRAPHIC_SHIELD -> new Offset(0.5F, 0.0F, -0.1796875F);
            case ION_BATTERY -> new Offset(0.5F, 0.0F, -0.5F);
            case TESLA_TOWER -> new Offset(0.5F, 0.0F, -0.6875F);
        };
    }

    static ItemDisplay forInventoryItem(TowerType type) {
        // Values are based on the exported geo bounds. Long barrels need less
        // scale, while tall towers need a lower Y anchor to stay inside slots.
        return switch (type) {
            case PANEL_SOLAR -> new ItemDisplay(1.95F, -0.10F, 0.0F, 0.78F);
            case TURRET -> new ItemDisplay(1.52F, -0.13F, 0.0F, 0.66F);
            case CROSSBOW_TOWER -> new ItemDisplay(1.98F, -0.17F, 0.0F, 0.68F);
            case CANNON -> new ItemDisplay(1.38F, -0.16F, 0.0F, 0.63F);
            case HOLOGRAPHIC_SHIELD -> new ItemDisplay(1.86F, -0.46F, 0.0F, 0.62F);
            case ION_BATTERY -> new ItemDisplay(1.99F, -0.11F, 0.0F, 0.73F);
            case TESLA_TOWER -> new ItemDisplay(2.03F, -0.47F, 0.0F, 0.50F);
        };
    }

    static Offset forPlacedEntity(TowerType type, float entityYaw) {
        // The exported Blockbench tower bases are centered half a block away from
        // the entity origin. Keep this correction stable so the entity can sit on
        // the diamond anchor without drifting when attack state or yaw changes.
        if (type == TowerType.PANEL_SOLAR) {
            return new Offset(-0.5F, -0.08F, 0.42F);
        }
        return new Offset(-0.5F, -0.08F, 0.30F);
    }

    record Offset(float x, float y, float z) {
    }

    record ItemDisplay(float x, float y, float z, float scale) {
    }
}
