package com.zjuqni.hexatowerdefense.client.renderer;

import com.zjuqni.hexatowerdefense.client.model.MinionModel;
import com.zjuqni.hexatowerdefense.enemy.HTDEnemyEntity;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public final class MinionRenderer extends GeoEntityRenderer<HTDEnemyEntity> {
    public MinionRenderer(class_5617.class_5618 context) {
        super(context, new MinionModel());
        this.field_4673 = 0.45F;
    }

    @Override
    public boolean hasLabel(HTDEnemyEntity entity) {
        return false;
    }

    @Override
    public void render(HTDEnemyEntity entity, float entityYaw, float partialTick, class_4587 poseStack,
                       class_4597 bufferSource, int packedLight) {
        super.method_3936(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
        renderHealthBar(entity, poseStack, bufferSource, partialTick);
    }

    private void renderHealthBar(HTDEnemyEntity entity, class_4587 matrices, class_4597 consumers, float tickDelta) {
        if (entity.method_31481() || !entity.method_5805() || entity.method_6063() <= 0.0F) {
            return;
        }
        FloatingHealthBarRenderer.render(matrices, consumers, this.field_4676,
                entity.method_5829().method_17940() + 0.24D,
                Math.round(entity.method_6032()), Math.round(entity.method_6063()), 0.025F, entity.isShinyMob());
    }
}
