package com.zjuqni.hexatowerdefense.client.renderer;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_765;
import net.minecraft.class_898;
import org.joml.Matrix4f;

final class FloatingHealthBarRenderer {
    private static final class_2960 WHITE_PIXEL = HexaTowerDefenseMod.id("textures/gui/white_pixel.png");
    private static final int BLACK = 0xFF050505;
    private static final int SHADOW = 0xAA000000;
    private static final int HEART_DARK = 0xFF7A0618;
    private static final int HEART_RED = 0xFFFF3048;
    private static final int HEART_LIGHT = 0xFFFF8A98;
    private static final int HEART_GOLD_DARK = 0xFF9A5F00;
    private static final int HEART_GOLD = 0xFFFFC43B;
    private static final int HEART_GOLD_LIGHT = 0xFFFFF1A1;
    private static final int BAR_EMPTY = 0xFF1B1B1B;
    private static final int BAR_HIGHLIGHT = 0x99FFFFFF;
    private static final String[] HEART_PIXELS = {
            "0110110",
            "1111111",
            "1111111",
            "0111110",
            "0011100",
            "0001000"
    };

    private FloatingHealthBarRenderer() {
    }

    static void render(class_4587 matrices, class_4597 consumers, class_898 dispatcher,
                       double yOffset, int health, int maxHealth, float scale) {
        render(matrices, consumers, dispatcher, yOffset, health, maxHealth, scale, false);
    }

    static void render(class_4587 matrices, class_4597 consumers, class_898 dispatcher,
                       double yOffset, int health, int maxHealth, float scale, boolean goldenHeart) {
        int clampedHealth = Math.max(0, Math.min(maxHealth, health));
        float percent = maxHealth <= 0 ? 0.0F : clampedHealth / (float) maxHealth;
        int fillColor = percent > 0.55F ? 0xFF32B82E : percent > 0.25F ? 0xFFFFC43B : 0xFFFF3030;
        render(matrices, consumers, dispatcher, yOffset, health, maxHealth, scale, goldenHeart, fillColor);
    }

    static void render(class_4587 matrices, class_4597 consumers, class_898 dispatcher,
                       double yOffset, int health, int maxHealth, float scale, boolean goldenHeart, int fillColor) {
        if (maxHealth <= 0) {
            return;
        }
        int clampedHealth = Math.max(0, Math.min(maxHealth, health));
        float percent = clampedHealth / (float) maxHealth;

        matrices.method_22903();
        matrices.method_22904(0.0D, yOffset, 0.0D);
        matrices.method_22907(dispatcher.method_24197());
        matrices.method_22905(scale, -scale, scale);

        class_4588 consumer = consumers.getBuffer(class_1921.method_28116(WHITE_PIXEL));
        class_4587.class_4665 entry = matrices.method_23760();

        float barX = -22.0F;
        float barY = -5.0F;
        float barW = 70.0F;
        float barH = 10.0F;
        renderHeart(entry, consumer, -48.0F, -8.0F, 2.4F, goldenHeart);
        fill(entry, consumer, barX + 2.0F, barY + 2.0F, -0.04F, barW, barH, SHADOW);
        fill(entry, consumer, barX - 2.0F, barY - 2.0F, -0.03F, barW + 4.0F, barH + 4.0F, BLACK);
        fill(entry, consumer, barX, barY, -0.02F, barW, barH, BAR_EMPTY);
        float innerW = Math.max(0.0F, (barW - 4.0F) * percent);
        if (innerW > 0.0F) {
            fill(entry, consumer, barX + 2.0F, barY + 2.0F, -0.01F, innerW, barH - 4.0F, fillColor);
            fill(entry, consumer, barX + 3.0F, barY + 2.0F, 0.0F, Math.max(0.0F, innerW - 2.0F), 1.4F, BAR_HIGHLIGHT);
        }
        fill(entry, consumer, barX + barW - 2.0F, barY - 1.0F, 0.01F, 2.0F, barH + 2.0F, BLACK);

        matrices.method_22909();
    }

    private static void renderHeart(class_4587.class_4665 entry, class_4588 consumer, float x, float y, float pixel, boolean golden) {
        for (int row = 0; row < HEART_PIXELS.length; row++) {
            String line = HEART_PIXELS[row];
            for (int col = 0; col < line.length(); col++) {
                if (line.charAt(col) != '1') {
                    continue;
                }
                float px = x + col * pixel;
                float py = y + row * pixel;
                fill(entry, consumer, px - 0.8F, py - 0.8F, -0.03F, pixel + 1.6F, pixel + 1.6F, BLACK);
            }
        }
        for (int row = 0; row < HEART_PIXELS.length; row++) {
            String line = HEART_PIXELS[row];
            for (int col = 0; col < line.length(); col++) {
                if (line.charAt(col) != '1') {
                    continue;
                }
                int color = golden
                        ? row <= 1 && col <= 2 ? HEART_GOLD_LIGHT : row >= 4 ? HEART_GOLD_DARK : HEART_GOLD
                        : row <= 1 && col <= 2 ? HEART_LIGHT : row >= 4 ? HEART_DARK : HEART_RED;
                fill(entry, consumer, x + col * pixel, y + row * pixel, -0.01F, pixel, pixel, color);
            }
        }
    }

    private static void fill(class_4587.class_4665 entry, class_4588 consumer, float x, float y, float z,
                             float width, float height, int color) {
        if (width <= 0.0F || height <= 0.0F) {
            return;
        }
        Matrix4f matrix = entry.method_23761();
        int light = class_765.field_32767;
        float x1 = x;
        float y1 = y;
        float x2 = x + width;
        float y2 = y + height;
        vertex(entry, consumer, matrix, x1, y2, z, color, 0.0F, 1.0F, light);
        vertex(entry, consumer, matrix, x2, y2, z, color, 1.0F, 1.0F, light);
        vertex(entry, consumer, matrix, x2, y1, z, color, 1.0F, 0.0F, light);
        vertex(entry, consumer, matrix, x1, y1, z, color, 0.0F, 0.0F, light);
    }

    private static void vertex(class_4587.class_4665 entry, class_4588 consumer, Matrix4f matrix,
                               float x, float y, float z, int color, float u, float v, int light) {
        int a = color >>> 24 & 255;
        int r = color >>> 16 & 255;
        int g = color >>> 8 & 255;
        int b = color & 255;
        consumer.method_22918(matrix, x, y, z)
                .method_1336(r, g, b, a)
                .method_22913(u, v)
                .method_22922(class_4608.field_21444)
                .method_60803(light)
                .method_60831(entry, 0.0F, 0.0F, 1.0F);
    }
}
