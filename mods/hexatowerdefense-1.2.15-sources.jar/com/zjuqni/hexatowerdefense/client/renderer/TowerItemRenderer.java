package com.zjuqni.hexatowerdefense.client.renderer;

import com.zjuqni.hexatowerdefense.client.model.TowerItemModel;
import com.zjuqni.hexatowerdefense.tower.TowerPlacementItem;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoItemRenderer;

public final class TowerItemRenderer extends GeoItemRenderer<TowerPlacementItem> {
    public TowerItemRenderer() {
        super(new TowerItemModel());
        withScale(0.46F);
        useAlternateGuiLighting();
    }

    @Override
    public void preRender(class_4587 poseStack, TowerPlacementItem animatable, BakedGeoModel model,
                          @Nullable class_4597 bufferSource, @Nullable class_4588 buffer,
                          boolean isReRender, float partialTick, int packedLight, int packedOverlay, int colour) {
        super.preRender(poseStack, animatable, model, bufferSource, buffer, isReRender, partialTick, packedLight, packedOverlay, colour);

        poseStack.method_22907(class_7833.field_40716.rotationDegrees(-90.0F));
        TowerRenderOffset.Offset offset = TowerRenderOffset.forType(animatable.towerType());
        if (renderPerspective == class_811.field_4317) {
            TowerRenderOffset.ItemDisplay display = TowerRenderOffset.forInventoryItem(animatable.towerType());
            poseStack.method_46416(display.x(), display.y(), display.z());
            poseStack.method_46416(0.0F, 0.0F, -0.92F);
            poseStack.method_22905(display.scale(), display.scale(), display.scale());
            return;
        }
        if (renderPerspective == class_811.field_4322
                || renderPerspective == class_811.field_4321
                || renderPerspective == class_811.field_4320
                || renderPerspective == class_811.field_4323) {
            poseStack.method_46416(offset.x() * 0.7F + 0.34F, -0.14F, offset.z() * 0.7F);
            poseStack.method_22905(0.74F, 0.74F, 0.74F);
            return;
        }
        if (renderPerspective == class_811.field_4318) {
            poseStack.method_46416(offset.x() * 0.68F + 0.30F, -0.06F, offset.z() * 0.68F);
            poseStack.method_22905(0.72F, 0.72F, 0.72F);
        }
    }
}
