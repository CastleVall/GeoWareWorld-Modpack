package com.zjuqni.hexatowerdefense.client.gui;

import com.zjuqni.hexatowerdefense.network.BuyShopItemC2SPayload;
import com.zjuqni.hexatowerdefense.registry.ModItems;
import com.zjuqni.hexatowerdefense.shop.ShopEntry;
import com.zjuqni.hexatowerdefense.shop.ShopManager;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class HexaTowerShopScreen extends class_437 {
    private static final int BASE_W = 520;
    private static final int BASE_H = 288;

    private static final int SHADOW = 0x99000000;
    private static final int BG = 0xF2C7AE79;
    private static final int BG_DARK = 0xFFD0AD71;
    private static final int PANEL = 0xFFF1DBAA;
    private static final int PANEL_HOVER = 0xFFFFEDBE;
    private static final int PANEL_SELECTED = 0xFF98D36A;
    private static final int PANEL_DISABLED = 0xFFE2C894;
    private static final int BORDER = 0xFF3B2514;
    private static final int BORDER_SOFT = 0xFF7A532E;
    private static final int TEXT = 0xFF25170C;
    private static final int MUTED = 0xFF684A28;
    private static final int RED = 0xFFB52A2A;
    private static final int GREEN = 0xFF205F1D;
    private static final int BLUE = 0xFF0B6E82;
    private static final int WHITE = 0xFFFFFFFF;

    private static final int CAT_X = 18;
    private static final int CAT_Y = 72;
    private static final int CAT_W = 92;
    private static final int CAT_H = 36;
    private static final int CAT_GAP = 12;

    private static final int ROW_X = 126;
    private static final int ROW_Y = 66;
    private static final int ROW_W = 266;
    private static final int ROW_H = 35;
    private static final int ROW_GAP = 6;
    private static final int VISIBLE_ROWS = 5;

    private static final int DETAIL_X = 405;
    private static final int DETAIL_Y = 66;
    private static final int DETAIL_W = 96;
    private static final int DETAIL_H = 151;

    private final List<ShopEntry> entries = ShopManager.entries();
    private int energy;
    private ShopCategory category = ShopCategory.TOWERS;
    private ShopEntry selected;
    private int scrollOffset;
    private int guiX;
    private int guiY;
    private int guiW;
    private int guiH;
    private float scale;

    public HexaTowerShopScreen(int energy) {
        super(class_2561.method_43470("TowerDefense"));
        this.energy = energy;
        this.selected = firstEntry(category);
    }

    @Override
    protected void method_25426() {
        int maxW = Math.min(field_22789 - 24, BASE_W * 2);
        int maxH = Math.min(field_22790 - 24, BASE_H * 2);
        float aspect = BASE_W / (float) BASE_H;
        guiW = maxW;
        guiH = Math.round(guiW / aspect);
        if (guiH > maxH) {
            guiH = maxH;
            guiW = Math.round(guiH * aspect);
        }
        scale = guiW / (float) BASE_W;
        guiX = (field_22789 - guiW) / 2;
        guiY = (field_22790 - guiH) / 2;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, class_310.method_1551().method_22683().method_4486(),
                class_310.method_1551().method_22683().method_4502(), SHADOW);

        double bx = toBaseX(mouseX);
        double by = toBaseY(mouseY);

        drawFrame(context);
        drawHeader(context);
        drawCategories(context, bx, by);
        drawTradeRows(context, bx, by);
        drawDetail(context);
        drawButtons(context, bx, by);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button != 0) {
            return super.method_25402(mouseX, mouseY, button);
        }

        double bx = toBaseX(mouseX);
        double by = toBaseY(mouseY);

        for (ShopCategory value : ShopCategory.values()) {
            int y = CAT_Y + value.ordinal() * (CAT_H + CAT_GAP);
            if (contains(bx, by, CAT_X, y, CAT_W, CAT_H)) {
                category = value;
                scrollOffset = 0;
                selected = firstEntry(category);
                return true;
            }
        }

        List<ShopEntry> visible = entriesFor(category);
        for (int i = 0; i < VISIBLE_ROWS; i++) {
            int index = scrollOffset + i;
            if (index >= visible.size()) {
                break;
            }
            int y = ROW_Y + i * (ROW_H + ROW_GAP);
            if (contains(bx, by, ROW_X, y, ROW_W, ROW_H)) {
                selected = visible.get(index);
                return true;
            }
        }

        if (contains(bx, by, 407, 231, 92, 34)) {
            buySelected();
            return true;
        }
        if (contains(bx, by, 20, 236, 86, 30)) {
            method_25419();
            return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        double bx = toBaseX(mouseX);
        double by = toBaseY(mouseY);
        if (!contains(bx, by, ROW_X, ROW_Y, ROW_W, VISIBLE_ROWS * (ROW_H + ROW_GAP))) {
            return false;
        }
        int maxScroll = Math.max(0, entriesFor(category).size() - VISIBLE_ROWS);
        scrollOffset = Math.max(0, Math.min(maxScroll, scrollOffset - (int) Math.signum(verticalAmount)));
        return true;
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    public void updateEnergy(int energy, boolean success, String message) {
        this.energy = energy;
    }

    private void drawFrame(class_332 context) {
        fillBase(context, 0, 0, BASE_W, BASE_H, BG);
        borderBase(context, 0, 0, BASE_W, BASE_H, BORDER, 4);
        borderBase(context, 8, 8, BASE_W - 16, BASE_H - 16, 0xFFFFEBC0, 1);

        fillBase(context, 12, 54, 104, 218, BG_DARK);
        borderBase(context, 12, 54, 104, 218, BORDER, 2);

        fillBase(context, 120, 54, 278, 218, PANEL);
        borderBase(context, 120, 54, 278, 218, BORDER, 2);

        fillBase(context, 402, 54, 104, 168, PANEL);
        borderBase(context, 402, 54, 104, 168, BORDER, 2);

        fillBase(context, 402, 226, 104, 44, BG_DARK);
        borderBase(context, 402, 226, 104, 44, BORDER, 2);
    }

    private void drawHeader(class_332 context) {
        drawText(context, "TowerDefense", 18, 17, TEXT, 1.45F, false);
        drawText(context, "INTERCAMBIOS", 132, 41, MUTED, 0.82F, false);

        fillBase(context, 384, 14, 118, 32, 0x55FFFFFF);
        borderBase(context, 384, 14, 118, 32, BORDER_SOFT, 1);
        drawItem(context, new class_1799(ModItems.ENERGY_CELL), 405, 30, 0.9F);
        drawText(context, Integer.toString(energy), 428, 22, BLUE, 1.25F, false);
    }

    private void drawCategories(class_332 context, double bx, double by) {
        drawText(context, "SECCIONES", 24, 60, TEXT, 0.82F, false);
        for (ShopCategory value : ShopCategory.values()) {
            int y = CAT_Y + value.ordinal() * (CAT_H + CAT_GAP);
            boolean active = value == category;
            boolean hover = contains(bx, by, CAT_X, y, CAT_W, CAT_H);
            fillBase(context, CAT_X, y, CAT_W, CAT_H, active ? PANEL_SELECTED : hover ? PANEL_HOVER : PANEL);
            borderBase(context, CAT_X, y, CAT_W, CAT_H, active ? GREEN : BORDER, active ? 2 : 1);
            drawItem(context, value.icon, CAT_X + 20, y + 18, value.iconScale);
            drawText(context, value.label, CAT_X + 40, y + 13, TEXT, 0.82F, false);
        }
    }

    private void drawTradeRows(class_332 context, double bx, double by) {
        List<ShopEntry> visible = entriesFor(category);
        for (int i = 0; i < VISIBLE_ROWS; i++) {
            int index = scrollOffset + i;
            int y = ROW_Y + i * (ROW_H + ROW_GAP);
            if (index >= visible.size()) {
                fillBase(context, ROW_X, y, ROW_W, ROW_H, 0x66C19A5F);
                borderBase(context, ROW_X, y, ROW_W, ROW_H, 0x66442A16, 1);
                continue;
            }

            ShopEntry entry = visible.get(index);
            boolean active = selected != null && selected.id().equals(entry.id());
            boolean hover = contains(bx, by, ROW_X, y, ROW_W, ROW_H);
            boolean canBuy = energy >= entry.price();
            int fill = active ? PANEL_SELECTED : hover ? PANEL_HOVER : canBuy ? 0xFFF6E0AD : PANEL_DISABLED;

            fillBase(context, ROW_X, y, ROW_W, ROW_H, fill);
            borderBase(context, ROW_X, y, ROW_W, ROW_H, active ? GREEN : BORDER, active ? 2 : 1);

            drawItem(context, new class_1799(ModItems.ENERGY_CELL), ROW_X + 18, y + 18, 0.68F);
            drawText(context, Integer.toString(entry.price()), ROW_X + 34, y + 13, canBuy ? TEXT : RED, 0.86F, false);
            drawText(context, ">", ROW_X + 86, y + 11, MUTED, 1.05F, false);
            drawItem(context, new class_1799(entry.item(), entry.count()), ROW_X + 126, y + 18, rowIconScale(entry.id()));
            drawText(context, clipped(entry.display(), 112), ROW_X + 156, y + 13, canBuy ? TEXT : MUTED, 0.8F, false);
            if (entry.limit() > 0) {
                drawText(context, "Máx " + entry.limit(), ROW_X + ROW_W - 38, y + 5, BLUE, 0.62F, false);
            }
        }

        int maxScroll = Math.max(0, visible.size() - VISIBLE_ROWS);
        if (maxScroll > 0) {
            drawText(context, "Scroll " + (scrollOffset + 1) + "/" + (maxScroll + 1), 348, 252, MUTED, 0.72F, false);
        }
    }

    private void drawDetail(class_332 context) {
        if (selected == null) {
            drawTextCentered(context, "Selecciona", 454, 118, MUTED, 0.82F, 84);
            return;
        }

        drawItem(context, new class_1799(selected.item(), selected.count()), 454, 91, detailIconScale(selected.id()));
        drawTextCentered(context, selected.display().toUpperCase(Locale.ROOT), 454, 130, TEXT, 0.68F, 88);
        drawText(context, "Costo", DETAIL_X + 10, 155, MUTED, 0.72F, false);
        drawItem(context, new class_1799(ModItems.ENERGY_CELL), DETAIL_X + 28, 177, 0.68F);
        drawText(context, Integer.toString(selected.price()), DETAIL_X + 48, 171, energy >= selected.price() ? GREEN : RED, 0.95F, false);
        if (selected.limit() > 0) {
            drawText(context, "Límite: " + selected.limit() + " por arena", DETAIL_X + 10, 186, BLUE, 0.55F, false);
        }

        List<String> lines = wrap(shortDescription(selected.id()), 86, 3);
        for (int i = 0; i < lines.size(); i++) {
            drawText(context, lines.get(i), DETAIL_X + 10, 194 + i * 9, MUTED, 0.58F, false);
        }
    }

    private void drawButtons(class_332 context, double bx, double by) {
        boolean canBuy = selected != null && energy >= selected.price();
        boolean buyHover = contains(bx, by, 407, 231, 92, 34);
        fillBase(context, 407, 231, 92, 34, canBuy ? buyHover ? 0xFF8FCB62 : 0xFF6FB447 : 0xFF9E645C);
        borderBase(context, 407, 231, 92, 34, canBuy ? GREEN : RED, 2);
        drawTextCentered(context, canBuy ? "INTERCAMBIAR" : "SIN CELULAS", 453, 243, WHITE, canBuy ? 0.68F : 0.62F, 86);

        fillBase(context, 20, 236, 86, 30, 0xFFC2633F);
        borderBase(context, 20, 236, 86, 30, BORDER, 2);
        drawTextCentered(context, "CERRAR", 63, 246, WHITE, 0.72F, 72);
    }

    private void buySelected() {
        if (selected == null || energy < selected.price()) {
            return;
        }
        ClientPlayNetworking.send(new BuyShopItemC2SPayload(selected.id()));
    }

    private ShopEntry firstEntry(ShopCategory category) {
        List<ShopEntry> visible = entriesFor(category);
        return visible.isEmpty() ? null : visible.getFirst();
    }

    private List<ShopEntry> entriesFor(ShopCategory category) {
        List<ShopEntry> result = new ArrayList<>();
        for (ShopEntry entry : entries) {
            if (categoryOf(entry.id()) == category) {
                result.add(entry);
            }
        }
        return result;
    }

    private static ShopCategory categoryOf(String id) {
        return switch (id) {
            case "panel_solar", "turret", "crossbow_tower", "cannon", "holographic_shield", "ion_battery", "tesla_tower" -> ShopCategory.TOWERS;
            case "blue_upgrade_kit", "purple_upgrade_kit" -> ShopCategory.UPGRADES;
            default -> ShopCategory.WEAPONS;
        };
    }

    private static String shortDescription(String id) {
        return switch (id) {
            case "panel_solar" -> "Genera Celulas de Energia.";
            case "turret" -> "Dispara a un objetivo.";
            case "crossbow_tower" -> "Perfora hasta 2 enemigos.";
            case "cannon" -> "Impacto y fuego en area.";
            case "holographic_shield" -> "Barrera de mucha vida.";
            case "ion_battery" -> "Potencia estructuras 3x3.";
            case "tesla_tower" -> "Area y paralisis.";
            case "blue_upgrade_kit" -> "Nivel 1 a 2.";
            case "purple_upgrade_kit" -> "Nivel 2 a 3.";
            default -> "Arma del jugador.";
        };
    }

    private static float rowIconScale(String id) {
        return categoryOf(id) == ShopCategory.TOWERS ? 0.56F : 0.78F;
    }

    private static float detailIconScale(String id) {
        return categoryOf(id) == ShopCategory.TOWERS ? 1.05F : 1.45F;
    }

    private List<String> wrap(String text, int maxWidth, int maxLines) {
        List<String> result = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ")) {
            String candidate = line.isEmpty() ? word : line + " " + word;
            if (field_22793.method_1727(candidate) <= maxWidth) {
                line = new StringBuilder(candidate);
                continue;
            }
            if (!line.isEmpty()) {
                result.add(line.toString());
            }
            line = new StringBuilder(word);
            if (result.size() >= maxLines - 1) {
                break;
            }
        }
        if (!line.isEmpty() && result.size() < maxLines) {
            result.add(clipped(line.toString(), maxWidth));
        }
        return result;
    }

    private String clipped(String text, int maxWidth) {
        if (field_22793.method_1727(text) <= maxWidth) {
            return text;
        }
        String value = text;
        while (!value.isEmpty() && field_22793.method_1727(value + "..") > maxWidth) {
            value = value.substring(0, value.length() - 1);
        }
        return value.isEmpty() ? "" : value + "..";
    }

    private void drawText(class_332 context, String text, int baseX, int baseY, int color, float textScale, boolean shadow) {
        context.method_51448().method_22903();
        context.method_51448().method_46416(guiX + baseX * scale, guiY + baseY * scale, 0.0F);
        context.method_51448().method_22905(scale * textScale, scale * textScale, 1.0F);
        context.method_51433(field_22793, text, 0, 0, color, shadow);
        context.method_51448().method_22909();
    }

    private void drawTextCentered(class_332 context, String text, int centerBaseX, int baseY, int color, float textScale, int maxWidth) {
        String clipped = clipped(text, maxWidth);
        context.method_51448().method_22903();
        context.method_51448().method_46416(guiX + centerBaseX * scale, guiY + baseY * scale, 0.0F);
        context.method_51448().method_22905(scale * textScale, scale * textScale, 1.0F);
        context.method_51433(field_22793, clipped, -field_22793.method_1727(clipped) / 2, 0, color, false);
        context.method_51448().method_22909();
    }

    private void drawItem(class_332 context, class_1799 stack, int centerBaseX, int centerBaseY, float itemScale) {
        context.method_51448().method_22903();
        context.method_51448().method_46416(guiX + centerBaseX * scale - 8.0F * itemScale * scale,
                guiY + centerBaseY * scale - 8.0F * itemScale * scale, 120.0F);
        context.method_51448().method_22905(scale * itemScale, scale * itemScale, 1.0F);
        context.method_51427(stack, 0, 0);
        context.method_51448().method_22909();
    }

    private void fillBase(class_332 context, int x, int y, int w, int h, int color) {
        context.method_25294(screenX(x), screenY(y), screenX(x + w), screenY(y + h), color);
    }

    private void borderBase(class_332 context, int x, int y, int w, int h, int color, int thickness) {
        for (int i = 0; i < thickness; i++) {
            fillBase(context, x + i, y + i, w - i * 2, 1, color);
            fillBase(context, x + i, y + h - i - 1, w - i * 2, 1, color);
            fillBase(context, x + i, y + i, 1, h - i * 2, color);
            fillBase(context, x + w - i - 1, y + i, 1, h - i * 2, color);
        }
    }

    private int screenX(int baseX) {
        return Math.round(guiX + baseX * scale);
    }

    private int screenY(int baseY) {
        return Math.round(guiY + baseY * scale);
    }

    private double toBaseX(double mouseX) {
        return (mouseX - guiX) / scale;
    }

    private double toBaseY(double mouseY) {
        return (mouseY - guiY) / scale;
    }

    private static boolean contains(double x, double y, int rx, int ry, int rw, int rh) {
        return x >= rx && x < rx + rw && y >= ry && y < ry + rh;
    }

    private enum ShopCategory {
        TOWERS("Torres", new class_1799(ModItems.TURRET_ITEM), 0.58F),
        UPGRADES("Mejoras", new class_1799(ModItems.BLUE_UPGRADE_KIT), 0.75F),
        WEAPONS("Armas", new class_1799(class_1802.field_8371), 0.72F);

        private final String label;
        private final class_1799 icon;
        private final float iconScale;

        ShopCategory(String label, class_1799 icon, float iconScale) {
            this.label = label;
            this.icon = icon;
            this.iconScale = iconScale;
        }
    }
}
