package com.zjuqni.hexatowerdefense.tower;

public enum TowerType {
    PANEL_SOLAR,
    TURRET,
    CROSSBOW_TOWER,
    CANNON,
    HOLOGRAPHIC_SHIELD,
    ION_BATTERY,
    TESLA_TOWER
}
