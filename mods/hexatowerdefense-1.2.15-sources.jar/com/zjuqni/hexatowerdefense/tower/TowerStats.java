package com.zjuqni.hexatowerdefense.tower;

public final class TowerStats {
}
