package com.zjuqni.hexatowerdefense.tower;

public enum TowerAnimationState {
    IDLE,
    ATTACKING,
    PRODUCING,
    BUFFING,
    DEFENDING,
    DESTROYED
}
