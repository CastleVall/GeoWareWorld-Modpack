package com.zjuqni.hexatowerdefense.tower;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import com.zjuqni.hexatowerdefense.arena.ArenaInstance;
import com.zjuqni.hexatowerdefense.arena.ArenaState;
import com.zjuqni.hexatowerdefense.config.ConfigManager;
import com.zjuqni.hexatowerdefense.enemy.HTDEnemyEntity;
import com.zjuqni.hexatowerdefense.enemy.EnemyType;
import com.zjuqni.hexatowerdefense.layout.LaneDefinition;
import com.zjuqni.hexatowerdefense.layout.StructurePlacementCell;
import com.zjuqni.hexatowerdefense.registry.ModEntities;
import com.zjuqni.hexatowerdefense.registry.ModItems;
import com.zjuqni.hexatowerdefense.shop.ShopManager;
import com.zjuqni.hexatowerdefense.util.HTDText;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_1268;
import net.minecraft.class_1542;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2390;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public final class TowerManager {
    private static final double GRID_CELL_SPACING = 6.0D;
    private static final double MAX_ATTACK_CELLS = 6.0D;
    private static final double MAX_ATTACK_RANGE = GRID_CELL_SPACING * MAX_ATTACK_CELLS + 0.75D;
    private static final double FRONT_TARGET_TOLERANCE = 0.85D;
    private static final int UPGRADE_CONFIRM_TICKS = 80;
    private static final class_2390 TURRET_BEAM = dust(0.15F, 1.0F, 0.38F, 1.05F);
    private static final class_2390 TURRET_EDGE = dust(0.0F, 0.85F, 1.0F, 0.75F);
    private static final class_2390 CROSSBOW_BEAM = dust(0.15F, 0.55F, 1.0F, 1.0F);
    private static final class_2390 CROSSBOW_CORE = dust(0.95F, 0.95F, 1.0F, 0.65F);
    private static final class_2390 CANNON_TRAIL = dust(1.0F, 0.34F, 0.02F, 1.25F);
    private static final class_2390 CANNON_FLASH = dust(1.0F, 0.8F, 0.12F, 1.35F);
    private static final class_2390 TESLA_CORE = dust(0.0F, 0.88F, 1.0F, 1.0F);
    private static final class_2390 TESLA_EDGE = dust(0.75F, 0.25F, 1.0F, 0.9F);
    private static final class_2390 ENERGY_GLOW = dust(0.0F, 0.8F, 1.0F, 0.8F);
    private static final class_2390 MAGMA_ORANGE = dust(1.0F, 0.28F, 0.0F, 1.15F);
    private static final class_2390 MAGMA_YELLOW = dust(1.0F, 0.86F, 0.05F, 1.1F);
    private static final class_2390 EMBER_RED = dust(1.0F, 0.05F, 0.0F, 0.9F);
    private static final class_2390 PLASMA_PURPLE = dust(0.82F, 0.0F, 1.0F, 1.05F);

    private static final Map<class_1792, TowerType> ITEM_TO_TOWER = new HashMap<>();

    static {
        ITEM_TO_TOWER.put(ModItems.PANEL_SOLAR_ITEM, TowerType.PANEL_SOLAR);
        ITEM_TO_TOWER.put(ModItems.TURRET_ITEM, TowerType.TURRET);
        ITEM_TO_TOWER.put(ModItems.CROSSBOW_TOWER_ITEM, TowerType.CROSSBOW_TOWER);
        ITEM_TO_TOWER.put(ModItems.CANNON_ITEM, TowerType.CANNON);
        ITEM_TO_TOWER.put(ModItems.HOLOGRAPHIC_SHIELD_ITEM, TowerType.HOLOGRAPHIC_SHIELD);
        ITEM_TO_TOWER.put(ModItems.ION_BATTERY_ITEM, TowerType.ION_BATTERY);
        ITEM_TO_TOWER.put(ModItems.TESLA_TOWER_ITEM, TowerType.TESLA_TOWER);
    }

    private final ArenaInstance arena;
    private final List<HTDTowerEntity> towers = new ArrayList<>();
    private final List<BurningZone> burningZones = new ArrayList<>();
    private final List<PendingShot> pendingShots = new ArrayList<>();
    private final Set<Integer> occupiedCellIds = new HashSet<>();
    private final Map<UUID, Integer> towerCellIds = new HashMap<>();
    private final Map<UUID, PendingUpgrade> pendingUpgradeConfirmations = new HashMap<>();

    public TowerManager(ArenaInstance arena) {
        this.arena = arena;
    }

    public void tick() {
        towers.removeIf(tower -> tower == null || tower.method_31481());
        if (arena.state() != ArenaState.PREPARING && arena.state() != ArenaState.RUNNING) {
            burningZones.clear();
            pendingShots.clear();
            return;
        }
        tickPendingShots();
        tickBurningZones();
        tickIonBatteryAuras();
        int interval = ConfigManager.panelSolarProductionIntervalTicks(1);
        for (HTDTowerEntity tower : towers) {
            if (tower.towerType() == TowerType.PANEL_SOLAR) {
                int level = tower.level();
                interval = ConfigManager.panelSolarProductionIntervalTicks(level);
                int amount = ConfigManager.panelSolarProductionAmount(level);
                if (hasAdjacentTurret(tower)) {
                    interval = Math.max(1, (int) Math.round(interval * 0.8D));
                }
                if (hasAdjacentIonBattery(tower)) {
                    interval = Math.max(1, (int) Math.round(interval * 0.85D));
                    amount = Math.max(amount + 1, (int) Math.ceil(amount * 1.25D));
                }
                if (tower.tickPanelSolarProduction(interval)) {
                    if (countNearbyEnergyCells(tower) >= Math.max(1, ConfigManager.general().panelSolarMaxUncollected)) {
                        for (class_3222 waiting : arena.getPlayers()) {
                            HTDText.sendWarning(waiting, "Recoge las Células de Energía: el generador está lleno y no produce más.", true);
                        }
                        continue;
                    }
                    tower.markProducing(56);
                    dropEnergyCells(tower, amount);
                    class_3218 world = arena.getWorld();
                    if (world != null) {
                        double particleY = tower.method_23318() + Math.max(0.85D, tower.method_5829().method_17940() * 0.72D);
                        emit(world,class_2398.field_29644,
                                tower.method_23317(), particleY, tower.method_23321(),
                                18, 0.42D, 0.35D, 0.42D, 0.025D);
                        emit(world,ENERGY_GLOW,
                                tower.method_23317(), particleY + 0.1D, tower.method_23321(),
                                14, 0.36D, 0.25D, 0.36D, 0.0D);
                        spawnParticleRing(world, new class_243(tower.method_23317(), particleY + 0.05D, tower.method_23321()),
                                ENERGY_GLOW, TURRET_EDGE, 0.58D, 28, tower.field_6012);
                        spawnParticleRing(world, new class_243(tower.method_23317(), particleY + 0.24D, tower.method_23321()),
                                TURRET_EDGE, ENERGY_GLOW, 0.34D, 18, tower.field_6012 + 17);
                    }
                    for (class_3222 player : arena.getPlayers()) {
                        HTDText.sendEnergy(player, "Generador produjo " + amount + " Células de Energía.", true);
                    }
                }
                continue;
            }
            if (tower.towerType() == TowerType.TESLA_TOWER) {
                tickTeslaAura(tower);
            }
            tickAttackTower(tower);
        }
    }

    public static boolean isTowerItem(class_1799 stack) {
        return !stack.method_7960() && ITEM_TO_TOWER.containsKey(stack.method_7909());
    }

    public static TowerType towerTypeFor(class_1792 item) {
        return ITEM_TO_TOWER.get(item);
    }

    public int countTowersOfType(TowerType type) {
        int count = 0;
        for (HTDTowerEntity tower : towers) {
            if (tower != null && !tower.method_31481() && tower.towerType() == type) {
                count++;
            }
        }
        return count;
    }

    public static boolean isUpgradeItem(class_1799 stack) {
        if (stack.method_7960()) {
            return false;
        }
        class_1792 item = stack.method_7909();
        return item == ModItems.BLUE_UPGRADE_KIT || item == ModItems.RED_UPGRADE_KIT;
    }

    public boolean placeInitialGenerator() {
        if (arena.referenceLayout() == null || arena.referenceLayout().placementCells.isEmpty()) {
            return false;
        }
        class_3218 world = arena.getWorld();
        if (world == null) {
            return false;
        }

        Optional<StructurePlacementCell> maybeCell = arena.referenceLayout().placementCells.stream()
                .filter(cell -> !isOccupied(cell))
                .filter(cell -> !arena.isLaneLocked(cell.laneId))
                .min(Comparator.comparingDouble(this::distanceToPlayerSpawnSq));
        if (maybeCell.isEmpty()) {
            maybeCell = arena.referenceLayout().placementCells.stream()
                    .filter(cell -> !isOccupied(cell))
                    .min(Comparator.comparingDouble(this::distanceToPlayerSpawnSq));
        }
        if (maybeCell.isEmpty()) {
            return false;
        }

        StructurePlacementCell cell = maybeCell.get();
        class_2338 anchor = cell.anchorWorld(arena.anchor());
        HTDTowerEntity tower = ModEntities.HTD_TOWER.method_5883(world);
        if (tower == null) {
            return false;
        }
        tower.configure(arena.arenaId(), arena.playerUuid(), TowerType.PANEL_SOLAR, 1, anchor, cell.laneId);
        tower.method_5808(anchor.method_10263() + 0.5D, anchor.method_10264(), anchor.method_10260() + 0.5D, -90.0F, 0.0F);
        tower.refreshHitbox();
        if (!world.method_8649(tower)) {
            return false;
        }

        towers.add(tower);
        markOccupied(cell, tower);
        emit(world,class_2398.field_11211, anchor.method_10263() + 0.5D, anchor.method_10264() + 1.0D, anchor.method_10260() + 0.5D, 18, 0.35D, 0.45D, 0.35D, 0.02D);
        world.method_8396(null, anchor, class_3417.field_14703, class_3419.field_15245, 0.8F, 1.15F);
        if (ConfigManager.general().debug) {
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] Placed initial panel solar arena={} cell={} anchor={}", arena.arenaId(), cell.id, anchor);
        }
        return true;
    }

    public int fillTestTowers() {
        if (arena.referenceLayout() == null || arena.referenceLayout().placementCells.isEmpty()) {
            return 0;
        }
        class_3218 world = arena.getWorld();
        if (world == null) {
            return 0;
        }
        List<Integer> rows = arena.referenceLayout().placementCells.stream()
                .map(cell -> cell.row)
                .distinct()
                .sorted()
                .limit(4)
                .toList();
        if (rows.isEmpty()) {
            return 0;
        }
        int placed = 0;
        for (StructurePlacementCell cell : arena.referenceLayout().placementCells) {
            int rowIndex = rows.indexOf(cell.row);
            if (rowIndex < 0 || isOccupied(cell)) {
                continue;
            }
            TowerType type = switch (rowIndex) {
                case 0 -> TowerType.PANEL_SOLAR;
                case 1 -> TowerType.TURRET;
                case 2 -> TowerType.TESLA_TOWER;
                default -> TowerType.CANNON;
            };
            if (placeTowerAtCell(cell, type, 3, world)) {
                placed++;
            }
        }
        HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] TEST: rellenadas {} torres en arena {}", placed, arena.arenaId());
        return placed;
    }

    private boolean placeTowerAtCell(StructurePlacementCell cell, TowerType type, int level, class_3218 world) {
        class_2338 anchor = cell.anchorWorld(arena.anchor());
        HTDTowerEntity tower = ModEntities.HTD_TOWER.method_5883(world);
        if (tower == null) {
            return false;
        }
        tower.configure(arena.arenaId(), arena.playerUuid(), type, level, anchor, cell.laneId);
        tower.method_5808(anchor.method_10263() + 0.5D, anchor.method_10264(), anchor.method_10260() + 0.5D, -90.0F, 0.0F);
        tower.refreshHitbox();
        if (!world.method_8649(tower)) {
            return false;
        }
        towers.add(tower);
        markOccupied(cell, tower);
        return true;
    }

    public boolean tryPlaceTower(class_3222 player, class_1268 hand, class_2338 clickedPos) {
        class_1799 stack = player.method_5998(hand);
        TowerType towerType = ITEM_TO_TOWER.get(stack.method_7909());
        if (towerType == null) {
            return false;
        }

        if (ConfigManager.general().debug) {
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] Placement attempt player={} item={} pos={}",
                    player.method_7334().getName(), stack.method_7909(), clickedPos);
        }

        if (arena.state() != ArenaState.PREPARING && arena.state() != ArenaState.RUNNING) {
            HTDText.sendWarning(player, "No puedes colocar estructuras en este estado de arena.", false);
            logFail("arena not running/preparing");
            return true;
        }
        Optional<StructurePlacementCell> maybeCell = getPlacementCellAt(clickedPos);
        if (maybeCell.isEmpty()) {
            HTDText.sendWarning(player, "No hay una celda válida de colocación aquí.", false);
            logFail("no cell at clicked position");
            return true;
        }

        StructurePlacementCell cell = maybeCell.get();
        if (isOccupied(cell)) {
            HTDText.sendWarning(player, "Esta celda ya está ocupada.", false);
            logFail("cell occupied");
            return true;
        }
        if (arena.isLaneLocked(cell.laneId) && !ConfigManager.general().allowPlacementOnLockedLanes) {
            HTDText.sendWarning(player, "Este carril todavía está bloqueado.", false);
            logFail("lane locked");
            return true;
        }
        int limit = ShopManager.limitFor(towerType);
        if (limit > 0 && countTowersOfType(towerType) >= limit) {
            HTDText.sendWarning(player, "Límite de " + displayName(towerType) + " alcanzado: máximo " + limit + " por arena.", false);
            logFail("tower limit reached");
            return true;
        }

        class_3218 world = arena.getWorld();
        if (world == null) {
            return true;
        }
        class_2338 anchor = cell.anchorWorld(arena.anchor());
        HTDTowerEntity tower = ModEntities.HTD_TOWER.method_5883(world);
        if (tower == null) {
            HTDText.sendError(player, "No se pudo crear la estructura.", false);
            return true;
        }
        int storedLevel = TowerPlacementItem.readStoredLevel(stack);
        tower.configure(arena.arenaId(), player.method_5667(), towerType, storedLevel, anchor, cell.laneId);
        TowerPlacementItem.StoredHealth storedHealth = TowerPlacementItem.readStoredHealth(stack);
        if (storedHealth != null) {
            tower.applyStoredHealth(storedHealth.health(), storedHealth.maxHealth());
        }
        tower.method_5808(anchor.method_10263() + 0.5D, anchor.method_10264(), anchor.method_10260() + 0.5D, -90.0F, 0.0F);
        world.method_8649(tower);
        towers.add(tower);
        emit(world,class_2398.field_29644, anchor.method_10263() + 0.5D, anchor.method_10264() + 1.0D, anchor.method_10260() + 0.5D, 18, 0.35D, 0.45D, 0.35D, 0.02D);
        world.method_8396(null, anchor, class_3417.field_14703, class_3419.field_15245, 0.8F, 1.25F);
        markOccupied(cell, tower);
        if (!player.method_7337()) {
            stack.method_7934(1);
        }
        HTDText.sendSuccess(player, "Colocaste " + displayName(towerType) + ".", false);
        if (ConfigManager.general().debug) {
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] Placed tower {} at anchor={}", towerType, anchor);
        }
        return true;
    }

    public boolean tryPickupTower(class_3222 player, class_1268 hand, HTDTowerEntity tower) {
        if (tower.arenaId() != arena.arenaId()) {
            HTDText.sendError(player, "Esa estructura no pertenece a tu arena.", false);
            return true;
        }
        if (arena.state() != ArenaState.PREPARING && arena.state() != ArenaState.RUNNING) {
            HTDText.sendWarning(player, "No puedes recoger estructuras en este estado de arena.", false);
            return true;
        }
        if (!tower.canPickup()) {
            int seconds = Math.max(1, (tower.pickupCooldownTicks() + 19) / 20);
            HTDText.sendWarning(player, "Puedes recoger esta estructura en " + seconds + "s.", true);
            return true;
        }

        class_1792 item = towerItemFor(tower.towerType());
        if (item == null) {
            HTDText.sendError(player, "No se pudo devolver el item de esta estructura.", false);
            return true;
        }

        collectFloatingEnergyCells(tower);
        freeCellFor(tower);
        towers.remove(tower);
        if (!tower.method_31481()) {
            tower.method_31472();
        }
        player.method_31548().method_7398(towerItemStack(item, tower));

        class_3218 world = arena.getWorld();
        if (world != null) {
            emit(world,class_2398.field_29644, tower.method_23317(), tower.method_23318() + 0.8D, tower.method_23321(), 14, 0.35D, 0.35D, 0.35D, 0.02D);
            world.method_8396(null, tower.method_24515(), class_3417.field_19344, class_3419.field_15245, 0.65F, 1.1F);
        }
        HTDText.sendSuccess(player, "Recogiste " + displayName(tower.towerType()) + ".", false);
        return true;
    }

    public boolean tryUpgradeTower(class_3222 player, class_1268 hand, HTDTowerEntity tower) {
        class_1799 stack = player.method_5998(hand);
        if (!isUpgradeItem(stack)) {
            return false;
        }
        if (tower.arenaId() != arena.arenaId()) {
            HTDText.sendError(player, "Esa estructura no pertenece a tu arena.", false);
            return true;
        }
        int requiredCurrentLevel = requiredCurrentLevel(stack.method_7909());
        int targetLevel = requiredCurrentLevel + 1;
        if (tower.level() != requiredCurrentLevel) {
            HTDText.sendWarning(player, "Este kit requiere una estructura de nivel " + requiredCurrentLevel + ".", false);
            return true;
        }

        class_3218 world = arena.getWorld();
        long now = world == null ? 0L : world.method_8510();
        UUID playerId = player.method_5667();
        PendingUpgrade pending = pendingUpgradeConfirmations.get(playerId);
        if (pending == null || !pending.matches(tower, stack.method_7909(), requiredCurrentLevel, targetLevel, now)) {
            pendingUpgradeConfirmations.put(playerId, new PendingUpgrade(
                    tower.method_5667(),
                    stack.method_7909(),
                    requiredCurrentLevel,
                    targetLevel,
                    now + UPGRADE_CONFIRM_TICKS
            ));
            HTDText.sendWarning(player, "Haz clic otra vez sobre esta misma estructura para confirmar la mejora a nivel " + targetLevel + ".", false);
            if (world != null) {
                emit(world,class_2398.field_29644, tower.method_23317(), tower.method_23318() + 1.0D, tower.method_23321(),
                        10, 0.35D, 0.45D, 0.35D, 0.02D);
                world.method_8396(null, tower.method_24515(), class_3417.field_15015.comp_349(), class_3419.field_15248, 0.45F, 1.45F);
            }
            return true;
        }
        pendingUpgradeConfirmations.remove(playerId);
        tower.setLevel(targetLevel);
        if (!player.method_7337()) {
            stack.method_7934(1);
        }
        if (world != null) {
            emit(world,class_2398.field_29644, tower.method_23317(), tower.method_23318() + 1.0D, tower.method_23321(), 24, 0.45D, 0.55D, 0.45D, 0.03D);
            world.method_8396(null, tower.method_24515(), class_3417.field_14891, class_3419.field_15245, 0.8F, 1.2F);
        }
        HTDText.sendEnergy(player, "Estructura mejorada a nivel " + targetLevel + ".", false);
        return true;
    }

    public Optional<StructurePlacementCell> getPlacementCellAt(class_2338 clickedPos) {
        if (arena.referenceLayout() == null) {
            return Optional.empty();
        }
        class_2338 relative = clickedPos.method_10059(arena.anchor());
        return arena.referenceLayout().placementCells.stream()
                .filter(cell -> containsWithTolerance(cell, relative))
                .min(Comparator.comparingDouble(cell -> distanceToCellAnchorSq(cell, relative)));
    }

    public int occupiedCount() {
        return occupiedCellIds.size();
    }

    public void clear() {
        occupiedCellIds.clear();
        towerCellIds.clear();
        for (HTDTowerEntity tower : towers) {
            if (tower != null && !tower.method_31481()) {
                tower.method_31472();
            }
        }
        towers.clear();
        burningZones.clear();
        pendingShots.clear();
        pendingUpgradeConfirmations.clear();
    }

    public List<StructurePlacementCell> cells() {
        return arena.referenceLayout() == null ? List.of() : List.copyOf(arena.referenceLayout().placementCells);
    }

    private boolean isOccupied(StructurePlacementCell cell) {
        return cell != null && occupiedCellIds.contains(cell.id);
    }

    private void markOccupied(StructurePlacementCell cell, HTDTowerEntity tower) {
        if (cell != null) {
            occupiedCellIds.add(cell.id);
            if (tower != null) {
                towerCellIds.put(tower.method_5667(), cell.id);
            }
        }
    }

    private static double distanceToCellAnchorSq(StructurePlacementCell cell, class_2338 relative) {
        int[] anchor = cell.structureAnchorDiamond;
        if (anchor == null || anchor.length < 3) {
            return Double.MAX_VALUE;
        }
        double dx = relative.method_10263() - anchor[0];
        double dy = relative.method_10264() - anchor[1];
        double dz = relative.method_10260() - anchor[2];
        return dx * dx + dy * dy * 0.15D + dz * dz;
    }

    private static boolean containsWithTolerance(StructurePlacementCell cell, class_2338 relative) {
        if (cell.clickableGoldArea == null || cell.clickableGoldArea.min == null || cell.clickableGoldArea.max == null) {
            return false;
        }
        int[] min = cell.clickableGoldArea.min;
        int[] max = cell.clickableGoldArea.max;
        return relative.method_10263() >= min[0] - 1 && relative.method_10263() <= max[0] + 1
                && relative.method_10264() >= min[1] - 2 && relative.method_10264() <= max[1] + 3
                && relative.method_10260() >= min[2] - 1 && relative.method_10260() <= max[2] + 1;
    }

    private double distanceToPlayerSpawnSq(StructurePlacementCell cell) {
        class_2338 anchorPos = cell.anchorWorld(arena.anchor());
        class_2338 spawn = arena.playerSpawnPosition();
        if (spawn == null) {
            double laneBias = cell.laneId - 2.5D;
            return laneBias * laneBias * 100.0D + cell.row;
        }
        double dx = anchorPos.method_10263() - spawn.method_10263();
        double dz = anchorPos.method_10260() - spawn.method_10260();
        return dx * dx + dz * dz;
    }

    private boolean hasAdjacentTurret(HTDTowerEntity panel) {
        class_2338 panelCell = panel.cellCenter();
        double maxCellDelta = GRID_CELL_SPACING + 0.75D;
        for (HTDTowerEntity other : towers) {
            if (other == null || other == panel || other.method_31481() || other.towerType() != TowerType.TURRET) {
                continue;
            }
            class_2338 otherCell = other.cellCenter();
            if (Math.abs(otherCell.method_10263() - panelCell.method_10263()) <= maxCellDelta
                    && Math.abs(otherCell.method_10260() - panelCell.method_10260()) <= maxCellDelta) {
                return true;
            }
        }
        return false;
    }

    private boolean hasAdjacentIonBattery(HTDTowerEntity tower) {
        if (tower.towerType() == TowerType.ION_BATTERY) {
            return false;
        }
        class_2338 center = tower.cellCenter();
        double maxCellDelta = GRID_CELL_SPACING + 0.75D;
        for (HTDTowerEntity other : towers) {
            if (other == null || other == tower || other.method_31481() || other.towerType() != TowerType.ION_BATTERY) {
                continue;
            }
            class_2338 otherCell = other.cellCenter();
            if (Math.abs(otherCell.method_10263() - center.method_10263()) <= maxCellDelta
                    && Math.abs(otherCell.method_10260() - center.method_10260()) <= maxCellDelta) {
                return true;
            }
        }
        return false;
    }

    private void tickIonBatteryAuras() {
        class_3218 world = arena.getWorld();
        if (world == null || world.method_8510() % 20L != 0L) {
            return;
        }
        for (HTDTowerEntity tower : towers) {
            if (tower == null || tower.method_31481() || tower.towerType() == TowerType.ION_BATTERY) {
                continue;
            }
            if (!hasAdjacentIonBattery(tower)) {
                continue;
            }
            double y = tower.method_23318() + Math.max(0.35D, tower.method_5829().method_17940() * 0.55D);
            emit(world,class_2398.field_29642, tower.method_23317(), y, tower.method_23321(),
                    3, 0.55D, 0.35D, 0.55D, 0.02D);
            emit(world,class_2398.field_29644, tower.method_23317(), y + 0.25D, tower.method_23321(),
                    2, 0.45D, 0.25D, 0.45D, 0.015D);
        }
    }

    private void dropEnergyCells(HTDTowerEntity tower, int amount) {
        class_3218 world = arena.getWorld();
        if (world == null || amount <= 0) {
            return;
        }
        double spawnY = tower.method_23318() + 0.9D;
        int remaining = amount;
        while (remaining > 0) {
            int stackSize = Math.min(ShopManager.ENERGY_CELL_MAX_SAFE_STACK, remaining);
            class_1799 stack = new class_1799(ModItems.ENERGY_CELL, stackSize);
            class_1542 itemEntity = new class_1542(world, tower.method_23317(), spawnY, tower.method_23321(), stack);
            itemEntity.method_5875(true);
            itemEntity.method_18800(0.0D, 0.0D, 0.0D);
            itemEntity.method_6982(20);
            world.method_8649(itemEntity);
            remaining -= stackSize;
        }
    }

    private int countNearbyEnergyCells(HTDTowerEntity tower) {
        class_3218 world = arena.getWorld();
        if (world == null) {
            return 0;
        }
        class_238 box = new class_238(tower.method_24515()).method_1009(3.0D, 10.0D, 3.0D);
        return world.method_8390(class_1542.class, box,
                entity -> !entity.method_31481() && entity.method_6983().method_31574(ModItems.ENERGY_CELL)).size();
    }

    private void freeCellFor(HTDTowerEntity tower) {
        if (arena.referenceLayout() == null) {
            return;
        }
        Integer cellId = towerCellIds.remove(tower.method_5667());
        if (cellId != null) {
            occupiedCellIds.remove(cellId);
            return;
        }
        class_2338 towerAnchor = tower.cellCenter();
        for (StructurePlacementCell cell : arena.referenceLayout().placementCells) {
            if (cell.anchorWorld(arena.anchor()).equals(towerAnchor)) {
                occupiedCellIds.remove(cell.id);
                return;
            }
        }
    }

    public Optional<HTDTowerEntity> blockingTowerFor(int laneId, class_243 enemyPos) {
        HTDTowerEntity best = null;
        double bestDistSq = Double.MAX_VALUE;
        for (HTDTowerEntity tower : towers) {
            if (tower == null || tower.method_31481() || tower.laneId() != laneId) {
                continue;
            }
            if (Math.abs(tower.method_23317() - enemyPos.field_1352) > 1.9D) {
                continue;
            }
            double dz = enemyPos.field_1350 - tower.method_23321();
            if (dz < -0.95D || dz > 2.45D) {
                continue;
            }
            double distSq = horizontalDistanceSq(tower.method_19538(), enemyPos);
            if (distSq < bestDistSq) {
                bestDistSq = distSq;
                best = tower;
            }
        }
        return Optional.ofNullable(best);
    }

    public HTDTowerEntity towerByUuid(UUID uuid) {
        for (HTDTowerEntity tower : towers) {
            if (tower != null && tower.method_5667().equals(uuid) && !tower.method_31481()) {
                return tower;
            }
        }
        return null;
    }

    public void removeTower(HTDTowerEntity tower) {
        if (tower == null) {
            return;
        }
        collectFloatingEnergyCells(tower);
        freeCellFor(tower);
        towers.remove(tower);
        if (!tower.method_31481()) {
            tower.method_31472();
        }
    }

    private void collectFloatingEnergyCells(HTDTowerEntity tower) {
        if (tower == null || tower.towerType() != TowerType.PANEL_SOLAR) {
            return;
        }
        class_3218 world = arena.getWorld();
        class_3222 player = null;
        double bestDistSq = Double.MAX_VALUE;
        for (class_3222 member : arena.getPlayers()) {
            double distSq = member.method_5649(tower.method_23317(), tower.method_23318(), tower.method_23321());
            if (distSq < bestDistSq) {
                bestDistSq = distSq;
                player = member;
            }
        }
        if (world == null || player == null) {
            return;
        }
        class_238 box = tower.method_5829().method_1009(2.25D, 4.0D, 2.25D);
        for (class_1542 itemEntity : world.method_8390(class_1542.class, box,
                entity -> !entity.method_31481() && entity.method_6983().method_31574(ModItems.ENERGY_CELL))) {
            class_1799 stack = itemEntity.method_6983().method_7972();
            ShopManager.giveEnergyCells(player, stack.method_7947());
            itemEntity.method_31472();
        }
        player.field_7512.method_7623();
    }

    private static class_1792 towerItemFor(TowerType type) {
        return switch (type) {
            case PANEL_SOLAR -> ModItems.PANEL_SOLAR_ITEM;
            case TURRET -> ModItems.TURRET_ITEM;
            case CROSSBOW_TOWER -> ModItems.CROSSBOW_TOWER_ITEM;
            case CANNON -> ModItems.CANNON_ITEM;
            case HOLOGRAPHIC_SHIELD -> ModItems.HOLOGRAPHIC_SHIELD_ITEM;
            case ION_BATTERY -> ModItems.ION_BATTERY_ITEM;
            case TESLA_TOWER -> ModItems.TESLA_TOWER_ITEM;
        };
    }

    private static class_1799 towerItemStack(class_1792 item, HTDTowerEntity tower) {
        class_1799 stack = new class_1799(item);
        TowerPlacementItem.writeStoredState(stack, tower.health(), tower.maxHealth(), tower.level());
        return stack;
    }

    private static String displayName(TowerType type) {
        return switch (type) {
            case PANEL_SOLAR -> "Panel Solar";
            case TURRET -> "Torreta";
            case CROSSBOW_TOWER -> "Ballesta";
            case CANNON -> "Cañón";
            case HOLOGRAPHIC_SHIELD -> "Escudo Holográfico";
            case ION_BATTERY -> "Batería de Iones";
            case TESLA_TOWER -> "Torre Tesla";
        };
    }

    private static int requiredCurrentLevel(class_1792 item) {
        if (item == ModItems.BLUE_UPGRADE_KIT) {
            return 1;
        }
        if (item == ModItems.RED_UPGRADE_KIT) {
            return 2;
        }
        return -1;
    }

    private void logFail(String reason) {
        if (ConfigManager.general().debug) {
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] Placement failed: {}", reason);
        }
    }

    private void tickAttackTower(HTDTowerEntity tower) {
        TowerType type = tower.towerType();
        if (type == TowerType.HOLOGRAPHIC_SHIELD || type == TowerType.ION_BATTERY) {
            return;
        }
        if (!tower.attackReady()) {
            return;
        }
        class_3218 world = arena.getWorld();
        if (world == null) {
            return;
        }
        int level = tower.level();
        double range = Math.min(ConfigManager.towerRange(type, level), MAX_ATTACK_RANGE);
        if (range <= 0.0D) {
            return;
        }
        HTDEnemyEntity target = findTarget(tower, range);
        if (target == null) {
            return;
        }

        int cooldown = ConfigManager.towerCooldownTicks(type, level);
        double damage = ConfigManager.towerDamage(type, level);
        boolean batteryBuffed = hasAdjacentIonBattery(tower);
        if (batteryBuffed) {
            damage *= 1.25D;
            cooldown = Math.max(6, (int) Math.round(cooldown * 0.8D));
        }
        tower.markAttacking(cooldown);
        scheduleShot(tower, target, damage, ConfigManager.towerAreaRadius(type, level));
        spawnChargeTell(world, tower, type);
    }

    private void scheduleShot(HTDTowerEntity tower, HTDEnemyEntity target, double damage, double radius) {
        int delay = shotReleaseDelay(tower.towerType());
        pendingShots.add(new PendingShot(tower.method_5667(), target.method_5667(), tower.towerType(), damage, radius, delay));
    }

    private static int shotReleaseDelay(TowerType type) {
        return switch (type) {
            case TURRET -> 2;
            case CANNON -> 8;
            case CROSSBOW_TOWER -> 15;
            case TESLA_TOWER -> 6;
            default -> 1;
        };
    }

    private void tickPendingShots() {
        if (pendingShots.isEmpty()) {
            return;
        }
        class_3218 world = arena.getWorld();
        if (world == null) {
            pendingShots.clear();
            return;
        }
        Iterator<PendingShot> iterator = pendingShots.iterator();
        while (iterator.hasNext()) {
            PendingShot shot = iterator.next();
            shot.ticksLeft--;
            if (shot.ticksLeft > 0) {
                continue;
            }
            iterator.remove();
            HTDTowerEntity tower = towerByUuid(shot.towerUuid);
            if (tower == null || tower.method_31481() || tower.arenaId() != arena.arenaId()) {
                continue;
            }
            HTDEnemyEntity target = enemyByUuid(shot.targetUuid);
            if (shot.type == TowerType.TESLA_TOWER) {
                fireTesla(world, tower, shot.damage, shot.radius);
                continue;
            }
            if (target == null || target.method_31481() || !target.method_5805() || target.arenaId() != arena.arenaId()) {
                continue;
            }
            switch (shot.type) {
                case CANNON -> fireCannon(world, tower, target, shot.damage, shot.radius);
                case CROSSBOW_TOWER -> fireCrossbow(world, tower, target, shot.damage);
                case TURRET -> fireTurret(world, tower, target, shot.damage);
                default -> {
                }
            }
        }
    }

    private HTDEnemyEntity enemyByUuid(UUID uuid) {
        for (HTDEnemyEntity enemy : arena.enemyManager().enemies()) {
            if (enemy != null && enemy.method_5667().equals(uuid) && !enemy.method_31481()) {
                return enemy;
            }
        }
        return null;
    }

    private HTDEnemyEntity findTarget(HTDTowerEntity tower, double range) {
        double rangeSq = range * range;
        class_243 towerPos = tower.method_19538().method_1031(0.0D, 0.8D, 0.0D);

        HTDEnemyEntity best = null;
        double bestPriority = Double.MAX_VALUE;
        for (HTDEnemyEntity enemy : arena.enemyManager().enemies()) {
            if (enemy == null || enemy.method_31481() || !enemy.method_5805() || enemy.arenaId() != arena.arenaId()) {
                continue;
            }
            if (horizontalDistanceSq(towerPos, enemy.method_19538()) > rangeSq || !canTowerDamageEnemy(tower, enemy)) {
                continue;
            }
            double priority = targetPriority(tower, enemy);
            if (priority < bestPriority) {
                bestPriority = priority;
                best = enemy;
            }
        }
        return best;
    }

    private void fireTurret(class_3218 world, HTDTowerEntity tower, HTDEnemyEntity target, double damage) {
        class_243 start = muzzlePoint(tower, 1.05D);
        class_243 end = target.method_19538().method_1031(0.0D, target.method_5829().method_17940() * 0.62D, 0.0D);
        drawHelixBeam(world, start, end, TURRET_BEAM, TURRET_EDGE, ENERGY_GLOW, 0.13D, 18, tower.field_6012);
        spawnMuzzleBurst(world, start, TURRET_BEAM, TURRET_EDGE, 0.42D, 18);
        spawnImpactBurst(world, end, TURRET_EDGE, ENERGY_GLOW, 0.38D, 22);
        damageEnemy(target, damage);
        world.method_8396(null, tower.method_24515(), class_3417.field_14970, class_3419.field_15251, 0.62F, 1.82F);
    }

    private void fireCrossbow(class_3218 world, HTDTowerEntity tower, HTDEnemyEntity target, double damage) {
        class_243 start = muzzlePoint(tower, 1.0D);
        class_243 end = target.method_19538().method_1031(0.0D, target.method_5829().method_17940() * 0.58D, 0.0D);
        class_243 side = perpendicular(start, end).method_1021(0.11D);
        drawRailShot(world, start.method_1019(side), end.method_1019(side), CROSSBOW_BEAM, CROSSBOW_CORE, tower.field_6012);
        drawRailShot(world, start.method_1020(side), end.method_1020(side), CROSSBOW_BEAM, CROSSBOW_CORE, tower.field_6012 + 7);
        spawnMuzzleBurst(world, start, CROSSBOW_BEAM, CROSSBOW_CORE, 0.5D, 20);
        spawnImpactBurst(world, end, CROSSBOW_CORE, CROSSBOW_BEAM, 0.34D, 18);
        damageEnemy(target, damage);
        world.method_8396(null, tower.method_24515(), class_3417.field_14600, class_3419.field_15251, 0.82F, 0.72F);
        int pierced = 0;
        class_243 targetPos = target.method_19538();
        for (HTDEnemyEntity enemy : arena.enemyManager().enemies()) {
            if (enemy == target || enemy == null || enemy.method_31481() || !enemy.method_5805() || enemy.arenaId() != arena.arenaId()) {
                continue;
            }
            if (canTowerDamageEnemy(tower, enemy) && horizontalDistanceSq(enemy.method_19538(), targetPos) <= 18.0D) {
                class_243 pierceEnd = enemy.method_19538().method_1031(0.0D, enemy.method_5829().method_17940() * 0.56D, 0.0D);
                drawRailShot(world, end, pierceEnd, CROSSBOW_CORE, CROSSBOW_BEAM, tower.field_6012 + pierced * 13);
                spawnImpactBurst(world, pierceEnd, CROSSBOW_BEAM, CROSSBOW_CORE, 0.28D, 14);
                damageEnemy(enemy, damage * 0.65D);
                pierced++;
                if (pierced >= 1) {
                    break;
                }
            }
        }
    }

    private void fireCannon(class_3218 world, HTDTowerEntity tower, HTDEnemyEntity target, double damage, double radius) {
        class_243 start = muzzlePoint(tower, 0.95D);
        class_243 impact = target.method_19538().method_1031(0.0D, target.method_5829().method_17940() * 0.48D, 0.0D);
        drawCannonTrail(world, start, impact, tower.field_6012);
        spawnMuzzleBurst(world, start, MAGMA_YELLOW, MAGMA_ORANGE, 0.62D, 26);
        spawnCannonImpact(world, impact);
        radius = Math.max(radius, 7.25D);
        double radiusSq = Math.max(1.0D, radius * radius);
        for (HTDEnemyEntity enemy : arena.enemyManager().enemies()) {
            if (enemy != null && !enemy.method_31481() && enemy.method_5805() && enemy.arenaId() == arena.arenaId()
                    && canTowerDamageEnemy(tower, enemy)
                    && horizontalDistanceSq(enemy.method_19538(), target.method_19538()) <= radiusSq) {
                damageEnemy(enemy, damage);
            }
        }
        burningZones.add(new BurningZone(impact, tower.laneId(), Math.max(1.0D, damage * 0.30D), 100, 20, 2.0D));
        world.method_8396(null, target.method_24515(), class_3417.field_15152.comp_349(), class_3419.field_15251, 0.6F, 1.3F);
    }

    private void fireTesla(class_3218 world, HTDTowerEntity tower, double damage, double radius) {
        radius = Math.max(radius, 7.25D);
        double radiusSq = Math.max(1.0D, radius * radius);
        boolean hitAny = false;
        class_243 origin = muzzlePoint(tower, 1.35D);
        spawnTeslaCorePulse(world, origin);
        for (HTDEnemyEntity enemy : arena.enemyManager().enemies()) {
            if (enemy == null || enemy.method_31481() || !enemy.method_5805() || enemy.arenaId() != arena.arenaId()) {
                continue;
            }
            if (canTowerDamageEnemy(tower, enemy) && horizontalDistanceSq(enemy.method_19538(), tower.method_19538()) <= radiusSq) {
                class_243 end = enemy.method_19538().method_1031(0.0D, enemy.method_5829().method_17940() * 0.65D, 0.0D);
                drawLightning(world, origin, end, tower.field_6012 + enemy.method_5628(), true);
                spawnImpactBurst(world, end, TESLA_EDGE, TESLA_CORE, 0.44D, 24);
                damageEnemy(enemy, damage);
                enemy.stun(35);
                hitAny = true;
            }
        }
        if (hitAny) {
            world.method_8396(null, tower.method_24515(), class_3417.field_14891, class_3419.field_15251, 0.75F, 1.8F);
        }
    }

    private void tickTeslaAura(HTDTowerEntity tower) {
        if (tower.field_6012 % 20 != 0) {
            return;
        }
        class_3218 world = arena.getWorld();
        if (world == null) {
            return;
        }
        double radius = Math.min(ConfigManager.towerRange(TowerType.TESLA_TOWER, tower.level()), MAX_ATTACK_RANGE);
        double radiusSq = radius * radius;
        double damage = Math.max(1.0D, ConfigManager.towerDamage(TowerType.TESLA_TOWER, tower.level()) * 0.18D);
        boolean hitAny = false;
        for (HTDEnemyEntity enemy : arena.enemyManager().enemies()) {
            if (enemy == null || enemy.method_31481() || !enemy.method_5805() || enemy.arenaId() != arena.arenaId()) {
                continue;
            }
            if (canTowerDamageEnemy(tower, enemy) && horizontalDistanceSq(enemy.method_19538(), tower.method_19538()) <= radiusSq) {
                drawLightning(world,
                        muzzlePoint(tower, 1.2D),
                        enemy.method_19538().method_1031(0.0D, enemy.method_5829().method_17940() * 0.62D, 0.0D),
                        tower.field_6012 + enemy.method_5628(),
                        false);
                damageEnemy(enemy, damage);
                hitAny = true;
            }
        }
        if (hitAny) {
            tower.markAttacking(12);
            world.method_8396(null, tower.method_24515(), class_3417.field_23116, class_3419.field_15251, 0.28F, 1.7F);
        }
    }

    private void tickBurningZones() {
        class_3218 world = arena.getWorld();
        if (world == null || burningZones.isEmpty()) {
            return;
        }
        Iterator<BurningZone> iterator = burningZones.iterator();
        while (iterator.hasNext()) {
            BurningZone zone = iterator.next();
            zone.ticksLeft--;
            if (zone.ticksLeft <= 0) {
                iterator.remove();
                continue;
            }
            if (zone.ticksLeft % zone.tickInterval != 0) {
                continue;
            }
            double radiusSq = zone.radius * zone.radius;
            emit(world,class_2398.field_11240, zone.center.field_1352, zone.center.field_1351, zone.center.field_1350, 6, 0.7D, 0.05D, 0.7D, 0.01D);
            for (HTDEnemyEntity enemy : arena.enemyManager().enemies()) {
                if (enemy == null || enemy.method_31481() || !enemy.method_5805() || enemy.arenaId() != arena.arenaId()) {
                    continue;
                }
                boolean sameOrAdjacentLane = Math.abs(enemy.laneId() - zone.laneId) <= 1;
                if (sameOrAdjacentLane && horizontalDistanceSq(enemy.method_19538(), zone.center) <= radiusSq) {
                    damageEnemy(enemy, zone.damagePerPulse);
                }
            }
        }
    }

    private void damageEnemy(HTDEnemyEntity enemy, double damage) {
        if (enemy == null || enemy.method_31481() || !enemy.method_5805()) {
            return;
        }
        enemy.method_5643(enemy.method_48923().method_48831(), (float) damage);
        if (enemy.method_6032() <= 0.0F && !enemy.method_31481()) {
            enemy.method_31472();
        }
    }

    private boolean canTowerDamageEnemy(HTDTowerEntity tower, HTDEnemyEntity enemy) {
        return canTowerTargetEnemy(tower, enemy) && isInAllowedAttackArc(tower, enemy);
    }

    private static boolean canTowerTargetEnemy(HTDTowerEntity tower, HTDEnemyEntity enemy) {
        if (tower.laneId() < 0) {
            return true;
        }
        int laneDelta = Math.abs(enemy.laneId() - tower.laneId());
        if (tower.towerType() == TowerType.CANNON || tower.towerType() == TowerType.TESLA_TOWER) {
            return laneDelta <= 1;
        }
        return laneDelta == 0;
    }

    private boolean isInAllowedAttackArc(HTDTowerEntity tower, HTDEnemyEntity enemy) {
        TowerType type = tower.towerType();
        if (type != TowerType.TURRET && type != TowerType.CROSSBOW_TOWER && type != TowerType.CANNON) {
            return true;
        }
        int approachSign = laneApproachSign(tower.laneId());
        if (approachSign >= 0) {
            return enemy.method_23321() >= tower.method_23321() - FRONT_TARGET_TOLERANCE;
        }
        return enemy.method_23321() <= tower.method_23321() + FRONT_TARGET_TOLERANCE;
    }

    private double targetPriority(HTDTowerEntity tower, HTDEnemyEntity enemy) {
        int approachSign = laneApproachSign(tower.laneId());
        return approachSign >= 0 ? enemy.method_23321() : -enemy.method_23321();
    }

    private int laneApproachSign(int laneId) {
        if (arena.referenceLayout() == null) {
            return 1;
        }
        LaneDefinition lane = arena.referenceLayout().laneById(laneId);
        if (lane == null || lane.enemySpawn == null || lane.enemySpawn.length < 3) {
            return 1;
        }
        int targetZ = lane.coreTarget != null && lane.coreTarget.length >= 3
                ? lane.coreTarget[2]
                : arena.referenceLayout().core != null && arena.referenceLayout().core.length >= 3
                ? arena.referenceLayout().core[2]
                : lane.waypoints != null && !lane.waypoints.isEmpty()
                ? lane.waypoints.get(lane.waypoints.size() - 1)[2]
                : lane.enemySpawn[2] - 1;
        return Integer.compare(lane.enemySpawn[2], targetZ);
    }

    private static double horizontalDistanceSq(class_243 first, class_243 second) {
        double dx = first.field_1352 - second.field_1352;
        double dz = first.field_1350 - second.field_1350;
        return dx * dx + dz * dz;
    }

    private static class_243 muzzlePoint(HTDTowerEntity tower, double height) {
        return tower.method_19538().method_1031(0.0D, height, 0.0D);
    }

    private static class_243 perpendicular(class_243 start, class_243 end) {
        class_243 delta = end.method_1020(start);
        class_243 side = new class_243(-delta.field_1350, 0.0D, delta.field_1352);
        if (side.method_1027() <= 0.0001D) {
            return new class_243(1.0D, 0.0D, 0.0D);
        }
        return side.method_1029();
    }

    private void drawHelixBeam(class_3218 world, class_243 start, class_243 end,
                               class_2390 core, class_2390 edge, class_2390 spark,
                               double radius, int minSteps, int seed) {
        class_243 delta = end.method_1020(start);
        double length = delta.method_1033();
        if (length <= 0.05D) {
            return;
        }
        class_243 side = perpendicular(start, end);
        class_243 up = beamUp(delta, side);
        int steps = Math.max(Math.min(minSteps, 10), (int) (length * 3.5D));
        for (int i = 0; i <= steps; i++) {
            double t = i / (double) steps;
            class_243 point = start.method_1019(delta.method_1021(t));
            emit(world,core, point.field_1352, point.field_1351, point.field_1350, 1, 0.004D, 0.004D, 0.004D, 0.0D);
            double angle = t * Math.PI * 8.0D + seed * 0.31D;
            class_243 spiral = side.method_1021(Math.cos(angle) * radius).method_1019(up.method_1021(Math.sin(angle) * radius));
            class_243 spiralPoint = point.method_1019(spiral);
            if (i % 2 == 0) {
                emit(world,edge, spiralPoint.field_1352, spiralPoint.field_1351, spiralPoint.field_1350, 1, 0.002D, 0.002D, 0.002D, 0.0D);
            }
            if (i % 5 == 0) {
                class_243 counter = point.method_1020(spiral.method_1021(0.65D));
                emit(world,spark, counter.field_1352, counter.field_1351, counter.field_1350, 1, 0.01D, 0.01D, 0.01D, 0.0D);
            }
        }
    }

    private void drawRailShot(class_3218 world, class_243 start, class_243 end,
                              class_2390 rail, class_2390 core, int seed) {
        class_243 delta = end.method_1020(start);
        double length = delta.method_1033();
        if (length <= 0.05D) {
            return;
        }
        class_243 side = perpendicular(start, end);
        class_243 up = beamUp(delta, side);
        int steps = Math.max(10, (int) (length * 3.0D));
        for (int i = 0; i <= steps; i++) {
            double t = i / (double) steps;
            class_243 point = start.method_1019(delta.method_1021(t));
            emit(world,core, point.field_1352, point.field_1351, point.field_1350, 1, 0.002D, 0.002D, 0.002D, 0.0D);
            if (i % 2 == 0) {
                double pulse = 0.07D + 0.04D * Math.sin(seed * 0.41D + i * 0.9D);
                class_243 top = point.method_1019(up.method_1021(pulse));
                class_243 bottom = point.method_1020(up.method_1021(pulse));
                emit(world,rail, top.field_1352, top.field_1351, top.field_1350, 1, 0.0D, 0.0D, 0.0D, 0.0D);
                emit(world,rail, bottom.field_1352, bottom.field_1351, bottom.field_1350, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            }
        }
    }

    private void drawCannonTrail(class_3218 world, class_243 start, class_243 end, int seed) {
        class_243 delta = end.method_1020(start);
        double length = delta.method_1033();
        if (length <= 0.05D) {
            return;
        }
        class_243 side = perpendicular(start, end);
        class_243 up = beamUp(delta, side);
        int steps = Math.max(8, (int) (length * 2.5D));
        for (int i = 0; i <= steps; i++) {
            double t = i / (double) steps;
            class_243 point = start.method_1019(delta.method_1021(t));
            double width = 0.04D + t * 0.13D;
            emit(world,CANNON_TRAIL, point.field_1352, point.field_1351, point.field_1350, 2, width, width * 0.5D, width, 0.0D);
            if (i % 2 == 0) {
                emit(world,MAGMA_YELLOW, point.field_1352, point.field_1351, point.field_1350, 1, width * 0.65D, width * 0.35D, width * 0.65D, 0.0D);
                class_243 ember = point
                        .method_1019(side.method_1021(Math.sin(seed + i * 0.7D) * width * 2.0D))
                        .method_1019(up.method_1021(Math.cos(seed + i * 0.5D) * width));
                emit(world,class_2398.field_11240, ember.field_1352, ember.field_1351, ember.field_1350, 1, 0.02D, 0.02D, 0.02D, 0.01D);
            }
            if (i % 6 == 0) {
                emit(world,class_2398.field_11251, point.field_1352, point.field_1351, point.field_1350, 1, width, width * 0.45D, width, 0.0D);
            }
        }
    }

    private void drawLightning(class_3218 world, class_243 start, class_243 end, int seed, boolean heavy) {
        class_243 delta = end.method_1020(start);
        double length = delta.method_1033();
        if (length <= 0.05D) {
            return;
        }
        class_243 side = perpendicular(start, end);
        class_243 up = beamUp(delta, side);
        int segments = Math.max(heavy ? 8 : 5, (int) (length * (heavy ? 1.6D : 1.0D)));
        class_243 previous = start;
        for (int i = 1; i <= segments; i++) {
            double t = i / (double) segments;
            double amplitude = heavy ? 0.34D : 0.16D;
            double wave = Math.sin((seed + i * 31) * 0.73D) * amplitude;
            double vertical = Math.cos((seed + i * 17) * 0.51D) * amplitude * 0.45D;
            class_243 next = i == segments ? end : start.method_1019(delta.method_1021(t)).method_1019(side.method_1021(wave)).method_1019(up.method_1021(vertical));
            drawHelixBeam(world, previous, next, TESLA_CORE, TESLA_EDGE, PLASMA_PURPLE, heavy ? 0.055D : 0.035D, 4, seed + i);
            if (heavy && i % 3 == 0) {
                spawnMiniSpark(world, next, TESLA_EDGE, 0.18D, 6);
            }
            previous = next;
        }
        emit(world,TESLA_EDGE, end.field_1352, end.field_1351, end.field_1350, heavy ? 24 : 10, 0.24D, 0.24D, 0.24D, 0.0D);
    }

    private void spawnChargeTell(class_3218 world, HTDTowerEntity tower, TowerType type) {
        class_243 point = muzzlePoint(tower, type == TowerType.TESLA_TOWER ? 1.35D : 1.0D);
        class_2390 primary = switch (type) {
            case TURRET -> TURRET_BEAM;
            case CROSSBOW_TOWER -> CROSSBOW_BEAM;
            case CANNON -> MAGMA_ORANGE;
            case TESLA_TOWER -> TESLA_EDGE;
            default -> ENERGY_GLOW;
        };
        class_2390 secondary = switch (type) {
            case CANNON -> MAGMA_YELLOW;
            case TESLA_TOWER -> TESLA_CORE;
            default -> ENERGY_GLOW;
        };
        spawnParticleRing(world, point, primary, secondary, 0.18D, 10, tower.field_6012);
    }

    private void spawnMuzzleBurst(class_3218 world, class_243 point, class_2390 primary,
                                  class_2390 secondary, double radius, int count) {
        emit(world,primary, point.field_1352, point.field_1351, point.field_1350, count, radius * 0.18D, radius * 0.18D, radius * 0.18D, 0.0D);
        spawnParticleRing(world, point, primary, secondary, radius, Math.max(10, count / 2), count);
        spawnMiniSpark(world, point, secondary, radius * 0.45D, Math.max(8, count / 3));
    }

    private void spawnImpactBurst(class_3218 world, class_243 point, class_2390 primary,
                                  class_2390 secondary, double radius, int count) {
        emit(world,primary, point.field_1352, point.field_1351, point.field_1350, count, radius * 0.35D, radius * 0.32D, radius * 0.35D, 0.0D);
        spawnParticleRing(world, point, primary, secondary, radius, count, count * 3);
        spawnMiniSpark(world, point, secondary, radius * 0.55D, Math.max(8, count / 2));
    }

    private void spawnTeslaCorePulse(class_3218 world, class_243 point) {
        spawnParticleRing(world, point, TESLA_CORE, TESLA_EDGE, 0.62D, 22, 19);
        spawnParticleRing(world, point.method_1031(0.0D, 0.18D, 0.0D), PLASMA_PURPLE, TESLA_CORE, 0.42D, 16, 47);
        emit(world,TESLA_EDGE, point.field_1352, point.field_1351, point.field_1350, 18, 0.22D, 0.22D, 0.22D, 0.0D);
    }

    private void spawnCannonImpact(class_3218 world, class_243 point) {
        emit(world,class_2398.field_11236, point.field_1352, point.field_1351, point.field_1350, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        emit(world,CANNON_FLASH, point.field_1352, point.field_1351, point.field_1350, 14, 0.55D, 0.24D, 0.55D, 0.0D);
        emit(world,MAGMA_YELLOW, point.field_1352, point.field_1351, point.field_1350, 10, 0.42D, 0.18D, 0.42D, 0.0D);
        emit(world,EMBER_RED, point.field_1352, point.field_1351, point.field_1350, 12, 0.6D, 0.25D, 0.6D, 0.0D);
        emit(world,class_2398.field_11240, point.field_1352, point.field_1351, point.field_1350, 18, 0.68D, 0.26D, 0.68D, 0.045D);
        emit(world,class_2398.field_11239, point.field_1352, point.field_1351, point.field_1350, 7, 0.42D, 0.2D, 0.42D, 0.02D);
        emit(world,class_2398.field_11251, point.field_1352, point.field_1351, point.field_1350, 10, 0.68D, 0.26D, 0.68D, 0.01D);
        spawnParticleRing(world, point.method_1031(0.0D, 0.05D, 0.0D), MAGMA_ORANGE, EMBER_RED, 0.82D, 30, 91);
    }

    private void spawnParticleRing(class_3218 world, class_243 center, class_2390 primary,
                                   class_2390 secondary, double radius, int count, int seed) {
        count = Math.max(6, count / 2);
        for (int i = 0; i < count; i++) {
            double angle = (Math.PI * 2.0D * i / count) + seed * 0.07D;
            double wobble = 0.82D + 0.18D * Math.sin(seed + i * 0.73D);
            class_243 point = center.method_1031(Math.cos(angle) * radius * wobble, Math.sin(angle * 2.0D) * radius * 0.08D, Math.sin(angle) * radius * wobble);
            emit(world,i % 3 == 0 ? secondary : primary, point.field_1352, point.field_1351, point.field_1350, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
    }

    private void spawnMiniSpark(class_3218 world, class_243 center, class_2390 color, double radius, int count) {
        count = Math.max(4, count / 2);
        for (int i = 0; i < count; i++) {
            double angle = Math.PI * 2.0D * i / count;
            class_243 point = center.method_1031(Math.cos(angle) * radius, (i % 3 - 1) * radius * 0.25D, Math.sin(angle) * radius);
            emit(world,color, point.field_1352, point.field_1351, point.field_1350, 1, 0.03D, 0.03D, 0.03D, 0.0D);
        }
    }

    private static class_243 beamUp(class_243 delta, class_243 side) {
        class_243 up = delta.method_1036(side);
        if (up.method_1027() <= 0.0001D) {
            return new class_243(0.0D, 1.0D, 0.0D);
        }
        return up.method_1029();
    }

    private static class_2390 dust(float red, float green, float blue, float scale) {
        return new class_2390(new Vector3f(red, green, blue), scale);
    }

    private void emit(class_3218 world, class_2394 effect, double x, double y, double z,
                      int count, double dx, double dy, double dz, double speed) {
        for (class_3222 viewer : arena.getPlayers()) {
            world.method_14166(viewer, effect, false, x, y, z, count, dx, dy, dz, speed);
        }
    }

    private static final class BurningZone {
        private final class_243 center;
        private final int laneId;
        private final double damagePerPulse;
        private final int tickInterval;
        private final double radius;
        private int ticksLeft;

        private BurningZone(class_243 center, int laneId, double damagePerPulse, int ticksLeft, int tickInterval, double radius) {
            this.center = center;
            this.laneId = laneId;
            this.damagePerPulse = damagePerPulse;
            this.ticksLeft = ticksLeft;
            this.tickInterval = tickInterval;
            this.radius = radius;
        }
    }

    private static final class PendingShot {
        private final UUID towerUuid;
        private final UUID targetUuid;
        private final TowerType type;
        private final double damage;
        private final double radius;
        private int ticksLeft;

        private PendingShot(UUID towerUuid, UUID targetUuid, TowerType type, double damage, double radius, int ticksLeft) {
            this.towerUuid = towerUuid;
            this.targetUuid = targetUuid;
            this.type = type;
            this.damage = damage;
            this.radius = radius;
            this.ticksLeft = Math.max(1, ticksLeft);
        }
    }

    private record PendingUpgrade(UUID towerUuid, class_1792 kitItem, int requiredLevel, int targetLevel, long expiresAt) {
        private boolean matches(HTDTowerEntity tower, class_1792 item, int requiredLevel, int targetLevel, long now) {
            return now <= expiresAt
                    && towerUuid.equals(tower.method_5667())
                    && kitItem == item
                    && this.requiredLevel == requiredLevel
                    && this.targetLevel == targetLevel;
        }
    }

}
