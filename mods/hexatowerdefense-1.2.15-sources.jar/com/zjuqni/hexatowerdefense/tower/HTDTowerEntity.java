package com.zjuqni.hexatowerdefense.tower;

import com.zjuqni.hexatowerdefense.config.ConfigManager;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_4048;
import net.minecraft.class_4050;

public final class HTDTowerEntity extends class_1297 implements GeoEntity {
    public static final int PICKUP_COOLDOWN_TICKS = 20 * 60;

    private static final class_2940<Integer> TRACKED_TOWER_TYPE = class_2945.method_12791(HTDTowerEntity.class, class_2943.field_13327);
    private static final class_2940<Integer> TRACKED_LEVEL = class_2945.method_12791(HTDTowerEntity.class, class_2943.field_13327);
    private static final class_2940<Integer> TRACKED_ANIMATION_STATE = class_2945.method_12791(HTDTowerEntity.class, class_2943.field_13327);
    private static final class_2940<Integer> TRACKED_ANIMATION_SEQ = class_2945.method_12791(HTDTowerEntity.class, class_2943.field_13327);
    private static final class_2940<Integer> TRACKED_HEALTH = class_2945.method_12791(HTDTowerEntity.class, class_2943.field_13327);
    private static final class_2940<Integer> TRACKED_MAX_HEALTH = class_2945.method_12791(HTDTowerEntity.class, class_2943.field_13327);

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private boolean runtimeSpawned;
    private int arenaId = -1;
    private UUID ownerUuid;
    private class_2338 cellCenter = class_2338.field_10980;
    private int laneId = -1;
    private int productionTicks;
    private int attackCooldownTicks;
    private int attackAnimationTicks;
    private int pickupCooldownTicks = PICKUP_COOLDOWN_TICKS;
    private int maxHealth = 100;
    private int health = 100;
    private int clientAnimationSeq = -1;

    public HTDTowerEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
        method_5875(true);
        field_5960 = true;
    }

    @Override
    public boolean method_5863() {
        return true;
    }

    @Override
    public boolean method_5732() {
        return true;
    }

    @Override
    public class_4048 method_18377(class_4050 pose) {
        return dimensionsFor(towerType());
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        builder.method_56912(TRACKED_TOWER_TYPE, TowerType.TURRET.ordinal());
        builder.method_56912(TRACKED_LEVEL, 1);
        builder.method_56912(TRACKED_ANIMATION_STATE, TowerAnimationState.IDLE.ordinal());
        builder.method_56912(TRACKED_ANIMATION_SEQ, 0);
        builder.method_56912(TRACKED_HEALTH, 100);
        builder.method_56912(TRACKED_MAX_HEALTH, 100);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        method_18800(0.0D, 0.0D, 0.0D);
        refreshHitbox();
        if (!method_37908().method_8608()) {
            tickAttackTimers();
            if (pickupCooldownTicks > 0) {
                pickupCooldownTicks--;
            }
        }
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "tower", 0, state -> {
            // GeckoLib no repite un clip one-shot igual al anterior sin un reset forzado.
            int seq = field_6011.method_12789(TRACKED_ANIMATION_SEQ);
            if (seq != clientAnimationSeq) {
                clientAnimationSeq = seq;
                state.getController().forceAnimationReset();
            }
            RawAnimation animation = animationFor(towerType(), animationState());
            return animation == null ? PlayState.STOP : state.setAndContinue(animation);
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }

    public boolean isRuntimeSpawned() {
        return runtimeSpawned;
    }

    public void configure(int arenaId, UUID ownerUuid, TowerType towerType, int level, class_2338 cellCenter, int laneId) {
        this.runtimeSpawned = true;
        this.arenaId = arenaId;
        this.ownerUuid = ownerUuid;
        this.cellCenter = cellCenter.method_10062();
        this.laneId = laneId;
        this.field_6011.method_12778(TRACKED_TOWER_TYPE, towerType.ordinal());
        this.field_6011.method_12778(TRACKED_LEVEL, Math.max(1, level));
        this.field_6011.method_12778(TRACKED_ANIMATION_STATE, defaultAnimationState(towerType).ordinal());
        this.maxHealth = ConfigManager.towerHealth(towerType, level);
        this.health = this.maxHealth;
        syncHealth();
        this.pickupCooldownTicks = PICKUP_COOLDOWN_TICKS;
        method_5665(null);
        method_5880(false);
        method_18382();
        refreshHitbox();
    }

    public void refreshHitbox() {
        HitboxSize size = hitboxSizeFor(towerType());
        double half = size.width() / 2.0D;
        double minY = method_23318() + 0.18D;
        method_5857(new class_238(
                method_23317() - half,
                minY,
                method_23321() - half,
                method_23317() + half,
                minY + size.height(),
                method_23321() + half
        ));
    }

    public boolean tickPanelSolarProduction(int intervalTicks) {
        if (towerType() != TowerType.PANEL_SOLAR || intervalTicks <= 0) {
            return false;
        }
        productionTicks++;
        if (productionTicks < intervalTicks) {
            return false;
        }
        productionTicks = 0;
        return true;
    }

    public void markProducing(int ticks) {
        this.attackAnimationTicks = Math.max(8, ticks);
        setAnimationState(TowerAnimationState.PRODUCING);
    }

    public boolean attackReady() {
        return attackCooldownTicks <= 0;
    }

    public void markAttacking(int cooldownTicks) {
        this.attackCooldownTicks = Math.max(1, cooldownTicks);
        int animationTicks = Math.min(18, Math.max(8, cooldownTicks / 2));
        if (towerType() == TowerType.CROSSBOW_TOWER) {
            // El clip disparo+recarga dura ~19 ticks; si se corta antes no se ve la recarga.
            animationTicks = Math.max(1, Math.min(19, cooldownTicks - 1));
        }
        this.attackAnimationTicks = animationTicks;
        setAnimationState(TowerAnimationState.ATTACKING);
    }

    public void setAnimationState(TowerAnimationState animationState) {
        this.field_6011.method_12778(TRACKED_ANIMATION_STATE, animationState.ordinal());
        this.field_6011.method_12778(TRACKED_ANIMATION_SEQ, this.field_6011.method_12789(TRACKED_ANIMATION_SEQ) + 1);
    }

    public class_2338 cellCenter() {
        return cellCenter;
    }

    public int laneId() {
        return laneId;
    }

    public boolean canPickup() {
        return pickupCooldownTicks <= 0;
    }

    public int pickupCooldownTicks() {
        return pickupCooldownTicks;
    }

    public int arenaId() {
        return arenaId;
    }

    public TowerType towerType() {
        int ordinal = field_6011.method_12789(TRACKED_TOWER_TYPE);
        TowerType[] values = TowerType.values();
        return ordinal >= 0 && ordinal < values.length ? values[ordinal] : TowerType.TURRET;
    }

    public int level() {
        return field_6011.method_12789(TRACKED_LEVEL);
    }

    public void setLevel(int level) {
        int oldMaxHealth = maxHealth();
        this.field_6011.method_12778(TRACKED_LEVEL, Math.max(1, level));
        this.maxHealth = ConfigManager.towerHealth(towerType(), level());
        int gainedHealth = Math.max(0, this.maxHealth - oldMaxHealth);
        this.health = Math.min(this.maxHealth, health() + gainedHealth);
        syncHealth();
    }

    public int health() {
        return field_6011.method_12789(TRACKED_HEALTH);
    }

    public int maxHealth() {
        return field_6011.method_12789(TRACKED_MAX_HEALTH);
    }

    public void applyStoredHealth(int storedHealth, int storedMaxHealth) {
        if (storedMaxHealth <= 0) {
            return;
        }
        double ratio = Math.max(0.0D, Math.min(1.0D, storedHealth / (double) storedMaxHealth));
        this.health = Math.max(1, Math.min(maxHealth(), (int) Math.round(maxHealth() * ratio)));
        syncHealth();
    }

    public boolean damageTower(int amount) {
        if (amount <= 0 || method_31481()) {
            return false;
        }
        this.health = Math.max(0, health() - amount);
        syncHealth();
        if (towerType() == TowerType.HOLOGRAPHIC_SHIELD) {
            this.attackAnimationTicks = Math.max(this.attackAnimationTicks, 16);
            setAnimationState(TowerAnimationState.DEFENDING);
        }
        if (health() <= 0) {
            method_31472();
            return true;
        }
        return false;
    }

    public TextureVariant textureVariant() {
        int level = level();
        if (level <= 1) {
            return TextureVariant.GREEN;
        }
        if (level == 2) {
            return TextureVariant.BLUE;
        }
        return TextureVariant.PURPLE;
    }

    public TowerAnimationState animationState() {
        int ordinal = field_6011.method_12789(TRACKED_ANIMATION_STATE);
        TowerAnimationState[] values = TowerAnimationState.values();
        return ordinal >= 0 && ordinal < values.length ? values[ordinal] : TowerAnimationState.IDLE;
    }

    @Override
    protected void method_5749(class_2487 nbt) {
        this.runtimeSpawned = nbt.method_10577("RuntimeSpawned");
        arenaId = nbt.method_10550("ArenaId");
        if (nbt.method_25928("OwnerUuid")) {
            ownerUuid = nbt.method_25926("OwnerUuid");
        }
        field_6011.method_12778(TRACKED_TOWER_TYPE, nbt.method_10550("TowerType"));
        field_6011.method_12778(TRACKED_LEVEL, Math.max(1, nbt.method_10550("Level")));
        field_6011.method_12778(TRACKED_ANIMATION_STATE, nbt.method_10550("AnimationState"));
        productionTicks = nbt.method_10550("ProductionTicks");
        attackCooldownTicks = nbt.method_10550("AttackCooldownTicks");
        attackAnimationTicks = nbt.method_10550("AttackAnimationTicks");
        pickupCooldownTicks = nbt.method_10545("PickupCooldownTicks") ? nbt.method_10550("PickupCooldownTicks") : PICKUP_COOLDOWN_TICKS;
        maxHealth = nbt.method_10545("MaxHealth") ? nbt.method_10550("MaxHealth") : ConfigManager.towerHealth(towerType(), level());
        health = nbt.method_10545("Health") ? nbt.method_10550("Health") : maxHealth;
        syncHealth();
        laneId = nbt.method_10550("LaneId");
        if (nbt.method_10545("CellX")) {
            cellCenter = new class_2338(nbt.method_10550("CellX"), nbt.method_10550("CellY"), nbt.method_10550("CellZ"));
        }
    }

    @Override
    protected void method_5652(class_2487 nbt) {
        nbt.method_10556("RuntimeSpawned", runtimeSpawned);
        nbt.method_10569("ArenaId", arenaId);
        if (ownerUuid != null) {
            nbt.method_25927("OwnerUuid", ownerUuid);
        }
        nbt.method_10569("TowerType", towerType().ordinal());
        nbt.method_10569("Level", level());
        nbt.method_10569("AnimationState", animationState().ordinal());
        nbt.method_10569("ProductionTicks", productionTicks);
        nbt.method_10569("AttackCooldownTicks", attackCooldownTicks);
        nbt.method_10569("AttackAnimationTicks", attackAnimationTicks);
        nbt.method_10569("PickupCooldownTicks", pickupCooldownTicks);
        nbt.method_10569("MaxHealth", maxHealth);
        nbt.method_10569("Health", health());
        nbt.method_10569("LaneId", laneId);
        nbt.method_10569("CellX", cellCenter.method_10263());
        nbt.method_10569("CellY", cellCenter.method_10264());
        nbt.method_10569("CellZ", cellCenter.method_10260());
    }

    private void tickAttackTimers() {
        if (attackCooldownTicks > 0) {
            attackCooldownTicks--;
        }
        if (attackAnimationTicks > 0) {
            attackAnimationTicks--;
            if (attackAnimationTicks == 0
                    && (animationState() == TowerAnimationState.ATTACKING || animationState() == TowerAnimationState.DEFENDING)) {
                setAnimationState(defaultAnimationState(towerType()));
            }
        }
    }

    private static TowerAnimationState defaultAnimationState(TowerType type) {
        return switch (type) {
            case PANEL_SOLAR -> TowerAnimationState.IDLE;
            case ION_BATTERY -> TowerAnimationState.BUFFING;
            default -> TowerAnimationState.IDLE;
        };
    }

    private void syncHealth() {
        maxHealth = Math.max(1, maxHealth);
        health = Math.max(0, Math.min(maxHealth, health));
        field_6011.method_12778(TRACKED_MAX_HEALTH, maxHealth);
        field_6011.method_12778(TRACKED_HEALTH, health);
    }

    private static class_4048 dimensionsFor(TowerType type) {
        return switch (type) {
            case PANEL_SOLAR -> class_4048.method_18385(1.65F, 1.45F);
            case TURRET -> class_4048.method_18385(1.55F, 1.35F);
            case CROSSBOW_TOWER -> class_4048.method_18385(1.65F, 1.35F);
            case CANNON -> class_4048.method_18385(1.8F, 1.45F);
            case HOLOGRAPHIC_SHIELD -> class_4048.method_18385(1.95F, 1.75F);
            case ION_BATTERY -> class_4048.method_18385(1.65F, 1.75F);
            case TESLA_TOWER -> class_4048.method_18385(1.6F, 2.15F);
        };
    }

    private static HitboxSize hitboxSizeFor(TowerType type) {
        return switch (type) {
            case PANEL_SOLAR -> new HitboxSize(1.65D, 1.45D);
            case TURRET -> new HitboxSize(1.55D, 1.35D);
            case CROSSBOW_TOWER -> new HitboxSize(1.65D, 1.35D);
            case CANNON -> new HitboxSize(1.8D, 1.45D);
            case HOLOGRAPHIC_SHIELD -> new HitboxSize(1.95D, 1.75D);
            case ION_BATTERY -> new HitboxSize(1.65D, 1.75D);
            case TESLA_TOWER -> new HitboxSize(1.6D, 2.15D);
        };
    }

    private record HitboxSize(double width, double height) {
    }

    private static RawAnimation animationFor(TowerType type, TowerAnimationState state) {
        return switch (type) {
            case PANEL_SOLAR -> state == TowerAnimationState.PRODUCING
                    ? RawAnimation.begin().thenPlay("animation.energy")
                    : null;
            case TURRET -> state == TowerAnimationState.ATTACKING
                    ? RawAnimation.begin().thenPlay("animation.disparo")
                    : RawAnimation.begin().thenLoop("animation.idle");
            case CROSSBOW_TOWER -> state == TowerAnimationState.ATTACKING
                    ? RawAnimation.begin().thenPlay("animation.disparo")
                    : null;
            case CANNON -> state == TowerAnimationState.ATTACKING
                    ? RawAnimation.begin().thenPlay("animation.disparo")
                    : RawAnimation.begin().thenLoop("animation.idle");
            case HOLOGRAPHIC_SHIELD -> state == TowerAnimationState.DEFENDING
                    ? RawAnimation.begin().thenPlay("animation.defense")
                    : null;
            case ION_BATTERY -> RawAnimation.begin().thenLoop("animation.energ\u00eda");
            case TESLA_TOWER -> state == TowerAnimationState.ATTACKING
                    ? RawAnimation.begin().thenPlay("animation.tesla")
                    : null;
        };
    }

    public static RawAnimation idleAnimationFor(TowerType type) {
        return switch (type) {
            case PANEL_SOLAR -> RawAnimation.begin();
            case TURRET -> RawAnimation.begin().thenLoop("animation.idle");
            case CROSSBOW_TOWER -> RawAnimation.begin();
            case CANNON -> RawAnimation.begin().thenLoop("animation.idle");
            case HOLOGRAPHIC_SHIELD -> RawAnimation.begin();
            case ION_BATTERY -> RawAnimation.begin().thenLoop("animation.energ\u00eda");
            case TESLA_TOWER -> RawAnimation.begin();
        };
    }

}
