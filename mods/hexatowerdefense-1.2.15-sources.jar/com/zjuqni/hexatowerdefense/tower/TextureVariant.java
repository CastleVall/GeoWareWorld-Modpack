package com.zjuqni.hexatowerdefense.tower;

public enum TextureVariant {
    GREEN,
    BLUE,
    PURPLE
}
