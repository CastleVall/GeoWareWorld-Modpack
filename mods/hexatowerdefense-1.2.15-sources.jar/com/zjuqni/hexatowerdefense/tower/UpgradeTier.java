package com.zjuqni.hexatowerdefense.tower;

public enum UpgradeTier {
    GREEN,
    BLUE,
    RED
}
