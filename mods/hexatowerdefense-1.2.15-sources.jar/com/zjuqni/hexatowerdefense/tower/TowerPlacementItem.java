package com.zjuqni.hexatowerdefense.tower;

import com.zjuqni.hexatowerdefense.client.renderer.TowerItemRenderer;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.client.GeoRenderProvider;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.function.Consumer;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_756;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

public final class TowerPlacementItem extends class_1792 implements GeoItem {
    private static final String STORED_HEALTH_KEY = "HexaTowerHealth";
    private static final String STORED_MAX_HEALTH_KEY = "HexaTowerMaxHealth";
    private static final String STORED_LEVEL_KEY = "HexaTowerLevel";

    private final TowerType towerType;
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public TowerPlacementItem(TowerType towerType, class_1793 settings) {
        super(settings);
        this.towerType = towerType;
        GeoItem.registerSyncedAnimatable(this);
    }

    public TowerType towerType() {
        return towerType;
    }

    @Override
    public boolean method_31567(class_1799 stack) {
        StoredHealth health = readStoredHealth(stack);
        return health != null && health.health() < health.maxHealth();
    }

    @Override
    public int method_31569(class_1799 stack) {
        StoredHealth health = readStoredHealth(stack);
        if (health == null) {
            return 13;
        }
        return Math.max(1, Math.min(13, Math.round(13.0F * health.health() / health.maxHealth())));
    }

    @Override
    public int method_31571(class_1799 stack) {
        return switch (towerType) {
            case PANEL_SOLAR -> 0x42F56F;
            case TURRET, CROSSBOW_TOWER, CANNON -> 0x55A7FF;
            case HOLOGRAPHIC_SHIELD -> 0xB05CFF;
            case ION_BATTERY, TESLA_TOWER -> 0xFFD34D;
        };
    }

    public static void writeStoredHealth(class_1799 stack, int health, int maxHealth) {
        if (stack.method_7960() || health >= maxHealth || maxHealth <= 0) {
            return;
        }
        class_2487 nbt = stack.method_57825(class_9334.field_49628, class_9279.field_49302).method_57461();
        nbt.method_10569(STORED_HEALTH_KEY, Math.max(0, health));
        nbt.method_10569(STORED_MAX_HEALTH_KEY, Math.max(1, maxHealth));
        stack.method_57379(class_9334.field_49628, class_9279.method_57456(nbt));
    }

    public static void writeStoredState(class_1799 stack, int health, int maxHealth, int level) {
        if (stack.method_7960()) {
            return;
        }
        boolean damaged = maxHealth > 0 && health < maxHealth;
        boolean upgraded = level > 1;
        if (!damaged && !upgraded) {
            return;
        }
        class_2487 nbt = stack.method_57825(class_9334.field_49628, class_9279.field_49302).method_57461();
        if (damaged) {
            nbt.method_10569(STORED_HEALTH_KEY, Math.max(0, health));
            nbt.method_10569(STORED_MAX_HEALTH_KEY, Math.max(1, maxHealth));
        }
        if (upgraded) {
            nbt.method_10569(STORED_LEVEL_KEY, Math.max(1, level));
        }
        stack.method_57379(class_9334.field_49628, class_9279.method_57456(nbt));
    }

    public static int readStoredLevel(class_1799 stack) {
        if (stack.method_7960()) {
            return 1;
        }
        class_9279 component = stack.method_57825(class_9334.field_49628, class_9279.field_49302);
        if (!component.method_57450(STORED_LEVEL_KEY)) {
            return 1;
        }
        return Math.max(1, component.method_57461().method_10550(STORED_LEVEL_KEY));
    }

    public static StoredHealth readStoredHealth(class_1799 stack) {
        if (stack.method_7960()) {
            return null;
        }
        class_9279 component = stack.method_57825(class_9334.field_49628, class_9279.field_49302);
        if (!component.method_57450(STORED_HEALTH_KEY) || !component.method_57450(STORED_MAX_HEALTH_KEY)) {
            return null;
        }
        class_2487 nbt = component.method_57461();
        int maxHealth = Math.max(1, nbt.method_10550(STORED_MAX_HEALTH_KEY));
        int health = Math.max(0, Math.min(maxHealth, nbt.method_10550(STORED_HEALTH_KEY)));
        return new StoredHealth(health, maxHealth);
    }

    @Override
    public void createGeoRenderer(Consumer<GeoRenderProvider> consumer) {
        consumer.accept(new GeoRenderProvider() {
            private TowerItemRenderer renderer;

            @Override
            public class_756 getGeoItemRenderer() {
                if (renderer == null) {
                    renderer = new TowerItemRenderer();
                }
                return renderer;
            }
        });
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "tower_item", 0, state -> {
            RawAnimation animation = inventoryAnimationFor(towerType);
            return animation == null ? PlayState.STOP : state.setAndContinue(animation);
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }

    public record StoredHealth(int health, int maxHealth) {
    }

    private static RawAnimation inventoryAnimationFor(TowerType type) {
        return switch (type) {
            case TURRET -> RawAnimation.begin().thenLoop("animation.idle");
            case CANNON -> RawAnimation.begin().thenLoop("animation.idle");
            case HOLOGRAPHIC_SHIELD -> RawAnimation.begin().thenLoop("animation.defense");
            case ION_BATTERY -> RawAnimation.begin().thenLoop("animation.energ\u00eda");
            default -> null;
        };
    }
}
