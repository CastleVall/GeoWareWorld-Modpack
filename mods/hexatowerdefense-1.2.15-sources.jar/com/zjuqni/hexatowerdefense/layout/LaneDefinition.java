package com.zjuqni.hexatowerdefense.layout;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;

public final class LaneDefinition {
    public int id;
    public int x;
    public boolean locked;
    public int[] enemySpawn;
    public List<int[]> waypoints = new ArrayList<>();
    public int[] coreApproachPoint;
    public int[] coreAttackPoint;
    public int[] coreTarget;

    public LaneDefinition() {
    }

    public LaneDefinition(int id, int x, boolean locked, int[] enemySpawn, List<int[]> waypoints) {
        this.id = id;
        this.x = x;
        this.locked = locked;
        this.enemySpawn = enemySpawn;
        this.waypoints = waypoints;
    }

    public class_2338 enemySpawnWorld(class_2338 arenaAnchor) {
        return arenaAnchor.method_10069(enemySpawn[0], enemySpawn[1], enemySpawn[2]);
    }

    public List<class_2338> waypointsWorld(class_2338 arenaAnchor) {
        List<class_2338> result = new ArrayList<>(waypoints.size());
        for (int[] waypoint : waypoints) {
            result.add(arenaAnchor.method_10069(waypoint[0], waypoint[1], waypoint[2]));
        }
        return result;
    }

    public class_2338 coreApproachWorld(class_2338 arenaAnchor, int[] fallbackCore) {
        int[] pos = coreApproachPoint != null ? coreApproachPoint : fallbackCore;
        return arenaAnchor.method_10069(pos[0], pos[1], pos[2]);
    }

    public class_2338 coreTargetWorld(class_2338 arenaAnchor, int[] fallbackCore) {
        int[] pos = coreTarget != null ? coreTarget : fallbackCore;
        return arenaAnchor.method_10069(pos[0], pos[1], pos[2]);
    }

    public class_2338 coreAttackWorld(class_2338 arenaAnchor, int[] fallbackCore) {
        int[] pos = coreAttackPoint != null ? coreAttackPoint : coreTarget != null ? coreTarget : fallbackCore;
        return arenaAnchor.method_10069(pos[0], pos[1], pos[2]);
    }
}
