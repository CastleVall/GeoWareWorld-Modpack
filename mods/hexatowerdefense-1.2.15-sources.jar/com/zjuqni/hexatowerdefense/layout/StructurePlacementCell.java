package com.zjuqni.hexatowerdefense.layout;

import net.minecraft.class_2338;

public final class StructurePlacementCell {
    public int id;
    public int laneId;
    public int row;
    public Area clickableGoldArea;
    public int[] structureAnchorDiamond;
    public boolean lockedLane;
    public boolean occupied;

    public StructurePlacementCell() {
    }

    public StructurePlacementCell(int id, int laneId, int row, Area clickableGoldArea, int[] structureAnchorDiamond, boolean lockedLane) {
        this.id = id;
        this.laneId = laneId;
        this.row = row;
        this.clickableGoldArea = clickableGoldArea;
        this.structureAnchorDiamond = structureAnchorDiamond;
        this.lockedLane = lockedLane;
        this.occupied = false;
    }

    public class_2338 anchorWorld(class_2338 arenaAnchor) {
        return arenaAnchor.method_10069(structureAnchorDiamond[0], structureAnchorDiamond[1], structureAnchorDiamond[2]);
    }

    public class_2338 centeredPlacementWorld(class_2338 arenaAnchor) {
        if (clickableGoldArea == null || clickableGoldArea.min == null || clickableGoldArea.max == null) {
            return anchorWorld(arenaAnchor);
        }
        int centerX = Math.round((clickableGoldArea.min[0] + clickableGoldArea.max[0]) / 2.0F);
        int centerZ = Math.round((clickableGoldArea.min[2] + clickableGoldArea.max[2]) / 2.0F);
        int y = Math.max(clickableGoldArea.min[1], clickableGoldArea.max[1]) + 1;
        return arenaAnchor.method_10069(centerX, y, centerZ);
    }

    public boolean containsRelative(class_2338 relativePos) {
        return clickableGoldArea != null && clickableGoldArea.contains(relativePos);
    }

    public static final class Area {
        public int[] min;
        public int[] max;

        public Area() {
        }

        public Area(int[] min, int[] max) {
            this.min = min;
            this.max = max;
        }

        public boolean contains(class_2338 relativePos) {
            return relativePos.method_10263() >= min[0] && relativePos.method_10263() <= max[0]
                    && relativePos.method_10264() >= min[1] && relativePos.method_10264() <= max[1]
                    && relativePos.method_10260() >= min[2] && relativePos.method_10260() <= max[2];
        }
    }
}
