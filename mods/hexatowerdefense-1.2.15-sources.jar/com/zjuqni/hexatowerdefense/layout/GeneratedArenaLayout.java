package com.zjuqni.hexatowerdefense.layout;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_238;

public final class GeneratedArenaLayout {
    public String source = "referencia.schem";
    public int[] offset = new int[]{0, 0, 0};
    public int mainMarkerY;
    public int[] playerSpawn;
    public int[] core;
    public String coreTargetBlock = "minecraft:shroomlight";
    public String coreTargetReason = "";
    public Shop shop;
    public Zone enemySpawnZone;
    public List<LaneDefinition> lanes = new ArrayList<>();
    public PlacementGrid placementGrid;
    public List<StructurePlacementCell> placementCells = new ArrayList<>();
    public List<Integer> lockedLanes = new ArrayList<>();
    public int unlockAtSecond = 900;
    public MarkerSummary markerSummary = new MarkerSummary();
    public List<String> warnings = new ArrayList<>();

    public class_2338 playerSpawnWorld(class_2338 arenaAnchor) {
        return world(arenaAnchor, playerSpawn);
    }

    public class_2338 shopWorld(class_2338 arenaAnchor) {
        return world(arenaAnchor, shop.position);
    }

    public class_2338 coreWorld(class_2338 arenaAnchor) {
        return world(arenaAnchor, core);
    }

    public class_2338 enemyZoneCenterWorld(class_2338 arenaAnchor) {
        return world(arenaAnchor, enemySpawnZone.center);
    }

    public class_238 gameplayBounds(class_2338 arenaAnchor) {
        int minX = min(playerSpawn[0], core[0], shop.position[0], enemySpawnZone.min[0]) - 12;
        int minY = min(playerSpawn[1], core[1], shop.position[1], enemySpawnZone.min[1]) - 12;
        int minZ = min(playerSpawn[2], core[2], shop.position[2], enemySpawnZone.min[2]) - 12;
        int maxX = max(playerSpawn[0], core[0], shop.position[0], enemySpawnZone.max[0]) + 12;
        int maxY = max(playerSpawn[1], core[1], shop.position[1], enemySpawnZone.max[1]) + 18;
        int maxZ = max(playerSpawn[2], core[2], shop.position[2], enemySpawnZone.max[2]) + 12;

        if (placementGrid != null) {
            for (int x : placementGrid.laneXs) {
                minX = Math.min(minX, x - 4);
                maxX = Math.max(maxX, x + 4);
            }
            for (int z : placementGrid.rowZs) {
                minZ = Math.min(minZ, z - 4);
                maxZ = Math.max(maxZ, z + 4);
            }
        }

        return new class_238(
                arenaAnchor.method_10263() + minX,
                arenaAnchor.method_10264() + minY,
                arenaAnchor.method_10260() + minZ,
                arenaAnchor.method_10263() + maxX + 1,
                arenaAnchor.method_10264() + maxY + 1,
                arenaAnchor.method_10260() + maxZ + 1
        );
    }

    public boolean isLaneLocked(int laneId, boolean lockedLanesUnlocked) {
        if (lockedLanesUnlocked) {
            return false;
        }
        return lockedLanes.contains(laneId);
    }

    public List<Integer> activeLaneIds(boolean lockedLanesUnlocked) {
        List<Integer> result = new ArrayList<>();
        for (LaneDefinition lane : lanes) {
            if (!isLaneLocked(lane.id, lockedLanesUnlocked)) {
                result.add(lane.id);
            }
        }
        return result;
    }

    public LaneDefinition laneById(int laneId) {
        for (LaneDefinition lane : lanes) {
            if (lane.id == laneId) {
                return lane;
            }
        }
        return null;
    }

    private static class_2338 world(class_2338 arenaAnchor, int[] relative) {
        return arenaAnchor.method_10069(relative[0], relative[1], relative[2]);
    }

    private static int min(int... values) {
        int result = Integer.MAX_VALUE;
        for (int value : values) {
            result = Math.min(result, value);
        }
        return result;
    }

    private static int max(int... values) {
        int result = Integer.MIN_VALUE;
        for (int value : values) {
            result = Math.max(result, value);
        }
        return result;
    }

    public static final class Shop {
        public int[] position;
        public String source;
    }

    public static final class Zone {
        public int[] min;
        public int[] max;
        public int[] center;
        public String source;
    }

    public static final class PlacementGrid {
        public List<Integer> laneXs = new ArrayList<>();
        public List<Integer> rowZs = new ArrayList<>();
        public int cellCount;
    }

    public static final class MarkerSummary {
        public int coalBlock;
        public int netheriteBlock;
        public int redstoneBlock;
        public int goldBlock;
        public int diamondBlock;
        public int emeraldBlock;
    }
}
