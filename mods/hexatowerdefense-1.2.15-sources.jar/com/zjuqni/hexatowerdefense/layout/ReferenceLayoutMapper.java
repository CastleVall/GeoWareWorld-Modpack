package com.zjuqni.hexatowerdefense.layout;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import com.zjuqni.hexatowerdefense.config.ConfigManager;
import com.zjuqni.hexatowerdefense.schematic.SchematicLoader;
import com.zjuqni.hexatowerdefense.schematic.SchematicTemplate;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.minecraft.class_2338;
import net.minecraft.class_2382;

public final class ReferenceLayoutMapper {
    private static final int SPAWN_ENTITY_Y_OFFSET = 1;
    private static final String BUILTIN_LAYOUT_VERSION = "builtin_reference_layout_v3";
    private static final int REFERENCE_GRID_MARKER_Y = 7;
    private static final int REFERENCE_PLACEMENT_LAYER_Y = 8;
    private static final int REFERENCE_GRID_CENTER_X = 47;
    private static final int REFERENCE_GRID_CENTER_Z = 58;
    private static GeneratedArenaLayout cachedLayout;

    public GeneratedArenaLayout loadOrGenerate() throws IOException {
        if (cachedLayout != null) {
            return cachedLayout;
        }
        SchematicTemplate activeTemplate = new SchematicLoader().load(ConfigManager.schematicPath());
        if (Files.exists(ConfigManager.generatedReferenceLayoutPath())) {
            cachedLayout = ConfigManager.readGeneratedJson(ConfigManager.generatedReferenceLayoutPath(), GeneratedArenaLayout.class);
            if (offsetMismatchesActiveSchematic(cachedLayout, activeTemplate)) {
                return activeBuiltinLayout("Generated layout offset does not match active schematic.", activeTemplate);
            }
            if (needsRegeneration(cachedLayout)) {
                cachedLayout = null;
                return scanOrFallback();
            }
            return cachedLayout;
        }
        if (!activeSchematicLooksLikeReference(activeTemplate)) {
            return activeBuiltinLayout("Active schematic is the clean arena; using transformed reference gameplay layout.", activeTemplate);
        }
        return scanOrFallback();
    }

    private GeneratedArenaLayout scanOrFallback() throws IOException {
        try {
            return scanAndGenerate();
        } catch (IOException | RuntimeException e) {
            SchematicTemplate activeTemplate = new SchematicLoader().load(ConfigManager.schematicPath());
            GeneratedArenaLayout layout = builtinReferenceLayout(e.getMessage(), activeTemplate);
            ConfigManager.writeJson(ConfigManager.generatedReferenceLayoutPath(), layout);
            cachedLayout = layout;
            HexaTowerDefenseMod.LOGGER.warn(
                    "[HexaTowerDefense] No se pudo mapear markers desde {}; usando layout interno de referencia para schematic limpia. Motivo: {}",
                    ConfigManager.referenceSchematicPath(),
                    e.getMessage()
            );
            return layout;
        }
    }

    private boolean offsetMismatchesActiveSchematic(GeneratedArenaLayout layout, SchematicTemplate activeTemplate) {
        if (layout == null || layout.offset == null || layout.offset.length < 3) {
            return true;
        }
        class_2382 activeOffset = activeTemplate.offset();
        return layout.offset[0] != activeOffset.method_10263()
                || layout.offset[1] != activeOffset.method_10264()
                || layout.offset[2] != activeOffset.method_10260();
    }

    private GeneratedArenaLayout activeBuiltinLayout(String reason, SchematicTemplate activeTemplate) throws IOException {
        GeneratedArenaLayout layout = builtinReferenceLayout(reason, activeTemplate);
        ConfigManager.writeJson(ConfigManager.generatedReferenceLayoutPath(), layout);
        cachedLayout = layout;
        return layout;
    }

    private static boolean activeSchematicLooksLikeReference(SchematicTemplate activeTemplate) {
        class_2382 offset = activeTemplate.offset();
        return activeTemplate.width() == 87
                && activeTemplate.height() == 71
                && activeTemplate.length() == 110
                && offset.method_10263() == 4
                && offset.method_10264() == 2
                && offset.method_10260() == 1;
    }

    public GeneratedArenaLayout scanAndGenerate() throws IOException {
        SchematicTemplate template = new SchematicLoader().load(ConfigManager.referenceSchematicPath());
        ReferenceMarkerScanner scanner = new ReferenceMarkerScanner();
        ReferenceMarkerScanner.ScanResult scan = scanner.scanAndWriteReport(template);
        GeneratedArenaLayout layout = buildLayout(template, scan);
        ConfigManager.writeJson(ConfigManager.generatedReferenceLayoutPath(), layout);
        cachedLayout = layout;

        HexaTowerDefenseMod.LOGGER.info(
                "[HexaTowerDefense] Reference scan complete: coal_block={} netherite_block={} redstone_block={} gold_block={} diamond_block={} emerald_block={} mainMarkerY={} cells={} lanes={} lockedLanes={}",
                layout.markerSummary.coalBlock,
                layout.markerSummary.netheriteBlock,
                layout.markerSummary.redstoneBlock,
                layout.markerSummary.goldBlock,
                layout.markerSummary.diamondBlock,
                layout.markerSummary.emeraldBlock,
                layout.mainMarkerY,
                layout.placementCells.size(),
                layout.lanes.size(),
                layout.lockedLanes
        );
        return layout;
    }

    public static void clearCache() {
        cachedLayout = null;
    }

    private static boolean needsRegeneration(GeneratedArenaLayout layout) {
        if (layout == null || layout.core == null || layout.lanes == null || layout.lanes.isEmpty()) {
            return true;
        }
        for (LaneDefinition lane : layout.lanes) {
            if (lane.coreTarget == null || lane.coreApproachPoint == null || lane.coreAttackPoint == null) {
                return true;
            }
        }
        if (layout.source != null && layout.source.startsWith("builtin_reference_layout")
                && !BUILTIN_LAYOUT_VERSION.equals(layout.source)) {
            return true;
        }
        return layout.coreTargetReason == null || layout.coreTargetReason.isBlank();
    }

    private GeneratedArenaLayout buildLayout(SchematicTemplate template, ReferenceMarkerScanner.ScanResult scan) {
        GeneratedArenaLayout layout = new GeneratedArenaLayout();
        layout.source = ConfigManager.referenceSchematicPath().getFileName().toString();
        layout.offset = new int[]{template.offset().method_10263(), template.offset().method_10264(), template.offset().method_10260()};
        layout.mainMarkerY = scan.mainMarkerY();
        fillMarkerSummary(layout, scan);
        validateReference(template, scan, layout);

        class_2338 coal = requireSingle(scan, ReferenceMarkerScanner.COAL, "coal_block");
        layout.playerSpawn = above(coal);

        List<class_2338> netherite = requireAny(scan, ReferenceMarkerScanner.NETHERITE, "netherite_block");
        Bounds shopBounds = Bounds.of(netherite);
        layout.shop = new GeneratedArenaLayout.Shop();
        layout.shop.position = new int[]{
                Math.round((shopBounds.minX + shopBounds.maxX) / 2.0F),
                shopBounds.maxY + SPAWN_ENTITY_Y_OFFSET,
                Math.round((shopBounds.minZ + shopBounds.maxZ) / 2.0F)
        };
        layout.shop.source = ReferenceMarkerScanner.NETHERITE;

        List<class_2338> redstone = requireAny(scan, ReferenceMarkerScanner.REDSTONE, "redstone_block");
        Bounds enemyBounds = Bounds.of(redstone);
        layout.enemySpawnZone = new GeneratedArenaLayout.Zone();
        layout.enemySpawnZone.min = new int[]{enemyBounds.minX, enemyBounds.minY, enemyBounds.minZ};
        layout.enemySpawnZone.max = new int[]{enemyBounds.maxX, enemyBounds.maxY, enemyBounds.maxZ};
        layout.enemySpawnZone.center = new int[]{
                Math.round((enemyBounds.minX + enemyBounds.maxX) / 2.0F),
                enemyBounds.maxY + SPAWN_ENTITY_Y_OFFSET,
                Math.round((enemyBounds.minZ + enemyBounds.maxZ) / 2.0F)
        };
        layout.enemySpawnZone.source = ReferenceMarkerScanner.REDSTONE;

        List<class_2338> diamondMain = requireAnyOnMainLayer(scan, ReferenceMarkerScanner.DIAMOND, "diamond_block");
        List<class_2338> goldMain = requireAnyOnMainLayer(scan, ReferenceMarkerScanner.GOLD, "gold_block");
        List<Integer> laneXs = sortedUnique(diamondMain.stream().map(class_2338::method_10263).toList());
        List<Integer> rowZs = sortedUnique(diamondMain.stream().map(class_2338::method_10260).toList());
        Set<Integer> lockedLaneXs = detectLockedLaneXs(scan, laneXs);

        layout.placementGrid = new GeneratedArenaLayout.PlacementGrid();
        layout.placementGrid.laneXs = laneXs;
        layout.placementGrid.rowZs = rowZs;
        layout.placementGrid.cellCount = diamondMain.size();

        layout.lockedLanes = new ArrayList<>();
        int id = 0;
        for (class_2338 diamond : diamondMain.stream()
                .sorted(Comparator.comparingInt(class_2338::method_10263).thenComparingInt(class_2338::method_10260))
                .toList()) {
            int laneId = laneXs.indexOf(diamond.method_10263());
            int row = rowZs.indexOf(diamond.method_10260());
            boolean locked = lockedLaneXs.contains(diamond.method_10263());
            if (locked && !layout.lockedLanes.contains(laneId)) {
                layout.lockedLanes.add(laneId);
            }
            StructurePlacementCell.Area goldArea = goldAreaForDiamond(goldMain, diamond);
            layout.placementCells.add(new StructurePlacementCell(
                    id++,
                    laneId,
                    row,
                    goldArea,
                    new int[]{diamond.method_10263(), diamond.method_10264() + SPAWN_ENTITY_Y_OFFSET, diamond.method_10260()},
                    locked
            ));
        }
        layout.lockedLanes.sort(Integer::compareTo);

        layout.core = generatedCorePosition(laneXs, rowZs, layout.mainMarkerY);
        CoreTargetDetector.Result coreTarget = new CoreTargetDetector().detect(template, layout.core);
        layout.coreTargetBlock = coreTarget.blockId();
        layout.coreTargetReason = coreTarget.reason();
        if (coreTarget.found()) {
            layout.core = coreTarget.target();
            layout.warnings.add("Core target mapped from " + coreTarget.blockId()
                    + " cluster size=" + coreTarget.selectedClusterSize()
                    + " clusters=" + coreTarget.clusterCount()
                    + " target=" + vec(layout.core) + ".");
        } else {
            layout.warnings.add("No " + coreTarget.blockId() + " core target found. Using generated core position "
                    + vec(layout.core) + ". Consider adding shroomlight around the geothermal core.");
        }

        for (int laneId = 0; laneId < laneXs.size(); laneId++) {
            int x = laneXs.get(laneId);
            boolean locked = layout.lockedLanes.contains(laneId);
            int[] enemySpawn = new int[]{x, layout.enemySpawnZone.center[1], layout.enemySpawnZone.center[2]};
            List<int[]> waypoints = new ArrayList<>();
            rowZs.stream().sorted(Comparator.reverseOrder()).forEach(z -> waypoints.add(new int[]{x, layout.enemySpawnZone.center[1], z}));
            if (waypoints.isEmpty() || waypoints.get(0)[2] != enemySpawn[2]) {
                waypoints.add(0, enemySpawn);
            }
            LaneDefinition lane = new LaneDefinition(laneId, x, locked, enemySpawn, waypoints);
            lane.coreApproachPoint = coreApproachForLane(x, layout.core);
            lane.coreAttackPoint = coreAttackPointForLane(laneId, laneXs.size(), layout.core);
            lane.coreTarget = layout.core;
            layout.lanes.add(lane);
        }

        addOutlierWarnings(layout, scan);
        return layout;
    }

    private GeneratedArenaLayout builtinReferenceLayout(String reason, SchematicTemplate activeTemplate) {
        LayoutTransform transform = LayoutTransform.forTemplate(activeTemplate);
        GeneratedArenaLayout layout = new GeneratedArenaLayout();
        layout.source = BUILTIN_LAYOUT_VERSION;
        layout.offset = new int[]{
                activeTemplate.offset().method_10263(),
                activeTemplate.offset().method_10264(),
                activeTemplate.offset().method_10260()
        };
        layout.mainMarkerY = transform.y(REFERENCE_PLACEMENT_LAYER_Y);
        layout.playerSpawn = transform.pos(47, 9, 31);
        layout.core = transform.pos(47, 9, 34);
        layout.coreTargetBlock = ConfigManager.general().coreTargetBlock;
        layout.coreTargetReason = "Built-in gameplay layout from referencia.schem markers; runtime schematic can be clean.";
        CoreTargetDetector.Result detectedCore = new CoreTargetDetector().detect(activeTemplate, layout.core);
        if (detectedCore.found()) {
            layout.core = detectedCore.target();
            layout.coreTargetBlock = detectedCore.blockId();
            layout.coreTargetReason = detectedCore.reason();
            layout.warnings.add("Core placed inside detected capsule target " + vec(layout.core)
                    + " from " + detectedCore.blockId() + " cluster.");
        }

        layout.shop = new GeneratedArenaLayout.Shop();
        layout.shop.position = transform.pos(32, 9, 30);
        layout.shop.source = "minecraft:netherite_block";

        layout.enemySpawnZone = new GeneratedArenaLayout.Zone();
        layout.enemySpawnZone.min = transform.pos(29, 8, 82);
        layout.enemySpawnZone.max = transform.pos(65, 8, 88);
        layout.enemySpawnZone.center = transform.pos(47, 9, 85);
        layout.enemySpawnZone.source = "minecraft:redstone_block";

        List<Integer> laneXs = new ArrayList<>(List.of(32, 38, 44, 50, 56, 62).stream().map(transform::x).toList());
        List<Integer> rowZs = new ArrayList<>(List.of(37, 43, 49, 55, 61, 67, 73, 79, 85).stream().map(transform::z).toList());
        layout.placementGrid = new GeneratedArenaLayout.PlacementGrid();
        layout.placementGrid.laneXs = laneXs;
        layout.placementGrid.rowZs = rowZs;
        layout.placementGrid.cellCount = laneXs.size() * rowZs.size();
        layout.lockedLanes = new ArrayList<>(List.of(0, 5));

        int id = 0;
        for (int laneId = 0; laneId < laneXs.size(); laneId++) {
            int x = laneXs.get(laneId);
            boolean locked = layout.lockedLanes.contains(laneId);
            for (int row = 0; row < rowZs.size(); row++) {
                int z = rowZs.get(row);
                layout.placementCells.add(new StructurePlacementCell(
                        id++,
                        laneId,
                        row,
                        new StructurePlacementCell.Area(
                                new int[]{x - 2, layout.mainMarkerY, z - 2},
                                new int[]{x + 2, layout.mainMarkerY, z + 2}
                        ),
                        new int[]{x, layout.mainMarkerY + SPAWN_ENTITY_Y_OFFSET, z},
                        locked
                ));
            }
        }

        for (int laneId = 0; laneId < laneXs.size(); laneId++) {
            int x = laneXs.get(laneId);
            boolean locked = layout.lockedLanes.contains(laneId);
            int[] enemySpawn = new int[]{x, layout.enemySpawnZone.center[1], layout.enemySpawnZone.center[2]};
            List<int[]> waypoints = new ArrayList<>();
            rowZs.stream().sorted(Comparator.reverseOrder()).forEach(z -> waypoints.add(new int[]{x, layout.mainMarkerY + SPAWN_ENTITY_Y_OFFSET, z}));
            if (waypoints.isEmpty() || waypoints.get(0)[2] != enemySpawn[2]) {
                waypoints.add(0, enemySpawn);
            }
            LaneDefinition lane = new LaneDefinition(laneId, x, locked, enemySpawn, waypoints);
            lane.coreApproachPoint = coreApproachForLane(x, layout.core);
            lane.coreAttackPoint = coreAttackPointForLane(laneId, laneXs.size(), layout.core);
            lane.coreTarget = layout.core;
            layout.lanes.add(lane);
        }

        layout.markerSummary.coalBlock = 1;
        layout.markerSummary.netheriteBlock = 24;
        layout.markerSummary.redstoneBlock = 109;
        layout.markerSummary.goldBlock = 439;
        layout.markerSummary.diamondBlock = 57;
        layout.markerSummary.emeraldBlock = 288;
        layout.warnings.add("Using built-in reference gameplay layout because the active schematic is clean and has no placement markers.");
        if (reason != null && !reason.isBlank()) {
            layout.warnings.add("Marker scan fallback reason: " + reason);
        }
        layout.warnings.add("Fallback transform delta=[" + transform.dx + ", " + transform.dy + ", " + transform.dz
                + "] derived from active schematic offset/legacy marker grid.");
        return layout;
    }

    private static int[] coreApproachForLane(int laneX, int[] core) {
        return new int[]{laneX, core[1], core[2] + 6};
    }

    private static int[] coreAttackPointForLane(int laneId, int laneCount, int[] core) {
        int centerLeft = Math.max(0, (laneCount - 1) / 2);
        int xOffset = Math.max(-1, Math.min(1, laneId - centerLeft));
        return new int[]{core[0] + xOffset, core[1], core[2] + 2};
    }

    private static void fillMarkerSummary(GeneratedArenaLayout layout, ReferenceMarkerScanner.ScanResult scan) {
        layout.markerSummary.coalBlock = scan.count(ReferenceMarkerScanner.COAL);
        layout.markerSummary.netheriteBlock = scan.count(ReferenceMarkerScanner.NETHERITE);
        layout.markerSummary.redstoneBlock = scan.count(ReferenceMarkerScanner.REDSTONE);
        layout.markerSummary.goldBlock = scan.count(ReferenceMarkerScanner.GOLD);
        layout.markerSummary.diamondBlock = scan.count(ReferenceMarkerScanner.DIAMOND);
        layout.markerSummary.emeraldBlock = scan.count(ReferenceMarkerScanner.EMERALD);
    }

    private static void validateReference(SchematicTemplate template, ReferenceMarkerScanner.ScanResult scan, GeneratedArenaLayout layout) {
        class_2382 offset = template.offset();
        if (template.width() != 87 || template.height() != 71 || template.length() != 110) {
            layout.warnings.add(String.format(Locale.ROOT,
                    "Reference dimensions are %dx%dx%d; expected 87x71x110.",
                    template.width(), template.height(), template.length()));
        }
        if (offset.method_10263() != 4 || offset.method_10264() != 2 || offset.method_10260() != 1) {
            layout.warnings.add("Reference offset is [" + offset.method_10263() + ", " + offset.method_10264() + ", " + offset.method_10260()
                    + "]; expected [4, 2, 1]. The mapper still uses local + offset.");
        }
        if (scan.mainMarkerY() != 8) {
            layout.warnings.add("Main marker layer detected as Y=" + scan.mainMarkerY() + "; expected Y=8.");
        }
    }

    private static void addOutlierWarnings(GeneratedArenaLayout layout, ReferenceMarkerScanner.ScanResult scan) {
        int goldOutliers = scan.outlierCount(ReferenceMarkerScanner.GOLD);
        if (goldOutliers > 0) {
            layout.warnings.add("Detected " + goldOutliers + " gold_block markers outside main marker layer Y="
                    + scan.mainMarkerY() + ". Ignoring for placement grid.");
        }
        int diamondOutliers = scan.outlierCount(ReferenceMarkerScanner.DIAMOND);
        if (diamondOutliers > 0) {
            layout.warnings.add("Detected " + diamondOutliers + " diamond_block markers outside main marker layer Y="
                    + scan.mainMarkerY() + ". Ignoring for placement grid.");
        }
    }

    private static int[] generatedCorePosition(List<Integer> laneXs, List<Integer> rowZs, int mainMarkerY) {
        int x = Math.round((laneXs.get(0) + laneXs.get(laneXs.size() - 1)) / 2.0F);
        int z = rowZs.get(0) - 3;
        return new int[]{x, mainMarkerY + SPAWN_ENTITY_Y_OFFSET, z};
    }

    private static Set<Integer> detectLockedLaneXs(ReferenceMarkerScanner.ScanResult scan, List<Integer> laneXs) {
        Set<Integer> emeraldXs = new LinkedHashSet<>();
        for (class_2338 emerald : scan.positionsOnMainLayer(ReferenceMarkerScanner.EMERALD)) {
            for (int laneX : laneXs) {
                if (Math.abs(emerald.method_10263() - laneX) <= 1) {
                    emeraldXs.add(laneX);
                }
            }
        }
        if (emeraldXs.isEmpty() && laneXs.size() >= 2) {
            emeraldXs.add(laneXs.get(0));
            emeraldXs.add(laneXs.get(laneXs.size() - 1));
        }
        return emeraldXs;
    }

    private static StructurePlacementCell.Area goldAreaForDiamond(List<class_2338> goldMain, class_2338 diamond) {
        List<class_2338> near = goldMain.stream()
                .filter(pos -> Math.abs(pos.method_10263() - diamond.method_10263()) <= 2)
                .filter(pos -> Math.abs(pos.method_10260() - diamond.method_10260()) <= 2)
                .toList();
        if (near.isEmpty()) {
            return new StructurePlacementCell.Area(
                    new int[]{diamond.method_10263() - 1, diamond.method_10264(), diamond.method_10260() - 1},
                    new int[]{diamond.method_10263() + 1, diamond.method_10264(), diamond.method_10260() + 1}
            );
        }
        Bounds bounds = Bounds.of(near);
        return new StructurePlacementCell.Area(
                new int[]{bounds.minX, bounds.minY, bounds.minZ},
                new int[]{bounds.maxX, bounds.maxY, bounds.maxZ}
        );
    }

    private static class_2338 requireSingle(ReferenceMarkerScanner.ScanResult scan, String marker, String display) {
        List<class_2338> positions = requireAny(scan, marker, display);
        if (positions.size() != 1) {
            throw new IllegalStateException("referencia.schem debe tener exactamente 1 " + display + "; encontro " + positions.size());
        }
        return positions.get(0);
    }

    private static List<class_2338> requireAny(ReferenceMarkerScanner.ScanResult scan, String marker, String display) {
        List<class_2338> positions = scan.positions(marker);
        if (positions.isEmpty()) {
            throw new IllegalStateException("referencia.schem no contiene marker obligatorio " + display);
        }
        return positions;
    }

    private static List<class_2338> requireAnyOnMainLayer(ReferenceMarkerScanner.ScanResult scan, String marker, String display) {
        List<class_2338> positions = scan.positionsOnMainLayer(marker);
        if (positions.isEmpty()) {
            throw new IllegalStateException("referencia.schem no contiene " + display + " en mainMarkerY=" + scan.mainMarkerY());
        }
        return positions;
    }

    private static List<Integer> sortedUnique(List<Integer> values) {
        return values.stream().distinct().sorted().toList();
    }

    private static int[] above(class_2338 marker) {
        return new int[]{marker.method_10263(), marker.method_10264() + SPAWN_ENTITY_Y_OFFSET, marker.method_10260()};
    }

    private static String vec(int[] value) {
        return "[" + value[0] + ", " + value[1] + ", " + value[2] + "]";
    }

    private static final class LayoutTransform {
        final int dx;
        final int dy;
        final int dz;

        private LayoutTransform(int dx, int dy, int dz) {
            this.dx = dx;
            this.dy = dy;
            this.dz = dz;
        }

        static LayoutTransform forTemplate(SchematicTemplate template) {
            LegacyMarkerCenter legacy = LegacyMarkerCenter.detect(template);
            if (legacy != null) {
                return new LayoutTransform(
                        legacy.centerX - REFERENCE_GRID_CENTER_X,
                        legacy.mainY - REFERENCE_GRID_MARKER_Y,
                        legacy.centerZ - REFERENCE_GRID_CENTER_Z
                );
            }

            class_2382 offset = template.offset();
            if (template.width() == 98
                    && template.height() == 74
                    && template.length() == 119
                    && offset.method_10263() == -47
                    && offset.method_10264() == -12
                    && offset.method_10260() == -64) {
                return new LayoutTransform(-48, -9, -59);
            }

            return new LayoutTransform(offset.method_10263() - 4, offset.method_10264() - 2, offset.method_10260() - 1);
        }

        int[] pos(int x, int y, int z) {
            return new int[]{x(x), y(y), z(z)};
        }

        int x(int value) {
            return value + dx;
        }

        int y(int value) {
            return value + dy;
        }

        int z(int value) {
            return value + dz;
        }
    }

    private static final class LegacyMarkerCenter {
        final int centerX;
        final int mainY;
        final int centerZ;

        private LegacyMarkerCenter(int centerX, int mainY, int centerZ) {
            this.centerX = centerX;
            this.mainY = mainY;
            this.centerZ = centerZ;
        }

        static LegacyMarkerCenter detect(SchematicTemplate template) {
            List<class_2338> markers = new ArrayList<>();
            addRelativeMarkers(template, markers, "minecraft:lime_concrete");
            addRelativeMarkers(template, markers, "minecraft:light_blue_concrete");
            if (markers.isEmpty()) {
                addRelativeMarkers(template, markers, "minecraft:red_concrete");
            }
            if (markers.isEmpty()) {
                return null;
            }

            int minX = Integer.MAX_VALUE;
            int maxX = Integer.MIN_VALUE;
            int minZ = Integer.MAX_VALUE;
            int maxZ = Integer.MIN_VALUE;
            java.util.Map<Integer, Integer> yCounts = new java.util.LinkedHashMap<>();
            for (class_2338 pos : markers) {
                minX = Math.min(minX, pos.method_10263());
                maxX = Math.max(maxX, pos.method_10263());
                minZ = Math.min(minZ, pos.method_10260());
                maxZ = Math.max(maxZ, pos.method_10260());
                yCounts.merge(pos.method_10264(), 1, Integer::sum);
            }
            int mainY = yCounts.entrySet().stream()
                    .max(java.util.Map.Entry.comparingByValue())
                    .map(java.util.Map.Entry::getKey)
                    .orElse(template.offset().method_10264() + 10);
            return new LegacyMarkerCenter(
                    Math.round((minX + maxX) / 2.0F),
                    mainY,
                    Math.round((minZ + maxZ) / 2.0F)
            );
        }

        private static void addRelativeMarkers(SchematicTemplate template, List<class_2338> target, String blockState) {
            List<class_2338> localPositions = template.markerBlocks().get(blockState);
            if (localPositions == null) {
                return;
            }
            class_2382 offset = template.offset();
            for (class_2338 local : localPositions) {
                target.add(new class_2338(
                        local.method_10263() + offset.method_10263(),
                        local.method_10264() + offset.method_10264(),
                        local.method_10260() + offset.method_10260()
                ));
            }
        }
    }

    private static final class Bounds {
        final int minX;
        final int minY;
        final int minZ;
        final int maxX;
        final int maxY;
        final int maxZ;

        private Bounds(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
            this.minX = minX;
            this.minY = minY;
            this.minZ = minZ;
            this.maxX = maxX;
            this.maxY = maxY;
            this.maxZ = maxZ;
        }

        static Bounds of(List<class_2338> positions) {
            int minX = Integer.MAX_VALUE;
            int minY = Integer.MAX_VALUE;
            int minZ = Integer.MAX_VALUE;
            int maxX = Integer.MIN_VALUE;
            int maxY = Integer.MIN_VALUE;
            int maxZ = Integer.MIN_VALUE;
            for (class_2338 pos : positions) {
                minX = Math.min(minX, pos.method_10263());
                minY = Math.min(minY, pos.method_10264());
                minZ = Math.min(minZ, pos.method_10260());
                maxX = Math.max(maxX, pos.method_10263());
                maxY = Math.max(maxY, pos.method_10264());
                maxZ = Math.max(maxZ, pos.method_10260());
            }
            return new Bounds(minX, minY, minZ, maxX, maxY, maxZ);
        }
    }
}
