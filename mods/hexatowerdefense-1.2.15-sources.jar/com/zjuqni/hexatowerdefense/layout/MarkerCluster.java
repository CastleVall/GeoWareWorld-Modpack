package com.zjuqni.hexatowerdefense.layout;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;

public final class MarkerCluster {
    public String blockState;
    public int count;
    public int[] min;
    public int[] max;
    public int[] center;
    public List<int[]> positions = new ArrayList<>();

    public MarkerCluster() {
    }

    public MarkerCluster(String blockState, List<class_2338> relativePositions) {
        this.blockState = blockState;
        this.count = relativePositions.size();
        int minX = Integer.MAX_VALUE;
        int minY = Integer.MAX_VALUE;
        int minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE;
        int maxY = Integer.MIN_VALUE;
        int maxZ = Integer.MIN_VALUE;

        for (class_2338 pos : relativePositions) {
            positions.add(new int[]{pos.method_10263(), pos.method_10264(), pos.method_10260()});
            minX = Math.min(minX, pos.method_10263());
            minY = Math.min(minY, pos.method_10264());
            minZ = Math.min(minZ, pos.method_10260());
            maxX = Math.max(maxX, pos.method_10263());
            maxY = Math.max(maxY, pos.method_10264());
            maxZ = Math.max(maxZ, pos.method_10260());
        }

        if (relativePositions.isEmpty()) {
            minX = minY = minZ = maxX = maxY = maxZ = 0;
        }

        this.min = new int[]{minX, minY, minZ};
        this.max = new int[]{maxX, maxY, maxZ};
        this.center = new int[]{
                Math.round((minX + maxX) / 2.0F),
                Math.round((minY + maxY) / 2.0F),
                Math.round((minZ + maxZ) / 2.0F)
        };
    }
}
