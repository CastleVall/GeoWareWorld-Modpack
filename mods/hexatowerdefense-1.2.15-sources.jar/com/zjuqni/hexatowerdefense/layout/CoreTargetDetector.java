package com.zjuqni.hexatowerdefense.layout;

import com.zjuqni.hexatowerdefense.config.ConfigManager;
import com.zjuqni.hexatowerdefense.schematic.SchematicTemplate;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import net.minecraft.class_2338;

public final class CoreTargetDetector {
    public Result detect(SchematicTemplate template, int[] fallbackCore) {
        String targetBlock = ConfigManager.general().coreTargetBlock;
        List<class_2338> localPositions = template.markerBlocks().getOrDefault(targetBlock, List.of());
        if (localPositions.isEmpty()) {
            return Result.missing(targetBlock);
        }

        List<class_2338> relativePositions = localPositions.stream()
                .map(pos -> template.localToRelative(pos.method_10263(), pos.method_10264(), pos.method_10260()))
                .toList();
        List<List<class_2338>> clusters = cluster(relativePositions);
        class_2338 fallback = new class_2338(fallbackCore[0], fallbackCore[1], fallbackCore[2]);
        List<class_2338> selected = clusters.stream()
                .min(Comparator.comparingDouble(cluster -> center(cluster).method_10262(fallback)))
                .orElse(List.of());
        if (selected.isEmpty()) {
            return Result.missing(targetBlock);
        }

        class_2338 center = center(selected);
        return new Result(
                true,
                targetBlock,
                new int[]{center.method_10263(), center.method_10264(), center.method_10260()},
                selected.size(),
                clusters.size(),
                "Using nearest " + targetBlock + " cluster as core target."
        );
    }

    private static List<List<class_2338>> cluster(List<class_2338> positions) {
        Set<class_2338> remaining = new HashSet<>(positions);
        List<List<class_2338>> clusters = new ArrayList<>();
        while (!remaining.isEmpty()) {
            class_2338 seed = remaining.iterator().next();
            remaining.remove(seed);
            List<class_2338> cluster = new ArrayList<>();
            Queue<class_2338> queue = new ArrayDeque<>();
            queue.add(seed);
            while (!queue.isEmpty()) {
                class_2338 current = queue.remove();
                cluster.add(current);
                List<class_2338> neighbors = remaining.stream()
                        .filter(pos -> manhattan(current, pos) <= 2)
                        .toList();
                for (class_2338 neighbor : neighbors) {
                    remaining.remove(neighbor);
                    queue.add(neighbor);
                }
            }
            clusters.add(cluster);
        }
        return clusters;
    }

    private static class_2338 center(List<class_2338> positions) {
        int minX = Integer.MAX_VALUE;
        int minY = Integer.MAX_VALUE;
        int minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE;
        int maxY = Integer.MIN_VALUE;
        int maxZ = Integer.MIN_VALUE;
        for (class_2338 pos : positions) {
            minX = Math.min(minX, pos.method_10263());
            minY = Math.min(minY, pos.method_10264());
            minZ = Math.min(minZ, pos.method_10260());
            maxX = Math.max(maxX, pos.method_10263());
            maxY = Math.max(maxY, pos.method_10264());
            maxZ = Math.max(maxZ, pos.method_10260());
        }
        return new class_2338(
                Math.round((minX + maxX) / 2.0F),
                Math.round((minY + maxY) / 2.0F),
                Math.round((minZ + maxZ) / 2.0F)
        );
    }

    private static int manhattan(class_2338 first, class_2338 second) {
        return Math.abs(first.method_10263() - second.method_10263())
                + Math.abs(first.method_10264() - second.method_10264())
                + Math.abs(first.method_10260() - second.method_10260());
    }

    public record Result(boolean found, String blockId, int[] target, int selectedClusterSize, int clusterCount, String reason) {
        static Result missing(String blockId) {
            return new Result(false, blockId, null, 0, 0, "No " + blockId + " core target cluster found.");
        }
    }
}
