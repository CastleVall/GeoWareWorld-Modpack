package com.zjuqni.hexatowerdefense.layout;

import com.zjuqni.hexatowerdefense.config.ConfigManager;
import com.zjuqni.hexatowerdefense.schematic.SchematicTemplate;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2338;

public final class ReferenceMarkerScanner {
    public static final String COAL = "minecraft:coal_block";
    public static final String NETHERITE = "minecraft:netherite_block";
    public static final String REDSTONE = "minecraft:redstone_block";
    public static final String GOLD = "minecraft:gold_block";
    public static final String DIAMOND = "minecraft:diamond_block";
    public static final String EMERALD = "minecraft:emerald_block";

    public static final List<String> OFFICIAL_MARKERS = List.of(COAL, NETHERITE, REDSTONE, GOLD, DIAMOND, EMERALD);

    public ScanResult scanAndWriteReport(SchematicTemplate template) throws IOException {
        ScanResult result = scan(template);
        ReferenceMarkerReport report = ReferenceMarkerReport.from(template, result);
        ConfigManager.writeJson(ConfigManager.referenceMarkerReportPath(), report);
        return result;
    }

    public ScanResult scan(SchematicTemplate template) {
        Map<String, List<class_2338>> relativeMarkers = new LinkedHashMap<>();
        for (String marker : OFFICIAL_MARKERS) {
            List<class_2338> positions = template.markerBlocks().getOrDefault(marker, List.of()).stream()
                    .map(pos -> template.localToRelative(pos.method_10263(), pos.method_10264(), pos.method_10260()))
                    .sorted(Comparator.comparingInt(class_2338::method_10264)
                            .thenComparingInt(class_2338::method_10260)
                            .thenComparingInt(class_2338::method_10263))
                    .toList();
            relativeMarkers.put(marker, positions);
        }

        int mainMarkerY = dominantY(relativeMarkers.get(GOLD), relativeMarkers.get(DIAMOND));
        return new ScanResult(relativeMarkers, mainMarkerY);
    }

    @SafeVarargs
    private static int dominantY(List<class_2338>... groups) {
        Map<Integer, Integer> counts = new LinkedHashMap<>();
        for (List<class_2338> group : groups) {
            for (class_2338 pos : group) {
                counts.merge(pos.method_10264(), 1, Integer::sum);
            }
        }
        return counts.entrySet().stream()
                .max(Map.Entry.<Integer, Integer>comparingByValue()
                        .thenComparing(Map.Entry.comparingByKey()))
                .map(Map.Entry::getKey)
                .orElse(0);
    }

    public record ScanResult(Map<String, List<class_2338>> relativeMarkers, int mainMarkerY) {
        public List<class_2338> positions(String marker) {
            return relativeMarkers.getOrDefault(marker, List.of());
        }

        public int count(String marker) {
            return positions(marker).size();
        }

        public List<class_2338> positionsOnMainLayer(String marker) {
            return positions(marker).stream()
                    .filter(pos -> pos.method_10264() == mainMarkerY)
                    .toList();
        }

        public int outlierCount(String marker) {
            return Math.max(0, count(marker) - positionsOnMainLayer(marker).size());
        }
    }

    public static final class ReferenceMarkerReport {
        public String source = "referencia.schem";
        public int[] dimensions;
        public int[] offset;
        public int mainMarkerY;
        public Map<String, MarkerCluster> markers = new LinkedHashMap<>();
        public List<String> warnings = new ArrayList<>();

        static ReferenceMarkerReport from(SchematicTemplate template, ScanResult result) {
            ReferenceMarkerReport report = new ReferenceMarkerReport();
            report.dimensions = new int[]{template.width(), template.height(), template.length()};
            report.offset = new int[]{template.offset().method_10263(), template.offset().method_10264(), template.offset().method_10260()};
            report.mainMarkerY = result.mainMarkerY();
            for (String marker : OFFICIAL_MARKERS) {
                report.markers.put(marker, new MarkerCluster(marker, result.positions(marker)));
            }
            appendOutlierWarning(report, result, GOLD, "gold_block");
            appendOutlierWarning(report, result, DIAMOND, "diamond_block");
            return report;
        }

        private static void appendOutlierWarning(ReferenceMarkerReport report, ScanResult result, String marker, String display) {
            int outliers = result.outlierCount(marker);
            if (outliers > 0) {
                report.warnings.add("Detected " + outliers + " " + display + " markers outside main marker layer Y="
                        + result.mainMarkerY() + ". Ignoring for placement grid.");
            }
        }
    }

    public static Path reportPath() {
        return ConfigManager.referenceMarkerReportPath();
    }
}
