package com.zjuqni.hexatowerdefense;

import com.zjuqni.hexatowerdefense.client.hud.HTDHud;
import com.zjuqni.hexatowerdefense.registry.ModEntityRenderers;
import com.zjuqni.hexatowerdefense.client.ClientNetworking;
import net.fabricmc.api.ClientModInitializer;

public final class HexaTowerDefenseClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ModEntityRenderers.init();
        ClientNetworking.init();
        HTDHud.init();
    }
}
