package com.zjuqni.hexatowerdefense.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import com.zjuqni.hexatowerdefense.enemy.EnemyRuntimeStats;
import com.zjuqni.hexatowerdefense.enemy.EnemyType;
import com.zjuqni.hexatowerdefense.tower.TowerType;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final String CONFIG_DIR_NAME = "hexatowerdefense";

    private static Path configDir;
    private static GeneralConfig generalConfig;
    private static MarkerConfig markerConfig;
    private static ArenaLayoutConfig arenaLayoutConfig;
    private static Map<String, String> yamlValues = new LinkedHashMap<>();

    private ConfigManager() {
    }

    public static void init() {
        configDir = FabricLoader.getInstance().getConfigDir().resolve(CONFIG_DIR_NAME);
        try {
            Files.createDirectories(configDir);
            ensureDefaults();
            archiveLegacyJsonConfigs();
            reload();
            ensureDefaultSchematic();
            ensureDefaultReferenceSchematic();
        } catch (IOException | RuntimeException e) {
            throw new IllegalStateException("No se pudieron preparar las configs de HexaTowerDefense", e);
        }
    }

    public static void reload() throws IOException {
        yamlValues = readYaml(configDir.resolve("config.yml"));
        GeneralConfig loadedGeneral = new GeneralConfig();
        MarkerConfig loadedMarkers = defaultMarkers();
        ArenaLayoutConfig loadedLayout = new ArenaLayoutConfig();
        applyYaml(loadedGeneral);
        migrateGeneral(loadedGeneral);
        validateAndNormalize(loadedGeneral, loadedMarkers, loadedLayout);

        generalConfig = loadedGeneral;
        markerConfig = loadedMarkers;
        arenaLayoutConfig = loadedLayout;
    }

    public static Path getConfigDir() {
        return configDir;
    }

    public static GeneralConfig general() {
        return generalConfig;
    }

    public static MarkerConfig markers() {
        return markerConfig;
    }

    public static ArenaLayoutConfig arenaLayout() {
        return arenaLayoutConfig;
    }

    public static Path resolveConfiguredPath(String rawPath) {
        if (rawPath == null || rawPath.isBlank()) {
            throw new IllegalArgumentException("La ruta configurada no puede estar vacia.");
        }
        Path path = Paths.get(rawPath);
        if (path.isAbsolute()) {
            return path.normalize();
        }
        return FabricLoader.getInstance().getGameDir().resolve(path).normalize();
    }

    public static Path schematicPath() {
        return resolveConfiguredPath(generalConfig.schematicPath);
    }

    public static Path referenceSchematicPath() {
        return resolveConfiguredPath(generalConfig.referenceSchematicPath);
    }

    public static Path markerReportPath() {
        return configDir.resolve("generated_marker_report.json");
    }

    public static Path referenceMarkerReportPath() {
        return configDir.resolve("reference_marker_report.json");
    }

    public static Path generatedReferenceLayoutPath() {
        String configured = stringValue("general.generatedLayoutPath", "config/hexatowerdefense/generated_layout_from_reference.json");
        return resolveConfiguredPath(configured);
    }

    public static EnemyRuntimeStats enemyStats(EnemyType type) {
        String key = type.name().toLowerCase(Locale.ROOT);
        return new EnemyRuntimeStats(
                doubleValue("enemies." + key + ".health", defaultEnemyHealth(type)),
                intValue("enemies." + key + ".coreDamage", defaultEnemyCoreDamage(type)),
                doubleValue("enemies." + key + ".speed", defaultEnemySpeed(type)),
                doubleValue("enemies." + key + ".attackRange", type == EnemyType.LAVA_GOLEM ? 4.0D : 3.0D),
                doubleValue("enemies." + key + ".stopDistance", type == EnemyType.LAVA_GOLEM ? 3.0D : 2.2D),
                intValue("enemies." + key + ".attackCooldownTicks", type == EnemyType.LAVA_GOLEM ? 60 : 40)
        );
    }

    public static int enemyCellReward(EnemyType type) {
        String key = type.name().toLowerCase(Locale.ROOT);
        return Math.max(0, intValue("enemies." + key + ".cellReward", defaultEnemyCellReward(type)));
    }

    private static int defaultEnemyCellReward(EnemyType type) {
        return switch (type) {
            case BLUE_MINION -> 3;
            case PURPLE_MINION -> 5;
            case GREEN_KNIGHT_MINION -> 4;
            case BLUE_KNIGHT_MINION -> 6;
            case PURPLE_KNIGHT_MINION -> 8;
            case LAVA_GOLEM -> 25;
            default -> 2;
        };
    }

    public static int shopPrice(String itemId, int fallback) {
        return intValue("shop.items." + itemId + ".price", fallback);
    }

    public static String shopDisplay(String itemId, String fallback) {
        return stringValue("shop.items." + itemId + ".display", fallback);
    }

    public static int shopLimit(String itemId, int fallback) {
        return intValue("shop.items." + itemId + ".limit", fallback);
    }

    public static int panelSolarProductionAmount(int level) {
        int safeLevel = Math.max(1, level);
        int configured = intValue("towers.panel_solar.levels." + safeLevel + ".productionAmount", defaultPanelSolarProductionAmount(safeLevel));
        return Math.max(defaultPanelSolarProductionAmount(safeLevel), configured);
    }

    public static int panelSolarProductionIntervalTicks(int level) {
        int safeLevel = Math.max(1, level);
        int configured = intValue("towers.panel_solar.levels." + safeLevel + ".productionIntervalTicks", defaultPanelSolarProductionIntervalTicks(safeLevel));
        return Math.max(1, configured);
    }

    public static int towerHealth(TowerType type, int level) {
        String key = towerKey(type);
        int safeLevel = Math.max(1, level);
        return intValue("towers." + key + ".levels." + safeLevel + ".health", defaultTowerHealth(type, safeLevel));
    }

    public static double towerDamage(TowerType type, int level) {
        String key = towerKey(type);
        int safeLevel = Math.max(1, level);
        return doubleValue("towers." + key + ".levels." + safeLevel + ".damage", defaultTowerDamage(type, safeLevel));
    }

    public static double towerRange(TowerType type, int level) {
        String key = towerKey(type);
        int safeLevel = Math.max(1, level);
        return doubleValue("towers." + key + ".levels." + safeLevel + ".range", defaultTowerRange(type, safeLevel));
    }

    public static int towerCooldownTicks(TowerType type, int level) {
        String key = towerKey(type);
        int safeLevel = Math.max(1, level);
        return intValue("towers." + key + ".levels." + safeLevel + ".cooldownTicks", defaultTowerCooldown(type, safeLevel));
    }

    public static double towerAreaRadius(TowerType type, int level) {
        String key = towerKey(type);
        int safeLevel = Math.max(1, level);
        return doubleValue("towers." + key + ".levels." + safeLevel + ".areaRadius", defaultTowerAreaRadius(type));
    }

    public static void writeJson(Path path, Object value) throws IOException {
        createParentDirectories(path);
        Files.writeString(path, GSON.toJson(value));
    }

    public static <T> T readGeneratedJson(Path path, Class<T> type) throws IOException {
        return readJson(path, type);
    }

    private static <T> T readJson(Path path, Class<T> type) throws IOException {
        try (Reader reader = Files.newBufferedReader(path)) {
            return Objects.requireNonNull(GSON.fromJson(reader, type), "Config vacia: " + path);
        }
    }

    private static void ensureDefaults() throws IOException {
        writeIfMissing("config.yml", defaultConfigYaml());
        appendIfMissing("config.yml", "points:", defaultPointsYaml());
        Files.createDirectories(configDir.resolve("schematics"));
    }

    private static void ensureDefaultSchematic() throws IOException {
        Path schematicPath = schematicPath();
        if (Files.exists(schematicPath)) {
            return;
        }

        createParentDirectories(schematicPath);
        String resourceName = schematicPath.getFileName() != null && "referencia.schem".equals(schematicPath.getFileName().toString())
                ? "referencia.schem"
                : "y1p.schem";
        try (InputStream input = ConfigManager.class.getResourceAsStream("/defaults/hexatowerdefense/schematics/" + resourceName)) {
            if (input == null) {
                HexaTowerDefenseMod.LOGGER.warn("No default {} resource found; expected {}", resourceName, schematicPath);
                return;
            }
            Files.copy(input, schematicPath);
        }
    }

    private static void ensureDefaultReferenceSchematic() throws IOException {
        Path schematicPath = referenceSchematicPath();
        if (schematicPath.equals(schematicPath())) {
            return;
        }
        if (Files.exists(schematicPath)) {
            return;
        }

        createParentDirectories(schematicPath);
        try (InputStream input = ConfigManager.class.getResourceAsStream("/defaults/hexatowerdefense/schematics/referencia.schem")) {
            if (input == null) {
                HexaTowerDefenseMod.LOGGER.warn("No default referencia.schem resource found; expected {}", schematicPath);
                return;
            }
            Files.copy(input, schematicPath);
        }
    }

    private static void writeIfMissing(String fileName, String content) throws IOException {
        Path path = configDir.resolve(fileName);
        if (Files.exists(path)) {
            return;
        }
        createParentDirectories(path);
        Files.writeString(path, content);
    }

    private static void appendIfMissing(String fileName, String needle, String content) throws IOException {
        Path path = configDir.resolve(fileName);
        if (!Files.exists(path)) {
            return;
        }
        String existing = Files.readString(path);
        if (existing.contains(needle)) {
            return;
        }
        Files.writeString(path, existing.stripTrailing() + System.lineSeparator() + System.lineSeparator() + content);
    }

    private static void createParentDirectories(Path path) throws IOException {
        Path parent = path.getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }
    }

    private static void archiveLegacyJsonConfigs() throws IOException {
        String[] legacyFiles = {
                "general.json",
                "arena_layout.json",
                "markers.json",
                "towers.json",
                "enemies.json",
                "waves.json",
                "shop.json",
                "items.json",
                "debug.json"
        };
        Path legacyDir = configDir.resolve("legacy_json");
        for (String fileName : legacyFiles) {
            Path source = configDir.resolve(fileName);
            if (!Files.exists(source)) {
                continue;
            }
            Files.createDirectories(legacyDir);
            Path target = legacyDir.resolve(fileName);
            if (Files.exists(target)) {
                target = legacyDir.resolve(fileName + ".old");
            }
            Files.move(source, target);
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] Archived legacy config {} to {}", source.getFileName(), target);
        }
    }

    private static void validateAndNormalize(GeneralConfig general, MarkerConfig markers, ArenaLayoutConfig layout) {
        if (!"hexatowerdefense:instances".equals(general.dimension)) {
            throw new IllegalArgumentException("config.yml: general.dimension debe ser hexatowerdefense:instances.");
        }
        if (general.arenaSpacing <= 0) {
            throw new IllegalArgumentException("config.yml: general.arenaSpacing debe ser mayor que 0.");
        }
        if (general.arenaColumns <= 0) {
            throw new IllegalArgumentException("config.yml: general.arenaColumns debe ser mayor que 0.");
        }
        if (general.maxArenas <= 0) {
            throw new IllegalArgumentException("config.yml: general.maxArenas debe ser mayor que 0.");
        }
        if (general.schematicBlocksPerTick <= 0) {
            throw new IllegalArgumentException("config.yml: general.schematicBlocksPerTick debe ser mayor que 0.");
        }
        if (general.preloadBlocksPerTick <= 0) {
            throw new IllegalArgumentException("config.yml: general.preloadBlocksPerTick debe ser mayor que 0.");
        }
        if (general.maxParallelPasteTasks <= 0) {
            throw new IllegalArgumentException("config.yml: general.maxParallelPasteTasks debe ser mayor que 0.");
        }
        if (general.cleanupBlocksPerTick <= 0) {
            throw new IllegalArgumentException("config.yml: general.cleanupBlocksPerTick debe ser mayor que 0.");
        }
        if (!"TRACKED_ONLY".equalsIgnoreCase(general.clearMode)
                && !"BOUNDING_BOX".equalsIgnoreCase(general.clearMode)) {
            throw new IllegalArgumentException("config.yml: general.clearMode debe ser TRACKED_ONLY o BOUNDING_BOX.");
        }
        general.shinyMobSpawnChance = Math.max(0.0D, Math.min(1.0D, general.shinyMobSpawnChance));
        general.shinyMobPointReward = Math.max(0, general.shinyMobPointReward);
        general.pasteMillisPerTick = Math.max(1.0D, Math.min(40.0D, general.pasteMillisPerTick));
        general.slowTickThresholdMs = Math.max(50.0D, general.slowTickThresholdMs);
        general.coreAttackerDamageTakenMultiplier = Math.max(1.0D, Math.min(5.0D, general.coreAttackerDamageTakenMultiplier));
        general.panelSolarMaxUncollected = Math.max(1, general.panelSolarMaxUncollected);

        if (markers.markerRoles == null) {
            markers.markerRoles = new LinkedHashMap<>();
        }
        if (markers.replacementBlocks == null) {
            markers.replacementBlocks = new LinkedHashMap<>();
        }

        if (layout.bounds == null) {
            layout.bounds = new ArenaLayoutConfig.BoundsConfig();
        }
        if (layout.grid == null) {
            layout.grid = new ArenaLayoutConfig.GridConfig();
        }
        if (layout.lanes == null) {
            layout.lanes = new ArenaLayoutConfig.LaneConfig[0];
        }
    }

    private static void migrateGeneral(GeneralConfig general) {
        if (general.referenceSchematicPath == null || general.referenceSchematicPath.isBlank()) {
            general.referenceSchematicPath = "config/hexatowerdefense/schematics/y1p.schem";
        }
        if (general.schematicPath == null
                || general.schematicPath.isBlank()
                || "config/hexatowerdefense/schematics/referencia.schem".equals(general.schematicPath)) {
            general.schematicPath = "config/hexatowerdefense/schematics/y1p.schem";
        }
        if ("config/hexatowerdefense/schematics/referencia.schem".equals(general.referenceSchematicPath)) {
            general.referenceSchematicPath = "config/hexatowerdefense/schematics/y1p.schem";
        }
        if (Math.abs(general.shinyMobSpawnChance - 0.05D) < 1.0E-6D || Math.abs(general.shinyMobSpawnChance - 0.10D) < 1.0E-6D) {
            general.shinyMobSpawnChance = 0.20D;
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] shinyMobs.spawnChance (valor antiguo) actualizado a 0.20");
        }
        if (general.shinyMobPointReward == 10) {
            general.shinyMobPointReward = 5;
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] shinyMobs.pointReward 10 (valor antiguo) actualizado a 5");
        }
        if (general.startingEnergy == 100) {
            general.startingEnergy = 50;
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] startingEnergy 100 (valor antiguo) actualizado a 50 por el modo dúo");
        }
        if (general.preparationSeconds == 60) {
            general.preparationSeconds = 90;
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] preparationSeconds 60 (valor antiguo) actualizado a 90");
        }
        if (general.activationsPerTick == 1 && general.activationIntervalTicks == 20) {
            general.activationsPerTick = 2;
            general.activationIntervalTicks = 10;
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] Reparto de arenas acelerado: 2 activaciones cada 10 ticks (antes 1 cada 20)");
        }
        if (general.preloadBlocksPerTick == 1000) {
            general.preloadBlocksPerTick = 4000;
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] preloadBlocksPerTick 1000 (valor antiguo) actualizado a 4000; el freno automatico lo baja solo si el servidor se lagea");
        }
        if (general.maxParallelPasteTasks == 1) {
            general.maxParallelPasteTasks = 2;
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] maxParallelPasteTasks 1 (valor antiguo) actualizado a 2");
        }
        if (general.arenaSpacing == 1000) {
            general.arenaSpacing = 130;
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] arenaSpacing 1000 (valor antiguo) actualizado a 130. IMPORTANTE: recrea las arenas (/hexatower unload all y luego /hexatower load) porque cambiaron de posicion.");
        }
    }

    private static void applyYaml(GeneralConfig general) {
        general.dimension = stringValue("general.dimension", general.dimension);
        general.schematicPath = stringValue("general.schematicPath", general.schematicPath);
        general.referenceSchematicPath = stringValue("general.referenceSchematicPath", general.referenceSchematicPath);
        general.arenaSpacing = intValue("general.arenaSpacing", general.arenaSpacing);
        general.arenaColumns = intValue("general.arenaColumns", general.arenaColumns);
        general.maxArenas = intValue("general.maxArenas", general.maxArenas);
        general.arenaY = intValue("general.arenaY", general.arenaY);
        general.schematicBlocksPerTick = intValue("general.schematicBlocksPerTick", general.schematicBlocksPerTick);
        general.preloadBlocksPerTick = intValue("general.preloadBlocksPerTick", general.preloadBlocksPerTick);
        general.maxParallelPasteTasks = intValue("general.maxParallelPasteTasks", general.maxParallelPasteTasks);
        general.cleanupBlocksPerTick = intValue("general.cleanupBlocksPerTick", general.cleanupBlocksPerTick);
        general.pasteMillisPerTick = doubleValue("general.pasteMillisPerTick", general.pasteMillisPerTick);
        general.slowTickThresholdMs = doubleValue("general.slowTickThresholdMs", general.slowTickThresholdMs);
        general.clearMode = stringValue("general.clearMode", general.clearMode);
        general.gameDurationSeconds = intValue("general.gameDurationSeconds", intValue("waves.durationSeconds", general.gameDurationSeconds));
        general.bossSpawnSecond = intValue("general.bossSpawnSecond", general.bossSpawnSecond);
        general.bossRepeatSeconds = intValue("general.bossRepeatSeconds", general.bossRepeatSeconds);
        general.endCeremonySeconds = intValue("general.endCeremonySeconds", general.endCeremonySeconds);
        general.maxLiveEnemiesPerArena = intValue("general.maxLiveEnemiesPerArena", general.maxLiveEnemiesPerArena);
        general.activationsPerTick = intValue("general.activationsPerTick", general.activationsPerTick);
        general.activationIntervalTicks = intValue("general.activationIntervalTicks", general.activationIntervalTicks);
        general.panelSolarMaxUncollected = intValue("towers.panel_solar.maxUncollected", intValue("general.panelSolarMaxUncollected", general.panelSolarMaxUncollected));
        general.preparationSeconds = intValue("general.preparationSeconds", general.preparationSeconds);
        general.startingEnergy = intValue("general.startingEnergy", general.startingEnergy);
        general.coreHealth = intValue("core.health", intValue("general.coreHealth", general.coreHealth));
        general.coreAttackerDamageTakenMultiplier = doubleValue("core.attackerDamageTakenMultiplier", general.coreAttackerDamageTakenMultiplier);
        general.coreTargetBlock = stringValue("arena.coreTargetBlock", stringValue("general.coreTargetBlock", general.coreTargetBlock));
        general.giveStarterSword = booleanValue("general.giveStarterSword", general.giveStarterSword);
        general.returnToOverworldSpawnOnEnd = booleanValue("general.returnToOverworldSpawnOnEnd", general.returnToOverworldSpawnOnEnd);
        general.pauseArenaOnDisconnect = booleanValue("general.pauseArenaOnDisconnect", general.pauseArenaOnDisconnect);
        general.allowBuildingOutsideGrid = booleanValue("arena.allowBuildingOutsideGrid", general.allowBuildingOutsideGrid);
        general.allowBreakingArenaBlocks = booleanValue("arena.allowBreakingArenaBlocks", general.allowBreakingArenaBlocks);
        general.allowPlacementOnLockedLanes = booleanValue("arena.allowPlacementOnLockedLanes", general.allowPlacementOnLockedLanes);
        general.shopInteractionDistance = doubleValue("arena.shopInteractionDistance", general.shopInteractionDistance);
        general.geowarePointsEnabled = booleanValue("points.enabled", general.geowarePointsEnabled);
        general.shinyMobEnabled = booleanValue("points.shinyMobs.enabled", general.shinyMobEnabled);
        general.shinyMobSpawnChance = doubleValue("points.shinyMobs.spawnChance", general.shinyMobSpawnChance);
        general.shinyMobPointReward = intValue("points.shinyMobs.pointReward", general.shinyMobPointReward);
        general.shinyMobGlowing = booleanValue("points.shinyMobs.glowingEnabled", general.shinyMobGlowing);
        general.shinyMobParticles = booleanValue("points.shinyMobs.particles", general.shinyMobParticles);
        general.debugShowEnemyNames = booleanValue("debug.showEnemyNames", general.debugShowEnemyNames);
        general.debug = booleanValue("debug.enabled", booleanValue("general.debug", general.debug));
    }

    private static MarkerConfig defaultMarkers() {
        MarkerConfig markers = new MarkerConfig();
        markers.markerRoles.put("minecraft:coal_block", "PLAYER_SPAWN");
        markers.markerRoles.put("minecraft:netherite_block", "SHOP");
        markers.markerRoles.put("minecraft:redstone_block", "ENEMY_SPAWN_ZONE");
        markers.markerRoles.put("minecraft:gold_block", "CLICKABLE_PLACEMENT");
        markers.markerRoles.put("minecraft:diamond_block", "STRUCTURE_ANCHOR");
        markers.markerRoles.put("minecraft:emerald_block", "LOCKED_LANE");
        return markers;
    }

    private static Map<String, String> readYaml(Path path) throws IOException {
        Map<String, String> values = new LinkedHashMap<>();
        if (!Files.exists(path)) {
            return values;
        }
        String[] stack = new String[16];
        for (String rawLine : Files.readAllLines(path)) {
            String line = rawLine.replace("\t", "  ");
            String trimmed = line.trim();
            if (trimmed.isEmpty() || trimmed.startsWith("#") || trimmed.startsWith("- ")) {
                continue;
            }
            int colon = trimmed.indexOf(':');
            if (colon <= 0) {
                continue;
            }
            int indent = countIndent(line) / 2;
            String key = trimmed.substring(0, colon).trim();
            String value = trimmed.substring(colon + 1).trim();
            stack[indent] = key;
            for (int i = indent + 1; i < stack.length; i++) {
                stack[i] = null;
            }
            if (value.isEmpty()) {
                continue;
            }
            StringBuilder pathBuilder = new StringBuilder();
            for (int i = 0; i <= indent; i++) {
                if (stack[i] == null) {
                    continue;
                }
                if (!pathBuilder.isEmpty()) {
                    pathBuilder.append('.');
                }
                pathBuilder.append(stack[i]);
            }
            values.put(pathBuilder.toString(), stripQuotes(value));
        }
        return values;
    }

    private static int countIndent(String line) {
        int count = 0;
        while (count < line.length() && line.charAt(count) == ' ') {
            count++;
        }
        return count;
    }

    private static String stripQuotes(String value) {
        String cleaned = value;
        int comment = cleaned.indexOf(" #");
        if (comment >= 0) {
            cleaned = cleaned.substring(0, comment).trim();
        }
        if ((cleaned.startsWith("\"") && cleaned.endsWith("\"")) || (cleaned.startsWith("'") && cleaned.endsWith("'"))) {
            return cleaned.substring(1, cleaned.length() - 1);
        }
        return cleaned;
    }

    private static String stringValue(String path, String fallback) {
        return yamlValues.getOrDefault(path, fallback);
    }

    private static int intValue(String path, int fallback) {
        try {
            return Integer.parseInt(yamlValues.getOrDefault(path, Integer.toString(fallback)));
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    private static double doubleValue(String path, double fallback) {
        try {
            return Double.parseDouble(yamlValues.getOrDefault(path, Double.toString(fallback)));
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    private static boolean booleanValue(String path, boolean fallback) {
        return Boolean.parseBoolean(yamlValues.getOrDefault(path, Boolean.toString(fallback)));
    }

    private static double defaultEnemyHealth(EnemyType type) {
        return switch (type) {
            case BLUE_MINION -> 115;
            case PURPLE_MINION -> 175;
            case GREEN_KNIGHT_MINION -> 135;
            case BLUE_KNIGHT_MINION -> 205;
            case PURPLE_KNIGHT_MINION -> 290;
            case LAVA_GOLEM -> 900;
            default -> 70;
        };
    }

    private static int defaultEnemyCoreDamage(EnemyType type) {
        return switch (type) {
            case BLUE_MINION -> 15;
            case PURPLE_MINION -> 20;
            case GREEN_KNIGHT_MINION -> 18;
            case BLUE_KNIGHT_MINION -> 24;
            case PURPLE_KNIGHT_MINION -> 32;
            case LAVA_GOLEM -> 60;
            default -> 10;
        };
    }

    private static double defaultEnemySpeed(EnemyType type) {
        return switch (type) {
            case BLUE_MINION -> 0.105D;
            case PURPLE_MINION -> 0.10D;
            case GREEN_KNIGHT_MINION, BLUE_KNIGHT_MINION, PURPLE_KNIGHT_MINION -> 0.075D;
            case LAVA_GOLEM -> 0.06D;
            default -> 0.11D;
        };
    }

    private static String towerKey(TowerType type) {
        return type.name().toLowerCase(Locale.ROOT);
    }

    private static double defaultTowerDamage(TowerType type, int level) {
        double base = switch (type) {
            case TURRET -> 8.0D;
            case CROSSBOW_TOWER -> 18.0D;
            case CANNON -> 24.0D;
            case TESLA_TOWER -> 12.0D;
            default -> 0.0D;
        };
        return base + Math.max(0, level - 1) * switch (type) {
            case TURRET -> 4.0D;
            case CROSSBOW_TOWER -> 7.0D;
            case CANNON -> 10.0D;
            case TESLA_TOWER -> 5.0D;
            default -> 0.0D;
        };
    }

    private static int defaultTowerHealth(TowerType type, int level) {
        int bonus = Math.max(0, level - 1);
        return switch (type) {
            case PANEL_SOLAR -> 100 + bonus * 40;
            case TURRET -> 120 + bonus * 45;
            case CROSSBOW_TOWER -> 130 + bonus * 50;
            case CANNON -> 165 + bonus * 60;
            case HOLOGRAPHIC_SHIELD -> 420 + bonus * 140;
            case ION_BATTERY -> 180 + bonus * 60;
            case TESLA_TOWER -> 150 + bonus * 55;
        };
    }

    private static double defaultTowerRange(TowerType type, int level) {
        int safeLevel = Math.max(1, Math.min(3, level));
        // Rango en casillas de la grilla (1 casilla = 6 bloques). Nivel 3 (morado) = maximo.
        int cells = switch (type) {
            case TURRET -> 3 + safeLevel;
            case CROSSBOW_TOWER -> 2 + safeLevel;
            case CANNON -> 1 + safeLevel;
            case TESLA_TOWER -> 1;
            default -> 0;
        };
        return cells * 6.0D;
    }

    private static int defaultTowerCooldown(TowerType type, int level) {
        int reduction = Math.max(0, level - 1) * 4;
        return switch (type) {
            case TURRET -> Math.max(14, 30 - reduction);
            case CROSSBOW_TOWER -> Math.max(24, 42 - reduction);
            case CANNON -> Math.max(36, 62 - reduction);
            case TESLA_TOWER -> Math.max(28, 50 - reduction);
            default -> 40;
        };
    }

    private static double defaultTowerAreaRadius(TowerType type) {
        return switch (type) {
            case CANNON -> 2.7D;
            case TESLA_TOWER -> 3.5D;
            default -> 0.0D;
        };
    }

    private static int defaultPanelSolarProductionAmount(int level) {
        return switch (Math.max(1, level)) {
            case 1 -> 25;
            case 2 -> 40;
            default -> 60;
        };
    }

    private static int defaultPanelSolarProductionIntervalTicks(int level) {
        return switch (Math.max(1, level)) {
            case 1 -> 960;
            case 2 -> 800;
            default -> 640;
        };
    }

    private static String defaultPointsYaml() {
        return """
                points:
                  # Activa la integracion de puntos externa para mobs especiales.
                  enabled: true
                  # Configuracion de enemigos especiales que dan puntos al morir.
                  shinyMobs:
                    # Activa la probabilidad de que un enemigo salga como especial.
                    enabled: true
                    # Probabilidad de enemigo especial. 0.10 equivale a 10%.
                    spawnChance: 0.10
                    # Puntos entregados al jugador que mate un enemigo especial.
                    pointReward: 10
                    # Mantener false: el glowing vanilla ensucia visualmente el mapa.
                    glowing: false
                    # Muestra particulas sobre enemigos especiales.
                    particles: true
                """;
    }

    private static String defaultConfigYaml() {
        return """
                # HexaTowerDefense config
                # Edita los valores y reinicia el servidor para aplicarlos.

                general:
                  # Dimension donde se pegan todas las arenas privadas.
                  dimension: "hexatowerdefense:instances"
                  # Separacion entre arenas (bloques). El schematic mide 119 de largo,
                  # asi que el minimo real sin que se superpongan es 120. 130 deja 11 de aire.
                  # Mantenerlo bajo achica el mundo y reduce la carga de chunks con 100 jugadores.
                  arenaSpacing: 130
                  # Cantidad de columnas usadas para distribuir arenas en grilla.
                  arenaColumns: 10
                  # Maximo de arenas simultaneas o precargadas.
                  maxArenas: 100
                  # Altura base del anchor de cada arena.
                  arenaY: 80
                  # Schematic limpia que se pega al iniciar o precargar arenas.
                  schematicPath: "config/hexatowerdefense/schematics/y1p.schem"
                  # Schematic usada para mapear layout. En produccion puede apuntar a la misma schematic limpia.
                  referenceSchematicPath: "config/hexatowerdefense/schematics/y1p.schem"
                  # Layout generado que guarda spawn, tienda, nucleo, carriles y celdas.
                  generatedLayoutPath: "config/hexatowerdefense/generated_layout_from_reference.json"
                  # Bloques colocados por tick durante /hexatower start.
                  schematicBlocksPerTick: 5000
                  # Bloques colocados por tick durante /hexatower load. Es un techo:
                  # el mod baja solo el ritmo si el servidor empieza a lagear.
                  preloadBlocksPerTick: 4000
                  # Pegados simultaneos permitidos al precargar arenas.
                  maxParallelPasteTasks: 2
                  # Milisegundos por tick que puede gastar el mod construyendo arenas.
                  # Si se pasa de este valor, reduce automaticamente los bloques por tick.
                  pasteMillisPerTick: 8.0
                  # Si el tick del servidor supera estos milisegundos, frena la construccion.
                  # 50ms equivale a 20 TPS; 55 deja un pequeno margen.
                  slowTickThresholdMs: 55.0
                  # Entrega una espada de madera irrompible al iniciar la partida.
                  giveStarterSword: true
                  # Bloques borrados por tick al limpiar una arena.
                  cleanupBlocksPerTick: 8000
                  # TRACKED_ONLY borra bloques pegados; BOUNDING_BOX borra todo el volumen.
                  clearMode: "TRACKED_ONLY"
                  # Tiempo de gracia antes de iniciar enemigos.
                  preparationSeconds: 90
                  # La partida NO termina sola: solo termina con /hexatower stop o si cae el nucleo.
                  # Este valor es cuanto tarda la dificultad en llegar a su maximo. 900 = 15 minutos.
                  # Pasado ese tiempo los enemigos siguen apareciendo al ritmo mas dificil.
                  gameDurationSeconds: 900
                  # Segundo de partida donde aparece el primer boss Golem de Lava.
                  bossSpawnSecond: 600
                  # Cada cuantos segundos aparece otro boss. 300 = 5 minutos.
                  bossRepeatSeconds: 300
                  # Segundos de celebracion (titulo y fuegos artificiales) antes de sacar al jugador.
                  endCeremonySeconds: 5
                  # Tope de enemigos vivos por arena. Como la partida no termina sola, este
                  # limite evita que se acumulen mobs infinitos y lageen el servidor.
                  # Los bosses ignoran este tope. Con 100 arenas, no lo subas mucho.
                  maxLiveEnemiesPerArena: 60
                  # Escalona la entrada de duos a su arena al hacer /start masivo,
                  # para no cargar todas las arenas en un solo tick (lo que congelaba el servidor).
                  # Entran 'activationsPerTick' arenas cada 'activationIntervalTicks' ticks.
                  # Por defecto 2 arenas cada 10 ticks: 50 arenas (100 jugadores en duo) = ~13s.
                  activationsPerTick: 2
                  activationIntervalTicks: 10
                  # Celulas iniciales entregadas a cada jugador.
                  startingEnergy: 50
                  # Devuelve al jugador al spawn del overworld al terminar.
                  returnToOverworldSpawnOnEnd: true
                  # Si false, se limpia la arena cuando el jugador se desconecta.
                  pauseArenaOnDisconnect: false

                arena:
                  # Si false, solo se puede colocar usando celdas del layout.
                  allowBuildingOutsideGrid: false
                  # Si false, no se pueden romper bloques del mapa.
                  allowBreakingArenaBlocks: false
                  # Permite preparar defensas en carriles laterales bloqueados.
                  allowPlacementOnLockedLanes: true
                  # (Obsoleto) Los 6 carriles estan activos desde el inicio de la partida.
                  unlockLockedLanesAtSecond: 0
                  # Distancia maxima para interactuar con la tienda.
                  shopInteractionDistance: 6.0
                  # Bloque usado para detectar el objetivo visual del nucleo.
                  coreTargetBlock: "minecraft:shroomlight"
                  # Permite que enemigos atraviesen barriers al seguir sus carriles.
                  enemyCanPassBarrier: true

                core:
                  # Vida maxima del Nucleo Geotermico.
                  health: 1000
                  # Dano extra que reciben los enemigos mientras golpean el nucleo.
                  # 1.20 equivale a un 20% mas de dano recibido.
                  attackerDamageTakenMultiplier: 1.20
                  # Distancia donde los enemigos dejan de moverse y atacan.
                  attackRangeToCore: 2.5
                  # CONTINUOUS hace que el enemigo siga golpeando hasta morir.
                  coreDamageMode: "CONTINUOUS"

                economy:
                  # Entrega celulas al matar enemigos si esta activo.
                  killRewardEnabled: true
                  # Entrega recompensas por oleada si esta activo.
                  waveRewardEnabled: true

                points:
                  # Activa la integracion de puntos para enemigos especiales.
                  enabled: true
                  # Enemigos especiales con particulas y recompensa.
                  shinyMobs:
                    # Activa o desactiva enemigos especiales.
                    enabled: true
                    # Probabilidad de spawn especial. 0.20 equivale a 20%.
                    spawnChance: 0.20
                    # Puntos otorgados al matar un enemigo especial. Se dan a ambos jugadores del duo.
                    pointReward: 5
                    # Brillo vanilla para distinguir a los enemigos especiales.
                    glowingEnabled: true
                    # Particulas visuales para distinguir enemigos especiales.
                    particles: true

                shop:
                  # Titulo visible en la tienda.
                  title: "TowerDefense"
                  # Intercambios de tienda. La moneda real es el item Celula de Energia.
                  items:
                    panel_solar:
                      # Nombre visible del producto.
                      display: "Panel Solar"
                      # Costo en items Celula de Energia.
                      price: 50
                      # Categoria mostrada en la GUI.
                      category: "TORRES"
                      # Item entregado al comprar.
                      item: "hexatowerdefense:panel_solar_item"
                      # Descripcion breve.
                      description: "Produce celulas de energia."
                      # Maximo por arena entre torres colocadas e items en inventario. 0 = sin limite.
                      limit: 10
                    turret:
                      # Torre de disparo basico a un objetivo.
                      display: "Torreta"
                      price: 100
                      category: "TORRES"
                      item: "hexatowerdefense:turret_item"
                      description: "Dispara rapidamente a un enemigo."
                      limit: 10
                    crossbow_tower:
                      # Torre con proyectil perforante.
                      display: "Ballesta"
                      price: 140
                      category: "TORRES"
                      item: "hexatowerdefense:crossbow_tower_item"
                      description: "Disparo fuerte con perforacion."
                      limit: 8
                    cannon:
                      # Torre de area con cooldown lento.
                      display: "Cañón"
                      price: 180
                      category: "TORRES"
                      item: "hexatowerdefense:cannon_item"
                      description: "Hace dano en area."
                      limit: 6
                    holographic_shield:
                      # Barrera defensiva con mucha vida.
                      display: "Escudo Holografico"
                      price: 120
                      category: "TORRES"
                      item: "hexatowerdefense:holographic_shield_item"
                      description: "Bloquea enemigos."
                      limit: 8
                    ion_battery:
                      # Estructura de apoyo para torres cercanas.
                      display: "Bateria de Iones"
                      price: 160
                      category: "TORRES"
                      item: "hexatowerdefense:ion_battery_item"
                      description: "Potencia torres cercanas."
                      limit: 6
                    tesla_tower:
                      # Torre de dano constante en area.
                      display: "Torre Tesla"
                      price: 220
                      category: "TORRES"
                      item: "hexatowerdefense:tesla_tower_item"
                      description: "Ataca en area usando energia."
                      limit: 3

                towers:
                  # Configuracion de estructuras por nivel.
                  panel_solar:
                    # Maximo de TANDAS (pilas de items) sin recoger cerca de un panel.
                    # OJO: NO son celulas sueltas; cada produccion suelta 1 pila (~60 celulas
                    # a nivel 3). 2 = el panel produce 2 veces y frena hasta que las recojan.
                    # Sube el numero si quieres que acumule mas antes de frenar.
                    maxUncollected: 2
                    # El panel solar dropea items Celula de Energia por ciclos.
                    levels:
                      1:
                        # Vida maxima nivel 1.
                        health: 100
                        # Celulas generadas por ciclo.
                        productionAmount: 25
                        # Ticks entre ciclos. 960 ticks = 48 segundos.
                        productionIntervalTicks: 960
                      2:
                        # Vida maxima nivel 2.
                        health: 140
                        # Celulas generadas por ciclo.
                        productionAmount: 40
                        # Ticks entre ciclos.
                        productionIntervalTicks: 800
                      3:
                        # Vida maxima nivel 3.
                        health: 180
                        # Celulas generadas por ciclo.
                        productionAmount: 60
                        # Ticks entre ciclos.
                        productionIntervalTicks: 640

                enemies:
                  # Esbirro verde normal.
                  green_minion:
                    # Vida maxima.
                    health: 70
                    # Dano al nucleo por golpe.
                    coreDamage: 10
                    # Velocidad de avance.
                    speed: 0.11
                    # Rango de ataque al nucleo o estructuras.
                    attackRange: 3.0
                    # Distancia donde deja de avanzar para no orbitar.
                    stopDistance: 2.2
                    # Ticks entre golpes.
                    attackCooldownTicks: 40
                    # Celulas dadas al inventario de cada jugador del duo al morir.
                    cellReward: 2
                  # Esbirro azul normal.
                  blue_minion:
                    health: 115
                    coreDamage: 15
                    speed: 0.105
                    attackRange: 3.0
                    stopDistance: 2.2
                    attackCooldownTicks: 40
                    cellReward: 3
                  # Esbirro morado normal.
                  purple_minion:
                    health: 175
                    coreDamage: 20
                    speed: 0.10
                    attackRange: 3.0
                    stopDistance: 2.2
                    attackCooldownTicks: 35
                    cellReward: 5
                  # Mini boss de lava.
                  lava_golem:
                    health: 900
                    coreDamage: 60
                    speed: 0.06
                    attackRange: 4.0
                    stopDistance: 3.0
                    attackCooldownTicks: 60
                    cellReward: 25

                debug:
                  # Activa logs de depuracion del mod.
                  enabled: false
                  # Muestra nombres sobre enemigos solo para debug.
                  showEnemyNames: false
                  # Muestra particulas de celdas en comandos debug.
                  showPlacementParticles: true
                  # Log detallado de movimiento enemigo.
                  logEnemyMovement: false
                  # Log detallado del dano al nucleo.
                  logCoreDamage: true
                """;
    }
}
