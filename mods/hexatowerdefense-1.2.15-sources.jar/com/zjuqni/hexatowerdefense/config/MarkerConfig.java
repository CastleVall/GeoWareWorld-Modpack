package com.zjuqni.hexatowerdefense.config;

import java.util.LinkedHashMap;
import java.util.Map;

public final class MarkerConfig {
    public boolean enabled = true;
    public Map<String, String> markerRoles = new LinkedHashMap<>();
    public boolean replaceMarkersOnPaste = false;
    public Map<String, String> replacementBlocks = new LinkedHashMap<>();
}
