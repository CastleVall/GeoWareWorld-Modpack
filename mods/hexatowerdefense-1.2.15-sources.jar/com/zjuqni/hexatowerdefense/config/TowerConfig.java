package com.zjuqni.hexatowerdefense.config;

public final class TowerConfig {
}
