package com.zjuqni.hexatowerdefense.config;

public final class ArenaLayoutConfig {
    public int[] playerSpawn = new int[]{0, 3, 0};
    public int[] returnSpawn = new int[]{0, 3, 0};
    public BoundsConfig bounds = new BoundsConfig();
    public PointConfig core = new PointConfig(new int[]{35, 1, 0}, 90);
    public PointConfig shop = new PointConfig(new int[]{30, 1, 10}, 180);
    public GridConfig grid = new GridConfig();
    public LaneConfig[] lanes = new LaneConfig[0];

    public static final class BoundsConfig {
        public int[] min = new int[]{-55, -15, -70};
        public int[] max = new int[]{55, 80, 65};
    }

    public static final class PointConfig {
        public int[] position;
        public int rotation;

        public PointConfig() {
            this(new int[]{0, 0, 0}, 0);
        }

        public PointConfig(int[] position, int rotation) {
            this.position = position;
            this.rotation = rotation;
        }
    }

    public static final class GridConfig {
        public String mode = "CONFIG";
        public int[] origin = new int[]{-25, 1, -18};
        public int rows = 5;
        public int columns = 9;
        public int cellSizeX = 4;
        public int cellSizeZ = 4;
        public int gapX = 1;
        public int gapZ = 1;
        public int placeY = 1;
    }

    public static final class LaneConfig {
        public int id;
        public String name;
        public int[][] waypoints;
    }
}
