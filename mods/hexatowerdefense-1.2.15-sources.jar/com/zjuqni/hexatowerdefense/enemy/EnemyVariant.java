package com.zjuqni.hexatowerdefense.enemy;

public enum EnemyVariant {
    GREEN,
    BLUE,
    PURPLE,
    LAVA
}
