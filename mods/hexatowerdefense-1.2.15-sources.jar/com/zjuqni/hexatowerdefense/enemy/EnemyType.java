package com.zjuqni.hexatowerdefense.enemy;

public enum EnemyType {
    GREEN_MINION,
    BLUE_MINION,
    PURPLE_MINION,
    GREEN_KNIGHT_MINION,
    BLUE_KNIGHT_MINION,
    PURPLE_KNIGHT_MINION,
    LAVA_GOLEM
}
