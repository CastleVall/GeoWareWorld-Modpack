package com.zjuqni.hexatowerdefense.enemy;

public record EnemyRuntimeStats(
        double health,
        int coreDamage,
        double speed,
        double attackRange,
        double stopDistance,
        int attackCooldownTicks
) {
}
