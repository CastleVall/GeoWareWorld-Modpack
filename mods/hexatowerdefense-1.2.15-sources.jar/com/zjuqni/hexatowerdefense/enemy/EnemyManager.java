package com.zjuqni.hexatowerdefense.enemy;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import com.zjuqni.hexatowerdefense.arena.ArenaInstance;
import com.zjuqni.hexatowerdefense.config.ConfigManager;
import com.zjuqni.hexatowerdefense.layout.LaneDefinition;
import com.zjuqni.hexatowerdefense.registry.ModEntities;
import com.zjuqni.hexatowerdefense.util.HTDText;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1299;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3730;

public final class EnemyManager {
    private final ArenaInstance arena;
    private final List<HTDEnemyEntity> enemies = new ArrayList<>();
    private final List<HTDEnemyEntity> enemiesView = java.util.Collections.unmodifiableList(enemies);

    public EnemyManager(ArenaInstance arena) {
        this.arena = arena;
    }

    public void tick() {
        enemies.removeIf(enemy -> enemy == null || enemy.method_31481() || !enemy.method_5805());
    }

    public int spawnTestWave(String enemyName, int laneId, int amount, boolean forceLockedLane, class_3222 commandUser) {
        EnemyType type;
        try {
            type = EnemyType.valueOf(enemyName.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            HTDText.sendError(commandUser, "Enemigo inválido: " + enemyName, false);
            return 0;
        }

        if (arena.referenceLayout() == null || arena.referenceLayout().lanes.isEmpty()) {
            HTDText.sendError(commandUser, "La arena no tiene carriles mapeados.", false);
            return 0;
        }
        if (laneId < 0 || laneId >= arena.referenceLayout().lanes.size()) {
            HTDText.sendError(commandUser, "Carril inválido: " + laneId + ". Carriles=" + arena.referenceLayout().lanes.size(), false);
            return 0;
        }
        if (arena.isLaneLocked(laneId) && !forceLockedLane) {
            HTDText.sendWarning(commandUser, "Carril " + laneId + " bloqueado. Usa true al final para forzar debug.", false);
            return 0;
        }

        int spawned = 0;
        for (int i = 0; i < amount; i++) {
            if (spawnEnemy(type, laneId, i * 0.75D) != null) {
                spawned++;
            }
        }
        HTDText.sendSuccess(commandUser, "Spawneados " + spawned + " " + enemyName + " en carril " + laneId + ".", false);
        return spawned;
    }

    public HTDEnemyEntity spawnEnemy(EnemyType type, int laneId, double lateralOffset) {
        class_3218 world = arena.getWorld();
        if (world == null) {
            logFailure("mundo incorrecto o dimension no cargada");
            return null;
        }
        if (arena.referenceLayout() == null || arena.referenceLayout().lanes.isEmpty()) {
            logFailure("no lanes");
            return null;
        }
        if (laneId < 0 || laneId >= arena.referenceLayout().lanes.size()) {
            logFailure("lane invalido " + laneId);
            return null;
        }

        LaneDefinition lane = arena.referenceLayout().laneById(laneId);
        if (lane == null) {
            logFailure("lane no existe " + laneId);
            return null;
        }
        class_2338 spawn = lane.enemySpawnWorld(arena.anchor()).method_10069(0, 0, (int) Math.round(lateralOffset));
        if (arena.bounds() == null || !arena.bounds().method_1008(spawn.method_10263() + 0.5D, spawn.method_10264() + 0.5D, spawn.method_10260() + 0.5D)) {
            logFailure("spawn fuera de bounds " + format(spawn));
            return null;
        }

        HTDEnemyEntity entity = entityTypeFor(type).method_5883(world);
        if (entity == null) {
            logFailure("entity type no registrado");
            return null;
        }
        entity.method_5808(spawn.method_10263() + 0.5D, spawn.method_10264(), spawn.method_10260() + 0.5D, 0.0F, 0.0F);
        List<class_2338> route = new ArrayList<>(lane.waypointsWorld(arena.anchor()));
        class_2338 coreTarget = arena.coreController() != null
                ? arena.coreController().corePosition()
                : lane.coreTargetWorld(arena.anchor(), arena.referenceLayout().core);
        class_2338 coreApproach = lane.coreApproachWorld(arena.anchor(), arena.referenceLayout().core);
        class_2338 coreAttack = lane.coreAttackWorld(arena.anchor(), arena.referenceLayout().core);
        entity.configure(arena.arenaId(), laneId, type, route, coreApproach, coreAttack, coreTarget);
        boolean shiny = ConfigManager.general().shinyMobEnabled
                && ThreadLocalRandom.current().nextDouble() < ConfigManager.general().shinyMobSpawnChance;
        if (shiny) {
            entity.setShinyMob(true);
        }
        entity.method_5943(world, world.method_8404(spawn), class_3730.field_16462, null);
        if (!world.method_8649(entity)) {
            logFailure("spawnEntity devolvio false en " + format(spawn));
            return null;
        }
        if (shiny) {
            for (class_3222 viewer : arena.getPlayers()) {
                world.method_14166(viewer, net.minecraft.class_2398.field_11207, false,
                        entity.method_23317(), entity.method_23318() + entity.method_5829().method_17940() * 0.75D, entity.method_23321(),
                        12, 0.55D, 0.75D, 0.55D, 0.035D);
            }
        }
        enemies.add(entity);
        if (ConfigManager.general().debug) {
            UUID uuid = entity.method_5667();
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] Spawning enemy {} lane={} at {} shiny={}", type, laneId, format(spawn), shiny);
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] Enemy spawned uuid={}", uuid);
        }
        return entity;
    }

    public List<HTDEnemyEntity> enemies() {
        return enemiesView;
    }

    public int liveCount() {
        return enemies.size();
    }

    public void clear() {
        for (HTDEnemyEntity enemy : enemies) {
            if (enemy != null && !enemy.method_31481()) {
                enemy.closeBossBar();
                enemy.method_31472();
            }
        }
        enemies.clear();
    }

    private void logFailure(String reason) {
        HexaTowerDefenseMod.LOGGER.warn("[HexaTowerDefense] Enemy spawn failed arena={} reason={}", arena.arenaId(), reason);
    }

    private static class_1299<HTDEnemyEntity> entityTypeFor(EnemyType type) {
        return switch (type) {
            case GREEN_KNIGHT_MINION, BLUE_KNIGHT_MINION, PURPLE_KNIGHT_MINION -> ModEntities.HTD_KNIGHT_ENEMY;
            case LAVA_GOLEM -> ModEntities.HTD_LAVA_GOLEM;
            default -> ModEntities.HTD_ENEMY;
        };
    }

    private static String format(class_2338 pos) {
        return "[" + pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260() + "]";
    }
}
