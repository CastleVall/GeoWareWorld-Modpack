package com.zjuqni.hexatowerdefense.enemy;

public enum EnemyMoveState {
    MOVING_LANE,
    MOVING_TO_CORE,
    ATTACKING_CORE,
    ATTACKING_TOWER,
    STUNNED,
    DEAD
}
