package com.zjuqni.hexatowerdefense.enemy;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import com.zjuqni.hexatowerdefense.arena.ArenaInstance;
import com.zjuqni.hexatowerdefense.arena.ArenaManager;
import com.zjuqni.hexatowerdefense.config.ConfigManager;
import com.zjuqni.hexatowerdefense.integration.GeoWarePointsBridge;
import com.zjuqni.hexatowerdefense.shop.ShopManager;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1259;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3213;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

public final class HTDEnemyEntity extends class_1308 implements GeoEntity {
    private static final class_2940<Integer> TRACKED_ENEMY_TYPE = class_2945.method_12791(HTDEnemyEntity.class, class_2943.field_13327);
    private static final class_2940<Integer> TRACKED_MOVE_STATE = class_2945.method_12791(HTDEnemyEntity.class, class_2943.field_13327);
    private static final class_2940<Boolean> TRACKED_SHINY_MOB = class_2945.method_12791(HTDEnemyEntity.class, class_2943.field_13323);

    private static final RawAnimation MINION_FLY = RawAnimation.begin().thenLoop("fly_molang");
    private static final RawAnimation GOLEM_WALK = RawAnimation.begin().thenLoop("animation.walk");
    private static final RawAnimation ATTACK = RawAnimation.begin().thenLoop("animation.attack");

    private final AnimatableInstanceCache animationCache = GeckoLibUtil.createInstanceCache(this);
    private boolean runtimeSpawned;
    private int arenaId = -1;
    private int laneId = -1;
    private EnemyType enemyType = EnemyType.GREEN_MINION;
    private final List<class_2338> waypoints = new ArrayList<>();
    private int currentWaypointIndex;
    private double laneSpeed = 0.07D;
    private EnemyMoveState moveState = EnemyMoveState.MOVING_LANE;
    private class_2338 coreApproachPoint;
    private class_2338 coreAttackPoint;
    private class_2338 coreTarget;
    private int attackCooldownTicks;
    private int attackCooldownMax = 40;
    private int coreDamage = 10;
    private double attackRange = 2.5D;
    private double stopDistance = 1.6D;
    private int movingToCoreTicks;
    private int stuckNearCoreTicks;
    private double lastCoreDistanceSq = Double.MAX_VALUE;
    private UUID targetTowerUuid;
    private EnemyMoveState resumeAfterTowerState = EnemyMoveState.MOVING_LANE;
    private int towerAttackCooldownTicks;
    private int stunTicks;
    private int stunImmunityTicks;
    private EnemyMoveState stateBeforeStun = EnemyMoveState.MOVING_LANE;
    private boolean shinyPointsAwarded;
    private boolean killCellsAwarded;
    private boolean bossBarEnabled = true;
    private class_3213 bossBar;

    public HTDEnemyEntity(class_1299<? extends class_1308> entityType, class_1937 world) {
        super(entityType, world);
        method_5971();
        method_5875(true);
    }

    @Override
    public boolean method_5810() {
        return false;
    }

    @Override
    public boolean method_30948() {
        return false;
    }

    @Override
    public boolean method_30949(class_1297 other) {
        return false;
    }

    @Override
    public boolean method_5863() {
        return true;
    }

    @Override
    public boolean method_5732() {
        return true;
    }

    @Override
    public void method_5697(class_1297 entity) {
    }

    @Override
    public boolean method_5643(class_1282 source, float amount) {
        float finalAmount = moveState == EnemyMoveState.ATTACKING_CORE
                ? amount * (float) ConfigManager.general().coreAttackerDamageTakenMultiplier
                : amount;
        boolean damaged = super.method_5643(source, finalAmount);
        if (damaged && !method_37908().method_8608()) {
            method_37908().method_8396(null, method_24515(), class_3417.field_14940, class_3419.field_15251, 0.55F, 1.15F);
        }
        if (!method_37908().method_8608() && method_6032() <= 0.0F && !method_31481()) {
            awardShinyPointsIfNeeded();
            awardKillCells();
            closeBossBar();
            setMoveState(EnemyMoveState.DEAD);
            method_31472();
        }
        return damaged;
    }

    private void awardKillCells() {
        if (killCellsAwarded) {
            return;
        }
        killCellsAwarded = true;
        ArenaInstance arena = ArenaManager.get().getArenaById(arenaId);
        if (arena == null) {
            return;
        }
        int reward = ConfigManager.enemyCellReward(enemyType);
        if (reward <= 0) {
            return;
        }
        for (class_3222 member : arena.getPlayers()) {
            ShopManager.giveEnergyCells(member, reward);
        }
    }

    @Override
    public void method_5650(class_5529 reason) {
        closeBossBar();
        super.method_5650(reason);
    }

    public static class_5132.class_5133 createAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 20.0D)
                .method_26868(class_5134.field_23719, 0.23D)
                .method_26868(class_5134.field_23721, 2.0D)
                .method_26868(class_5134.field_23717, 16.0D);
    }

    @Override
    protected void method_5959() {
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(TRACKED_ENEMY_TYPE, EnemyType.GREEN_MINION.ordinal());
        builder.method_56912(TRACKED_MOVE_STATE, EnemyMoveState.MOVING_LANE.ordinal());
        builder.method_56912(TRACKED_SHINY_MOB, false);
    }

    @Override
    public void method_5674(class_2940<?> data) {
        super.method_5674(data);
        if (TRACKED_ENEMY_TYPE.equals(data)) {
            this.enemyType = trackedEnemyType();
            method_18382();
            refreshEnemyHitbox();
        } else if (TRACKED_MOVE_STATE.equals(data)) {
            this.moveState = trackedMoveState();
        }
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "movement", 0, state -> {
            EnemyMoveState stateForAnimation = trackedMoveState();
            if (trackedEnemyType() == EnemyType.LAVA_GOLEM) {
                return state.setAndContinue(isAttacking(stateForAnimation) ? ATTACK : GOLEM_WALK);
            }
            return state.setAndContinue(isAttacking(stateForAnimation) ? ATTACK : MINION_FLY);
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return animationCache;
    }

    public boolean isRuntimeSpawned() {
        return runtimeSpawned;
    }

    public void configure(int arenaId, int laneId, EnemyType enemyType, List<class_2338> waypoints, class_2338 coreApproachPoint, class_2338 coreAttackPoint, class_2338 coreTarget) {
        this.runtimeSpawned = true;
        this.arenaId = arenaId;
        this.laneId = laneId;
        this.enemyType = enemyType;
        this.field_6011.method_12778(TRACKED_ENEMY_TYPE, enemyType.ordinal());
        this.waypoints.clear();
        this.waypoints.addAll(waypoints);
        this.coreApproachPoint = coreApproachPoint == null ? null : coreApproachPoint.method_10062();
        this.coreAttackPoint = coreAttackPoint == null ? null : coreAttackPoint.method_10062();
        this.coreTarget = coreTarget == null ? null : coreTarget.method_10062();
        this.currentWaypointIndex = Math.min(1, Math.max(0, waypoints.size() - 1));
        EnemyRuntimeStats stats = ConfigManager.enemyStats(enemyType);
        this.laneSpeed = stats.speed();
        this.coreDamage = stats.coreDamage();
        this.attackRange = stats.attackRange();
        this.stopDistance = stats.stopDistance();
        this.attackCooldownMax = stats.attackCooldownTicks();
        this.attackCooldownTicks = 10;
        this.movingToCoreTicks = 0;
        this.stuckNearCoreTicks = 0;
        this.lastCoreDistanceSq = Double.MAX_VALUE;
        this.targetTowerUuid = null;
        this.resumeAfterTowerState = EnemyMoveState.MOVING_LANE;
        this.towerAttackCooldownTicks = 0;
        this.stunTicks = 0;
        this.stateBeforeStun = EnemyMoveState.MOVING_LANE;
        this.shinyPointsAwarded = false;
        setShinyMob(false);
        setMoveState(EnemyMoveState.MOVING_LANE);
        method_5875(true);
        if (method_5996(class_5134.field_23716) != null) {
            method_5996(class_5134.field_23716).method_6192(stats.health());
        }
        method_6033((float) stats.health());
        applyNameVisibility();
        method_18382();
        refreshEnemyHitbox();
        setupBossBar();
    }

    @Override
    public void method_5773() {
        super.method_5773();
        refreshEnemyHitbox();
        if (!method_37908().method_8608()) {
            this.field_5960 = true;
            if (stunImmunityTicks > 0) {
                stunImmunityTicks--;
            }
            updateBossBar();
            tickLaneMovement();
            applySeparation();
            tickShinyParticles();
            enforceArenaBounds();
        }
    }

    public void setShinyMob(boolean shiny) {
        field_6011.method_12778(TRACKED_SHINY_MOB, shiny);
        method_5834(shiny && ConfigManager.general().shinyMobGlowing);
    }

    public boolean isShinyMob() {
        return field_6011.method_12789(TRACKED_SHINY_MOB);
    }

    private void tickShinyParticles() {
        if (!isShinyMob() || !ConfigManager.general().shinyMobParticles || !(method_37908() instanceof class_3218 serverWorld)) {
            return;
        }
        if (field_6012 % 10 != 0) {
            return;
        }
        ArenaInstance arena = ArenaManager.get().getArenaById(arenaId);
        if (arena == null) {
            return;
        }
        double height = method_5829().method_17940();
        for (class_3222 viewer : arena.getPlayers()) {
            serverWorld.method_14166(viewer, class_2398.field_11207, false, method_23317(), method_23318() + height * 0.85D, method_23321(),
                    4, 0.5D, Math.max(0.35D, height * 0.22D), 0.5D, 0.012D);
            serverWorld.method_14166(viewer, class_2398.field_29644, false, method_23317(), method_23318() + height * 0.45D, method_23321(),
                    3, 0.42D, Math.max(0.25D, height * 0.16D), 0.42D, 0.025D);
        }
    }

    private void awardShinyPointsIfNeeded() {
        if (shinyPointsAwarded || !isShinyMob() || !ConfigManager.general().shinyMobEnabled) {
            return;
        }
        shinyPointsAwarded = true;
        ArenaInstance arena = ArenaManager.get().getArenaById(arenaId);
        if (arena == null) {
            return;
        }
        int points = ConfigManager.general().shinyMobPointReward;
        for (class_3222 owner : arena.getPlayers()) {
            GeoWarePointsBridge.addPoints(owner, points);
            if (ConfigManager.general().debug) {
                HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] Shiny mob killed arena={} player={} points={}",
                        arenaId, owner.method_7334().getName(), points);
            }
        }
    }

    private void tickLaneMovement() {
        if (moveState == EnemyMoveState.DEAD) {
            stopMovement(true);
            return;
        }
        if (moveState == EnemyMoveState.STUNNED) {
            tickStun();
            return;
        }
        if (moveState == EnemyMoveState.ATTACKING_CORE) {
            tickCoreAttack();
            return;
        }
        if (moveState == EnemyMoveState.ATTACKING_TOWER) {
            tickTowerAttack();
            return;
        }
        if (moveState == EnemyMoveState.MOVING_TO_CORE) {
            moveToCore();
            return;
        }

        if (waypoints.isEmpty() || currentWaypointIndex >= waypoints.size()) {
            beginMovingToCore();
            return;
        }

        class_243 target = waypoints.get(currentWaypointIndex).method_46558();
        class_243 current = method_19538();
        class_243 delta = target.method_1020(current);
        if (delta.method_1027() < 1.2D) {
            currentWaypointIndex++;
            if (currentWaypointIndex >= waypoints.size()) {
                beginMovingToCore();
                return;
            }
            target = waypoints.get(currentWaypointIndex).method_46558();
            delta = target.method_1020(current);
        }

        if (tryBeginTowerAttack()) {
            return;
        }
        applyMotion(delta);
    }

    private void beginMovingToCore() {
        setMoveState(EnemyMoveState.MOVING_TO_CORE);
        movingToCoreTicks = 0;
        stuckNearCoreTicks = 0;
        lastCoreDistanceSq = Double.MAX_VALUE;
        refreshRuntimeCoreTarget();
        if (coreTarget == null) {
            if (ConfigManager.general().debug) {
                HexaTowerDefenseMod.LOGGER.warn("[HexaTowerDefense] Enemy reached last waypoint but no coreTarget was found. arena={} lane={}", arenaId, laneId);
            }
            stopMovement(true);
            return;
        }
        normalizeCoreAttackPoint();
        moveToCore();
    }

    private void moveToCore() {
        refreshRuntimeCoreTarget();
        if (coreTarget == null) {
            stopMovement(true);
            return;
        }
        normalizeCoreAttackPoint();

        double coreDistanceSq = squaredHorizontalDistanceToBlock(coreTarget);
        double effectiveAttackRange = effectiveCoreAttackRange();
        if (coreDistanceSq <= effectiveAttackRange * effectiveAttackRange) {
            beginCoreAttack();
            return;
        }
        if (hasCrossedCoreLine(coreDistanceSq)) {
            beginCoreAttack();
            return;
        }
        if (coreAttackPoint != null && squaredHorizontalDistanceToBlock(coreAttackPoint) <= Math.max(stopDistance, 2.2D) * Math.max(stopDistance, 2.2D)) {
            beginCoreAttack();
            return;
        }
        if (isStuckNearCore(coreDistanceSq)) {
            beginCoreAttack();
            return;
        }
        if (tryBeginTowerAttack()) {
            return;
        }

        class_2338 targetPos = coreApproachPoint != null && squaredHorizontalDistanceToBlock(coreApproachPoint) > stopDistance * stopDistance
                ? coreApproachPoint
                : coreAttackPoint != null ? coreAttackPoint : coreTarget;
        if (targetPos == null) {
            stopMovement(false);
            return;
        }
        class_243 target = targetPos.method_46558();
        class_243 delta = target.method_1020(method_19538());
        if (horizontalLengthSquared(delta) <= Math.max(stopDistance, 2.0D) * Math.max(stopDistance, 2.0D)) {
            if (targetPos.equals(coreAttackPoint) || targetPos.equals(coreTarget)) {
                beginCoreAttack();
            } else {
                coreApproachPoint = null;
                moveToCore();
            }
            return;
        }
        applyMotion(delta);
    }

    private void tickCoreAttack() {
        stopMovement(true);
        if (coreTarget != null) {
            face(coreTarget.method_46558().method_1020(method_19538()));
        }
        if (attackCooldownTicks > 0) {
            attackCooldownTicks--;
            return;
        }
        ArenaInstance arena = ArenaManager.get().getArenaById(arenaId);
        if (arena == null || arena.coreController() == null || arena.coreController().isDestroyed()) {
            HexaTowerDefenseMod.LOGGER.warn("[HexaTowerDefense] Enemy cannot attack core: CoreController missing arena={} lane={} type={}", arenaId, laneId, enemyType);
            method_31472();
            setMoveState(EnemyMoveState.DEAD);
            return;
        }
        arena.coreController().damage(coreDamage, this);
        method_37908().method_8396(null, method_24515(), class_3417.field_14562, class_3419.field_15251, 0.55F, 1.15F);
        attackCooldownTicks = attackCooldownMax;
    }

    private void tickTowerAttack() {
        stopMovement(true);
        ArenaInstance arena = ArenaManager.get().getArenaById(arenaId);
        if (arena == null || targetTowerUuid == null) {
            resumeMovementAfterTower();
            return;
        }
        var tower = arena.towerManager().towerByUuid(targetTowerUuid);
        if (tower == null || tower.method_31481()) {
            resumeMovementAfterTower();
            return;
        }
        class_243 toTower = tower.method_19538().method_1020(method_19538());
        if (horizontalLengthSquared(toTower) > 36.0D) {
            resumeMovementAfterTower();
            return;
        }
        face(toTower);
        if (towerAttackCooldownTicks > 0) {
            towerAttackCooldownTicks--;
            return;
        }
        int damage = Math.max(3, coreDamage / 2);
        boolean destroyed = tower.damageTower(damage);
        method_37908().method_8396(null, tower.method_24515(), class_3417.field_14562, class_3419.field_15251, 0.5F, 1.25F);
        towerAttackCooldownTicks = attackCooldownMax;
        if (destroyed) {
            arena.towerManager().removeTower(tower);
            resumeMovementAfterTower();
        }
    }

    private void applyMotion(class_243 delta) {
        if (delta.method_1027() <= 0.0025D) {
            stopMovement(false);
            return;
        }
        class_243 horizontal = new class_243(delta.field_1352, 0.0D, delta.field_1350);
        if (horizontal.method_1027() <= 0.0025D) {
            stopMovement(false);
            return;
        }
        class_243 velocity = horizontal.method_1029().method_1021(laneSpeed);
        method_5814(method_23317() + velocity.field_1352, method_23318(), method_23321() + velocity.field_1350);
        method_18800(0.0D, 0.0D, 0.0D);
        field_6007 = true;
        face(velocity);
    }

    private void beginCoreAttack() {
        setMoveState(EnemyMoveState.ATTACKING_CORE);
        this.field_5960 = true;
        this.attackCooldownTicks = 0;
        stopMovement(true);
        if (coreTarget != null) {
            face(coreTarget.method_46558().method_1020(method_19538()));
        }
        if (ConfigManager.general().debug) {
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] Enemy entered ATTACKING_CORE arena={} lane={} type={} pos={} core={} range={}",
                    arenaId, laneId, enemyType, method_24515(), coreTarget, effectiveCoreAttackRange());
        }
    }

    private boolean tryBeginTowerAttack() {
        ArenaInstance arena = ArenaManager.get().getArenaById(arenaId);
        if (arena == null) {
            return false;
        }
        var blockingTower = arena.towerManager().blockingTowerFor(laneId, method_19538());
        if (blockingTower.isEmpty()) {
            return false;
        }
        beginTowerAttack(blockingTower.get());
        return true;
    }

    private void beginTowerAttack(com.zjuqni.hexatowerdefense.tower.HTDTowerEntity tower) {
        resumeAfterTowerState = moveState == EnemyMoveState.MOVING_TO_CORE ? EnemyMoveState.MOVING_TO_CORE : EnemyMoveState.MOVING_LANE;
        targetTowerUuid = tower.method_5667();
        towerAttackCooldownTicks = 0;
        setMoveState(EnemyMoveState.ATTACKING_TOWER);
        stopMovement(true);
        face(tower.method_19538().method_1020(method_19538()));
    }

    private void resumeMovementAfterTower() {
        targetTowerUuid = null;
        setMoveState(resumeAfterTowerState == EnemyMoveState.MOVING_TO_CORE ? EnemyMoveState.MOVING_TO_CORE : EnemyMoveState.MOVING_LANE);
    }

    private void tickStun() {
        stopMovement(true);
        if (stunTicks > 0) {
            stunTicks--;
        }
        if (stunTicks <= 0) {
            setMoveState(stateBeforeStun == EnemyMoveState.STUNNED ? EnemyMoveState.MOVING_LANE : stateBeforeStun);
        }
    }

    public void stun(int ticks) {
        if (ticks <= 0 || moveState == EnemyMoveState.DEAD) {
            return;
        }
        if (enemyType == EnemyType.LAVA_GOLEM || stunImmunityTicks > 0) {
            return;
        }
        if (moveState != EnemyMoveState.STUNNED) {
            stateBeforeStun = moveState;
        }
        stunTicks = Math.max(stunTicks, ticks);
        // Inmunidad: los ticks del stun actual + 2 segundos libres despues de terminar.
        stunImmunityTicks = stunTicks + 40;
        setMoveState(EnemyMoveState.STUNNED);
        stopMovement(true);
    }

    private void stopMovement(boolean fullStop) {
        class_243 current = method_18798();
        method_18800(0.0D, fullStop ? 0.0D : current.field_1351, 0.0D);
        field_6007 = true;
    }

    private void setMoveState(EnemyMoveState newState) {
        this.moveState = newState;
        this.field_6011.method_12778(TRACKED_MOVE_STATE, newState.ordinal());
    }

    private EnemyMoveState trackedMoveState() {
        int ordinal = field_6011.method_12789(TRACKED_MOVE_STATE);
        EnemyMoveState[] values = EnemyMoveState.values();
        return ordinal >= 0 && ordinal < values.length ? values[ordinal] : EnemyMoveState.MOVING_LANE;
    }

    private EnemyType trackedEnemyType() {
        int ordinal = field_6011.method_12789(TRACKED_ENEMY_TYPE);
        EnemyType[] values = EnemyType.values();
        return ordinal >= 0 && ordinal < values.length ? values[ordinal] : EnemyType.GREEN_MINION;
    }

    private static boolean isAttacking(EnemyMoveState state) {
        return state == EnemyMoveState.ATTACKING_CORE || state == EnemyMoveState.ATTACKING_TOWER;
    }

    private void refreshRuntimeCoreTarget() {
        ArenaInstance arena = ArenaManager.get().getArenaById(arenaId);
        if (arena != null && arena.coreController() != null && !arena.coreController().isDestroyed()) {
            coreTarget = arena.coreController().corePosition();
        }
    }

    private void normalizeCoreAttackPoint() {
        if (coreTarget == null) {
            return;
        }
        int sideZ = coreTarget.method_10260() + Math.max(2, (int) Math.ceil(effectiveCoreAttackRange()));
        int xOffset = Math.max(-2, Math.min(2, laneId - 2));
        coreAttackPoint = new class_2338(coreTarget.method_10263() + xOffset, coreTarget.method_10264(), sideZ);
        coreApproachPoint = new class_2338(coreAttackPoint.method_10263(), coreTarget.method_10264(), coreAttackPoint.method_10260() + 4);
    }

    private boolean hasCrossedCoreLine(double coreDistanceSq) {
        if (coreTarget == null) {
            return false;
        }
        double maxLineDistanceSq = enemyType == EnemyType.LAVA_GOLEM ? 64.0D : 49.0D;
        return method_23321() <= coreTarget.method_10260() + effectiveCoreAttackRange() + 1.5D && coreDistanceSq <= maxLineDistanceSq;
    }

    private boolean isStuckNearCore(double coreDistanceSq) {
        movingToCoreTicks++;
        if (coreDistanceSq < lastCoreDistanceSq - 0.04D) {
            stuckNearCoreTicks = 0;
            lastCoreDistanceSq = coreDistanceSq;
            return false;
        }
        lastCoreDistanceSq = coreDistanceSq;
        if (coreDistanceSq > 144.0D) {
            stuckNearCoreTicks = 0;
            return false;
        }
        stuckNearCoreTicks++;
        return movingToCoreTicks > 40 && stuckNearCoreTicks > 35;
    }

    private double effectiveCoreAttackRange() {
        return Math.max(attackRange, enemyType == EnemyType.LAVA_GOLEM ? 3.25D : 4.0D);
    }

    private void applySeparation() {
        if (moveState != EnemyMoveState.MOVING_LANE && moveState != EnemyMoveState.MOVING_TO_CORE) {
            return;
        }
        ArenaInstance arena = ArenaManager.get().getArenaById(arenaId);
        if (arena == null) {
            return;
        }
        class_243 push = class_243.field_1353;
        for (HTDEnemyEntity other : arena.enemyManager().enemies()) {
            if (other == this || other.method_31481() || other.laneId != laneId) {
                continue;
            }
            class_243 away = method_19538().method_1020(other.method_19538());
            double distSq = away.method_1027();
            if (distSq > 0.0001D && distSq < 0.42D) {
                push = push.method_1019(away.method_1029().method_1021(0.012D));
            }
        }
        if (push.method_1027() > 0.0D) {
            method_5814(method_23317() + push.field_1352, method_23318(), method_23321() + push.field_1350);
            method_18800(0.0D, 0.0D, 0.0D);
            field_6007 = true;
        }
    }

    private void face(class_243 velocity) {
        if (velocity.method_1027() <= 0.0001D) {
            return;
        }
        float yaw = (float) (Math.toDegrees(Math.atan2(velocity.field_1350, velocity.field_1352)) - 90.0D);
        method_36456(yaw);
        field_6283 = yaw;
        field_6241 = yaw;
    }

    private void applyNameVisibility() {
        if (ConfigManager.general().debugShowEnemyNames) {
            method_5665(net.minecraft.class_2561.method_43470(enemyType.name() + " L" + laneId));
            method_5880(true);
            return;
        }
        method_5665(null);
        method_5880(false);
    }

    public void setBossBarEnabled(boolean enabled) {
        this.bossBarEnabled = enabled;
        if (!enabled) {
            closeBossBar();
        }
    }

    private void setupBossBar() {
        closeBossBar();
        if (method_37908().method_8608() || enemyType != EnemyType.LAVA_GOLEM || !bossBarEnabled) {
            return;
        }
        bossBar = new class_3213(class_2561.method_43470("Golem de Lava"), class_1259.class_1260.field_5784, class_1259.class_1261.field_5795);
        updateBossBar();
    }

    private void updateBossBar() {
        if (bossBar == null) {
            return;
        }
        bossBar.method_5408(Math.max(0.0F, Math.min(1.0F, method_6032() / method_6063())));
        bossBar.method_5413(class_2561.method_43470("Golem de Lava " + Math.max(0, Math.round(method_6032())) + "/" + Math.round(method_6063())));
        ArenaInstance arena = ArenaManager.get().getArenaById(arenaId);
        if (arena == null) {
            return;
        }
        for (class_3222 owner : arena.getPlayers()) {
            if (!bossBar.method_14092().contains(owner)) {
                bossBar.method_14088(owner);
            }
        }
    }

    public void closeBossBar() {
        if (bossBar != null) {
            bossBar.method_14094();
            bossBar = null;
        }
    }

    private void enforceArenaBounds() {
        ArenaInstance arena = ArenaManager.get().getArenaById(arenaId);
        if (arena == null || arena.bounds() == null) {
            return;
        }
        class_2338 pos = method_24515();
        if (!arena.bounds().method_1008(pos.method_10263() + 0.5D, pos.method_10264() + 0.5D, pos.method_10260() + 0.5D)) {
            if (ConfigManager.general().debug) {
                HexaTowerDefenseMod.LOGGER.warn("[HexaTowerDefense] Enemy removed reason=out_of_bounds arena={} lane={} pos={}",
                        arenaId, laneId, pos);
            }
            setMoveState(EnemyMoveState.DEAD);
            method_31472();
        }
    }

    private void refreshEnemyHitbox() {
        EnemyHitboxSize size = hitboxSizeFor(trackedEnemyType());
        double half = size.width() / 2.0D;
        double minY = method_23318() + size.yOffset();
        method_5857(new class_238(
                method_23317() - half,
                minY,
                method_23321() - half,
                method_23317() + half,
                minY + size.height(),
                method_23321() + half
        ));
    }

    private double squaredDistanceToBlock(class_2338 pos) {
        return method_19538().method_1025(pos.method_46558());
    }

    private double squaredHorizontalDistanceToBlock(class_2338 pos) {
        class_243 target = pos.method_46558();
        double dx = method_23317() - target.field_1352;
        double dz = method_23321() - target.field_1350;
        return dx * dx + dz * dz;
    }

    private static double horizontalLengthSquared(class_243 vector) {
        return vector.field_1352 * vector.field_1352 + vector.field_1350 * vector.field_1350;
    }

    private static double squaredHorizontal(class_2338 first, class_2338 second) {
        double dx = first.method_10263() - second.method_10263();
        double dz = first.method_10260() - second.method_10260();
        return dx * dx + dz * dz;
    }

    @Override
    public void method_5652(class_2487 nbt) {
        super.method_5652(nbt);
        nbt.method_10569("ArenaId", arenaId);
        nbt.method_10569("LaneId", laneId);
        nbt.method_10582("EnemyType", enemyType.name());
        nbt.method_10582("MoveState", moveState.name());
        nbt.method_10549("AttackRange", attackRange);
        nbt.method_10549("StopDistance", stopDistance);
        nbt.method_10569("StunTicks", stunTicks);
        nbt.method_10556("ShinyMob", isShinyMob());
        nbt.method_10556("ShinyPointsAwarded", shinyPointsAwarded);
    }

    @Override
    public void method_5749(class_2487 nbt) {
        super.method_5749(nbt);
        arenaId = nbt.method_10550("ArenaId");
        laneId = nbt.method_10550("LaneId");
        try {
            enemyType = EnemyType.valueOf(nbt.method_10558("EnemyType"));
        } catch (IllegalArgumentException ignored) {
            enemyType = EnemyType.GREEN_MINION;
        }
        field_6011.method_12778(TRACKED_ENEMY_TYPE, enemyType.ordinal());
        try {
            setMoveState(EnemyMoveState.valueOf(nbt.method_10558("MoveState")));
        } catch (IllegalArgumentException ignored) {
            setMoveState(EnemyMoveState.MOVING_LANE);
        }
        attackRange = nbt.method_10545("AttackRange") ? nbt.method_10574("AttackRange") : attackRange;
        stopDistance = nbt.method_10545("StopDistance") ? nbt.method_10574("StopDistance") : stopDistance;
        stunTicks = nbt.method_10545("StunTicks") ? nbt.method_10550("StunTicks") : 0;
        setShinyMob(nbt.method_10545("ShinyMob") && nbt.method_10577("ShinyMob"));
        shinyPointsAwarded = nbt.method_10545("ShinyPointsAwarded") && nbt.method_10577("ShinyPointsAwarded");
        applyNameVisibility();
    }

    public int arenaId() {
        return arenaId;
    }

    public int laneId() {
        return laneId;
    }

    public EnemyType enemyType() {
        return trackedEnemyType();
    }

    public EnemyMoveState moveState() {
        return moveState;
    }

    private static double speedFor(EnemyType enemyType) {
        return switch (enemyType) {
            case BLUE_MINION -> 0.075D;
            case PURPLE_MINION -> 0.08D;
            case GREEN_KNIGHT_MINION, BLUE_KNIGHT_MINION, PURPLE_KNIGHT_MINION -> 0.055D;
            case LAVA_GOLEM -> 0.035D;
            default -> 0.07D;
        };
    }

    private static int damageFor(EnemyType enemyType) {
        return switch (enemyType) {
            case BLUE_MINION -> 15;
            case PURPLE_MINION -> 22;
            case GREEN_KNIGHT_MINION -> 18;
            case BLUE_KNIGHT_MINION -> 24;
            case PURPLE_KNIGHT_MINION -> 32;
            case LAVA_GOLEM -> 60;
            default -> 10;
        };
    }

    private static int attackCooldownFor(EnemyType enemyType) {
        return enemyType == EnemyType.LAVA_GOLEM ? 60 : 40;
    }

    private static EnemyHitboxSize hitboxSizeFor(EnemyType enemyType) {
        return switch (enemyType) {
            case GREEN_KNIGHT_MINION, BLUE_KNIGHT_MINION, PURPLE_KNIGHT_MINION -> new EnemyHitboxSize(3.45D, 2.7D, 0.0D);
            case LAVA_GOLEM -> new EnemyHitboxSize(4.45D, 4.15D, 0.0D);
            default -> new EnemyHitboxSize(3.4D, 2.7D, 0.0D);
        };
    }

    private record EnemyHitboxSize(double width, double height, double yOffset) {
    }
}
