package com.zjuqni.hexatowerdefense.enemy;

public final class EnemyStats {
}
