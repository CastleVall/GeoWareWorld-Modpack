package com.zjuqni.hexatowerdefense.projectile;

public final class ProjectileManager {
}
