package com.zjuqni.hexatowerdefense.projectile;

public enum ProjectileType {
    BASIC,
    CROSSBOW,
    CANNON,
    TESLA_LOGIC
}
