package com.zjuqni.hexatowerdefense.network;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record BuyShopItemC2SPayload(String itemId) implements class_8710 {
    public static final class_9154<BuyShopItemC2SPayload> ID = new class_9154<>(HexaTowerDefenseMod.id("buy_shop_item"));
    public static final class_9139<class_9129, BuyShopItemC2SPayload> CODEC = class_9139.method_56438(BuyShopItemC2SPayload::write, BuyShopItemC2SPayload::new);

    private BuyShopItemC2SPayload(class_9129 buf) {
        this(buf.method_19772());
    }

    private void write(class_9129 buf) {
        buf.method_10814(itemId);
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
