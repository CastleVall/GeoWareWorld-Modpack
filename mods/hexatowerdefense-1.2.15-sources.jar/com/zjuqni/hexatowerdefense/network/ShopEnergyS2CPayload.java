package com.zjuqni.hexatowerdefense.network;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record ShopEnergyS2CPayload(int energy, boolean success, String message) implements class_8710 {
    public static final class_9154<ShopEnergyS2CPayload> ID = new class_9154<>(HexaTowerDefenseMod.id("shop_energy"));
    public static final class_9139<class_9129, ShopEnergyS2CPayload> CODEC = class_9139.method_56438(ShopEnergyS2CPayload::write, ShopEnergyS2CPayload::new);

    private ShopEnergyS2CPayload(class_9129 buf) {
        this(buf.method_10816(), buf.readBoolean(), buf.method_19772());
    }

    private void write(class_9129 buf) {
        buf.method_10804(energy);
        buf.method_52964(success);
        buf.method_10814(message);
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
