package com.zjuqni.hexatowerdefense.network;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record OpenShopS2CPayload(int energy) implements class_8710 {
    public static final class_9154<OpenShopS2CPayload> ID = new class_9154<>(HexaTowerDefenseMod.id("open_shop"));
    public static final class_9139<class_9129, OpenShopS2CPayload> CODEC = class_9139.method_56438(OpenShopS2CPayload::write, OpenShopS2CPayload::new);

    private OpenShopS2CPayload(class_9129 buf) {
        this(buf.method_10816());
    }

    private void write(class_9129 buf) {
        buf.method_10804(energy);
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
