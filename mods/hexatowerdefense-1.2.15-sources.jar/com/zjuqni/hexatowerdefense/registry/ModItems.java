package com.zjuqni.hexatowerdefense.registry;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import com.zjuqni.hexatowerdefense.item.EnergyCellItem;
import com.zjuqni.hexatowerdefense.tower.TowerPlacementItem;
import com.zjuqni.hexatowerdefense.tower.TowerType;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ModItems {
    public static final class_1792 ENERGY_CELL = register("energy_cell", new EnergyCellItem(new class_1792.class_1793().method_7889(99)));
    public static final class_1792 GEOTHERMAL_CORE_ITEM = register("geothermal_core_item", new class_1792(new class_1792.class_1793()));
    public static final class_1792 GREEN_UPGRADE_KIT = register("green_upgrade_kit", new class_1792(new class_1792.class_1793()));
    public static final class_1792 BLUE_UPGRADE_KIT = register("blue_upgrade_kit", new class_1792(new class_1792.class_1793()));
    public static final class_1792 RED_UPGRADE_KIT = register("red_upgrade_kit", new class_1792(new class_1792.class_1793()));

    public static final class_1792 PANEL_SOLAR_ITEM = register("panel_solar_item", new TowerPlacementItem(TowerType.PANEL_SOLAR, new class_1792.class_1793()));
    public static final class_1792 TURRET_ITEM = register("turret_item", new TowerPlacementItem(TowerType.TURRET, new class_1792.class_1793()));
    public static final class_1792 CROSSBOW_TOWER_ITEM = register("crossbow_tower_item", new TowerPlacementItem(TowerType.CROSSBOW_TOWER, new class_1792.class_1793()));
    public static final class_1792 CANNON_ITEM = register("cannon_item", new TowerPlacementItem(TowerType.CANNON, new class_1792.class_1793()));
    public static final class_1792 HOLOGRAPHIC_SHIELD_ITEM = register("holographic_shield_item", new TowerPlacementItem(TowerType.HOLOGRAPHIC_SHIELD, new class_1792.class_1793()));
    public static final class_1792 ION_BATTERY_ITEM = register("ion_battery_item", new TowerPlacementItem(TowerType.ION_BATTERY, new class_1792.class_1793()));
    public static final class_1792 TESLA_TOWER_ITEM = register("tesla_tower_item", new TowerPlacementItem(TowerType.TESLA_TOWER, new class_1792.class_1793()));

    private ModItems() {
    }

    public static void init() {
    }

    private static class_1792 register(String path, class_1792 item) {
        class_2960 id = HexaTowerDefenseMod.id(path);
        return class_2378.method_10230(class_7923.field_41178, id, item);
    }
}
