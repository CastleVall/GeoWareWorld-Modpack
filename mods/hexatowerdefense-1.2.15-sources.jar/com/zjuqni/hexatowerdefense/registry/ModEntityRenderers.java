package com.zjuqni.hexatowerdefense.registry;

import com.zjuqni.hexatowerdefense.client.renderer.CoreRenderer;
import com.zjuqni.hexatowerdefense.client.renderer.KnightMinionRenderer;
import com.zjuqni.hexatowerdefense.client.renderer.LavaGolemRenderer;
import com.zjuqni.hexatowerdefense.client.renderer.MinionRenderer;
import com.zjuqni.hexatowerdefense.client.renderer.TowerRenderer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public final class ModEntityRenderers {
    private ModEntityRenderers() {
    }

    public static void init() {
        EntityRendererRegistry.register(ModEntities.HTD_ENEMY, MinionRenderer::new);
        EntityRendererRegistry.register(ModEntities.HTD_KNIGHT_ENEMY, KnightMinionRenderer::new);
        EntityRendererRegistry.register(ModEntities.HTD_LAVA_GOLEM, LavaGolemRenderer::new);
        EntityRendererRegistry.register(ModEntities.HTD_TOWER, TowerRenderer::new);
        EntityRendererRegistry.register(ModEntities.CORE, CoreRenderer::new);
    }
}
