package com.zjuqni.hexatowerdefense.registry;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import net.minecraft.class_1937;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public final class ModDimensions {
    public static final class_5321<class_1937> INSTANCES_WORLD = class_5321.method_29179(
            class_7924.field_41223,
            HexaTowerDefenseMod.id("instances")
    );

    private ModDimensions() {
    }

    public static void init() {
        // The dimension is provided by data/hexatowerdefense/dimension/instances.json.
    }
}
