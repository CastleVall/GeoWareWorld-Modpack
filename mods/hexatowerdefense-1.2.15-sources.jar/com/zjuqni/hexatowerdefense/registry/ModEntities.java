package com.zjuqni.hexatowerdefense.registry;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import com.zjuqni.hexatowerdefense.core.CoreEntity;
import com.zjuqni.hexatowerdefense.enemy.HTDEnemyEntity;
import com.zjuqni.hexatowerdefense.tower.HTDTowerEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_4048;
import net.minecraft.class_7923;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;

public final class ModEntities {
    public static final class_1299<HTDEnemyEntity> HTD_ENEMY = class_2378.method_10230(
            class_7923.field_41177,
            HexaTowerDefenseMod.id("htd_enemy"),
            FabricEntityTypeBuilder.create(class_1311.field_6302, HTDEnemyEntity::new)
                    .dimensions(class_4048.method_18385(3.4F, 2.7F))
                    .trackRangeChunks(8)
                    .trackedUpdateRate(2)
                    .build()
    );

    public static final class_1299<HTDEnemyEntity> HTD_KNIGHT_ENEMY = class_2378.method_10230(
            class_7923.field_41177,
            HexaTowerDefenseMod.id("htd_knight_enemy"),
            FabricEntityTypeBuilder.create(class_1311.field_6302, HTDEnemyEntity::new)
                    .dimensions(class_4048.method_18385(3.45F, 2.7F))
                    .trackRangeChunks(8)
                    .trackedUpdateRate(2)
                    .build()
    );

    public static final class_1299<HTDEnemyEntity> HTD_LAVA_GOLEM = class_2378.method_10230(
            class_7923.field_41177,
            HexaTowerDefenseMod.id("htd_lava_golem"),
            FabricEntityTypeBuilder.create(class_1311.field_6302, HTDEnemyEntity::new)
                    .dimensions(class_4048.method_18385(4.45F, 4.15F))
                    .trackRangeChunks(8)
                    .trackedUpdateRate(2)
                    .build()
    );

    public static final class_1299<HTDTowerEntity> HTD_TOWER = class_2378.method_10230(
            class_7923.field_41177,
            HexaTowerDefenseMod.id("htd_tower"),
            FabricEntityTypeBuilder.create(class_1311.field_17715, HTDTowerEntity::new)
                    .dimensions(class_4048.method_18385(2.0F, 2.25F))
                    .trackRangeChunks(8)
                    .trackedUpdateRate(2)
                    .build()
    );

    public static final class_1299<CoreEntity> CORE = class_2378.method_10230(
            class_7923.field_41177,
            HexaTowerDefenseMod.id("geothermal_core"),
            FabricEntityTypeBuilder.create(class_1311.field_17715, CoreEntity::new)
                    .dimensions(class_4048.method_18385(1.6F, 2.2F))
                    .trackRangeChunks(8)
                    .trackedUpdateRate(2)
                    .build()
    );

    private ModEntities() {
    }

    public static void init() {
        FabricDefaultAttributeRegistry.register(HTD_ENEMY, HTDEnemyEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(HTD_KNIGHT_ENEMY, HTDEnemyEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(HTD_LAVA_GOLEM, HTDEnemyEntity.createAttributes());
    }
}
