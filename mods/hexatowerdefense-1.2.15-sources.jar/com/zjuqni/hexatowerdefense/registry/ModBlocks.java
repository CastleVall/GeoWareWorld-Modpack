package com.zjuqni.hexatowerdefense.registry;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

public final class ModBlocks {
    public static final class_2248 SHOP_BLOCK = register("shop_block", new class_2248(class_4970.class_2251.method_9630(class_2246.field_16328).method_22488()));

    private ModBlocks() {
    }

    public static void init() {
    }

    private static class_2248 register(String path, class_2248 block) {
        class_2960 id = HexaTowerDefenseMod.id(path);
        class_2248 registered = class_2378.method_10230(class_7923.field_41175, id, block);
        class_2378.method_10230(class_7923.field_41178, id, new class_1747(registered, new class_1792.class_1793()));
        return registered;
    }
}
