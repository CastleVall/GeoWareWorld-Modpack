package com.zjuqni.hexatowerdefense.registry;

public final class ModSounds {
    private ModSounds() {
    }

    public static void init() {
    }
}
