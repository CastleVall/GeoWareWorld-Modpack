package com.zjuqni.hexatowerdefense.registry;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.zjuqni.hexatowerdefense.arena.ArenaInstance;
import com.zjuqni.hexatowerdefense.arena.ArenaManager;
import com.zjuqni.hexatowerdefense.config.ConfigManager;
import com.zjuqni.hexatowerdefense.layout.GeneratedArenaLayout;
import com.zjuqni.hexatowerdefense.layout.LaneDefinition;
import com.zjuqni.hexatowerdefense.layout.ReferenceLayoutMapper;
import com.zjuqni.hexatowerdefense.layout.StructurePlacementCell;
import com.zjuqni.hexatowerdefense.schematic.SchematicTemplate;
import com.zjuqni.hexatowerdefense.shop.ShopManager;
import com.zjuqni.hexatowerdefense.util.HTDText;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public final class ModCommands {
    private ModCommands() {
    }

    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(class_2170.method_9247("hexatower")
                        .requires(source -> source.method_9259(2))
                        .then(class_2170.method_9247("start")
                                .executes(context -> start(context.getSource(), context.getSource().method_44023()))
                                .then(class_2170.method_9244("targets", class_2186.method_9308())
                                        .executes(context -> start(context.getSource(), class_2186.method_9312(context, "targets")))))
                        .then(class_2170.method_9247("teststart")
                                .executes(context -> teststart(context.getSource(), List.of(context.getSource().method_9207())))
                                .then(class_2170.method_9244("targets", class_2186.method_9308())
                                        .executes(context -> teststart(context.getSource(), class_2186.method_9312(context, "targets")))))
                        .then(class_2170.method_9247("generate")
                                .then(class_2170.method_9244("targets", class_2186.method_9308())
                                        .executes(context -> generate(context.getSource(), class_2186.method_9312(context, "targets")))))
                        .then(class_2170.method_9247("stop")
                                .then(class_2170.method_9244("targets", class_2186.method_9308())
                                        .executes(context -> stop(context.getSource(), class_2186.method_9312(context, "targets")))))
                        .then(class_2170.method_9247("reload").executes(context -> reloadConfig(context.getSource())))
                        .then(class_2170.method_9247("load")
                                .then(class_2170.method_9244("amount", IntegerArgumentType.integer(1))
                                        .executes(context -> load(context.getSource(), IntegerArgumentType.getInteger(context, "amount")))))
                        .then(class_2170.method_9247("unload")
                                .then(class_2170.method_9247("all")
                                        .executes(context -> unloadAll(context.getSource())))
                                .then(class_2170.method_9244("amount", IntegerArgumentType.integer(1))
                                        .executes(context -> unload(context.getSource(), IntegerArgumentType.getInteger(context, "amount")))))
                        .then(class_2170.method_9247("wipe")
                                .then(class_2170.method_9247("confirm")
                                        .executes(context -> wipe(context.getSource()))))
                        .then(class_2170.method_9247("status").executes(context -> status(context.getSource())))
                        .then(class_2170.method_9247("list").executes(context -> adminList(context.getSource())))
                        .then(class_2170.method_9247("tp")
                                .executes(context -> tpFirstArena(context.getSource()))
                                .then(class_2170.method_9244("arenaId", IntegerArgumentType.integer(0))
                                        .executes(context -> adminTp(context.getSource(), IntegerArgumentType.getInteger(context, "arenaId")))))));
    }

    private static int start(class_2168 source, class_3222 target) {
        if (target == null) {
            feedback(source, "Debes indicar jugadores: /hexatower start <jugadores>.");
            return 0;
        }
        return start(source, List.of(target));
    }

    private static int start(class_2168 source, Collection<class_3222> targets) {
        for (String message : ArenaManager.get().startArenas(targets, false)) {
            feedback(source, message);
        }
        feedback(source, "Start solicitado para " + targets.size() + " jugador(es). Las arenas se arman en dúo.");
        return targets.size();
    }

    private static int teststart(class_2168 source, Collection<class_3222> targets) {
        for (String message : ArenaManager.get().startArenas(targets, true)) {
            feedback(source, message);
        }
        feedback(source, "Teststart solicitado para " + targets.size() + " jugador(es). Cada arena se llena de torres al entrar.");
        return targets.size();
    }

    private static int load(class_2168 source, int amount) {
        int scheduled = ArenaManager.get().preloadArenas(amount);
        feedback(source, "Arenas precargandose: " + scheduled + "/" + amount + ".");
        if (scheduled > 0) {
            attachProgressBar(source);
            feedback(source, "Segui el progreso en la barra de arriba. NO uses /hexatower start hasta que termine.");
        }
        return scheduled;
    }

    private static int status(class_2168 source) {
        ArenaManager manager = ArenaManager.get();
        int generating = manager.generatingArenaCount();
        int ready = manager.readyArenaCount();
        int total = manager.activeArenas().size();

        feedback(source, "Arenas creadas: " + total + " | libres y listas: " + ready + " | generandose: " + generating);
        int queued = manager.pendingActivations();
        if (queued > 0) {
            feedback(source, "Jugadores entrando a su arena (en cola): " + queued);
        }
        if (generating > 0) {
            feedback(source, "Progreso: " + manager.loadProgress().finishedArenas() + "/"
                    + manager.loadProgress().totalArenas() + " - " + manager.loadProgress().etaLabel());
            feedback(source, "Ritmo actual: " + manager.pasteThrottle().currentBudget() + " bloques/tick"
                    + " (tick del servidor: " + Math.round(manager.pasteThrottle().averageServerTickMs()) + "ms)");
            attachProgressBar(source);
        } else if (ready > 0) {
            feedback(source, "Todo listo. Podes usar /hexatower start.");
        } else if (total > 0) {
            feedback(source, "No hay arenas libres: todas estan en partida.");
        } else {
            feedback(source, "No hay arenas. Crealas con /hexatower load <cantidad>.");
        }
        return 1;
    }

    private static void attachProgressBar(class_2168 source) {
        class_3222 player = source.method_44023();
        if (player != null) {
            ArenaManager.get().loadProgress().addViewer(player);
        }
    }

    private static int unload(class_2168 source, int amount) {
        int removed = ArenaManager.get().unloadArenas(amount);
        feedback(source, "Arenas libres borradas: " + removed + "/" + amount + ".");
        return removed;
    }

    private static int wipe(class_2168 source) {
        feedback(source, ArenaManager.get().wipeDimension());
        return 1;
    }

    private static int unloadAll(class_2168 source) {
        ArenaManager manager = ArenaManager.get();
        int free = manager.readyArenaCount();
        int removed = manager.unloadArenas(Integer.MAX_VALUE);
        int inGame = manager.activeArenas().size();
        feedback(source, "Arenas libres borradas: " + removed + "/" + free + ".");
        if (inGame > 0) {
            feedback(source, "Quedan " + inGame + " arena(s) en partida o generandose; esas no se tocan.");
        }
        return removed;
    }

    private static int generate(class_2168 source, Collection<class_3222> targets) {
        int requested = 0;
        for (class_3222 target : targets) {
            feedback(source, ArenaManager.get().generateArena(target));
            requested++;
        }
        feedback(source, "Generacion solicitada para " + requested + " jugador(es).");
        return requested;
    }

    private static int stop(class_2168 source, Collection<class_3222> targets) {
        int requested = 0;
        for (class_3222 target : targets) {
            feedback(source, ArenaManager.get().stopArena(target));
            requested++;
        }
        feedback(source, "Stop solicitado para " + requested + " jugador(es).");
        return requested;
    }

    private static int debugLayout(class_2168 source, class_3222 target) {
        ArenaInstance arena = ArenaManager.get().getArena(target);
        if (arena == null) {
            feedback(source, target.method_5477().getString() + " no tiene arena activa.");
            return 0;
        }

        feedback(source, "Arena #" + arena.arenaId() + " state=" + arena.state());
        feedback(source, "anchor: " + ArenaManager.formatBlockPos(arena.anchor()));
        feedback(source, "schematicBounds: " + ArenaManager.formatBox(arena.schematicBounds()));
        feedback(source, "gameplayBounds: " + ArenaManager.formatBox(arena.bounds()));
        feedback(source, "playerSpawn: " + formatNullablePos(arena.playerSpawnPosition()));
        feedback(source, "shopPos: " + formatNullablePos(arena.shopPosition()));
        feedback(source, "corePos: " + formatNullablePos(arena.corePosition()));
        GeneratedArenaLayout layout = arena.referenceLayout();
        if (layout == null) {
            feedback(source, "layout: none");
            return 0;
        }
        feedback(source, "source: " + layout.source + " offset=" + formatVec(layout.offset) + " mainMarkerY=" + layout.mainMarkerY);
        feedback(source, "relative playerSpawn: " + formatVec(layout.playerSpawn));
        feedback(source, "relative shop: " + formatVec(layout.shop.position));
        feedback(source, "relative core: " + formatVec(layout.core));
        feedback(source, "enemySpawnZone: " + formatVec(layout.enemySpawnZone.min) + " -> " + formatVec(layout.enemySpawnZone.max));
        feedback(source, "lanes: " + layout.lanes.size());
        feedback(source, "lockedLanes: " + layout.lockedLanes + " unlocked=" + arena.lockedLanesUnlocked());
        int occupied = arena.towerManager().occupiedCount();
        int free = Math.max(0, layout.placementCells.size() - occupied);
        feedback(source, "placementCells: " + layout.placementCells.size());
        feedback(source, "occupiedCells: " + occupied);
        feedback(source, "freeCells: " + free);
        feedback(source, "canPlaceOnLockedLanes: " + ConfigManager.general().allowPlacementOnLockedLanes);
        feedback(source, "markers: coal=" + layout.markerSummary.coalBlock
                + " netherite=" + layout.markerSummary.netheriteBlock
                + " redstone=" + layout.markerSummary.redstoneBlock
                + " gold=" + layout.markerSummary.goldBlock
                + " diamond=" + layout.markerSummary.diamondBlock
                + " emerald=" + layout.markerSummary.emeraldBlock);
        feedback(source, "waveRunning: " + arena.waveManager().isRunning());
        feedback(source, "nextWave: " + arena.waveManager().nextWaveInfo());
        feedback(source, "preparationTicksLeft: " + arena.preparationTicksLeft());
        feedback(source, "aliveEnemies: " + arena.enemyManager().liveCount());
        if (!layout.warnings.isEmpty()) {
            feedback(source, "warnings: " + layout.warnings);
        }
        showLayoutParticles(arena);
        return 1;
    }

    private static int reset(class_2168 source, class_3222 target) {
        return reset(source, List.of(target));
    }

    private static int reset(class_2168 source, Collection<class_3222> targets) {
        int requested = 0;
        for (class_3222 target : targets) {
            ArenaManager.get().resetArena(target);
            requested++;
        }
        feedback(source, "Reset solicitado para " + requested + " jugador(es).");
        return requested;
    }

    private static int debugArena(class_2168 source, class_3222 target) {
        ArenaInstance arena = ArenaManager.get().getArena(target);
        if (arena == null) {
            feedback(source, target.method_5477().getString() + " no tiene arena activa.");
            return 0;
        }

        SchematicTemplate template = ArenaManager.get().template();
        feedback(source, "Arena #" + arena.arenaId());
        feedback(source, "state: " + arena.state());
        feedback(source, "target: " + target.method_5477().getString());
        feedback(source, "anchor: " + ArenaManager.formatBlockPos(arena.anchor()));
        feedback(source, "bounds: " + ArenaManager.formatBox(arena.bounds()));
        feedback(source, "schematicBounds: " + ArenaManager.formatBox(arena.schematicBounds()));
        feedback(source, "playerSpawn: " + formatNullablePos(arena.playerSpawnPosition()));
        feedback(source, "shop: " + formatNullablePos(arena.shopPosition()));
        feedback(source, "playerUuid: " + arena.playerUuid());
        feedback(source, "dimension: " + arena.dimension().method_29177());
        feedback(source, "enemies: " + arena.enemyManager().liveCount());
        feedback(source, "towers: " + arena.towerManager().occupiedCount());
        feedback(source, "projectiles: 0");
        feedback(source, "energyCells: " + ShopManager.countEnergyCells(target));
        feedback(source, "coreHealth: " + com.zjuqni.hexatowerdefense.config.ConfigManager.general().coreHealth);
        feedback(source, "wave: 0");
        feedback(source, "elapsedTicks: " + arena.elapsedTicks());
        feedback(source, "preparationTicksLeft: " + arena.preparationTicksLeft());
        if (template != null) {
            feedback(source, "schematic: " + template.width() + "x" + template.height() + "x" + template.length()
                    + " offset [" + template.offset().method_10263() + ", " + template.offset().method_10264() + ", " + template.offset().method_10260() + "]"
                    + " nonAir " + template.nonAirBlockCount());
        }
        return 1;
    }

    private static int scanMarkers(class_2168 source) {
        try {
            Path output = ArenaManager.get().scanMarkers();
            feedback(source, "Reporte de markers generado: " + output);
            return 1;
        } catch (IOException | RuntimeException e) {
            feedback(source, "No se pudo escanear el schematic configurado: " + e.getMessage());
            return 0;
        }
    }

    private static int scanReference(class_2168 source) {
        try {
            GeneratedArenaLayout layout = new ReferenceLayoutMapper().scanAndGenerate();
            feedback(source, "Reference scan complete:");
            feedback(source, "coal_block: " + layout.markerSummary.coalBlock);
            feedback(source, "netherite_block: " + layout.markerSummary.netheriteBlock);
            feedback(source, "redstone_block: " + layout.markerSummary.redstoneBlock);
            feedback(source, "gold_block: " + layout.markerSummary.goldBlock);
            feedback(source, "diamond_block: " + layout.markerSummary.diamondBlock);
            feedback(source, "emerald_block: " + layout.markerSummary.emeraldBlock);
            feedback(source, "Main marker layer: Y=" + layout.mainMarkerY);
            feedback(source, "Placement cells: " + layout.placementCells.size());
            feedback(source, "Lanes: " + layout.lanes.size());
            feedback(source, "Locked lanes: " + layout.lockedLanes);
            feedback(source, "Player spawn: " + formatVec(layout.playerSpawn));
            feedback(source, "Shop: " + formatVec(layout.shop.position));
            feedback(source, "Enemy spawn zone: " + formatVec(layout.enemySpawnZone.min) + " -> " + formatVec(layout.enemySpawnZone.max));
            if (!layout.warnings.isEmpty()) {
                feedback(source, "Warnings:");
                for (String warning : layout.warnings) {
                    feedback(source, "- " + warning);
                }
            }
            feedback(source, "Generated: " + com.zjuqni.hexatowerdefense.config.ConfigManager.referenceMarkerReportPath());
            feedback(source, "Generated: " + com.zjuqni.hexatowerdefense.config.ConfigManager.generatedReferenceLayoutPath());
            return 1;
        } catch (IOException | RuntimeException e) {
            feedback(source, "No se pudo escanear referencia.schem: " + e.getMessage());
            return 0;
        }
    }

    private static int reloadConfig(class_2168 source) {
        try {
            ArenaManager.get().reloadConfig();
            feedback(source, "Configs recargadas.");
            return 1;
        } catch (IOException | RuntimeException e) {
            feedback(source, "No se pudieron recargar configs: " + e.getMessage());
            return 0;
        }
    }

    private static int buy(class_2168 source, String itemId) throws CommandSyntaxException {
        class_3222 player = source.method_44023();
        return ShopManager.buy(player, itemId) ? 1 : 0;
    }

    private static int testWave(class_2168 source, String enemy, int lane, int amount, boolean forceLockedLane) throws CommandSyntaxException {
        class_3222 player = source.method_44023();
        ArenaInstance arena = ArenaManager.get().getArena(player);
        if (arena == null) {
            feedback(source, "No tienes arena activa.");
            return 0;
        }
        int spawned = arena.enemyManager().spawnTestWave(enemy, lane, amount, forceLockedLane, player);
        return spawned > 0 ? 1 : 0;
    }

    private static int adminList(class_2168 source) {
        ArenaManager manager = ArenaManager.get();
        List<ArenaInstance> arenas = manager.activeArenas();
        if (arenas.isEmpty() && manager.generatingArenaCount() == 0) {
            feedback(source, "No hay arenas creadas. Usa /hexatower load <cantidad>.");
            return 1;
        }

        int ready = manager.readyArenaCount();
        int generating = manager.generatingArenaCount();
        List<String> playing = new ArrayList<>();
        for (ArenaInstance arena : arenas) {
            if (arena.playerUuid() != null) {
                List<String> names = new ArrayList<>();
                for (class_3222 member : arena.getPlayers()) {
                    names.add(member.method_5477().getString());
                }
                String who = names.isEmpty() ? arena.playerUuid().toString().substring(0, 8) : String.join(" + ", names);
                playing.add("#" + arena.arenaId() + " " + who + " (" + arena.state() + ")");
            }
        }

        feedback(source, "== Arenas ==");
        feedback(source, "Total creadas: " + arenas.size());
        feedback(source, "Libres y listas: " + ready);
        feedback(source, "En partida: " + playing.size());
        for (String line : playing) {
            feedback(source, "  - " + line);
        }
        if (generating > 0) {
            feedback(source, "Generandose: " + generating + " (" + manager.loadProgress().etaLabel() + ")");
        }
        return 1;
    }

    private static int adminStop(class_2168 source, Collection<class_3222> targets) {
        int requested = 0;
        for (class_3222 target : targets) {
            ArenaInstance arena = ArenaManager.get().getArena(target);
            if (arena == null) {
                feedback(source, target.method_5477().getString() + " no tiene arena activa.");
                continue;
            }
            ArenaManager.get().requestCleanup(arena, false);
            requested++;
        }
        feedback(source, "Admin stop enviado a " + requested + " arena(s).");
        return requested;
    }

    private static int tpFirstArena(class_2168 source) throws CommandSyntaxException {
        ArenaInstance first = null;
        for (ArenaInstance arena : ArenaManager.get().activeArenas()) {
            if (first == null || arena.arenaId() < first.arenaId()) {
                first = arena;
            }
        }
        if (first == null) {
            feedback(source, "No hay arenas creadas. Usa /hexatower load <cantidad> primero.");
            return 0;
        }
        return adminTp(source, first.arenaId());
    }

    private static int adminTp(class_2168 source, int arenaId) throws CommandSyntaxException {
        class_3222 player = source.method_44023();
        ArenaInstance arena = ArenaManager.get().getArenaById(arenaId);
        if (arena == null) {
            feedback(source, "No existe arena activa con id " + arenaId + ". Usa /hexatower list para ver las arenas.");
            return 0;
        }
        class_3218 world = arena.getWorld();
        if (world == null) {
            feedback(source, "No se pudo cargar la dimension hexatowerdefense:instances.");
            return 0;
        }
        class_2338 pos = arena.playerSpawnPosition() != null ? arena.playerSpawnPosition() : arena.anchor().method_10086(3);
        player.method_14251(world, pos.method_10263() + 0.5D, pos.method_10264(), pos.method_10260() + 0.5D, player.method_36454(), player.method_36455());
        feedback(source, "Teletransportado a arena #" + arenaId + " (" + arena.state() + ").");
        return 1;
    }

    private static int adminCleanup(class_2168 source, int arenaId) {
        ArenaInstance arena = ArenaManager.get().getArenaById(arenaId);
        if (arena == null) {
            feedback(source, "No existe arena activa con id " + arenaId + ".");
            return 0;
        }
        ArenaManager.get().requestCleanup(arena, false);
        feedback(source, "Arena #" + arenaId + " enviada a limpieza.");
        return 1;
    }

    private static int adminFree(class_2168 source, int arenaId) {
        ArenaManager.get().forceFreeSlot(arenaId);
        feedback(source, "Slot #" + arenaId + " liberado.");
        return 1;
    }

    private static int notInFirstDelivery(class_2168 source, String message) {
        feedback(source, message);
        return 0;
    }

    private static String formatNullablePos(class_2338 pos) {
        return pos == null ? "none" : ArenaManager.formatBlockPos(pos);
    }

    private static String formatVec(int[] value) {
        if (value == null || value.length < 3) {
            return "none";
        }
        return "[" + value[0] + ", " + value[1] + ", " + value[2] + "]";
    }

    private static void showLayoutParticles(ArenaInstance arena) {
        class_3218 world = arena.getWorld();
        GeneratedArenaLayout layout = arena.referenceLayout();
        if (world == null || layout == null) {
            return;
        }
        spawnParticle(world, arena.playerSpawnPosition(), class_2398.field_11207);
        spawnParticle(world, arena.shopPosition(), class_2398.field_11249);
        spawnParticle(world, arena.corePosition(), class_2398.field_11240);
        for (LaneDefinition lane : layout.lanes) {
            spawnParticle(world, lane.enemySpawnWorld(arena.anchor()), class_2398.field_11240);
        }
        int laneBudget = 0;
        for (LaneDefinition lane : layout.lanes) {
            for (class_2338 waypoint : lane.waypointsWorld(arena.anchor())) {
                if (laneBudget++ > 80) {
                    break;
                }
                spawnParticle(world, waypoint, class_2398.field_11211);
            }
        }
        int gridBudget = 0;
        for (StructurePlacementCell cell : layout.placementCells) {
            if (gridBudget++ > 120) {
                break;
            }
            class_2338 anchor = cell.anchorWorld(arena.anchor());
            spawnParticle(world, anchor, class_2398.field_29644);
            if (cell.occupied) {
                spawnParticle(world, anchor, class_2398.field_11240);
            } else if (arena.isLaneLocked(cell.laneId)) {
                spawnParticle(world, anchor, class_2398.field_17741);
            } else {
                spawnParticle(world, anchor, class_2398.field_11211);
            }
            if (cell.clickableGoldArea != null && cell.clickableGoldArea.min != null && cell.clickableGoldArea.max != null) {
                class_2338 min = arena.anchor().method_10069(cell.clickableGoldArea.min[0], cell.clickableGoldArea.min[1], cell.clickableGoldArea.min[2]);
                class_2338 max = arena.anchor().method_10069(cell.clickableGoldArea.max[0], cell.clickableGoldArea.max[1], cell.clickableGoldArea.max[2]);
                spawnParticle(world, min, class_2398.field_11240);
                spawnParticle(world, max, class_2398.field_11240);
            }
        }
    }

    private static void spawnParticle(class_3218 world, class_2338 pos, net.minecraft.class_2394 particle) {
        if (pos == null) {
            return;
        }
        world.method_14199(particle, pos.method_10263() + 0.5D, pos.method_10264() + 1.0D, pos.method_10260() + 0.5D, 8, 0.25D, 0.35D, 0.25D, 0.02D);
    }

    private static void feedback(class_2168 source, String message) {
        HTDText.feedback(source, message);
    }
}
