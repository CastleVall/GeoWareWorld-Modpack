package com.zjuqni.hexatowerdefense.registry;

public final class ModParticles {
    private ModParticles() {
    }

    public static void init() {
    }
}
