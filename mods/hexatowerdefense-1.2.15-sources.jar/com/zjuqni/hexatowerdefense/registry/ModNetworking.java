package com.zjuqni.hexatowerdefense.registry;

import com.zjuqni.hexatowerdefense.network.BuyShopItemC2SPayload;
import com.zjuqni.hexatowerdefense.network.OpenShopS2CPayload;
import com.zjuqni.hexatowerdefense.network.ShopEnergyS2CPayload;
import com.zjuqni.hexatowerdefense.shop.ShopManager;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

public final class ModNetworking {
    private ModNetworking() {
    }

    public static void init() {
        PayloadTypeRegistry.playS2C().register(OpenShopS2CPayload.ID, OpenShopS2CPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(ShopEnergyS2CPayload.ID, ShopEnergyS2CPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(BuyShopItemC2SPayload.ID, BuyShopItemC2SPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(BuyShopItemC2SPayload.ID,
                (payload, context) -> context.server().execute(() -> ShopManager.buyFromGui(context.player(), payload.itemId())));
    }
}
