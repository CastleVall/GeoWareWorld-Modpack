package com.zjuqni.hexatowerdefense.registry;

public final class ModMenus {
    private ModMenus() {
    }

    public static void init() {
    }
}
