package com.zjuqni.hexatowerdefense.util;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_3222;
import net.minecraft.class_5250;

public final class HTDText {
    private static final String ENERGY_GLYPH = "\uE000";

    private HTDText() {
    }

    public static class_5250 energy(String message) {
        return withEnergyCell("ENERGIA", class_124.field_1075, message, class_124.field_1065);
    }

    public static class_5250 success(String message) {
        return withEnergyCell("OK", class_124.field_1060, message, class_124.field_1054);
    }

    public static class_5250 warning(String message) {
        return withEnergyCell("!", class_124.field_1065, message, class_124.field_1054);
    }

    public static class_5250 error(String message) {
        return withEnergyCell("ERROR", class_124.field_1061, message, class_124.field_1061);
    }

    public static class_5250 info(String message) {
        return withEnergyCell("INFO", class_124.field_1062, message, class_124.field_1075);
    }

    public static class_5250 command(String message) {
        return class_2561.method_43470("")
                .method_10852(energyLabel())
                .method_10852(class_2561.method_43470(" • ").method_27695(class_124.field_1062, class_124.field_1067))
                .method_10852(defaultText(message, class_124.field_1075));
    }

    public static void sendEnergy(class_3222 player, String message, boolean actionBar) {
        player.method_7353(energy(message), actionBar);
    }

    public static void sendSuccess(class_3222 player, String message, boolean actionBar) {
        player.method_7353(success(message), actionBar);
    }

    public static void sendWarning(class_3222 player, String message, boolean actionBar) {
        player.method_7353(warning(message), actionBar);
    }

    public static void sendError(class_3222 player, String message, boolean actionBar) {
        player.method_7353(error(message), actionBar);
    }

    public static void sendInfo(class_3222 player, String message, boolean actionBar) {
        player.method_7353(info(message), actionBar);
    }

    public static void feedback(class_2168 source, String message) {
        source.method_9226(() -> command(message), false);
    }

    public static class_5250 energyLabel() {
        return class_2561.method_43470(ENERGY_GLYPH).method_10862(class_2583.field_24360
                .method_27704(HexaTowerDefenseMod.id("icons"))
                .method_36139(0xFFFFFF));
    }

    private static class_5250 withEnergyCell(String symbol, class_124 symbolColor, String message, class_124 messageColor) {
        return class_2561.method_43470("")
                .method_10852(energyLabel())
                .method_10852(defaultText(" " + symbol + " • ", symbolColor, class_124.field_1067))
                .method_10852(defaultText(message, messageColor));
    }

    private static class_5250 defaultText(String value, class_124... formatting) {
        return class_2561.method_43470(value).method_27695(formatting);
    }
}
