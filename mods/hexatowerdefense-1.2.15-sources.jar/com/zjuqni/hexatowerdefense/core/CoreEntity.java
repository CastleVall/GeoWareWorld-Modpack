package com.zjuqni.hexatowerdefense.core;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

public final class CoreEntity extends class_1297 implements GeoEntity {
    private static final class_2940<Integer> TRACKED_ARENA_ID = class_2945.method_12791(CoreEntity.class, class_2943.field_13327);
    private static final class_2940<Integer> TRACKED_HEALTH = class_2945.method_12791(CoreEntity.class, class_2943.field_13327);
    private static final class_2940<Integer> TRACKED_MAX_HEALTH = class_2945.method_12791(CoreEntity.class, class_2943.field_13327);
    private static final class_2940<Boolean> TRACKED_HUD_VISIBLE = class_2945.method_12791(CoreEntity.class, class_2943.field_13323);
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("animation.idle");
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private boolean runtimeSpawned;

    public CoreEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
        method_5875(true);
        field_5960 = true;
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        builder.method_56912(TRACKED_ARENA_ID, -1);
        builder.method_56912(TRACKED_HEALTH, 1000);
        builder.method_56912(TRACKED_MAX_HEALTH, 1000);
        builder.method_56912(TRACKED_HUD_VISIBLE, false);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "core", 0, state -> state.setAndContinue(IDLE)));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }

    public void configure(int arenaId) {
        configure(arenaId, health(), maxHealth());
    }

    public void configure(int arenaId, int health, int maxHealth) {
        this.runtimeSpawned = true;
        field_6011.method_12778(TRACKED_ARENA_ID, arenaId);
        setHealthValues(health, maxHealth);
        method_5665(null);
        method_5880(false);
    }

    public boolean isRuntimeSpawned() {
        return runtimeSpawned;
    }

    public void setHudVisible(boolean visible) {
        field_6011.method_12778(TRACKED_HUD_VISIBLE, visible);
    }

    public void setHealthValues(int health, int maxHealth) {
        int safeMax = Math.max(1, maxHealth);
        field_6011.method_12778(TRACKED_MAX_HEALTH, safeMax);
        field_6011.method_12778(TRACKED_HEALTH, Math.max(0, Math.min(safeMax, health)));
    }

    public int arenaId() {
        return field_6011.method_12789(TRACKED_ARENA_ID);
    }

    public int health() {
        return field_6011.method_12789(TRACKED_HEALTH);
    }

    public int maxHealth() {
        return field_6011.method_12789(TRACKED_MAX_HEALTH);
    }

    public boolean hudVisible() {
        return field_6011.method_12789(TRACKED_HUD_VISIBLE);
    }

    @Override
    protected void method_5749(class_2487 nbt) {
        this.runtimeSpawned = nbt.method_10577("RuntimeSpawned");
        field_6011.method_12778(TRACKED_ARENA_ID, nbt.method_10550("ArenaId"));
        field_6011.method_12778(TRACKED_HEALTH, nbt.method_10545("Health") ? nbt.method_10550("Health") : 1000);
        field_6011.method_12778(TRACKED_MAX_HEALTH, nbt.method_10545("MaxHealth") ? nbt.method_10550("MaxHealth") : 1000);
        field_6011.method_12778(TRACKED_HUD_VISIBLE, nbt.method_10577("HudVisible"));
    }

    @Override
    protected void method_5652(class_2487 nbt) {
        nbt.method_10556("RuntimeSpawned", runtimeSpawned);
        nbt.method_10569("ArenaId", arenaId());
        nbt.method_10569("Health", health());
        nbt.method_10569("MaxHealth", maxHealth());
        nbt.method_10556("HudVisible", hudVisible());
    }
}
