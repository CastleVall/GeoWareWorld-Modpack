package com.zjuqni.hexatowerdefense.core;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import com.zjuqni.hexatowerdefense.arena.ArenaInstance;
import com.zjuqni.hexatowerdefense.config.ConfigManager;
import com.zjuqni.hexatowerdefense.enemy.HTDEnemyEntity;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_3222;

public final class CoreController {
    private static final int RETALIATION_DAMAGE = 8;

    private final ArenaInstance arena;
    private final class_2338 corePosition;
    private final int maxHealth;
    private int health;
    private boolean destroyed;
    private boolean hudVisible;

    public CoreController(ArenaInstance arena, class_2338 corePosition) {
        this.arena = arena;
        this.corePosition = corePosition.method_10062();
        this.maxHealth = ConfigManager.general().coreHealth;
        this.health = maxHealth;
        updateCoreEntity();
    }

    public void damage(int amount, HTDEnemyEntity source) {
        if (destroyed || amount <= 0) {
            return;
        }
        health = Math.max(0, health - amount);
        updateCoreEntity();
        if (ConfigManager.general().debug) {
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] {} damaged core for {}. Core HP: {}/{}",
                    source == null ? "Enemy" : source.enemyType(), amount, health, maxHealth);
        }
        damageAttacker(source);
        if (health <= 0) {
            destroyed = true;
            arena.lose();
        }
    }

    private void damageAttacker(HTDEnemyEntity source) {
        if (source == null || source.method_31481() || !source.method_5805()) {
            return;
        }
        source.method_5643(source.method_48923().method_48831(), RETALIATION_DAMAGE);
    }

    public void close() {
        setHudVisible(false);
    }

    public void addPlayer(class_3222 player) {
        updateCoreEntity();
    }

    public class_2338 corePosition() {
        return corePosition;
    }

    public int health() {
        return health;
    }

    public int maxHealth() {
        return maxHealth;
    }

    public boolean isDestroyed() {
        return destroyed;
    }

    public void setHudVisible(boolean visible) {
        this.hudVisible = visible;
        updateCoreEntity();
    }

    private void updateCoreEntity() {
        var world = arena.getWorld();
        if (world == null) {
            return;
        }
        class_238 box = new class_238(corePosition).method_1014(8.0D);
        for (CoreEntity core : world.method_8390(CoreEntity.class, box, entity -> entity.arenaId() == arena.arenaId())) {
            core.setHealthValues(health, maxHealth);
            core.setHudVisible(hudVisible);
        }
    }
}
