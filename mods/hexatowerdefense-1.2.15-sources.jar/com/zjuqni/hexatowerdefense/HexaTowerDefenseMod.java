package com.zjuqni.hexatowerdefense;

import com.zjuqni.hexatowerdefense.arena.ArenaManager;
import com.zjuqni.hexatowerdefense.config.ConfigManager;
import com.zjuqni.hexatowerdefense.registry.ModBlocks;
import com.zjuqni.hexatowerdefense.registry.ModCommands;
import com.zjuqni.hexatowerdefense.registry.ModDimensions;
import com.zjuqni.hexatowerdefense.registry.ModEntities;
import com.zjuqni.hexatowerdefense.registry.ModItems;
import com.zjuqni.hexatowerdefense.registry.ModMenus;
import com.zjuqni.hexatowerdefense.registry.ModNetworking;
import com.zjuqni.hexatowerdefense.registry.ModParticles;
import com.zjuqni.hexatowerdefense.registry.ModSounds;
import com.zjuqni.hexatowerdefense.shop.ShopManager;
import com.zjuqni.hexatowerdefense.enemy.HTDEnemyEntity;
import com.zjuqni.hexatowerdefense.player.WeaponManager;
import com.zjuqni.hexatowerdefense.tower.HTDTowerEntity;
import com.zjuqni.hexatowerdefense.tower.TowerManager;
import com.zjuqni.hexatowerdefense.core.CoreEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class HexaTowerDefenseMod implements ModInitializer {
    public static final String MOD_ID = "hexatowerdefense";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ConfigManager.init();
        ModDimensions.init();
        ModItems.init();
        ModBlocks.init();
        ModEntities.init();
        ModSounds.init();
        ModParticles.init();
        ModNetworking.init();
        ModMenus.init();
        ModCommands.init();

        ServerLifecycleEvents.SERVER_STARTED.register(server -> ArenaManager.get().init(server));
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> ArenaManager.get().shutdown());
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            ArenaManager.get().tick(server);
            WeaponManager.tick(server);
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) ->
                ArenaManager.get().handleDisconnect(handler.method_32311()));
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (!world.method_27983().equals(ModDimensions.INSTANCES_WORLD)) {
                return;
            }
            boolean stale = entity instanceof HTDEnemyEntity enemy && !enemy.isRuntimeSpawned()
                    || entity instanceof HTDTowerEntity tower && !tower.isRuntimeSpawned()
                    || entity instanceof CoreEntity core && !core.isRuntimeSpawned();
            if (stale) {
                ArenaManager.get().queueStaleEntity(entity);
            }
        });
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
                ShopManager.normalizeEnergyCellStacks(handler.method_32311()));
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.method_8608() || !(player instanceof class_3222 serverPlayer) || !(world instanceof class_3218 serverWorld)) {
                return class_1269.field_5811;
            }
            if (TowerManager.isTowerItem(serverPlayer.method_5998(hand))) {
                var arena = ArenaManager.get().getInteractionArena(serverPlayer, serverWorld, hitResult.method_17777());
                if (arena == null || !serverWorld.method_27983().equals(arena.dimension())) {
                    return class_1269.field_5814;
                }
                return arena.towerManager().tryPlaceTower(serverPlayer, hand, hitResult.method_17777())
                        ? class_1269.field_5812
                        : class_1269.field_5814;
            }
            return ShopManager.handleUse(serverPlayer, serverWorld, hitResult.method_17777())
                    ? class_1269.field_5812
                    : class_1269.field_5811;
        });
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.method_8608() || !(player instanceof class_3222 serverPlayer) || !(world instanceof class_3218 serverWorld)) {
                return class_1269.field_5811;
            }
            if (!(entity instanceof HTDTowerEntity tower)) {
                return class_1269.field_5811;
            }
            var arena = ArenaManager.get().getInteractionArenaForTower(serverPlayer, tower.arenaId());
            if (arena == null || !serverWorld.method_27983().equals(arena.dimension())) {
                return class_1269.field_5814;
            }
            boolean handled;
            if (TowerManager.isUpgradeItem(serverPlayer.method_5998(class_1268.field_5808))) {
                handled = arena.towerManager().tryUpgradeTower(serverPlayer, class_1268.field_5808, tower);
            } else if (TowerManager.isUpgradeItem(serverPlayer.method_5998(class_1268.field_5810))) {
                handled = arena.towerManager().tryUpgradeTower(serverPlayer, class_1268.field_5810, tower);
            } else if (serverPlayer.method_5998(class_1268.field_5808).method_7960()
                    && serverPlayer.method_5998(class_1268.field_5810).method_7960()) {
                handled = arena.towerManager().tryPickupTower(serverPlayer, hand, tower);
            } else {
                handled = false;
            }
            return handled
                    ? class_1269.field_5812
                    : class_1269.field_5814;
        });
        UseItemCallback.EVENT.register(WeaponManager::handleUseItem);
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (!(entity instanceof HTDEnemyEntity enemy)) {
                return class_1269.field_5811;
            }
            if (world.method_8608()) {
                return class_1269.field_5811;
            }
            if (!(player instanceof class_3222 serverPlayer) || !(world instanceof class_3218 serverWorld)) {
                return class_1269.field_5811;
            }
            var arena = ArenaManager.get().getArena(serverPlayer);
            if (arena == null || enemy.arenaId() != arena.arenaId() || !serverWorld.method_27983().equals(arena.dimension())) {
                return class_1269.field_5811;
            }

            float cooldown = serverPlayer.method_7261(0.5F);
            double baseDamage = Math.max(1.0D, serverPlayer.method_45325(class_5134.field_23721));
            float damage = (float) (baseDamage * (0.2F + cooldown * cooldown * 0.8F));
            enemy.method_5643(serverPlayer.method_48923().method_48802(serverPlayer), damage);
            serverPlayer.method_7350();
            serverPlayer.method_23667(hand, true);
            return class_1269.field_5812;
        });
    }

    public static class_2960 id(String path) {
        return class_2960.method_60655(MOD_ID, path);
    }
}
