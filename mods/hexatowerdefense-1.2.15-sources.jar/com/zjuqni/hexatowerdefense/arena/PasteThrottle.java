package com.zjuqni.hexatowerdefense.arena;

import com.zjuqni.hexatowerdefense.config.ConfigManager;

public final class PasteThrottle {
    private static final int MIN_BUDGET = 250;
    private static final double SMOOTHING = 0.15D;

    private long lastServerTickNanos;
    private double avgServerTickMs = 50.0D;
    private int budget;

    public void observeServerTick() {
        long now = System.nanoTime();
        if (lastServerTickNanos != 0L) {
            double deltaMs = (now - lastServerTickNanos) / 1_000_000.0D;
            if (deltaMs < 2000.0D) {
                avgServerTickMs = avgServerTickMs * (1.0D - SMOOTHING) + deltaMs * SMOOTHING;
            }
        }
        lastServerTickNanos = now;
    }

    public int budget(int configuredMax) {
        int max = Math.max(MIN_BUDGET, configuredMax);
        if (budget <= 0) {
            budget = Math.max(MIN_BUDGET, max / 2);
        }
        return Math.min(max, Math.max(MIN_BUDGET, budget));
    }

    public void observePasteWork(long elapsedNanos, int configuredMax) {
        int max = Math.max(MIN_BUDGET, configuredMax);
        double workMs = elapsedNanos / 1_000_000.0D;
        double workLimitMs = Math.max(1.0D, ConfigManager.general().pasteMillisPerTick);
        boolean serverLagging = avgServerTickMs > ConfigManager.general().slowTickThresholdMs;

        if (serverLagging || workMs > workLimitMs) {
            budget = Math.max(MIN_BUDGET, (int) (budget * 0.7D));
        } else if (workMs < workLimitMs * 0.6D) {
            budget = Math.min(max, (int) (budget * 1.25D) + 100);
        }
    }

    public void reset() {
        lastServerTickNanos = 0L;
        avgServerTickMs = 50.0D;
        budget = 0;
    }

    public double averageServerTickMs() {
        return avgServerTickMs;
    }

    public int currentBudget() {
        return budget;
    }
}
