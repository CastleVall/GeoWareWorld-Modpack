package com.zjuqni.hexatowerdefense.arena;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1259;
import net.minecraft.class_2561;
import net.minecraft.class_3213;
import net.minecraft.class_3222;

public final class ArenaLoadProgress {
    private static final int REFRESH_INTERVAL_TICKS = 20;
    private static final int FINISHED_LINGER_TICKS = 200;

    private final class_3213 bossBar = new class_3213(
            class_2561.method_43470("HexaTower"),
            class_1259.class_1260.field_5780,
            class_1259.class_1261.field_5790
    );
    private final Set<UUID> viewers = new LinkedHashSet<>();

    private boolean active;
    private int totalArenas;
    private int finishedArenas;
    private int elapsedTicks;
    private int refreshCooldown;
    private int lingerTicks;

    public ArenaLoadProgress() {
        bossBar.method_14091(false);
    }

    public void beginBatch(int arenasQueued) {
        if (arenasQueued <= 0) {
            return;
        }
        if (active) {
            totalArenas += arenasQueued;
        } else {
            active = true;
            totalArenas = arenasQueued;
            finishedArenas = 0;
            elapsedTicks = 0;
            bossBar.method_5416(class_1259.class_1260.field_5780);
            bossBar.method_14091(true);
        }
        lingerTicks = 0;
        refreshCooldown = 0;
    }

    public void onArenaFinished() {
        if (!active) {
            return;
        }
        finishedArenas = Math.min(totalArenas, finishedArenas + 1);
    }

    public void tick(int currentArenaId, int placedBlocks, int totalBlocks) {
        if (!active) {
            tickLinger();
            return;
        }

        elapsedTicks++;
        if (finishedArenas >= totalArenas) {
            complete();
            return;
        }
        if (--refreshCooldown > 0) {
            return;
        }
        refreshCooldown = REFRESH_INTERVAL_TICKS;

        double arenaFraction = totalBlocks > 0 ? Math.min(1.0D, placedBlocks / (double) totalBlocks) : 0.0D;
        double overall = (finishedArenas + arenaFraction) / totalArenas;
        bossBar.method_5408((float) Math.max(0.0D, Math.min(1.0D, overall)));
        bossBar.method_5413(class_2561.method_43470("Arenas " + finishedArenas + "/" + totalArenas)
                .method_27695(class_124.field_1075, class_124.field_1067)
                .method_10852(class_2561.method_43470("  •  ").method_27692(class_124.field_1062))
                .method_10852(class_2561.method_43470(currentArenaId >= 0
                                ? "construyendo #" + currentArenaId + " (" + (int) Math.round(arenaFraction * 100) + "%)"
                                : "preparando...")
                        .method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470("  •  ").method_27692(class_124.field_1062))
                .method_10852(class_2561.method_43470(remainingLabel(overall)).method_27692(class_124.field_1054)));
    }

    private void complete() {
        active = false;
        lingerTicks = FINISHED_LINGER_TICKS;
        bossBar.method_5408(1.0F);
        bossBar.method_5416(class_1259.class_1260.field_5785);
        bossBar.method_5413(class_2561.method_43470("Arenas listas: " + totalArenas + "/" + totalArenas)
                .method_27695(class_124.field_1060, class_124.field_1067)
                .method_10852(class_2561.method_43470("  •  ya podés usar /hexatower start").method_27692(class_124.field_1054)));
    }

    private void tickLinger() {
        if (lingerTicks <= 0) {
            return;
        }
        if (--lingerTicks == 0) {
            hide();
        }
    }

    private String remainingLabel(double overall) {
        boolean enoughSamples = finishedArenas >= 1 || overall >= 0.02D;
        if (!enoughSamples || overall <= 0.001D || elapsedTicks < 60) {
            return "calculando tiempo...";
        }
        int remainingTicks = (int) (elapsedTicks * (1.0D - overall) / overall);
        return "faltan ~" + formatDuration(remainingTicks / 20);
    }

    private static String formatDuration(int seconds) {
        if (seconds < 60) {
            return Math.max(1, seconds) + "s";
        }
        int minutes = seconds / 60;
        int rest = seconds % 60;
        return rest == 0 ? minutes + "m" : minutes + "m " + rest + "s";
    }

    public void addViewer(class_3222 player) {
        if (viewers.add(player.method_5667())) {
            bossBar.method_14088(player);
        }
    }

    public void removeViewer(class_3222 player) {
        if (viewers.remove(player.method_5667())) {
            bossBar.method_14089(player);
        }
    }

    public void hide() {
        bossBar.method_14091(false);
        bossBar.method_14094();
        viewers.clear();
        lingerTicks = 0;
    }

    public void reset() {
        hide();
        active = false;
        totalArenas = 0;
        finishedArenas = 0;
        elapsedTicks = 0;
    }

    public boolean isActive() {
        return active;
    }

    public int totalArenas() {
        return totalArenas;
    }

    public int finishedArenas() {
        return finishedArenas;
    }

    public String etaLabel() {
        if (!active || totalArenas <= 0) {
            return "sin generación en curso";
        }
        double overall = finishedArenas / (double) totalArenas;
        return remainingLabel(overall);
    }
}
