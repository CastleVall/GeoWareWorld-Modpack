package com.zjuqni.hexatowerdefense.arena;

import com.zjuqni.hexatowerdefense.config.ArenaLayoutConfig;
import com.zjuqni.hexatowerdefense.config.ConfigManager;
import com.zjuqni.hexatowerdefense.core.CoreEntity;
import com.zjuqni.hexatowerdefense.core.CoreController;
import com.zjuqni.hexatowerdefense.economy.EconomyManager;
import com.zjuqni.hexatowerdefense.enemy.EnemyManager;
import com.zjuqni.hexatowerdefense.layout.GeneratedArenaLayout;
import com.zjuqni.hexatowerdefense.layout.LaneDefinition;
import com.zjuqni.hexatowerdefense.layout.ReferenceLayoutMapper;
import com.zjuqni.hexatowerdefense.layout.StructurePlacementCell;
import com.zjuqni.hexatowerdefense.player.WeaponManager;
import com.zjuqni.hexatowerdefense.registry.ModBlocks;
import com.zjuqni.hexatowerdefense.registry.ModDimensions;
import com.zjuqni.hexatowerdefense.schematic.SchematicTemplate;
import com.zjuqni.hexatowerdefense.shop.ShopManager;
import com.zjuqni.hexatowerdefense.tower.TowerManager;
import com.zjuqni.hexatowerdefense.util.HTDText;
import com.zjuqni.hexatowerdefense.wave.WaveManager;
import com.zjuqni.hexatowerdefense.registry.ModEntities;
import it.unimi.dsi.fastutil.ints.IntList;
import net.minecraft.class_124;
import net.minecraft.class_1671;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_5905;
import net.minecraft.class_9283;
import net.minecraft.class_9284;
import net.minecraft.class_9334;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.io.IOException;

public final class ArenaInstance {
    private static final int SET_BLOCK_FLAGS = 2 | 16;
    private static final int FIREWORKS_PER_BURST = 2;
    private static final int MAX_FIREWORK_BURSTS = 3;

    private final ArenaManager manager;
    private final int arenaId;
    private final List<UUID> playerUuids = new ArrayList<>();
    private final class_5321<class_1937> dimension;
    private final class_2338 anchor;
    private ArenaState state = ArenaState.RESERVED;
    private class_238 bounds;
    private class_238 schematicBounds;
    private class_2338 shopPosition;
    private class_2338 corePosition;
    private class_2338 runtimePlayerSpawn;
    private final EconomyManager economyManager;
    private final EnemyManager enemyManager;
    private final WaveManager waveManager;
    private final TowerManager towerManager;
    private CoreController coreController;
    private final List<class_2338> temporaryBlocks = new ArrayList<>();
    private GeneratedArenaLayout referenceLayout;
    private int elapsedTicks;
    private int preparationTicksLeft;
    private int endCountdownTicks = -1;
    private boolean resetAfterCleanup;
    private boolean celebrating;
    private boolean testFill;
    private int fireworkBursts;
    private final Set<Integer> unlockedLaneIds = new HashSet<>();
    private final Map<class_2338, class_2680> lockedCellFloorBackup = new HashMap<>();
    private boolean preloaded;
    private final boolean startOnReady;

    ArenaInstance(ArenaManager manager, int arenaId, UUID playerUuid, class_2338 anchor) {
        this(manager, arenaId, playerUuid, anchor, false);
    }

    ArenaInstance(ArenaManager manager, int arenaId, UUID playerUuid, class_2338 anchor, boolean preloaded) {
        this(manager, arenaId, playerUuid, anchor, preloaded, true);
    }

    ArenaInstance(ArenaManager manager, int arenaId, UUID playerUuid, class_2338 anchor, boolean preloaded, boolean startOnReady) {
        this.manager = manager;
        this.arenaId = arenaId;
        if (playerUuid != null) {
            this.playerUuids.add(playerUuid);
        }
        this.preloaded = preloaded;
        this.startOnReady = startOnReady;
        this.dimension = ModDimensions.INSTANCES_WORLD;
        this.anchor = anchor;
        this.preparationTicksLeft = ConfigManager.general().preparationSeconds * 20;
        this.economyManager = new EconomyManager(ConfigManager.general().startingEnergy);
        this.enemyManager = new EnemyManager(this);
        this.waveManager = new WaveManager(this);
        this.towerManager = new TowerManager(this);
        applyLayoutBounds();
    }

    public void tick() {
        if (state != ArenaState.CLOSED && state != ArenaState.CLEANING) {
            elapsedTicks++;
            if (state == ArenaState.PREPARING) {
                preparationTicksLeft = Math.max(0, preparationTicksLeft - 1);
                if (preparationTicksLeft == 0) {
                    startRunning();
                }
            }
            if (state == ArenaState.RUNNING) {
                waveManager.tick();
            }
            tickPreEnemyCountdown();
            if ((state == ArenaState.WON || state == ArenaState.LOST) && endCountdownTicks > 0) {
                endCountdownTicks--;
                if (celebrating && fireworkBursts < MAX_FIREWORK_BURSTS && endCountdownTicks % 20 == 0) {
                    class_3222 celebrant = getPlayer();
                    if (celebrant != null) {
                        launchFireworks(celebrant);
                    }
                }
                if (endCountdownTicks == 0) {
                    manager.releaseArena(this);
                    return;
                }
            }
            towerManager.tick();
            enemyManager.tick();
        }
    }

    public void onSchematicPasted(SchematicTemplate template) {
        this.schematicBounds = template.getBoundsAt(anchor);
        applyLayoutBounds();
        try {
            this.referenceLayout = new ReferenceLayoutMapper().loadOrGenerate();
        } catch (IOException e) {
            throw new IllegalStateException("No se pudo cargar generated_layout_from_reference.json: " + e.getMessage(), e);
        }
        class_3218 world = getWorld();
        this.runtimePlayerSpawn = findSafeEntityPosition(world, referenceLayout.playerSpawnWorld(anchor));
        this.corePosition = adjustedCorePosition(referenceLayout.coreWorld(anchor));
        this.bounds = union(this.schematicBounds, referenceLayout.gameplayBounds(anchor));
        sanitizeReferenceOverlay(world);
        this.shopPosition = ShopManager.placeShop(this, findSafeEntityPosition(world, referenceLayout.shopWorld(anchor)));
        this.coreController = new CoreController(this, corePosition);
        discardStaleGameplayEntities();
        transitionTo(ArenaState.READY);
        manager.persistArenas();

        List<class_3222> players = getPlayers();
        if (preloaded && players.isEmpty()) {
            return;
        }
        if (!players.isEmpty() && startOnReady) {
            activateReserved();
        } else {
            for (class_3222 player : players) {
                clearPlayerInventory(player);
                teleportPlayerToArena(player);
                HTDText.sendInfo(player, "Arena generada. Espera el inicio de partida.", false);
            }
        }
    }

    public void onCleanupFinished() {
        if (coreController != null) {
            coreController.close();
            coreController = null;
        }
        enemyManager.clear();
        waveManager.stop();
        towerManager.clear();
        state = ArenaState.CLOSED;
        manager.finishArenaCleanup(this, resetAfterCleanup);
    }

    public void restoreFromWorld() {
        applyLayoutBounds();
        try {
            this.referenceLayout = new ReferenceLayoutMapper().loadOrGenerate();
        } catch (IOException e) {
            throw new IllegalStateException("No se pudo cargar generated_layout_from_reference.json: " + e.getMessage(), e);
        }
        class_3218 world = getWorld();
        this.runtimePlayerSpawn = findSafeEntityPosition(world, referenceLayout.playerSpawnWorld(anchor));
        this.corePosition = adjustedCorePosition(referenceLayout.coreWorld(anchor));
        this.bounds = union(this.schematicBounds, referenceLayout.gameplayBounds(anchor));
        this.shopPosition = restoreShopPosition(world, referenceLayout.shopWorld(anchor));
        if (shopPosition != null) {
            trackTemporaryBlock(shopPosition);
        }
        resetForReuse();
    }

    private class_2338 restoreShopPosition(class_3218 world, class_2338 mapped) {
        if (world == null || mapped == null) {
            return findSafeEntityPosition(world, mapped);
        }
        class_2338 existing = null;
        class_2338.class_2339 mutable = new class_2338.class_2339();
        for (int dy = -2; dy <= 8; dy++) {
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    mutable.method_10103(mapped.method_10263() + dx, mapped.method_10264() + dy, mapped.method_10260() + dz);
                    if (!world.method_8320(mutable).method_27852(ModBlocks.SHOP_BLOCK)) {
                        continue;
                    }
                    if (existing == null) {
                        existing = mutable.method_10062();
                    } else {
                        world.method_8652(mutable, class_2246.field_10124.method_9564(), SET_BLOCK_FLAGS);
                    }
                }
            }
        }
        return existing != null ? existing : findSafeEntityPosition(world, mapped);
    }

    public void resetForReuse() {
        waveManager.stop();
        enemyManager.clear();
        towerManager.clear();
        if (coreController != null) {
            coreController.close();
        }
        discardStaleGameplayEntities();
        this.playerUuids.clear();
        this.preloaded = true;
        this.elapsedTicks = 0;
        this.preparationTicksLeft = ConfigManager.general().preparationSeconds * 20;
        this.endCountdownTicks = -1;
        restoreLockedLaneVisuals();
        this.unlockedLaneIds.clear();
        this.resetAfterCleanup = false;
        this.celebrating = false;
        this.testFill = false;
        this.fireworkBursts = 0;
        this.economyManager.reset(ConfigManager.general().startingEnergy);
        if (corePosition != null) {
            this.coreController = new CoreController(this, corePosition);
        }
        ShopManager.restoreShop(this);
        transitionTo(ArenaState.READY);
    }

    private void discardStaleGameplayEntities() {
        class_3218 world = getWorld();
        if (world == null) {
            return;
        }
        class_238 sweep = bounds != null ? bounds.method_1014(24.0D)
                : schematicBounds != null ? schematicBounds.method_1014(24.0D)
                : new class_238(anchor).method_1014(160.0D);
        for (CoreEntity core : world.method_8390(CoreEntity.class, sweep, entity -> entity.arenaId() == arenaId)) {
            core.method_31472();
        }
        for (com.zjuqni.hexatowerdefense.tower.HTDTowerEntity tower :
                world.method_8390(com.zjuqni.hexatowerdefense.tower.HTDTowerEntity.class, sweep, entity -> entity.arenaId() == arenaId)) {
            tower.method_31472();
        }
        for (com.zjuqni.hexatowerdefense.enemy.HTDEnemyEntity enemy :
                world.method_8390(com.zjuqni.hexatowerdefense.enemy.HTDEnemyEntity.class, sweep, entity -> entity.arenaId() == arenaId)) {
            enemy.method_31472();
        }
    }

    public void startCleaning(boolean resetAfterCleanup) {
        this.resetAfterCleanup = resetAfterCleanup;
        this.celebrating = false;
        restoreLockedLaneVisuals();
        this.unlockedLaneIds.clear();
        waveManager.stop();
        enemyManager.clear();
        towerManager.clear();
        if (coreController != null) {
            coreController.close();
        }
        transitionTo(ArenaState.CLEANING);
    }

    public boolean isInside(class_2338 pos) {
        return bounds != null && bounds.method_1008(pos.method_10263() + 0.5D, pos.method_10264() + 0.5D, pos.method_10260() + 0.5D);
    }

    public class_2338 relative(int x, int y, int z) {
        return anchor.method_10069(x, y, z);
    }

    public class_2338 schematicLocalToWorld(int localX, int localY, int localZ, SchematicTemplate template) {
        return template.localToWorld(anchor, localX, localY, localZ);
    }

    public class_3222 getPlayer() {
        List<class_3222> players = getPlayers();
        return players.isEmpty() ? null : players.get(0);
    }

    public List<class_3222> getPlayers() {
        MinecraftServer server = manager.server();
        if (server == null || playerUuids.isEmpty()) {
            return List.of();
        }
        List<class_3222> players = new ArrayList<>(playerUuids.size());
        for (UUID uuid : playerUuids) {
            class_3222 player = server.method_3760().method_14602(uuid);
            if (player != null) {
                players.add(player);
            }
        }
        return players;
    }

    public class_3218 getWorld() {
        MinecraftServer server = manager.server();
        if (server == null) {
            return null;
        }
        return server.method_3847(dimension);
    }

    public void teleportPlayerToArena(class_3222 player) {
        class_3218 world = getWorld();
        if (world != null) {
            class_2338 pos = runtimePlayerSpawn != null ? runtimePlayerSpawn : configuredPlayerSpawn();
            player.method_14251(world, pos.method_10263() + 0.5D, pos.method_10264(), pos.method_10260() + 0.5D, 0.0F, 0.0F);
        }
    }

    public void reserveFor(UUID uuid) {
        if (state == ArenaState.READY && playerUuids.size() < 2 && !playerUuids.contains(uuid)) {
            this.playerUuids.add(uuid);
        }
    }

    public void activateReserved() {
        if (state != ArenaState.READY) {
            return;
        }
        List<class_3222> players = getPlayers();
        if (players.isEmpty()) {
            return;
        }
        this.preloaded = false;
        this.elapsedTicks = 0;
        this.preparationTicksLeft = ConfigManager.general().preparationSeconds * 20;

        initializeLaneUnlocks();
        spawnGameplayEntities();
        for (class_3222 player : players) {
            player.method_7336(class_1934.field_9216);
            clearPlayerInventory(player);
            teleportPlayerToArena(player);
            if (coreController != null) {
                coreController.addPlayer(player);
            }
            WeaponManager.giveStarterWeapon(player);
            ShopManager.giveEnergyCells(player, ConfigManager.general().startingEnergy);
            if (players.size() == 2) {
                class_3222 partner = players.get(0) == player ? players.get(1) : players.get(0);
                HTDText.sendInfo(player, "Jugás en dúo con " + partner.method_5477().getString() + ".", false);
            }
        }
        startPreparingOrRunning();
        if (testFill) {
            towerManager.fillTestTowers();
            testFill = false;
        }
        manager.persistArenas();
    }

    public void markTestFill() {
        this.testFill = true;
    }

    private void spawnGameplayEntities() {
        discardStaleGameplayEntities();
        if (corePosition != null && coreController == null) {
            this.coreController = new CoreController(this, corePosition);
        }
        placeCoreMarker();
        towerManager.placeInitialGenerator();
    }

    public void clearPlayerInventory(class_3222 player) {
        player.method_31548().method_5448();
        player.field_7512.method_7623();
    }

    public void teleportPlayerToOverworld(class_3222 player) {
        MinecraftServer server = manager.server();
        if (server == null) {
            return;
        }
        class_3218 overworld = server.method_30002();
        class_2338 spawn = overworld.method_43126();
        player.method_14251(overworld, spawn.method_10263() + 0.5D, spawn.method_10264(), spawn.method_10260() + 0.5D, player.method_36454(), player.method_36455());
    }

    private void applyLayoutBounds() {
        ArenaLayoutConfig layout = ConfigManager.arenaLayout();
        int[] min = safeVec(layout.bounds.min, new int[]{-55, -15, -70});
        int[] max = safeVec(layout.bounds.max, new int[]{55, 80, 65});
        this.bounds = new class_238(
                anchor.method_10263() + min[0],
                anchor.method_10264() + min[1],
                anchor.method_10260() + min[2],
                anchor.method_10263() + max[0] + 1,
                anchor.method_10264() + max[1] + 1,
                anchor.method_10260() + max[2] + 1
        );
    }

    private class_2338 configuredPlayerSpawn() {
        ArenaLayoutConfig layout = ConfigManager.arenaLayout();
        int[] spawn = safeVec(layout.playerSpawn, new int[]{0, 3, 0});
        return relative(spawn[0], spawn[1], spawn[2]);
    }

    private void startPreparingOrRunning() {
        if (ConfigManager.general().preparationSeconds <= 0) {
            startRunning();
            return;
        }
        transitionTo(ArenaState.PREPARING);
    }

    private void startRunning() {
        transitionTo(ArenaState.RUNNING);
        waveManager.start();
    }

    private void tickPreEnemyCountdown() {
        int ticksLeft;
        if (state == ArenaState.PREPARING) {
            ticksLeft = preparationTicksLeft + WaveManager.FIRST_SPAWN_WARMUP_TICKS;
        } else if (state == ArenaState.RUNNING && waveManager.runningTicks() < WaveManager.FIRST_SPAWN_WARMUP_TICKS) {
            ticksLeft = WaveManager.FIRST_SPAWN_WARMUP_TICKS - waveManager.runningTicks();
        } else {
            return;
        }
        if (elapsedTicks % 20 != 0) {
            return;
        }
        int secondsLeft = Math.max(1, (ticksLeft + 19) / 20);
        for (class_3222 player : getPlayers()) {
            HTDText.sendWarning(player, "Preparate: primer enemigo en " + secondsLeft + "s", true);
        }
    }

    private void placeCoreMarker() {
        class_3218 world = getWorld();
        if (world == null || corePosition == null) {
            return;
        }
        CoreEntity core = ModEntities.CORE.method_5883(world);
        if (core == null) {
            return;
        }
        if (coreController != null) {
            core.configure(arenaId, coreController.health(), coreController.maxHealth());
        } else {
            core.configure(arenaId);
        }
        core.method_5808(corePosition.method_10263() + 0.5D, corePosition.method_10264(), corePosition.method_10260() + 0.5D, 0.0F, 0.0F);
        world.method_8649(core);
    }

    private class_2338 adjustedCorePosition(class_2338 mappedCore) {
        return mappedCore.method_10069(-1, -5, 1);
    }

    private void sanitizeReferenceOverlay(class_3218 world) {
        if (world == null || referenceLayout == null) {
            return;
        }
        class_238 markerBox = referenceLayout.gameplayBounds(anchor).method_1009(8.0D, 4.0D, 8.0D);
        int minX = (int) Math.floor(markerBox.field_1323);
        int minY = (int) Math.floor(markerBox.field_1322);
        int minZ = (int) Math.floor(markerBox.field_1321);
        int maxX = (int) Math.floor(markerBox.field_1320);
        int maxY = (int) Math.floor(markerBox.field_1325);
        int maxZ = (int) Math.floor(markerBox.field_1324);
        class_2338.class_2339 mutable = new class_2338.class_2339();
        for (int y = minY; y <= maxY; y++) {
            for (int z = minZ; z <= maxZ; z++) {
                for (int x = minX; x <= maxX; x++) {
                    mutable.method_10103(x, y, z);
                    class_2680 state = world.method_8320(mutable);
                    if (state.method_27852(class_2246.field_22122)) {
                        world.method_8652(mutable, class_2246.field_10124.method_9564(), SET_BLOCK_FLAGS);
                    } else if (isReferenceGameplayMarker(state)) {
                        world.method_8652(mutable, referenceMarkerReplacement(state), SET_BLOCK_FLAGS);
                    }
                }
            }
        }
    }

    private static boolean isReferenceGameplayMarker(class_2680 state) {
        return state.method_27852(class_2246.field_10381)
                || state.method_27852(class_2246.field_22108)
                || state.method_27852(class_2246.field_10002)
                || state.method_27852(class_2246.field_10205)
                || state.method_27852(class_2246.field_10201)
                || state.method_27852(class_2246.field_10234);
    }

    private static class_2680 referenceMarkerReplacement(class_2680 state) {
        if (state.method_27852(class_2246.field_10002)
                || state.method_27852(class_2246.field_10205)
                || state.method_27852(class_2246.field_10201)
                || state.method_27852(class_2246.field_10234)) {
            return class_2246.field_28896.method_9564();
        }
        return class_2246.field_23873.method_9564();
    }

    private class_2338 findSafeEntityPosition(class_3218 world, class_2338 preferred) {
        if (world == null) {
            return preferred;
        }
        if (isSafeEntityPosition(world, preferred)) {
            return preferred;
        }

        int minY = schematicBounds == null ? preferred.method_10264() - 16 : (int) Math.floor(schematicBounds.field_1322) + 1;
        int maxY = schematicBounds == null ? preferred.method_10264() + 48 : (int) Math.floor(schematicBounds.field_1325) - 2;
        for (int radius = 0; radius <= 12; radius++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (radius > 0 && Math.abs(dx) != radius && Math.abs(dz) != radius) {
                        continue;
                    }
                    for (int y = maxY; y >= minY; y--) {
                        class_2338 candidate = new class_2338(preferred.method_10263() + dx, y, preferred.method_10260() + dz);
                        if (isSafeEntityPosition(world, candidate)) {
                            return candidate;
                        }
                    }
                }
            }
        }
        return preferred;
    }

    private boolean isSafeEntityPosition(class_3218 world, class_2338 pos) {
        if (schematicBounds != null && !schematicBounds.method_1008(pos.method_10263() + 0.5D, pos.method_10264() + 0.5D, pos.method_10260() + 0.5D)) {
            return false;
        }

        class_2338 belowPos = pos.method_10074();
        class_2680 below = world.method_8320(belowPos);
        if (below.method_26215() || below.method_27852(class_2246.field_10164) || below.method_27852(class_2246.field_10499) || !below.method_26212(world, belowPos)) {
            return false;
        }
        return isSafeAir(world, pos) && isSafeAir(world, pos.method_10084());
    }

    private boolean isSafeAir(class_3218 world, class_2338 pos) {
        class_2680 state = world.method_8320(pos);
        return !state.method_27852(class_2246.field_10164)
                && !state.method_27852(class_2246.field_10499)
                && (state.method_26215() || state.method_26220(world, pos).method_1110());
    }

    public void lose() {
        if (state == ArenaState.LOST || state == ArenaState.CLEANING || state == ArenaState.CLOSED) {
            return;
        }
        transitionTo(ArenaState.LOST);
        waveManager.stop();
        enemyManager.clear();
        endCountdownTicks = -1;
        for (class_3222 player : getPlayers()) {
            sendTitle(player, "DERROTA", "El Nucleo Geotermico fue destruido", class_124.field_1061);
            HTDText.sendError(player, "DERROTA - El nucleo geotermico fue destruido.", false);
            player.method_7336(class_1934.field_9219);
            HTDText.sendInfo(player, "Quedaste en modo espectador. Con /hexatower stop vuelves al lobby.", false);
        }
    }

    public void win() {
        finishGame("VICTORIA", "Defendiste el Nucleo Geotermico", "VICTORIA - Defendiste el nucleo geotermico.");
    }

    public void finishByAdmin() {
        finishGame("FIN DE LA PARTIDA", "¡Gracias por jugar!", "La partida terminó. ¡Gracias por jugar!");
    }

    private void finishGame(String title, String subtitle, String chatMessage) {
        if (state == ArenaState.WON || state == ArenaState.CLEANING || state == ArenaState.CLOSED) {
            return;
        }
        transitionTo(ArenaState.WON);
        waveManager.stop();
        enemyManager.clear();
        endCountdownTicks = endCeremonyTicks();
        celebrating = true;
        List<class_3222> players = getPlayers();
        for (class_3222 player : players) {
            teleportPlayerToArena(player);
            sendTitle(player, title, subtitle, class_124.field_1065);
            HTDText.sendSuccess(player, chatMessage, false);
            HTDText.sendInfo(player, "Volverás al mundo principal en " + endCeremonySeconds() + " segundos.", false);
        }
        if (!players.isEmpty()) {
            launchFireworks(players.get(0));
        }
    }

    private static int endCeremonySeconds() {
        return Math.max(1, ConfigManager.general().endCeremonySeconds);
    }

    private static int endCeremonyTicks() {
        return endCeremonySeconds() * 20;
    }

    private void launchFireworks(class_3222 player) {
        class_3218 world = getWorld();
        if (world == null) {
            return;
        }
        for (int i = 0; i < FIREWORKS_PER_BURST; i++) {
            double angle = (Math.PI * 2.0D / FIREWORKS_PER_BURST) * i + fireworkBursts;
            double x = player.method_23317() + Math.cos(angle) * 3.0D;
            double z = player.method_23321() + Math.sin(angle) * 3.0D;
            class_1799 rocket = new class_1799(class_1802.field_8639);
            rocket.method_57379(class_9334.field_49616, new class_9284(1, List.of(fireworkExplosion(i))));
            world.method_8649(new class_1671(world, x, player.method_23318() + 0.5D, z, rocket));
        }
        fireworkBursts++;
    }

    private static class_9283 fireworkExplosion(int index) {
        int[] palette = {0xFF4D4D, 0xFFD24D, 0x4DA6FF, 0x8CFF4D, 0xE84DFF};
        return new class_9283(
                index % 2 == 0 ? class_9283.class_1782.field_7977 : class_9283.class_1782.field_7973,
                IntList.of(palette[index % palette.length]),
                IntList.of(0xFFFFFF),
                true,
                true
        );
    }

    private static void sendTitle(class_3222 player, String title, String subtitle, class_124 titleColor) {
        player.field_13987.method_14364(new class_5905(10, 70, 20));
        player.field_13987.method_14364(new class_5904(class_2561.method_43470(title).method_27695(titleColor, class_124.field_1067)));
        player.field_13987.method_14364(new class_5903(class_2561.method_43470(subtitle).method_27692(class_124.field_1054)));
    }

    private static int[] safeVec(int[] input, int[] fallback) {
        if (input == null || input.length < 3) {
            return fallback;
        }
        return input;
    }

    public int arenaId() {
        return arenaId;
    }

    public UUID playerUuid() {
        return playerUuids.isEmpty() ? null : playerUuids.get(0);
    }

    public List<UUID> playerUuids() {
        return List.copyOf(playerUuids);
    }

    public void removePlayer(UUID uuid) {
        playerUuids.remove(uuid);
    }

    public boolean isPreloadedReady() {
        return preloaded && state == ArenaState.READY && playerUuids.isEmpty();
    }

    public ArenaState state() {
        return state;
    }

    public void state(ArenaState state) {
        transitionTo(state);
    }

    public class_5321<class_1937> dimension() {
        return dimension;
    }

    public class_2338 anchor() {
        return anchor;
    }

    public class_238 bounds() {
        return bounds;
    }

    public class_238 schematicBounds() {
        return schematicBounds;
    }

    public void schematicBounds(class_238 schematicBounds) {
        this.schematicBounds = schematicBounds;
    }

    public int elapsedTicks() {
        return elapsedTicks;
    }

    public int preparationTicksLeft() {
        return preparationTicksLeft;
    }

    public class_2338 shopPosition() {
        return shopPosition;
    }

    public class_2338 corePosition() {
        return corePosition;
    }

    public class_2338 playerSpawnPosition() {
        return runtimePlayerSpawn;
    }

    public EconomyManager economyManager() {
        return economyManager;
    }

    public EnemyManager enemyManager() {
        return enemyManager;
    }

    public WaveManager waveManager() {
        return waveManager;
    }

    public TowerManager towerManager() {
        return towerManager;
    }

    public CoreController coreController() {
        return coreController;
    }

    public GeneratedArenaLayout referenceLayout() {
        return referenceLayout;
    }

    public boolean isLaneLocked(int laneId) {
        if (referenceLayout == null || unlockedLaneIds.isEmpty()) {
            return false;
        }
        return !unlockedLaneIds.contains(laneId);
    }

    public boolean lockedLanesUnlocked() {
        return referenceLayout != null && !referenceLayout.lanes.isEmpty()
                && unlockedLaneIds.size() >= referenceLayout.lanes.size();
    }

    public List<Integer> activeLaneIds() {
        List<Integer> ids = new ArrayList<>(unlockedLaneIds);
        ids.sort(null);
        return ids;
    }

    private void initializeLaneUnlocks() {
        restoreLockedLaneVisuals();
        unlockedLaneIds.clear();
        updateLaneUnlocks(0);
    }

    public void updateLaneUnlocks(int seconds) {
        if (referenceLayout == null || referenceLayout.lanes.isEmpty()) {
            return;
        }
        List<Integer> order = laneUnlockOrder();
        int target = Math.min(order.size(), lanesActiveAtSecond(seconds));
        boolean changed = false;
        for (int i = 0; i < target; i++) {
            if (unlockedLaneIds.add(order.get(i))) {
                changed = true;
            }
        }
        if (!changed) {
            return;
        }
        refreshLockedLaneVisuals();
        if (seconds > 5) {
            for (class_3222 player : getPlayers()) {
                HTDText.sendWarning(player, "¡Se abrió un nuevo carril! Enemigos atacando por " + unlockedLaneIds.size() + " carriles.", false);
            }
        }
        if (ConfigManager.general().debug) {
            com.zjuqni.hexatowerdefense.HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] Arena {} lanes active: {}", arenaId, unlockedLaneIds);
        }
    }

    private static int lanesActiveAtSecond(int seconds) {
        if (seconds >= 360) {
            return Integer.MAX_VALUE;
        }
        if (seconds >= 240) {
            return 4;
        }
        if (seconds >= 120) {
            return 2;
        }
        return 1;
    }

    private List<Integer> laneUnlockOrder() {
        List<Integer> sorted = new ArrayList<>();
        for (LaneDefinition lane : referenceLayout.lanes) {
            sorted.add(lane.id);
        }
        sorted.sort(null);
        double center = (sorted.size() - 1) / 2.0D;
        List<Integer> order = new ArrayList<>(sorted);
        order.sort(Comparator.comparingDouble(id -> Math.abs(sorted.indexOf(id) - center)));
        return order;
    }

    private void refreshLockedLaneVisuals() {
        class_3218 world = getWorld();
        if (world == null || referenceLayout == null) {
            return;
        }
        for (StructurePlacementCell cell : referenceLayout.placementCells) {
            class_2338 floor = cell.anchorWorld(anchor).method_10074();
            if (!unlockedLaneIds.contains(cell.laneId)) {
                if (!lockedCellFloorBackup.containsKey(floor)) {
                    class_2680 original = world.method_8320(floor);
                    if (!original.method_27852(class_2246.field_9986)) {
                        lockedCellFloorBackup.put(floor.method_10062(), original);
                        world.method_8652(floor, class_2246.field_9986.method_9564(), SET_BLOCK_FLAGS);
                    }
                }
            } else {
                class_2680 original = lockedCellFloorBackup.remove(floor);
                if (original != null) {
                    world.method_8652(floor, original, SET_BLOCK_FLAGS);
                }
            }
        }
    }

    private void restoreLockedLaneVisuals() {
        class_3218 world = getWorld();
        if (world != null) {
            for (Map.Entry<class_2338, class_2680> entry : lockedCellFloorBackup.entrySet()) {
                world.method_8652(entry.getKey(), entry.getValue(), SET_BLOCK_FLAGS);
            }
        }
        lockedCellFloorBackup.clear();
    }

    public void trackTemporaryBlock(class_2338 pos) {
        temporaryBlocks.add(pos.method_10062());
    }

    public List<class_2338> temporaryBlocks() {
        return List.copyOf(temporaryBlocks);
    }

    private void transitionTo(ArenaState newState) {
        if (this.state == newState) {
            return;
        }
        ArenaState oldState = this.state;
        this.state = newState;
        if (coreController != null) {
            coreController.setHudVisible(newState == ArenaState.PREPARING || newState == ArenaState.RUNNING);
        }
        if (ConfigManager.general().debug) {
            com.zjuqni.hexatowerdefense.HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] Arena {} state changed {} -> {}", arenaId, oldState, newState);
        }
    }

    private static class_238 union(class_238 first, class_238 second) {
        if (first == null) {
            return second;
        }
        if (second == null) {
            return first;
        }
        return new class_238(
                Math.min(first.field_1323, second.field_1323),
                Math.min(first.field_1322, second.field_1322),
                Math.min(first.field_1321, second.field_1321),
                Math.max(first.field_1320, second.field_1320),
                Math.max(first.field_1325, second.field_1325),
                Math.max(first.field_1324, second.field_1324)
        );
    }
}
