package com.zjuqni.hexatowerdefense.arena;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import com.zjuqni.hexatowerdefense.config.ConfigManager;
import com.zjuqni.hexatowerdefense.config.GeneralConfig;
import com.zjuqni.hexatowerdefense.enemy.HTDEnemyEntity;
import com.zjuqni.hexatowerdefense.layout.ReferenceLayoutMapper;
import com.zjuqni.hexatowerdefense.registry.ModDimensions;
import com.zjuqni.hexatowerdefense.schematic.MarkerScanner;
import com.zjuqni.hexatowerdefense.schematic.SchematicCleanupTask;
import com.zjuqni.hexatowerdefense.schematic.SchematicLoader;
import com.zjuqni.hexatowerdefense.schematic.SchematicPasteTask;
import com.zjuqni.hexatowerdefense.schematic.SchematicTemplate;
import com.zjuqni.hexatowerdefense.util.HTDText;
import net.minecraft.class_1297;
import net.minecraft.class_1934;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5218;
import net.minecraft.server.MinecraftServer;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;

public final class ArenaManager {
    private static final ArenaManager INSTANCE = new ArenaManager();

    private final Map<UUID, ArenaInstance> playerArenas = new HashMap<>();
    private final Map<Integer, ArenaInstance> activeArenas = new HashMap<>();
    private final Queue<Integer> freeSlots = new ArrayDeque<>();
    private final Set<Integer> reservedSlots = new HashSet<>();
    private final List<SchematicPasteTask> pasteTasks = new ArrayList<>();
    private final List<SchematicCleanupTask> cleanupTasks = new ArrayList<>();
    private final Queue<Integer> pendingRestores = new ArrayDeque<>();
    private final Queue<UUID> activationQueue = new ArrayDeque<>();
    private int activationCooldown;
    private final List<class_1297> staleEntities = new ArrayList<>();
    private final ArenaLoadProgress loadProgress = new ArenaLoadProgress();
    private final PasteThrottle pasteThrottle = new PasteThrottle();
    private MinecraftServer server;
    private SchematicTemplate template;

    private ArenaManager() {
    }

    public static ArenaManager get() {
        return INSTANCE;
    }

    public void init(MinecraftServer server) {
        this.server = server;
        if (Files.exists(wipeFlagPath())) {
            deleteInstanceDimensionFiles();
            try {
                Files.deleteIfExists(wipeFlagPath());
            } catch (IOException e) {
                HexaTowerDefenseMod.LOGGER.error("No se pudo borrar wipe.flag", e);
            }
        }
        rebuildSlots();
        loadArenaRegistry();
        HexaTowerDefenseMod.LOGGER.info("HexaTowerDefense ArenaManager listo con {} slots", ConfigManager.general().maxArenas);
    }

    public void shutdown() {
        persistArenas();
        for (ArenaInstance arena : List.copyOf(activeArenas.values())) {
            class_3218 world = arena.getWorld();
            if (world != null) {
                discardArenaEntities(arena, world);
            }
            arena.enemyManager().clear();
            arena.waveManager().stop();
            arena.towerManager().clear();
            if (arena.coreController() != null) {
                arena.coreController().close();
            }
        }
        loadProgress.reset();
        pasteThrottle.reset();
        pasteTasks.clear();
        cleanupTasks.clear();
        pendingRestores.clear();
        activationQueue.clear();
        staleEntities.clear();
        playerArenas.clear();
        activeArenas.clear();
        freeSlots.clear();
        reservedSlots.clear();
        template = null;
        server = null;
    }

    public void tick(MinecraftServer server) {
        pasteThrottle.observeServerTick();
        drainStaleEntities();
        tickPendingRestores();
        tickPasteTasks();
        tickCleanupTasks();
        tickActivations();
        tickLoadProgress();
        for (ArenaInstance arena : List.copyOf(activeArenas.values())) {
            arena.tick();
        }
    }

    private void tickActivations() {
        if (activationQueue.isEmpty() || server == null) {
            return;
        }
        if (activationCooldown > 0) {
            activationCooldown--;
            return;
        }
        int budget = Math.max(1, ConfigManager.general().activationsPerTick);
        while (budget > 0) {
            UUID uuid = activationQueue.poll();
            if (uuid == null) {
                break;
            }
            ArenaInstance arena = playerArenas.get(uuid);
            if (arena == null || arena.state() != ArenaState.READY) {
                continue;
            }
            if (arena.getPlayers().isEmpty()) {
                releaseArena(arena);
                continue;
            }
            arena.activateReserved();
            budget--;
        }
        activationCooldown = Math.max(0, ConfigManager.general().activationIntervalTicks);
    }

    public int pendingActivations() {
        return activationQueue.size();
    }

    private void tickLoadProgress() {
        SchematicPasteTask current = null;
        for (SchematicPasteTask task : pasteTasks) {
            if (!task.isFinished()) {
                current = task;
                break;
            }
        }
        if (current != null) {
            loadProgress.tick(current.arena().arenaId(), current.placed(), current.total());
        } else {
            loadProgress.tick(-1, 0, 0);
        }
    }

    public ArenaLoadProgress loadProgress() {
        return loadProgress;
    }

    public PasteThrottle pasteThrottle() {
        return pasteThrottle;
    }

    public int generatingArenaCount() {
        int count = 0;
        for (SchematicPasteTask task : pasteTasks) {
            if (!task.isFinished()) {
                count++;
            }
        }
        return count + pendingRestores.size();
    }

    public int readyArenaCount() {
        int count = 0;
        for (ArenaInstance arena : activeArenas.values()) {
            if (arena.isPreloadedReady()) {
                count++;
            }
        }
        return count;
    }

    public void queueStaleEntity(class_1297 entity) {
        staleEntities.add(entity);
    }

    private void drainStaleEntities() {
        if (staleEntities.isEmpty()) {
            return;
        }
        for (class_1297 entity : staleEntities) {
            if (!entity.method_31481()) {
                entity.method_31472();
            }
        }
        staleEntities.clear();
    }

    public String startArena(class_3222 player) {
        return String.join(" ", startArenas(List.of(player), false));
    }

    public List<String> startArenas(Collection<class_3222> targets, boolean testFill) {
        List<String> messages = new ArrayList<>();
        List<class_3222> pending = new ArrayList<>();
        Set<UUID> seen = new HashSet<>();
        String suffix = testFill ? " (PRUEBA)" : "";
        for (class_3222 player : targets) {
            if (player == null || !seen.add(player.method_5667())) {
                continue;
            }
            String name = player.method_5477().getString();
            ArenaInstance existing = playerArenas.get(player.method_5667());
            if (existing == null) {
                pending.add(player);
            } else if (existing.state() == ArenaState.READY) {
                if (testFill) {
                    existing.markTestFill();
                }
                enqueueActivation(player.method_5667());
                messages.add(name + ": arena #" + existing.arenaId() + suffix + " asignada, entrando en breve...");
            } else if (existing.state() == ArenaState.WON || existing.state() == ArenaState.LOST) {
                releaseArena(existing);
                pending.add(player);
            } else if (existing.state() == ArenaState.GENERATING) {
                messages.add(name + ": su arena todavía se está generando, espera unos segundos.");
            } else {
                messages.add(name + ": ya tiene una partida en curso en la arena #" + existing.arenaId() + ".");
            }
        }
        for (int i = 0; i < pending.size(); i += 2) {
            List<class_3222> duo = pending.subList(i, Math.min(i + 2, pending.size()));
            ArenaInstance claimed = reservePreloadedArena(duo);
            if (claimed == null) {
                for (int j = i; j < pending.size(); j++) {
                    messages.add(pending.get(j).method_5477().getString() + ": " + noArenaAvailableReason());
                }
                break;
            }
            if (testFill) {
                claimed.markTestFill();
            }
            enqueueActivation(duo.get(0).method_5667());
            if (duo.size() == 2) {
                messages.add(duo.get(0).method_5477().getString() + " y " + duo.get(1).method_5477().getString()
                        + ": arena #" + claimed.arenaId() + suffix + " asignada en dúo, entrando en breve...");
            } else {
                messages.add(duo.get(0).method_5477().getString() + ": arena #" + claimed.arenaId() + suffix
                        + " asignada (solo), entrando en breve...");
            }
        }
        return messages;
    }

    public ArenaInstance getInteractionArena(class_3222 player, class_3218 world, class_2338 pos) {
        ArenaInstance own = getArena(player);
        if (own != null && own.isInside(pos)) {
            return own;
        }
        if (player.method_5687(2)) {
            ArenaInstance at = getArenaAt(pos, world);
            if (at != null) {
                return at;
            }
        }
        return own;
    }

    public ArenaInstance getInteractionArenaForTower(class_3222 player, int towerArenaId) {
        ArenaInstance own = getArena(player);
        if (own != null && own.arenaId() == towerArenaId) {
            return own;
        }
        if (player.method_5687(2)) {
            return getArenaById(towerArenaId);
        }
        return own;
    }

    private void enqueueActivation(UUID uuid) {
        if (!activationQueue.contains(uuid)) {
            activationQueue.add(uuid);
        }
    }

    private String noArenaAvailableReason() {
        int generating = generatingArenaCount();
        if (generating > 0) {
            return "todavía no hay arenas listas. Se están construyendo ("
                    + loadProgress.finishedArenas() + "/" + loadProgress.totalArenas() + " terminadas, "
                    + loadProgress.etaLabel() + "). Mirá el progreso con /hexatower status.";
        }
        if (activeArenas.isEmpty()) {
            return "no hay ninguna arena creada. Un admin debe crearlas con /hexatower load <cantidad>.";
        }
        return "todas las arenas están ocupadas (" + activeArenas.size() + " creadas, 0 libres). "
                + "Crea más con /hexatower load <cantidad> o espera a que terminen partidas.";
    }

    public String generateArena(class_3222 player) {
        if (playerArenas.containsKey(player.method_5667())) {
            return player.method_5477().getString() + ": ya tiene una arena generada o activa.";
        }
        return startArena(player, null, false);
    }

    private String startArena(class_3222 player, Integer preferredSlot, boolean startOnReady) {
        if (playerArenas.containsKey(player.method_5667())) {
            return player.method_5477().getString() + ": ya tiene una arena activa.";
        }

        class_3218 instanceWorld = requireInstanceWorld();
        if (instanceWorld == null) {
            return player.method_5477().getString() + ": no se pudo cargar la dimension hexatowerdefense:instances.";
        }

        Integer slot = allocateSlot(preferredSlot);
        if (slot == null) {
            return player.method_5477().getString() + ": no hay slots de arena libres.";
        }

        SchematicTemplate loadedTemplate;
        try {
            loadedTemplate = getOrLoadTemplate();
        } catch (IOException | RuntimeException e) {
            releaseSlot(slot);
            HexaTowerDefenseMod.LOGGER.error("No se pudo cargar el schematic", e);
            return player.method_5477().getString() + ": no se pudo cargar el schematic configurado: " + e.getMessage();
        }

        class_2338 anchor = calculateAnchor(slot);
        ArenaInstance arena = new ArenaInstance(this, slot, player.method_5667(), anchor, false, startOnReady);
        arena.clearPlayerInventory(player);
        arena.schematicBounds(loadedTemplate.getBoundsAt(anchor));
        arena.state(ArenaState.GENERATING);
        activeArenas.put(slot, arena);
        playerArenas.put(player.method_5667(), arena);

        SchematicPasteTask task = new SchematicPasteTask(
                arena,
                loadedTemplate,
                anchor,
                instanceWorld,
                ConfigManager.general().schematicBlocksPerTick
        );
        pasteTasks.add(task);
        return player.method_5477().getString() + ": generando arena privada #" + slot + " en " + formatBlockPos(anchor) + ".";
    }

    public String stopArena(class_3222 player) {
        ArenaInstance arena = playerArenas.get(player.method_5667());
        if (arena == null) {
            return player.method_5477().getString() + ": no tiene una arena activa.";
        }
        ArenaState state = arena.state();
        if (state == ArenaState.PREPARING || state == ArenaState.RUNNING) {
            arena.finishByAdmin();
            return player.method_5477().getString() + ": partida finalizada, vuelve al lobby en "
                    + Math.max(1, ConfigManager.general().endCeremonySeconds) + " segundos.";
        }
        if (state == ArenaState.WON) {
            return player.method_5477().getString() + ": la partida ya está en la ceremonia final, sale al lobby en unos segundos.";
        }
        releaseArena(arena);
        return player.method_5477().getString() + ": partida detenida, arena reiniciada y lista para reutilizarse.";
    }

    public void releaseArena(ArenaInstance arena) {
        ArenaState state = arena.state();
        if (state == ArenaState.CLEANING || state == ArenaState.CLOSED) {
            return;
        }
        if (state == ArenaState.GENERATING || arena.referenceLayout() == null) {
            requestCleanup(arena, false);
            return;
        }

        for (UUID uuid : arena.playerUuids()) {
            playerArenas.remove(uuid);
        }
        for (class_3222 player : arena.getPlayers()) {
            arena.clearPlayerInventory(player);
            player.method_7336(class_1934.field_9216);
            if (ConfigManager.general().returnToOverworldSpawnOnEnd) {
                arena.teleportPlayerToOverworld(player);
            }
        }
        class_3218 world = arena.getWorld();
        if (world != null) {
            discardArenaEntities(arena, world);
        }
        arena.resetForReuse();
        persistArenas();
        if (ConfigManager.general().debug) {
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] Arena {} reiniciada y devuelta al pool", arena.arenaId());
        }
    }

    public int unloadArenas(int count) {
        int removed = 0;
        for (ArenaInstance arena : List.copyOf(activeArenas.values())) {
            if (removed >= count) {
                break;
            }
            if (arena.isPreloadedReady()) {
                requestCleanup(arena, false);
                removed++;
            }
        }
        return removed;
    }

    public void resetArena(class_3222 player) {
        ArenaInstance arena = playerArenas.get(player.method_5667());
        if (arena == null) {
            startArena(player);
            return;
        }
        requestCleanup(arena, true);
        HTDText.sendInfo(player, "Reiniciando arena después de la limpieza.", false);
    }

    public void requestCleanup(ArenaInstance arena, boolean resetAfterCleanup) {
        if (arena.state() == ArenaState.CLEANING || arena.state() == ArenaState.CLOSED) {
            return;
        }

        cancelPasteTask(arena);
        SchematicTemplate loadedTemplate;
        try {
            loadedTemplate = getOrLoadTemplate();
        } catch (IOException | RuntimeException e) {
            HexaTowerDefenseMod.LOGGER.error("No se pudo cargar el schematic para cleanup", e);
            finishArenaCleanup(arena, resetAfterCleanup);
            return;
        }

        class_3218 world = arena.getWorld();
        if (world == null) {
            finishArenaCleanup(arena, resetAfterCleanup);
            return;
        }

        arena.startCleaning(resetAfterCleanup);
        discardArenaEntities(arena, world);
        for (class_3222 player : arena.getPlayers()) {
            arena.clearPlayerInventory(player);
            player.method_7336(class_1934.field_9216);
            if (ConfigManager.general().returnToOverworldSpawnOnEnd) {
                arena.teleportPlayerToOverworld(player);
            }
        }

        cleanupTasks.add(new SchematicCleanupTask(
                arena,
                loadedTemplate,
                arena.anchor(),
                world,
                ConfigManager.general().cleanupBlocksPerTick,
                ConfigManager.general().clearMode
        ));
    }

    public void finishArenaCleanup(ArenaInstance arena, boolean resetAfterCleanup) {
        class_3218 world = arena.getWorld();
        if (world != null) {
            discardArenaEntities(arena, world);
        }
        UUID owner = arena.playerUuid();
        activeArenas.remove(arena.arenaId());
        for (UUID uuid : arena.playerUuids()) {
            playerArenas.remove(uuid);
        }

        if (resetAfterCleanup && server != null && owner != null) {
            class_3222 player = server.method_3760().method_14602(owner);
            if (player != null && arena.arenaId() < ConfigManager.general().maxArenas) {
                startArena(player, arena.arenaId(), true);
                return;
            }
        }

        releaseSlot(arena.arenaId());
        persistArenas();
    }

    public Path scanMarkers() throws IOException {
        SchematicTemplate loadedTemplate = getOrLoadTemplate();
        return new MarkerScanner().scan(loadedTemplate);
    }

    public void reloadConfig() throws IOException {
        ConfigManager.reload();
        template = null;
        ReferenceLayoutMapper.clearCache();
        rebuildSlotsPreservingActiveArenas();
    }

    public void handleDisconnect(class_3222 player) {
        loadProgress.removeViewer(player);
        ArenaInstance arena = playerArenas.get(player.method_5667());
        if (arena == null) {
            return;
        }

        if (ConfigManager.general().pauseArenaOnDisconnect) {
            return;
        }
        List<class_3222> remaining = new ArrayList<>();
        for (class_3222 other : arena.getPlayers()) {
            if (!other.method_5667().equals(player.method_5667())) {
                remaining.add(other);
            }
        }
        if (remaining.isEmpty()) {
            releaseArena(arena);
            return;
        }
        playerArenas.remove(player.method_5667());
        arena.removePlayer(player.method_5667());
        for (class_3222 partner : remaining) {
            HTDText.sendWarning(partner, "Tu compañero se desconectó. Seguís la partida solo.", false);
        }
        persistArenas();
    }

    public ArenaInstance getArena(class_3222 player) {
        return playerArenas.get(player.method_5667());
    }

    public ArenaInstance getArenaById(int id) {
        return activeArenas.get(id);
    }

    public ArenaInstance getArenaAt(class_2338 pos, class_3218 world) {
        if (world == null || !world.method_27983().equals(ModDimensions.INSTANCES_WORLD)) {
            return null;
        }
        for (ArenaInstance arena : activeArenas.values()) {
            if (arena.isInside(pos)) {
                return arena;
            }
        }
        return null;
    }

    public List<ArenaInstance> activeArenas() {
        return List.copyOf(activeArenas.values());
    }

    public int preloadArenas(int count) {
        if (count <= 0 || server == null) {
            return 0;
        }
        class_3218 instanceWorld = server.method_3847(ModDimensions.INSTANCES_WORLD);
        if (instanceWorld == null) {
            HexaTowerDefenseMod.LOGGER.error("No se pudo cargar la dimension hexatowerdefense:instances para precargar arenas.");
            return 0;
        }

        SchematicTemplate loadedTemplate;
        try {
            loadedTemplate = getOrLoadTemplate();
        } catch (IOException | RuntimeException e) {
            HexaTowerDefenseMod.LOGGER.error("No se pudo cargar el schematic para precargar arenas", e);
            return 0;
        }

        int scheduled = 0;
        for (int i = 0; i < count; i++) {
            Integer slot = allocateSlot(null);
            if (slot == null) {
                break;
            }
            class_2338 anchor = calculateAnchor(slot);
            ArenaInstance arena = new ArenaInstance(this, slot, null, anchor, true);
            arena.schematicBounds(loadedTemplate.getBoundsAt(anchor));
            arena.state(ArenaState.GENERATING);
            activeArenas.put(slot, arena);
            pasteTasks.add(new SchematicPasteTask(
                    arena,
                    loadedTemplate,
                    anchor,
                    instanceWorld,
                    Math.min(ConfigManager.general().schematicBlocksPerTick, ConfigManager.general().preloadBlocksPerTick)
            ));
            scheduled++;
        }
        loadProgress.beginBatch(scheduled);
        return scheduled;
    }

    public void persistArenas() {
        if (server == null) {
            return;
        }
        Map<Integer, String> entries = new TreeMap<>();
        for (ArenaInstance arena : activeArenas.values()) {
            ArenaState state = arena.state();
            if (arena.referenceLayout() == null
                    || state == ArenaState.GENERATING
                    || state == ArenaState.CLEANING
                    || state == ArenaState.CLOSED) {
                continue;
            }
            entries.put(arena.arenaId(), arena.playerUuid() != null ? "en_juego" : "libre");
        }
        for (Integer pending : pendingRestores) {
            entries.putIfAbsent(pending, "libre");
        }
        StringBuilder yml = new StringBuilder();
        yml.append("# Arenas construidas por HexaTowerDefense. Este archivo se actualiza solo.\n");
        yml.append("# Al reiniciar el servidor estas arenas se restauran automaticamente.\n");
        yml.append("# Borra este archivo (con el servidor apagado) si quieres empezar de cero.\n");
        yml.append("arenas:\n");
        for (Map.Entry<Integer, String> entry : entries.entrySet()) {
            yml.append("  ").append(entry.getKey()).append(": ").append(entry.getValue()).append('\n');
        }
        try {
            Files.writeString(arenasFile(), yml.toString());
        } catch (IOException e) {
            HexaTowerDefenseMod.LOGGER.error("No se pudo guardar arenas.yml", e);
        }
    }

    private void loadArenaRegistry() {
        Path path = arenasFile();
        if (!Files.exists(path)) {
            return;
        }
        int queued = 0;
        try {
            for (String rawLine : Files.readAllLines(path)) {
                String line = rawLine.trim();
                if (line.isEmpty() || line.startsWith("#") || line.startsWith("arenas")) {
                    continue;
                }
                int colon = line.indexOf(':');
                if (colon <= 0) {
                    continue;
                }
                int slot;
                try {
                    slot = Integer.parseInt(line.substring(0, colon).trim());
                } catch (NumberFormatException ignored) {
                    continue;
                }
                if (slot < 0 || slot >= ConfigManager.general().maxArenas || pendingRestores.contains(slot)) {
                    continue;
                }
                freeSlots.remove(Integer.valueOf(slot));
                reservedSlots.add(slot);
                pendingRestores.add(slot);
                queued++;
            }
        } catch (IOException e) {
            HexaTowerDefenseMod.LOGGER.error("No se pudo leer arenas.yml", e);
        }
        if (queued > 0) {
            loadProgress.beginBatch(queued);
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] Restaurando {} arenas guardadas de arenas.yml...", queued);
        }
    }

    private void tickPendingRestores() {
        Integer slot = pendingRestores.poll();
        if (slot == null) {
            return;
        }
        try {
            restoreArena(slot);
        } catch (IOException | RuntimeException e) {
            HexaTowerDefenseMod.LOGGER.error("No se pudo restaurar la arena {} desde arenas.yml", slot, e);
            releaseSlot(slot);
        }
        loadProgress.onArenaFinished();
        if (pendingRestores.isEmpty()) {
            persistArenas();
            HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] Restauracion de arenas completada. Arenas activas: {}", activeArenas.size());
        }
    }

    private void restoreArena(int arenaId) throws IOException {
        class_3218 world = requireInstanceWorld();
        if (world == null) {
            throw new IllegalStateException("No se pudo cargar la dimension hexatowerdefense:instances.");
        }
        SchematicTemplate loadedTemplate = getOrLoadTemplate();
        class_2338 anchor = calculateAnchor(arenaId);
        ArenaInstance arena = new ArenaInstance(this, arenaId, null, anchor, true);
        arena.schematicBounds(loadedTemplate.getBoundsAt(anchor));
        activeArenas.put(arenaId, arena);
        arena.restoreFromWorld();
    }

    private Path arenasFile() {
        return ConfigManager.getConfigDir().resolve("arenas.yml");
    }

    private Path wipeFlagPath() {
        return ConfigManager.getConfigDir().resolve("wipe.flag");
    }

    public String wipeDimension() {
        if (server == null) {
            return "Servidor no disponible.";
        }
        int movedPlayers = 0;
        class_3218 world = server.method_3847(ModDimensions.INSTANCES_WORLD);
        if (world != null) {
            class_3218 overworld = server.method_30002();
            class_2338 spawn = overworld.method_43126();
            for (class_3222 player : List.copyOf(world.method_18456())) {
                player.method_14251(overworld, spawn.method_10263() + 0.5D, spawn.method_10264(), spawn.method_10260() + 0.5D, player.method_36454(), player.method_36455());
                movedPlayers++;
            }
            List<class_1297> loaded = new ArrayList<>();
            world.method_27909().forEach(loaded::add);
            for (class_1297 entity : loaded) {
                if (!(entity instanceof class_3222)) {
                    entity.method_31472();
                }
            }
        }

        for (ArenaInstance arena : List.copyOf(activeArenas.values())) {
            cancelTasks(arena);
            arena.waveManager().stop();
            arena.enemyManager().clear();
            arena.towerManager().clear();
            if (arena.coreController() != null) {
                arena.coreController().close();
            }
        }
        activeArenas.clear();
        playerArenas.clear();
        pendingRestores.clear();
        activationQueue.clear();
        pasteTasks.clear();
        cleanupTasks.clear();
        staleEntities.clear();
        loadProgress.reset();
        rebuildSlots();

        try {
            Files.deleteIfExists(arenasFile());
        } catch (IOException e) {
            HexaTowerDefenseMod.LOGGER.error("No se pudo borrar arenas.yml", e);
        }
        try {
            Files.writeString(wipeFlagPath(), "wipe");
        } catch (IOException e) {
            HexaTowerDefenseMod.LOGGER.error("No se pudo escribir wipe.flag", e);
            return "Se limpio el estado pero no se pudo marcar el borrado en disco. Revisa permisos de la carpeta config.";
        }
        return "Arenas y estado limpiados (" + movedPlayers + " jugador(es) devueltos al lobby). "
                + "REINICIA el servidor AHORA: al arrancar se borran todos los bloques de las arenas viejas. "
                + "Recien despues usa /hexatower load.";
    }

    private void deleteInstanceDimensionFiles() {
        if (server == null) {
            return;
        }
        Path dimDir = server.method_27050(class_5218.field_24188)
                .resolve("dimensions")
                .resolve(ModDimensions.INSTANCES_WORLD.method_29177().method_12836())
                .resolve(ModDimensions.INSTANCES_WORLD.method_29177().method_12832());
        int deleted = 0;
        for (String sub : new String[]{"region", "entities", "poi"}) {
            deleted += deleteDirContents(dimDir.resolve(sub));
        }
        HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] Dimension instances borrada por wipe ({} archivos eliminados). Arenas viejas eliminadas.", deleted);
    }

    private static int deleteDirContents(Path dir) {
        if (!Files.exists(dir)) {
            return 0;
        }
        int[] count = {0};
        try (java.util.stream.Stream<Path> stream = Files.walk(dir)) {
            stream.sorted(Comparator.reverseOrder()).forEach(path -> {
                if (path.equals(dir)) {
                    return;
                }
                try {
                    if (Files.deleteIfExists(path)) {
                        count[0]++;
                    }
                } catch (IOException ignored) {
                }
            });
        } catch (IOException e) {
            HexaTowerDefenseMod.LOGGER.error("No se pudo borrar {}", dir, e);
        }
        return count[0];
    }

    public MinecraftServer server() {
        return server;
    }

    public SchematicTemplate template() {
        return template;
    }

    private class_3218 requireInstanceWorld() {
        class_3218 instanceWorld = server.method_3847(ModDimensions.INSTANCES_WORLD);
        if (instanceWorld == null) {
            return null;
        }
        return instanceWorld;
    }

    private void rebuildSlots() {
        freeSlots.clear();
        reservedSlots.clear();
        for (int i = 0; i < ConfigManager.general().maxArenas; i++) {
            freeSlots.add(i);
        }
    }

    private void rebuildSlotsPreservingActiveArenas() {
        freeSlots.clear();
        reservedSlots.clear();
        reservedSlots.addAll(activeArenas.keySet());
        reservedSlots.addAll(pendingRestores);
        for (int i = 0; i < ConfigManager.general().maxArenas; i++) {
            if (!activeArenas.containsKey(i) && !pendingRestores.contains(i)) {
                freeSlots.add(i);
            }
        }
    }

    private Integer allocateSlot(Integer preferredSlot) {
        if (preferredSlot != null) {
            if (preferredSlot < 0
                    || preferredSlot >= ConfigManager.general().maxArenas
                    || activeArenas.containsKey(preferredSlot)
                    || reservedSlots.contains(preferredSlot)) {
                return null;
            }
            freeSlots.remove(preferredSlot);
            reservedSlots.add(preferredSlot);
            return preferredSlot;
        }
        Integer slot;
        while ((slot = freeSlots.poll()) != null) {
            if (activeArenas.containsKey(slot) || reservedSlots.contains(slot)) {
                continue;
            }
            reservedSlots.add(slot);
            return slot;
        }
        return null;
    }

    private void releaseSlot(int arenaId) {
        if (arenaId < 0
                || arenaId >= ConfigManager.general().maxArenas
                || activeArenas.containsKey(arenaId)) {
            return;
        }
        reservedSlots.remove(arenaId);
        if (!freeSlots.contains(arenaId)) {
            freeSlots.add(arenaId);
        }
    }

    public void forceFreeSlot(int arenaId) {
        ArenaInstance arena = activeArenas.remove(arenaId);
        if (arena != null) {
            class_3218 world = arena.getWorld();
            if (world != null) {
                discardArenaEntities(arena, world);
            }
            cancelTasks(arena);
            arena.enemyManager().clear();
            arena.waveManager().stop();
            arena.towerManager().clear();
            if (arena.coreController() != null) {
                arena.coreController().close();
            }
            arena.state(ArenaState.CLOSED);
            for (UUID uuid : arena.playerUuids()) {
                playerArenas.remove(uuid);
            }
        }
        releaseSlot(arenaId);
    }

    public class_2338 calculateAnchor(int arenaId) {
        GeneralConfig config = ConfigManager.general();
        // Piso de seguridad: el schematic mide 119 bloques de largo, asi que menos
        // de 120 haria que las arenas se superpongan y se rompan entre si.
        int safeSpacing = Math.max(config.arenaSpacing, 120);
        int col = arenaId % config.arenaColumns;
        int row = arenaId / config.arenaColumns;
        return new class_2338(col * safeSpacing, config.arenaY, row * safeSpacing);
    }

    private SchematicTemplate getOrLoadTemplate() throws IOException {
        if (template == null) {
            template = new SchematicLoader().load(ConfigManager.schematicPath());
        }
        return template;
    }

    private ArenaInstance reservePreloadedArena(List<class_3222> group) {
        ArenaInstance selected = null;
        for (ArenaInstance arena : activeArenas.values()) {
            if (!arena.isPreloadedReady()) {
                continue;
            }
            if (selected == null || arena.arenaId() < selected.arenaId()) {
                selected = arena;
            }
        }
        if (selected == null) {
            return null;
        }
        for (class_3222 player : group) {
            playerArenas.put(player.method_5667(), selected);
            selected.reserveFor(player.method_5667());
        }
        return selected;
    }

    private void tickPasteTasks() {
        if (pasteTasks.isEmpty()) {
            return;
        }

        int configuredMax = ConfigManager.general().preloadBlocksPerTick;
        int maxTickedTasks = Math.max(1, ConfigManager.general().maxParallelPasteTasks);
        int budgetPerTask = Math.max(1, pasteThrottle.budget(configuredMax) / maxTickedTasks);
        long startNanos = System.nanoTime();

        Iterator<SchematicPasteTask> iterator = pasteTasks.iterator();
        int tickedTasks = 0;
        while (iterator.hasNext()) {
            SchematicPasteTask task = iterator.next();
            if (task.isFinished()) {
                iterator.remove();
                continue;
            }
            if (tickedTasks >= maxTickedTasks) {
                continue;
            }
            try {
                task.tick(budgetPerTask);
                tickedTasks++;
            } catch (RuntimeException e) {
                HexaTowerDefenseMod.LOGGER.error("Error pegando arena {}", task.arena().arenaId(), e);
                iterator.remove();
                loadProgress.onArenaFinished();
                requestCleanup(task.arena(), false);
                continue;
            }
            if (task.isFinished()) {
                iterator.remove();
                loadProgress.onArenaFinished();
            }
        }

        if (tickedTasks > 0) {
            pasteThrottle.observePasteWork(System.nanoTime() - startNanos, configuredMax);
        }
    }

    private void tickCleanupTasks() {
        Iterator<SchematicCleanupTask> iterator = cleanupTasks.iterator();
        while (iterator.hasNext()) {
            SchematicCleanupTask task = iterator.next();
            try {
                task.tick();
            } catch (RuntimeException e) {
                HexaTowerDefenseMod.LOGGER.error("Error limpiando arena {}", task.arena().arenaId(), e);
                iterator.remove();
                finishArenaCleanup(task.arena(), false);
                continue;
            }
            if (task.isFinished()) {
                iterator.remove();
            }
        }
    }

    private void cancelPasteTask(ArenaInstance arena) {
        for (SchematicPasteTask task : pasteTasks) {
            if (task.arena() == arena) {
                task.cancel();
            }
        }
    }

    private void cancelTasks(ArenaInstance arena) {
        cancelPasteTask(arena);
        for (SchematicCleanupTask task : cleanupTasks) {
            if (task.arena() == arena) {
                task.cancel();
            }
        }
    }

    private void discardArenaEntities(ArenaInstance arena, class_3218 world) {
        class_238 cleanupBox = arena.bounds() != null
                ? arena.bounds().method_1014(24.0D)
                : arena.schematicBounds() != null
                ? arena.schematicBounds().method_1014(24.0D)
                : new class_238(arena.anchor()).method_1014(160.0D);

        for (HTDEnemyEntity enemy : world.method_8390(HTDEnemyEntity.class, cleanupBox.method_1014(256.0D),
                entity -> entity.arenaId() == arena.arenaId())) {
            enemy.method_31472();
        }
        world.method_8333(null, cleanupBox, entity -> !(entity instanceof class_3222))
                .forEach(entity -> {
                    if (ConfigManager.general().debug) {
                        HexaTowerDefenseMod.LOGGER.info("[HexaTowerDefense] Cleanup discarded entity {} in arena {}",
                                entity.method_5864().method_35050(), arena.arenaId());
                    }
                    entity.method_31472();
                });
    }

    public static String formatBlockPos(class_2338 pos) {
        return "[" + pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260() + "]";
    }

    public static String formatBox(class_238 box) {
        if (box == null) {
            return "none";
        }
        int minX = (int) Math.floor(box.field_1323);
        int minY = (int) Math.floor(box.field_1322);
        int minZ = (int) Math.floor(box.field_1321);
        int maxX = (int) Math.floor(box.field_1320) - 1;
        int maxY = (int) Math.floor(box.field_1325) - 1;
        int maxZ = (int) Math.floor(box.field_1324) - 1;
        return "[" + minX + ", " + minY + ", " + minZ + "] -> [" + maxX + ", " + maxY + ", " + maxZ + "]";
    }
}
