package com.zjuqni.hexatowerdefense.arena;

import net.minecraft.class_238;

public record ArenaBounds(class_238 box) {
    public String describeInclusive() {
        if (box == null) {
            return "none";
        }
        int minX = (int) Math.floor(box.field_1323);
        int minY = (int) Math.floor(box.field_1322);
        int minZ = (int) Math.floor(box.field_1321);
        int maxX = (int) Math.floor(box.field_1320) - 1;
        int maxY = (int) Math.floor(box.field_1325) - 1;
        int maxZ = (int) Math.floor(box.field_1324) - 1;
        return "[" + minX + ", " + minY + ", " + minZ + "] -> [" + maxX + ", " + maxY + ", " + maxZ + "]";
    }
}
