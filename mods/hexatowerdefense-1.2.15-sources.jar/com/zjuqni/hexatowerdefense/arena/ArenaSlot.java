package com.zjuqni.hexatowerdefense.arena;

import net.minecraft.class_2338;

public record ArenaSlot(int arenaId, class_2338 anchor) {
}
