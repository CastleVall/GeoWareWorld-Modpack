package com.zjuqni.hexatowerdefense.arena;

public enum ArenaState {
    RESERVED,
    GENERATING,
    READY,
    PREPARING,
    RUNNING,
    WON,
    LOST,
    CLEANING,
    CLOSED
}
