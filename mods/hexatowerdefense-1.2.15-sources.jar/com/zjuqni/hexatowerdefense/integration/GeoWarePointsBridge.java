package com.zjuqni.hexatowerdefense.integration;

import com.zjuqni.hexatowerdefense.HexaTowerDefenseMod;
import com.zjuqni.hexatowerdefense.config.ConfigManager;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_3222;
import java.lang.reflect.Method;

public final class GeoWarePointsBridge {
    private static final String MOD_ID = "geowarepoints";
    private static final String API_CLASS = "ethernal.shimonsolo.geowarepoints.api.GeoWarePointsAPI";

    private static Method showPointsUpdateMethod;
    private static Method gameFinishMethod;
    private static Method refreshHudMethod;
    private static boolean warnedUnavailable;
    private static boolean warnedFailure;

    private GeoWarePointsBridge() {
    }

    public static void addPoints(class_3222 player, int points) {
        if (player == null || points <= 0 || !ConfigManager.general().geowarePointsEnabled) {
            return;
        }
        if (!FabricLoader.getInstance().isModLoaded(MOD_ID)) {
            warnUnavailable();
            return;
        }
        try {
            getShowPointsUpdateMethod().invoke(null, player, points, true);
            getGameFinishMethod().invoke(null, player);
            getRefreshHudMethod().invoke(null, player);
        } catch (ReflectiveOperationException | LinkageError e) {
            warnFailure(e);
        }
    }

    private static Method getShowPointsUpdateMethod() throws ClassNotFoundException, NoSuchMethodException {
        if (showPointsUpdateMethod == null) {
            Class<?> api = Class.forName(API_CLASS);
            showPointsUpdateMethod = api.getMethod("showPointsUpdate", class_3222.class, int.class, boolean.class);
        }
        return showPointsUpdateMethod;
    }

    private static Method getGameFinishMethod() throws ClassNotFoundException, NoSuchMethodException {
        if (gameFinishMethod == null) {
            Class<?> api = Class.forName(API_CLASS);
            gameFinishMethod = api.getMethod("gameFinish", class_3222.class);
        }
        return gameFinishMethod;
    }

    private static Method getRefreshHudMethod() throws ClassNotFoundException, NoSuchMethodException {
        if (refreshHudMethod == null) {
            Class<?> api = Class.forName(API_CLASS);
            refreshHudMethod = api.getMethod("refreshHUD", class_3222.class);
        }
        return refreshHudMethod;
    }

    private static void warnUnavailable() {
        if (warnedUnavailable) {
            return;
        }
        warnedUnavailable = true;
        HexaTowerDefenseMod.LOGGER.warn("[HexaTowerDefense] GeoWarePoints no esta cargado; no se aplicaran puntos de mobs brillantes.");
    }

    private static void warnFailure(Throwable throwable) {
        if (warnedFailure) {
            return;
        }
        warnedFailure = true;
        HexaTowerDefenseMod.LOGGER.warn("[HexaTowerDefense] No se pudieron aplicar puntos mediante GeoWarePoints.", throwable);
    }
}
