package org.valkyrienskies.mod.common;

import net.minecraft.class_1937;

public class VSGameUtilsKt {
    public static double squaredDistanceBetweenInclShips(class_1937 level, double x1, double y1, double z1, double x2, double y2, double z3) {
        throw new UnsupportedOperationException("Stub!");
    }
}
