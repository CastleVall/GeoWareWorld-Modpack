package io.github.gusthavosouza.srt;

import lombok.experimental.UtilityClass;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@UtilityClass
public final class SRTParser {
    private static final Logger logger = LogManager.getLogger(SRTParser.class);

    private static final Pattern PATTERN_TIMES = Pattern.compile("(\\d{2}:\\d{2}:\\d{2},\\d{3}).*(\\d{2}:\\d{2}:\\d{2},\\d{3})");
    private static final Pattern PATTERN_NUMBERS = Pattern.compile("(\\d+)");
    private static final Charset DEFAULT_CHARSET = StandardCharsets.UTF_8;

    private static final String REGEX_REMOVE_TAGS = "<[^>]*>";

    private static final long MILLIS_IN_SECOND = 1000;
    private static final long MILLIS_IN_MINUTE = MILLIS_IN_SECOND * 60;
    private static final long MILLIS_IN_HOUR = MILLIS_IN_MINUTE * 60;

    private static final Pattern PATTERN_TIME = Pattern.compile("(\\d{2}):(\\d{2}):(\\d{2}),(\\d{3})");

    private static final int PATTER_TIME_GROUP_HOURS = 1;
    private static final int PATTER_TIME_GROUP_MINUTES = 2;
    private static final int PATTER_TIME_GROUP_SECONDS = 3;
    private static final int PATTER_TIME_GROUP_MILLISECONDS = 4;

    public static Subtitles loadSubtitles(InputStream inputStream, boolean keepNewlinesEscape) {
        Subtitles subtitles = new Subtitles();
        try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, DEFAULT_CHARSET))) {
            String line;
            StringBuilder sb = new StringBuilder();
            while ((line = bufferedReader.readLine()) != null) {
                if (line.isEmpty()) continue;

                int id = 0;
                Matcher matcher = PATTERN_NUMBERS.matcher(line);
                if (matcher.find()) {
                    id = Integer.parseInt(matcher.group(1));
                    line = bufferedReader.readLine();
                }
                matcher = PATTERN_TIMES.matcher(line);

                if (matcher.find()) {
                    long startTime = textTimeToMillis(matcher.group(1));
                    long endTime = textTimeToMillis(matcher.group(2));

                    sb.setLength(0);
                    while ((line = bufferedReader.readLine()) != null && !line.isEmpty()) {
                        sb.append(line);
                        if (keepNewlinesEscape) {
                            sb.append("\n");
                        } else {
                            sb.append(" ");
                        }
                    }
                    if (!sb.isEmpty()) {
                        sb.setLength(sb.length() - 1);
                    }

                    String subtitleText = sb.toString().replaceAll(REGEX_REMOVE_TAGS, "");
                    subtitles.add(new Subtitle(id, startTime, endTime, subtitleText));
                }
            }
        } catch (Exception e) {
            logger.error("Error parsing srt file", e);
        }
        return subtitles;
    }

    private static long textTimeToMillis(final String time) throws IllegalArgumentException {
        if (time == null || time.isEmpty()) {
            throw new IllegalArgumentException("Time should not be null or empty");
        }
        Matcher matcher = PATTERN_TIME.matcher(time);
        if (!matcher.matches()) {
            throw new IllegalArgumentException("Incorrect time format...");
        }

        int hours = Integer.parseInt(matcher.group(PATTER_TIME_GROUP_HOURS));
        int minutes = Integer.parseInt(matcher.group(PATTER_TIME_GROUP_MINUTES));
        int seconds = Integer.parseInt(matcher.group(PATTER_TIME_GROUP_SECONDS));
        int milliseconds = Integer.parseInt(matcher.group(PATTER_TIME_GROUP_MILLISECONDS));

        return hours * MILLIS_IN_HOUR + minutes * MILLIS_IN_MINUTE + seconds * MILLIS_IN_SECOND + milliseconds;
    }
}
