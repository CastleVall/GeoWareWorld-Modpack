package io.github.gusthavosouza.srt;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter @Setter
@RequiredArgsConstructor
public class Subtitle {
	private final int id;
	private final Long startTime;
	private final Long endTime;
	private final String text;

	public boolean isTimeBetween(Long time) {
		return time >= startTime && time <= endTime;
	}
}
