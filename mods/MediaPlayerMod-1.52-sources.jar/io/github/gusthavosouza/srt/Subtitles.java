package io.github.gusthavosouza.srt;

import java.util.LinkedList;

public class Subtitles extends LinkedList<Subtitle> {

    public Subtitle getSubtitle(long time) {
        for (Subtitle subtitle : this) {
            if (subtitle.isTimeBetween(time)) {
                return subtitle;
            }
        }
        return null;
    }

    public long getDuration() {
        if (isEmpty()) {
            return 0;
        }
        return getLast().getEndTime();
    }
}
