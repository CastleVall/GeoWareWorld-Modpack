package me.elb.mediaplayermod;

import me.elb.mediaplayermod.command.*;
import me.elb.mediaplayermod.screenhandler.ModScreenHandlers;
import me.elb.mediaplayermod.server.voice.VoiceDistanceManager;
import me.elb.mediaplayermod.server.ProjectionWandManager;
import me.elb.mediaplayermod.server.ServerProjectionManager;
import me.elb.mediaplayermod.server.ServerPlaylistManager;
import me.elb.mediaplayermod.networking.packet.Packet;
import me.elb.mediaplayermod.networking.packet.ClientRequestPlaylistAdminPacket;
import me.elb.mediaplayermod.networking.packet.ServerPlaylistAdminSyncPacket;
import me.elb.mediaplayermod.payload.MediaPayload;
import me.elb.mediaplayermod.server.ServerHandler;
import me.elb.mediaplayermod.cameraplayer.CameraEntity;
import me.elb.mediaplayermod.cameraplayer.StreamScreenEntity;
import me.elb.mediaplayermod.cameraplayer.ScreenNetworkPayloads.*;
import me.elb.mediaplayermod.cameraplayer.ScreenStreamManager;
import lombok.Getter;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1934;
import net.minecraft.class_2170;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import me.lucko.fabric.api.permissions.v0.Permissions;
import java.util.HashMap;
import java.util.Map;

public class MediaPlayerMod extends ServerHandler<class_3222> implements ModInitializer {
	public static final String MOD_ID = "mediaplayer";
	public static final String COMMAND_PERMISSION = "mediaplayer.command.";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	@Getter
	private static MediaPlayerMod instance = new MediaPlayerMod();

	public static class_1299<StreamScreenEntity> STREAM_SCREEN_ENTITY;
	public static class_1299<CameraEntity> CAMERA_ENTITY;

	private final Map<class_3222, class_1934> gamemodeMap = new HashMap<>();
	@Getter
	private MinecraftServer server;

	@Override
	public void onInitialize() {
		instance = this;

		// Registra las sugerencias de archivos locales para que el CLIENTE las resuelva localmente
		// (debe ocurrir en ambos lados; por eso va aqui y no dentro del registro de comandos).
		me.elb.mediaplayermod.command.provider.MediaSuggestions.register();

		ModScreenHandlers.register();

		ServerLifecycleEvents.SERVER_STARTED.register(srv -> {
			this.server = srv;
			ServerProjectionManager.init(srv.method_3831());
			ServerPlaylistManager.init(srv.method_3831());
			VoiceDistanceManager.init(srv.method_3831());
			getPlaylists().clear();
			getPlaylists().addAll(ServerPlaylistManager.load());
		});
		ServerLifecycleEvents.SERVER_STOPPED.register(srv -> this.server = null);

		ServerTickEvents.END_SERVER_TICK.register(srv -> tickDeliveries());

		CommandRegistrationCallback.EVENT.register((dispatcher, dedicated, environment) -> {
			PlayMediaCommand.register(dispatcher);
			StopMediaCommand.register(dispatcher);
			PlayVideoCommand.register(dispatcher);
			PlayAudioCommand.register(dispatcher);
			PlayImageCommand.register(dispatcher);
			PlayInteractiveImageCommand.register(dispatcher);
			PlayAnimationCommand.register(dispatcher);
			CountdownCommand.register(dispatcher);
			PlayFadeCommand.register(dispatcher);
			SetVolumeCommand.register(dispatcher);
			PlayGlowCommand.register(dispatcher);
			PlayBlinkCommand.register(dispatcher);
			PlayColorCommand.register(dispatcher);
			PlayProjectionCommand.register(dispatcher);
			PlaySubtitlesCommand.register(dispatcher);
			PlayTutorialCommand.register(dispatcher);
			PlayTextCommand.register(dispatcher);
			PlayZoomCommand.register(dispatcher);
			PlayCameraCommand.register(dispatcher);
			PlayListCommand.register(dispatcher);
			ListMediaCommand.register(dispatcher);
			ClientOptionsCommand.register(dispatcher);
			PlayCameraProjectionCommand.register(dispatcher);
			SeeInvCommand.register(dispatcher);

			dispatcher.register(class_2170.method_9247("st-cam").requires(source -> Permissions.check(source, COMMAND_PERMISSION + "st-cam", 2))
					.then(class_2170.method_9247("summon").then(class_2170.method_9244("name", com.mojang.brigadier.arguments.StringArgumentType.string())
							.executes(context -> {
								var source = context.getSource();
								var player = source.method_9207();
								String name = com.mojang.brigadier.arguments.StringArgumentType.getString(context, "name");
								CameraEntity camera = new CameraEntity(CAMERA_ENTITY, source.method_9225());
								camera.setCameraName(name);
								camera.method_5808(player.method_23317(), player.method_23320(), player.method_23321(), player.method_36454(), player.method_36455());
								source.method_9225().method_8649(camera);
								return 1;
							})))
					.then(class_2170.method_9247("remove").then(class_2170.method_9244("name", com.mojang.brigadier.arguments.StringArgumentType.string())
							.executes(context -> {
								var source = context.getSource();
								String name = com.mojang.brigadier.arguments.StringArgumentType.getString(context, "name");
								for (net.minecraft.class_1297 e : source.method_9225().method_27909()) {
									if (e instanceof CameraEntity cam && cam.getCameraName().equalsIgnoreCase(name)) e.method_31472();
								}
								return 1;
							})))
					.then(class_2170.method_9247("player").executes(context -> {
						ServerPlayNetworking.send(context.getSource().method_9207(), new CameraPovPayload("PLAYER"));
						return 1;
					}))
					.then(class_2170.method_9247("view").then(class_2170.method_9244("name", com.mojang.brigadier.arguments.StringArgumentType.string())
							.executes(context -> {
								String name = com.mojang.brigadier.arguments.StringArgumentType.getString(context, "name");
								ServerPlayNetworking.send(context.getSource().method_9207(), new CameraPovPayload(name));
								return 1;
							}))));
		});

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			joinPlayer(handler.field_14140);
			ServerProjectionManager.getAll().forEach(proj -> syncProjectionToPlayer(handler.field_14140, proj));
		});
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server1) -> {
			disconnectPlayer(handler.field_14140);
			ScreenStreamManager.onStreamerDisconnect(handler.field_14140.method_5667());
		});
		PayloadTypeRegistry.playC2S().register(MediaPayload.ID, MediaPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(MediaPayload.ID, MediaPayload.CODEC);
		ServerPlayNetworking.registerGlobalReceiver(MediaPayload.ID,
				(payload, context) -> handlePacket(context.player(), payload.packet()));

		PayloadTypeRegistry.playC2S().register(FrameC2SPayload.ID, FrameC2SPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(FrameS2CPayload.ID, FrameS2CPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(SyncStreamPayload.ID, SyncStreamPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(VideoSyncPayload.ID, VideoSyncPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(CameraPovPayload.ID, CameraPovPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(OverlayPayload.ID, OverlayPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(EffectsPayload.ID, EffectsPayload.CODEC);

		STREAM_SCREEN_ENTITY = class_2378.method_10230(
				class_7923.field_41177,
				class_2960.method_60655(MOD_ID, "stream_screen_entity"),
				class_1299.class_1300.method_5903(StreamScreenEntity::new, class_1311.field_17715)
						.method_17687(2f, 2f)
						.method_27299(64)
						.method_27300(1)
						.method_5905("stream_screen_entity"));

		CAMERA_ENTITY = class_2378.method_10230(
				class_7923.field_41177,
				class_2960.method_60655(MOD_ID, "camera_entity"),
				class_1299.class_1300.method_5903(CameraEntity::new, class_1311.field_17715)
						.method_17687(0.5f, 0.5f)
						.method_5905("camera_entity"));

		ServerPlayNetworking.registerGlobalReceiver(FrameC2SPayload.ID, (payload, context) -> {
			context.server().execute(() -> ScreenStreamManager.handleFrameChunk(
					context.player(), payload.frameId(), payload.chunkIndex(), payload.totalChunks(), payload.data()));
		});

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			var player = handler.method_32311();
			for (net.minecraft.class_3218 world : server.method_3738()) {
				for (net.minecraft.class_1297 entity : world.method_27909()) {
					if (entity instanceof StreamScreenEntity screen &&
							screen.getStreamerUuid().map(uuid -> uuid.equals(player.method_5667())).orElse(false)) {
						ServerPlayNetworking.send(player, new SyncStreamPayload());
					}
				}
			}
		});

		AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
			if (!world.method_8608() && ProjectionWandManager.isWand(player.method_6047())) {
				ProjectionWandManager.setPos1(player.method_5667(), pos);
				player.method_7353(class_2561.method_30163("[Projection] Pos1 -> " + pos.method_23854()), true);
				return net.minecraft.class_1269.field_5814;
			}
			return net.minecraft.class_1269.field_5811;
		});

		UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
			if (!world.method_8608() && hand == net.minecraft.class_1268.field_5808
					&& ProjectionWandManager.isWand(player.method_6047())) {
				ProjectionWandManager.setPos2(player.method_5667(), hitResult.method_17777());
				player.method_7353(class_2561.method_30163("[Projection] Pos2 -> " + hitResult.method_17777().method_23854()), true);
				return net.minecraft.class_1269.field_5812;
			}
			return net.minecraft.class_1269.field_5811;
		});

		LOGGER.info("MediaPlayerMod initialized!");
	}

	@Override
	protected void preparePlayer(class_3222 player) {
		gamemodeMap.put(player, player.field_13974.method_14257());
		player.method_7336(class_1934.field_9219);
	}

	@Override
	protected void restorePlayer(class_3222 serverPlayerEntity) {
		class_1934 previousGamemode = gamemodeMap.remove(serverPlayerEntity);
		if (previousGamemode != null) {
			serverPlayerEntity.method_7336(previousGamemode);
		}
	}

	@Override
	protected void sendPlayerPacket(class_3222 serverPlayerEntity, Packet packet) {
		ServerPlayNetworking.send(serverPlayerEntity, new MediaPayload(packet));
	}

	@Override
	protected void sendPacketToAll(Packet packet) {
		if (server != null) {
			server.method_3760().method_14571().forEach(player -> sendPlayerPacket(player, packet));
		}
	}

	@Override
	protected void sendOptionInfo(String requester, class_3222 target, String option, String value) {
		if (server == null) return;
		class_3222 requesterPlayer = server.method_3760().method_14566(requester);
		String targetName = target.method_5477().getString();
		String msg = "[MediaPlayer] " + targetName + "'s " + option + " = " + value;
		if (requesterPlayer != null) {
			requesterPlayer.method_43496(class_2561.method_30163(msg));
		} else {
			LOGGER.info(msg);
		}
	}

	@Override
	protected void onPlaylistStateChanged() {
		ServerPlaylistManager.persist(getPlaylists());
	}

	@Override
	public void handlePacket(class_3222 player, Packet packet) {
		if (packet instanceof ClientRequestPlaylistAdminPacket) {
			sendPlaylistAdminSync(player);
			return;
		}
		super.handlePacket(player, packet);
	}

	/**
	 * Reenvia una proyeccion a un jugador que entra, respetando su estado real:
	 * detenida -> negra; pausada -> en su posicion; reproduciendo -> sincronizada al
	 * segundo en que va el resto del servidor.
	 */
	private void syncProjectionToPlayer(class_3222 player,
			me.elb.mediaplayermod.model.media.Projection proj) {
		String id = proj.id();
		boolean hasVideo = proj.url() != null && !proj.url().isEmpty();

		// Detenida: enviar la pantalla SIN url para que NO arranque ningun reproductor
		// (si no, queda audio fantasma que ni /stopmedia puede parar). Queda en negro.
		if (hasVideo && ServerProjectionManager.isStopped(id)) {
			sendPacket(player, new me.elb.mediaplayermod.networking.packet.ServerPlayMediaPacket(
					new me.elb.mediaplayermod.model.media.Projection(id, "",
							proj.x1(), proj.y1(), proj.z1(), proj.x2(), proj.y2(), proj.z2(),
							proj.rotX(), proj.rotY(), proj.rotZ())));
			return;
		}

		sendPacket(player, new me.elb.mediaplayermod.networking.packet.ServerPlayMediaPacket(proj));
		if (!hasVideo || !ServerProjectionManager.hasState(id)) {
			return;
		}
		if (ServerProjectionManager.isLoop(id)) {
			sendProjectionOp(player, id, me.elb.mediaplayermod.model.media.ProjectionOperation.Op.LOOP_ON, "");
		}
		// El cliente calcula el punto exacto (y el ciclo del loop) con su propia duracion.
		sendProjectionOp(player, id, me.elb.mediaplayermod.model.media.ProjectionOperation.Op.SEEK,
				Long.toString(ServerProjectionManager.elapsedMs(id)));
		if (ServerProjectionManager.isPaused(id)) {
			sendProjectionOp(player, id, me.elb.mediaplayermod.model.media.ProjectionOperation.Op.PAUSE, "");
		}
	}

	private void sendProjectionOp(class_3222 player, String id,
			me.elb.mediaplayermod.model.media.ProjectionOperation.Op op, String arg) {
		sendPacket(player, new me.elb.mediaplayermod.networking.packet.ServerPlayMediaPacket(
				new me.elb.mediaplayermod.model.media.ProjectionOperation(id, op, arg)));
	}

	public void sendPlaylistAdminSync(class_3222 player) {
		boolean allowed = Permissions.check(player.method_5671(), COMMAND_PERMISSION + "playlist", 2);
		ServerPlaylistAdminSyncPacket packet = allowed
				? ServerPlaylistAdminSyncPacket.fromPlaylists(getPlaylists())
				: ServerPlaylistAdminSyncPacket.denied();
		ServerPlayNetworking.send(player, new MediaPayload(packet));
	}

	public void sendPlaylistAdminSyncToAdmins() {
		if (server == null) {
			return;
		}
		server.method_3760().method_14571().forEach(player -> {
			if (Permissions.check(player.method_5671(), COMMAND_PERMISSION + "playlist", 2)) {
				sendPlaylistAdminSync(player);
			}
		});
	}
}
