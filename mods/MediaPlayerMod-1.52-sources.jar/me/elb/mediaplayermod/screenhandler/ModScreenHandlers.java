package me.elb.mediaplayermod.screenhandler;

import me.elb.mediaplayermod.MediaPlayerMod;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7923;

/** Registro del ScreenHandler del inventario compartido y helper para abrirlo. */
public final class ModScreenHandlers {
    public static ExtendedScreenHandlerType<SharedInventoryScreenHandler, SharedInvData> SHARED_INVENTORY;

    private ModScreenHandlers() {
    }

    public static void register() {
        SHARED_INVENTORY = class_2378.method_10230(
                class_7923.field_41187,
                class_2960.method_60655(MediaPlayerMod.MOD_ID, "shared_inventory"),
                new ExtendedScreenHandlerType<>(SharedInventoryScreenHandler::new, SharedInvData.CODEC));
    }

    /** Abre para {@code admin} el inventario compartido del jugador {@code target}. */
    public static void open(class_3222 admin, class_3222 target) {
        admin.method_17355(new ExtendedScreenHandlerFactory<SharedInvData>() {
            @Override
            public SharedInvData getScreenOpeningData(class_3222 player) {
                return new SharedInvData(target.method_5628());
            }

            @Override
            public class_2561 method_5476() {
                return class_2561.method_43470("Inventario de " + target.method_5477().getString());
            }

            @Override
            public class_1703 createMenu(int syncId, class_1661 inventory, class_1657 player) {
                return new SharedInventoryScreenHandler(syncId, inventory, target);
            }
        });
    }
}
