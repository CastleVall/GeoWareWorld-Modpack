package me.elb.mediaplayermod.screenhandler;

import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Datos que el servidor manda al cliente al abrir el inventario compartido: el id de entidad del
 * jugador objetivo, para poder dibujar su vista previa.
 */
public record SharedInvData(int targetEntityId) {
    public static final class_9139<class_9129, SharedInvData> CODEC = class_9139.method_56434(
            class_9135.field_48550, SharedInvData::targetEntityId,
            SharedInvData::new);
}
