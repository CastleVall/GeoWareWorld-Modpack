package me.elb.mediaplayermod.screenhandler;

import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

/**
 * Inventario compartido admin <-> jugador objetivo. La mitad de arriba refleja el inventario del
 * objetivo (armadura, mano secundaria, inventario y hotbar); la de abajo es el inventario del admin.
 * El movimiento de items lo gestiona el {@link class_1703} vanilla de forma autoritativa.
 *
 * <p>Indices de los slots del handler:
 * <ul>
 *   <li>0-3: armadura objetivo (casco, peto, pantalon, botas)</li>
 *   <li>4: mano secundaria objetivo</li>
 *   <li>5-31: inventario principal objetivo</li>
 *   <li>32-40: hotbar objetivo</li>
 *   <li>41-67: inventario principal admin</li>
 *   <li>68-76: hotbar admin</li>
 * </ul>
 */
public class SharedInventoryScreenHandler extends class_1703 {
    public static final int TARGET_SECTION_END = 41; // primer slot del admin

    private final int targetEntityId;

    /** Constructor de cliente (factory de ExtendedScreenHandlerType). */
    public SharedInventoryScreenHandler(int syncId, class_1661 playerInventory, SharedInvData data) {
        this(syncId, playerInventory, new class_1277(41), data.targetEntityId());
    }

    /** Constructor de servidor: referencia el inventario real del objetivo. */
    public SharedInventoryScreenHandler(int syncId, class_1661 adminInventory, class_1657 target) {
        this(syncId, adminInventory, target.method_31548(), target.method_5628());
    }

    private SharedInventoryScreenHandler(int syncId, class_1661 adminInventory, class_1263 targetInventory, int targetEntityId) {
        super(ModScreenHandlers.SHARED_INVENTORY, syncId);
        this.targetEntityId = targetEntityId;

        // --- Objetivo: armadura (casco arriba -> botas abajo). Indices de PlayerInventory: 39..36 ---
        for (int i = 0; i < 4; i++) {
            int invIndex = 39 - i;
            method_7621(new class_1735(targetInventory, invIndex, 8, 18 + i * 18));
        }
        // Mano secundaria objetivo (indice 40).
        method_7621(new class_1735(targetInventory, 40, 8, 92));

        // Inventario principal objetivo (indices 9..35).
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                method_7621(new class_1735(targetInventory, 9 + row * 9 + col, 80 + col * 18, 18 + row * 18));
            }
        }
        // Hotbar objetivo (indices 0..8).
        for (int col = 0; col < 9; col++) {
            method_7621(new class_1735(targetInventory, col, 80 + col * 18, 76));
        }

        // --- Admin: inventario principal (indices 9..35) ---
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                method_7621(new class_1735(adminInventory, 9 + row * 9 + col, 80 + col * 18, 110 + row * 18));
            }
        }
        // Hotbar admin (indices 0..8).
        for (int col = 0; col < 9; col++) {
            method_7621(new class_1735(adminInventory, col, 80 + col * 18, 168));
        }
    }

    public int getTargetEntityId() {
        return targetEntityId;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return true;
    }

    @Override
    public class_1799 method_7601(class_1657 player, int index) {
        class_1799 newStack = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(index);
        if (slot != null && slot.method_7681()) {
            class_1799 original = slot.method_7677();
            newStack = original.method_7972();
            boolean moved;
            if (index < TARGET_SECTION_END) {
                // De la mitad del objetivo a la del admin.
                moved = method_7616(original, TARGET_SECTION_END, this.field_7761.size(), false);
            } else {
                // De la mitad del admin al inventario principal + hotbar del objetivo (slots 5..40).
                moved = method_7616(original, 5, TARGET_SECTION_END, false);
            }
            if (!moved) {
                return class_1799.field_8037;
            }
            if (original.method_7960()) {
                slot.method_53512(class_1799.field_8037);
            } else {
                slot.method_7668();
            }
        }
        return newStack;
    }
}
