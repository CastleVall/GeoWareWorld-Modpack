package me.elb.mediaplayermod.mixin.player;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_4604;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_897.class)
public abstract class EntityRendererMixin<T extends class_1297> {

    @Inject(method = { "shouldRender" }, at = { @At("HEAD") }, cancellable = true)
    public void shouldRender(final T entity, final class_4604 frustum, final double x, final double y, final double z, final CallbackInfoReturnable<Boolean> cir) {
        if (entity instanceof class_1657 player && player.method_7325()) {
            cir.setReturnValue(false);
        }
    }
}
