package me.elb.mediaplayermod.mixin.camera;

import me.elb.mediaplayermod.client.CameraHandler;
import me.elb.mediaplayermod.client.ClientHandler;
import me.elb.mediaplayermod.cameraplayer.client.render.WorldCameraRenderer;
import me.elb.mediaplayermod.client.camera.CameraTransition;
import me.elb.mediaplayermod.model.media.Camera;
import me.elb.mediaplayermod.utils.CoordinateUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import org.joml.Vector2f;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(net.minecraft.class_4184.class)
public abstract class CameraMixin {
    @Shadow
    private class_1297 focusedEntity;
    @Shadow
    private class_1922 area;
    @Shadow @Final
    private Vector3f verticalPlane;
    @Shadow @Final
    private Vector3f diagonalPlane;
    @Shadow
    private class_243 pos;
    @Shadow
    private float pitch;
    @Shadow
    private float yaw;

    @Redirect(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setPos(DDD)V", ordinal = 0))
    private void setPosition(net.minecraft.class_4184 instance, double x, double y, double z) {
        CameraHandler cameraHandler = ClientHandler.getCameraHandler();
        CameraTransition<Camera.Movement> cameraTransition = cameraHandler.getCameraTransition();
        if (cameraTransition.isEnabled() && !cameraTransition.getTo().detached()) {
            Vector3f vector = cameraHandler.limitPosition(x, y, z);
            setPos(vector.x(), vector.y(), vector.z());
            return;
        }
        Float toYaw = null;
        Float toPitch = null;
        CameraTransition<Float> yawTransition = cameraHandler.getYawTransition();
        if (yawTransition.isEnabled()) {
            if (yawTransition.isLoading()) {
                toYaw = CoordinateUtils.interpolateYaw(yawTransition.getFrom(), yawTransition.getTo(), yawTransition.getLoadPercent());
            } else {
                toYaw = yawTransition.getTo();
            }
        }
        CameraTransition<Float> pitchTransition = cameraHandler.getPitchTransition();
        if (pitchTransition.isEnabled()) {
            if (pitchTransition.isLoading()) {
                toPitch = CoordinateUtils.interpolatePitch(pitchTransition.getFrom(), pitchTransition.getTo(), pitchTransition.getLoadPercent());
            } else {
                toPitch = pitchTransition.getTo();
            }
        }
        if (cameraTransition.isEnabled()) {
            Camera.Movement to = cameraTransition.getTo();
            if (cameraTransition.isLoading()) {
                Camera.Movement from = cameraHandler.getFixedFrom(true);
                float percent = cameraTransition.getLoadPercent();
                x = (float) (from.x() + (to.x() - from.x()) * percent);
                y = (float) (from.y() + (to.y() - from.y()) * percent);
                z = (float) (from.z() + (to.z() - from.z()) * percent);
                if (toYaw == null) {
                    toYaw = CoordinateUtils.interpolateYaw(from.yaw(), to.yaw(), percent);
                }
                if (toPitch == null) {
                    toPitch = CoordinateUtils.interpolatePitch(from.pitch(), to.pitch(), percent);
                }
            } else {
                x = to.x();
                y = to.y();
                z = to.z();
                if (toYaw == null) {
                    toYaw = to.yaw();
                }
                if (toPitch == null) {
                    toPitch = to.pitch();
                }
            }
        }
        setPos(x, y, z);
        if (toYaw != null && toPitch != null) {
            setRotation(toYaw, toPitch);
        } else if (toYaw != null) {
            setRotation(toYaw, pitch);
        } else if (toPitch != null) {
            setRotation(yaw, toPitch);
        }
    }

    @Redirect(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;moveBy(FFF)V", ordinal = 0))
    private void move(net.minecraft.class_4184 instance, float f, float g, float h) {
        CameraHandler cameraHandler = ClientHandler.getCameraHandler();
        CameraTransition<Camera.Movement> cameraTransition = cameraHandler.getCameraTransition();
        if (!cameraTransition.isEnabled()) {
            if (!WorldCameraRenderer.isCapturing) {
                moveBy(-clipToSpace(4F), 0F, 0F);
            }
            return;
        }
        Camera.Movement to = cameraTransition.getTo();
        if (to.detached()) {
            return;
        }
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            return;
        }
        float fromYaw = client.field_1724.method_36454();
        float fromPitch = client.field_1724.method_36455();
        if (!cameraHandler.isLimiting()) {
            float moveX;
            float moveY;
            float moveZ;
            if (cameraTransition.isLoading()) {
                Camera.Movement from = cameraHandler.getFixedFrom(false);
                float percent = cameraTransition.getLoadPercent();
                moveX = (float) (from.x() + (to.x() - from.x()) * percent);
                moveY = (float) (from.y() + (to.y() - from.y()) * percent);
                moveZ = (float) (from.z() + (to.z() - from.z()) * percent);
                fromYaw = from.yaw();
                fromPitch = from.pitch();
            } else {
                moveX = (float) to.x();
                moveY = (float) to.y();
                moveZ = (float) to.z();
            }
            moveBy(clipToSpace(moveX), moveY, moveZ);
        }

        float finalYaw = yaw + (to.inverted() ? 180F : 0F);
        float finalPitch = (to.inverted() ? -pitch : pitch);
        if (cameraTransition.isLoading()) {
            float percent = cameraTransition.getLoadPercent();
            finalYaw = CoordinateUtils.interpolateYaw(fromYaw, finalYaw + to.yaw(), percent);
            finalPitch = CoordinateUtils.interpolatePitch(fromPitch, finalPitch + to.pitch(), percent);
        } else {
            finalYaw += to.yaw();
            finalPitch += to.pitch();
        }
        Vector2f rotation = cameraHandler.limitRotation(finalYaw, finalPitch);
        setRotation(rotation.x(), rotation.y());
    }

    @Shadow
    protected abstract void moveBy(float d, float e, float f);

    @Shadow
    protected abstract float clipToSpace(float d);

    @Shadow
    protected abstract void setRotation(float f, float g);

    @Shadow
    protected abstract void setPos(double d, double e, double f);

    private float clipToSpaceZ(float f) {
        for (int i = 0; i < 8; i++) {
            float h = ((i & 1) * 2 - 1);
            float j = ((i >> 1 & 1) * 2 - 1);
            float k = ((i >> 2 & 1) * 2 - 1);
            class_243 vec3d = this.pos.method_1031(h * 0.1F, j * 0.1F, k * 0.1F);
            class_243 vec3d2 = vec3d.method_1019(new class_243(this.diagonalPlane).method_1021(-f));
            class_239 hitResult = this.area
                    .method_17742(new class_3959(vec3d, vec3d2, class_3959.class_3960.field_23142, class_3959.class_242.field_1348, this.focusedEntity));
            if (hitResult.method_17783() != class_239.class_240.field_1333) {
                float l = (float)hitResult.method_17784().method_1025(this.pos);
                if (l < class_3532.method_27285(f)) {
                    f = class_3532.method_15355(l);
                }
            }
        }

        return f;
    }

    private float clipToSpaceY(float f) {
        for (int i = 0; i < 8; i++) {
            float h = ((i & 1) * 2 - 1);
            float j = ((i >> 1 & 1) * 2 - 1);
            float k = ((i >> 2 & 1) * 2 - 1);
            class_243 vec3d = this.pos.method_1031(h * 0.1F, j * 0.1F, k * 0.1F);
            class_243 vec3d2 = vec3d.method_1019(new class_243(this.verticalPlane).method_1021(-f));
            class_239 hitResult = this.area
                    .method_17742(new class_3959(vec3d, vec3d2, class_3959.class_3960.field_23142, class_3959.class_242.field_1348, this.focusedEntity));
            if (hitResult.method_17783() != class_239.class_240.field_1333) {
                float l = (float)hitResult.method_17784().method_1025(this.pos);
                if (l < class_3532.method_27285(f)) {
                    f = class_3532.method_15355(l);
                }
            }
        }

        return f;
    }

}
