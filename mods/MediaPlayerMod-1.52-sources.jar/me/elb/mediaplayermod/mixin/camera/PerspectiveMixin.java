package me.elb.mediaplayermod.mixin.camera;

import me.elb.mediaplayermod.client.ClientHandler;
import net.minecraft.class_5498;
import me.elb.mediaplayermod.cameraplayer.client.render.WorldCameraRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_5498.class)
public class PerspectiveMixin {
    @Inject(method = "isFirstPerson", at = @At("HEAD"), cancellable = true)
    private void isFirstPerson(CallbackInfoReturnable<Boolean> ci) {
        if (ClientHandler.getCameraHandler().isEnabled() || WorldCameraRenderer.isCapturing) {
            ci.setReturnValue(false);
        }
    }

    @Inject(method = "isFrontView", at = @At("HEAD"), cancellable = true)
    private void isFrontView(CallbackInfoReturnable<Boolean> ci) {
        if (ClientHandler.getCameraHandler().isEnabled() || WorldCameraRenderer.isCapturing) {
            ci.setReturnValue(false);
        }
    }
}
