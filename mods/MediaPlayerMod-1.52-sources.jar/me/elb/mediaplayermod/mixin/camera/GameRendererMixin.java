package me.elb.mediaplayermod.mixin.camera;

import me.elb.mediaplayermod.client.ClientHandler;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public abstract class GameRendererMixin {

    @Inject(at = @At("HEAD"), method = "updateFovMultiplier")
    private void updateFovMultiplier(CallbackInfo info) {
        ClientHandler.getZoomTracker().tick();
    }

    @ModifyConstant(method = "updateFovMultiplier", constant = @Constant(floatValue = 1.5F))
    private float increaseFloatValue(float constant) {
        return 2.0F;
    }

    @Inject(at = @At("HEAD"), method = "bobView", cancellable = true)
    private void bobView(class_4587 matrices, float tickDelta, CallbackInfo ci) {
        if (ClientHandler.getCameraHandler().isDetached()) {
            ci.cancel();
        }
    }

}
