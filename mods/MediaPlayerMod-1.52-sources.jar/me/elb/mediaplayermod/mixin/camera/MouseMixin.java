package me.elb.mediaplayermod.mixin.camera;

import me.elb.mediaplayermod.client.ClientHandler;
import net.minecraft.class_312;
import net.minecraft.class_7172;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_312.class)
public abstract class MouseMixin {

    @Redirect(method = "updateMouse", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/option/SimpleOption;getValue()Ljava/lang/Object;",
            ordinal = 0))
    private Object sensitivity(class_7172<Double> option) {
        return option.method_41753() * Math.min(1D, ClientHandler.getZoomTracker().getCurrentFov());
    }
}
