package me.elb.mediaplayermod.mixin.camera;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import me.elb.mediaplayermod.client.ClientHandler;
import net.minecraft.class_742;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_742.class)
public abstract class AbstractClientPlayerEntityMixin {

    @ModifyReturnValue(at = @At("RETURN"), method = "getFovMultiplier")
    private float getFieldOfViewModifier(float original) {
        float currentZoom = ClientHandler.getZoomTracker().getCurrentFov();
        if (ClientHandler.getCameraHandler().isDetached()) {
            return 1 * currentZoom;
        }
        return original * currentZoom;
    }
}
