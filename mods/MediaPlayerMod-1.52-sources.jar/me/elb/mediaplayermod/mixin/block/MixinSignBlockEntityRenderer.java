package me.elb.mediaplayermod.mixin.block;

import net.minecraft.class_2625;
import net.minecraft.class_827;
import net.minecraft.class_837;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_837.class)
public abstract class MixinSignBlockEntityRenderer implements class_827<class_2625> {

    @Unique
    @Override
    public int method_33893() {
        return 64;
    }

    @Unique
    @Override
    public boolean rendersOutsideBoundingBox(class_2625 sign) {
        return true;
    }
}
