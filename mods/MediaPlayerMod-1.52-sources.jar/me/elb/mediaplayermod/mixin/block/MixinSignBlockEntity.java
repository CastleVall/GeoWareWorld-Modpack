package me.elb.mediaplayermod.mixin.block;

import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2625;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value = class_2625.class, priority = 1100)
public abstract class MixinSignBlockEntity extends class_2586 {
    protected MixinSignBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }
}
