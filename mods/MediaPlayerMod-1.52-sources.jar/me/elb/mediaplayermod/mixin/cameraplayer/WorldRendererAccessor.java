package me.elb.mediaplayermod.mixin.cameraplayer;

import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_761.class)
public interface WorldRendererAccessor {
    @Accessor("lastCameraX") double getLastCameraX();
    @Accessor("lastCameraX") void setLastCameraX(double x);
    @Accessor("lastCameraY") double getLastCameraY();
    @Accessor("lastCameraY") void setLastCameraY(double y);
    @Accessor("lastCameraZ") double getLastCameraZ();
    @Accessor("lastCameraZ") void setLastCameraZ(double z);
    @Invoker("scheduleTerrainUpdate") void invokeScheduleTerrainUpdate();
    @Accessor("transparencyPostProcessor") net.minecraft.class_279 getTransparencyPostProcessor();
    @Accessor("transparencyPostProcessor") void setTransparencyPostProcessor(net.minecraft.class_279 processor);
    @Accessor("entityOutlinePostProcessor") net.minecraft.class_279 getEntityOutlinePostProcessor();
    @Accessor("entityOutlinePostProcessor") void setEntityOutlinePostProcessor(net.minecraft.class_279 processor);
}
