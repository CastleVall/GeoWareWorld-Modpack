package me.elb.mediaplayermod.mixin.cameraplayer;

import me.elb.mediaplayermod.cameraplayer.client.render.WorldCameraRenderer;
import net.minecraft.class_761;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public class WorldRendererCaptureMixin {
    @Inject(method = "renderSky", at = @At("HEAD"), cancellable = true)
    private void onRenderSky(Matrix4f matrices, Matrix4f projectionMatrix, float tickDelta, net.minecraft.class_4184 camera, boolean thickFog, Runnable fogCallback, CallbackInfo ci) {
        if (WorldCameraRenderer.isCapturing) {
            ci.cancel();
        }
    }
}
