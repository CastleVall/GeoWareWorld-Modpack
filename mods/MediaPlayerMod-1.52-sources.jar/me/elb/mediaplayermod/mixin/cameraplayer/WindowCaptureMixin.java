package me.elb.mediaplayermod.mixin.cameraplayer;

import me.elb.mediaplayermod.cameraplayer.client.render.WorldCameraRenderer;
import net.minecraft.class_1041;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1041.class)
public class WindowCaptureMixin {
    @Inject(method = "getFramebufferWidth", at = @At("HEAD"), cancellable = true)
    private void overrideFramebufferWidth(CallbackInfoReturnable<Integer> cir) {
        if (WorldCameraRenderer.isCapturing) cir.setReturnValue(854);
    }

    @Inject(method = "getFramebufferHeight", at = @At("HEAD"), cancellable = true)
    private void overrideFramebufferHeight(CallbackInfoReturnable<Integer> cir) {
        if (WorldCameraRenderer.isCapturing) cir.setReturnValue(480);
    }

    @Inject(method = "getWidth", at = @At("HEAD"), cancellable = true)
    private void overrideWidth(CallbackInfoReturnable<Integer> cir) {
        if (WorldCameraRenderer.isCapturing) cir.setReturnValue(854);
    }

    @Inject(method = "getHeight", at = @At("HEAD"), cancellable = true)
    private void overrideHeight(CallbackInfoReturnable<Integer> cir) {
        if (WorldCameraRenderer.isCapturing) cir.setReturnValue(480);
    }

    @Inject(method = "getScaleFactor", at = @At("HEAD"), cancellable = true)
    private void overrideScaleFactor(CallbackInfoReturnable<Double> cir) {
        if (WorldCameraRenderer.isCapturing) cir.setReturnValue(1.0);
    }

    @Inject(method = "getScaledWidth", at = @At("HEAD"), cancellable = true)
    private void overrideScaledWidth(CallbackInfoReturnable<Integer> cir) {
        if (WorldCameraRenderer.isCapturing) cir.setReturnValue(854);
    }

    @Inject(method = "getScaledHeight", at = @At("HEAD"), cancellable = true)
    private void overrideScaledHeight(CallbackInfoReturnable<Integer> cir) {
        if (WorldCameraRenderer.isCapturing) cir.setReturnValue(480);
    }

    @Inject(method = "isFullscreen", at = @At("HEAD"), cancellable = true)
    private void overrideIsFullscreen(CallbackInfoReturnable<Boolean> cir) {
        if (WorldCameraRenderer.isCapturing) cir.setReturnValue(false);
    }
}
