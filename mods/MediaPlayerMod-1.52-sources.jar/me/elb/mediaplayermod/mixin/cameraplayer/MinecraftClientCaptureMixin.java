package me.elb.mediaplayermod.mixin.cameraplayer;

import me.elb.mediaplayermod.cameraplayer.client.render.WorldCameraRenderer;
import net.minecraft.class_276;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_310.class)
public class MinecraftClientCaptureMixin {
    @Inject(method = "getFramebuffer", at = @At("HEAD"), cancellable = true)
    private void overrideFramebuffer(CallbackInfoReturnable<class_276> cir) {
        if (WorldCameraRenderer.isCapturing && WorldCameraRenderer.cameraFramebuffer != null) {
            cir.setReturnValue(WorldCameraRenderer.cameraFramebuffer);
        }
    }
}
