package me.elb.mediaplayermod.mixin.cameraplayer;

import com.mojang.blaze3d.systems.RenderSystem;
import me.elb.mediaplayermod.cameraplayer.client.render.WorldCameraRenderer;
import net.minecraft.class_4184;
import net.minecraft.class_758;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_758.class)
public class BackgroundRendererCaptureMixin {
    @Inject(method = "applyFog", at = @At("HEAD"), cancellable = true)
    private static void onApplyFog(class_4184 camera, class_758.class_4596 fogType, float viewDistance, boolean thickFog, float tickDelta, CallbackInfo ci) {
        if (WorldCameraRenderer.isCapturing) {
            float forcedDistance = 9.0f * 16.0f;
            RenderSystem.setShaderFogStart(forcedDistance * 0.75f);
            RenderSystem.setShaderFogEnd(forcedDistance);
            ci.cancel();
        }
    }
}
