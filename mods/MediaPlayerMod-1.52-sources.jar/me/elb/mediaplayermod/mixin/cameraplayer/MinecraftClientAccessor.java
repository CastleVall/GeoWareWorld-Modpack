package me.elb.mediaplayermod.mixin.cameraplayer;

import net.minecraft.class_276;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_310.class)
public interface MinecraftClientAccessor {
    @Accessor("framebuffer")
    void setFramebuffer(class_276 framebuffer);

    @Accessor("chunkCullingEnabled")
    boolean isChunkCullingEnabled();

    @Accessor("chunkCullingEnabled")
    void setChunkCullingEnabled(boolean enabled);
}
