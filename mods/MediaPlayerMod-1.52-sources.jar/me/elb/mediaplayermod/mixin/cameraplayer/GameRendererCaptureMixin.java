package me.elb.mediaplayermod.mixin.cameraplayer;

import me.elb.mediaplayermod.cameraplayer.ScreenStreamClientManager;
import me.elb.mediaplayermod.cameraplayer.client.render.WorldCameraRenderer;
import net.minecraft.class_7172;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.joml.Matrix4f;

@Mixin(class_757.class)
public class GameRendererCaptureMixin {
    @Inject(method = "renderWorld", at = @At("HEAD"), cancellable = true)
    private void onRenderWorldStart(net.minecraft.class_9779 tickCounter, CallbackInfo ci) {
        // Guard contra estados transitorios (ej. /reload o cambio de dimension) donde el
        // jugador y la entidad de camara son null: vanilla pasaria null a Camera.update y
        // reventaria con NPE. Si no hay a quien enfocar, saltamos el render del mundo.
        net.minecraft.class_310 client = net.minecraft.class_310.method_1551();
        if (client.field_1724 == null && client.method_1560() == null) {
            ci.cancel();
            return;
        }
        ScreenStreamClientManager.captureFrameInternal();
    }

    @Redirect(method = "renderWorld", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/option/SimpleOption;getValue()Ljava/lang/Object;"))
    private Object overrideViewDistance(class_7172<?> instance) {
        if (WorldCameraRenderer.isCapturing && instance == net.minecraft.class_310.method_1551().field_1690.method_42503()) {
            return 9;
        }
        return instance.method_41753();
    }

    @Inject(method = "getFov", at = @At("HEAD"), cancellable = true)
    private void overrideFov(net.minecraft.class_4184 camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Double> cir) {
        if (WorldCameraRenderer.isCapturing) {
            cir.setReturnValue(90.0);
        }
    }

    @Inject(method = "getBasicProjectionMatrix", at = @At("RETURN"), cancellable = true)
    private void forceProjectionMatrix(double fov, CallbackInfoReturnable<Matrix4f> cir) {
        if (WorldCameraRenderer.isCapturing) {
            Matrix4f matrix = new Matrix4f();
            float aspectRatio = 854.0f / 480.0f;
            matrix.setPerspective((float) (fov * Math.PI / 180.0), aspectRatio, 0.05f, 1000.0f);
            cir.setReturnValue(matrix);
        }
    }
}
