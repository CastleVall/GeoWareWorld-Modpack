package me.elb.mediaplayermod.mixin.fog;

import me.elb.mediaplayermod.client.fog.FogUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4184;
import net.minecraft.class_758;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_758.class, priority = 1500)
@Environment(EnvType.CLIENT)
public class RendererMixin {
    @Inject(method = "applyFog", at = @At("RETURN"))
    private static void setFogFalloff(class_4184 camera, class_758.class_4596 fogType, float viewDistance, boolean thickFog, float tickDelta, CallbackInfo ci) {
        FogUtils.setFogFalloff(camera, fogType, viewDistance);
    }
}
