package me.elb.mediaplayermod.mixin.fog;

import me.elb.mediaplayermod.MediaPlayerMod;
import net.caffeinemc.mods.sodium.client.gl.shader.ShaderLoader;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.apache.commons.io.IOUtils;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

@Mixin(ShaderLoader.class)
public class SodiumShaderLoadMixin {

    @Inject(method = "getShaderSource(Lnet/minecraft/util/Identifier;)Ljava/lang/String;", at = @At(value = "HEAD"), cancellable = true)
    private static void loadCustomFogShader(class_2960 name, CallbackInfoReturnable<String> cir) {
        if (name.toString().equals("sodium:include/fog.glsl")) {
            MediaPlayerMod.LOGGER.info("Overwriting sodium fog shader");

            String path = "sodium-include/fog.glsl";
            class_310.method_1551().method_1478()
                    .method_14486(class_2960.method_60655("mediaplayer", path))
                    .ifPresent(resource -> {
                        try (InputStream in = resource.method_14482()) {
                            if (in == null) {
                                throw new RuntimeException("Shader not found: " + path);
                            }

                            cir.setReturnValue(IOUtils.toString(in, StandardCharsets.UTF_8));
                        } catch (IOException e) {
                            throw new RuntimeException("Failed to read shader source for " + path, e);
                        }
                    });
        }
    }
}
