package me.elb.mediaplayermod.mixin.display;

import me.elb.mediaplayermod.client.ClientHandler;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class InGameHudMixin {
    @Inject(method = "renderMiscOverlays", at = @At("HEAD"))
    private void renderMiscOverlays(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        ClientHandler.getMediaOverlay().onHudRender(context, tickCounter);
    }
}
