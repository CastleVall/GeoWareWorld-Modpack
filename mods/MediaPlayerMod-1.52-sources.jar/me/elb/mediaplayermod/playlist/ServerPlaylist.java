package me.elb.mediaplayermod.playlist;

import me.elb.mediaplayermod.model.media.Audio;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.util.*;

@Getter @Setter
@RequiredArgsConstructor
public class ServerPlaylist<P> {
    private final String id;
    private final LinkedList<Audio> audios = new LinkedList<>();
    private boolean broadcastEveryone;
    private final Set<P> players = new HashSet<>();
    private boolean paused;
    private boolean stopped;
    private long start;
    private boolean shuffle;
    private boolean loop;

    public void addAudio(Audio audio) {
        audios.add(audio);
    }

    public boolean removeAudio(int index) {
        if (index < 0 || index >= audios.size()) {
            return false;
        }
        return audios.remove(index) != null;
    }

    public boolean moveAudio(int from, int to) {
        if (from < 0 || from >= audios.size() || to < 0 || to >= audios.size() || from == to) {
            return false;
        }
        Audio audio = audios.remove(from);
        audios.add(to, audio);
        return true;
    }

    public boolean addPlayer(P target) {
        return players.add(target);
    }

    @SafeVarargs
    public final void addPlayers(P... players) {
        this.players.addAll(Arrays.asList(players));
    }

    public void removePlayer(P player) {
        players.remove(player);
    }
}
