package me.elb.mediaplayermod.api;

import me.elb.mediaplayermod.client.URLUtil;
import me.elb.mediaplayermod.utils.ImageUtils;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.watermedia.api.image.decoders.GifDecoder;

import javax.imageio.ImageIO;
import javax.imageio.stream.ImageInputStream;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

/**
 * Fuente de imagen para el inspeccionador ({@code /inspectimage} y {@link ImageInspectorApi}).
 * Solo cliente. Usa el mismo pipeline de carga que el resto del mod: {@link URLUtil} para
 * resolver rutas locales/urls/placeholders y deteccion de GIF animado.
 *
 * <p>Otros mods pueden inspeccionar imagenes empaquetadas en sus assets con
 * {@link #resource(class_2960)}, por ejemplo {@code Identifier.of("mimod", "textures/gui/nota.png")}
 * (que apunta a {@code assets/mimod/textures/gui/nota.png}).</p>
 */
public sealed interface InspectImageSource permits InspectImageSource.UrlSource, InspectImageSource.ResourceSource {

    /** Lado maximo de la textura; imagenes mas grandes se reescalan para no agotar VRAM. */
    int MAX_TEXTURE_SIZE = 4096;

    /**
     * Decodifica la imagen (se llama fuera del hilo de render). Devuelve un
     * {@link GifDecoder} si es un GIF animado o un {@link BufferedImage} en caso contrario.
     */
    Object decode() throws IOException;

    /** Nombre corto para mostrar como titulo (nombre de archivo, sin ruta). */
    String describe();

    /**
     * Imagen local o remota: nombre limpio de {@code config/mediaplayer} (ej. {@code carta}),
     * ruta relativa (ej. {@code images/carta.png}), ruta absoluta, {@code ~/...} o url http(s).
     */
    static InspectImageSource url(String url) {
        return new UrlSource(url);
    }

    /** Imagen empaquetada en los assets de un mod (o resource pack), via ResourceManager. */
    static InspectImageSource resource(class_2960 id) {
        return new ResourceSource(id);
    }

    record UrlSource(String url) implements InspectImageSource {
        @Override
        public Object decode() throws IOException {
            URL target = URLUtil.loadUrl(URLUtil.fixUrl(url));
            byte[] bytes;
            try (InputStream in = target.openStream()) {
                bytes = in.readAllBytes();
            }
            return decodeBytes(bytes);
        }

        @Override
        public String describe() {
            String clean = url;
            int query = clean.indexOf('?');
            if (query >= 0) clean = clean.substring(0, query);
            clean = clean.replace('\\', '/');
            int slash = clean.lastIndexOf('/');
            return slash >= 0 ? clean.substring(slash + 1) : clean;
        }
    }

    record ResourceSource(class_2960 id) implements InspectImageSource {
        @Override
        public Object decode() throws IOException {
            var resource = class_310.method_1551().method_1478().method_14486(id)
                    .orElseThrow(() -> new FileNotFoundException("Resource not found: " + id));
            byte[] bytes;
            try (InputStream in = resource.method_14482()) {
                bytes = in.readAllBytes();
            }
            return decodeBytes(bytes);
        }

        @Override
        public String describe() {
            String path = id.method_12832();
            int slash = path.lastIndexOf('/');
            return slash >= 0 ? path.substring(slash + 1) : path;
        }
    }

    private static Object decodeBytes(byte[] bytes) throws IOException {
        try (ImageInputStream stream = ImageIO.createImageInputStream(new ByteArrayInputStream(bytes))) {
            if (ImageUtils.isGifImage(stream)) {
                GifDecoder gifDecoder = new GifDecoder();
                gifDecoder.read(new ByteArrayInputStream(bytes));
                return gifDecoder;
            }
        }
        BufferedImage image = ImageIO.read(new ByteArrayInputStream(bytes));
        if (image == null) {
            throw new IOException("Unsupported image format");
        }
        int maxSide = Math.max(image.getWidth(), image.getHeight());
        if (maxSide > MAX_TEXTURE_SIZE) {
            image = ImageUtils.scaleImage(image, MAX_TEXTURE_SIZE / (1F * maxSide));
        }
        return image;
    }
}
