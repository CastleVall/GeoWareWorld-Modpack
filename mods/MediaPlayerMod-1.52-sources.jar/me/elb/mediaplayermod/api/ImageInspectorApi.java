package me.elb.mediaplayermod.api;

import me.elb.mediaplayermod.client.gui.screen.ImageInspectScreen;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.jetbrains.annotations.Nullable;

/**
 * API publica del inspeccionador de imagenes estilo Resident Evil para otros mods.
 * <b>Solo cliente</b>: llamar unicamente desde codigo de cliente (puede ser desde cualquier
 * hilo; la pantalla se abre en el hilo del cliente).
 *
 * <p>Ejemplos:</p>
 * <pre>{@code
 * // Imagen de los assets del propio mod (assets/mimod/textures/gui/nota.png):
 * ImageInspectorApi.inspect(Identifier.of("mimod", "textures/gui/nota.png"));
 *
 * // Con reverso y titulo personalizado:
 * ImageInspectorApi.inspect(
 *         InspectImageSource.resource(Identifier.of("mimod", "textures/gui/nota.png")),
 *         InspectImageSource.resource(Identifier.of("mimod", "textures/gui/nota_dorso.png")),
 *         Text.literal("Nota misteriosa"));
 *
 * // Archivo local de config/mediaplayer o url:
 * ImageInspectorApi.inspect("images/carta.png");
 * }</pre>
 *
 * <p>El jugador cierra la pantalla con ESC; soporta zoom (rueda), mover (arrastrar), rotar
 * (Q/E) y ver el reverso (clic derecho / F). Soporta PNG, JPG, BMP y GIF animado.</p>
 */
public final class ImageInspectorApi {

    private ImageInspectorApi() {
    }

    /** Abre el inspeccionador con una imagen local (config/mediaplayer, ruta absoluta) o url. */
    public static void inspect(String image) {
        inspect(image, null);
    }

    /** Igual que {@link #inspect(String)} con una segunda imagen como reverso. */
    public static void inspect(String image, @Nullable String backImage) {
        inspect(InspectImageSource.url(image),
                backImage == null || backImage.isBlank() ? null : InspectImageSource.url(backImage), null);
    }

    /** Abre el inspeccionador con una textura de los assets de un mod (o resource pack). */
    public static void inspect(class_2960 image) {
        inspect(image, null);
    }

    /** Igual que {@link #inspect(class_2960)} con una segunda textura como reverso. */
    public static void inspect(class_2960 image, @Nullable class_2960 backImage) {
        inspect(InspectImageSource.resource(image),
                backImage == null ? null : InspectImageSource.resource(backImage), null);
    }

    /**
     * Forma general: fuentes arbitrarias (url o resource, se pueden mezclar) y titulo opcional
     * que se muestra sobre la imagen (por defecto, el nombre del archivo).
     */
    public static void inspect(InspectImageSource front, @Nullable InspectImageSource back, @Nullable class_2561 title) {
        class_310 client = class_310.method_1551();
        // send() difiere al siguiente tick: si se llama desde un comando o desde otra pantalla,
        // evita que el cierre de esa pantalla (ChatScreen, menus...) pise la nuestra.
        client.method_18858(() -> client.method_1507(new ImageInspectScreen(front, back, title)));
    }

    /** true si el inspeccionador esta abierto ahora mismo. */
    public static boolean isInspecting() {
        return class_310.method_1551().field_1755 instanceof ImageInspectScreen;
    }

    /** Cierra el inspeccionador si esta abierto. */
    public static void close() {
        class_310 client = class_310.method_1551();
        client.method_18858(() -> {
            if (client.field_1755 instanceof ImageInspectScreen inspectScreen) {
                inspectScreen.method_25419();
            }
        });
    }
}
