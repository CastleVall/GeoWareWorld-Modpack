package me.elb.mediaplayermod.networking.packet;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import me.elb.mediaplayermod.model.option.ClientOptions;
import me.elb.mediaplayermod.model.option.ClientOption;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.lang.reflect.Method;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ServerSetOptionPacket implements Packet {
    private ClientOption option;

    @Override
    public void read(ByteArrayDataInput buf) {
        final int id = buf.readInt();
        ClientOptions type = ClientOptions.fromId(id);
        Class<? extends ClientOption> clazz = type.getClazz();
        try {
            Method method = clazz.getMethod("readPacket", ByteArrayDataInput.class);
            this.option = (ClientOption) method.invoke(null, buf);
        } catch (Exception e) {
            throw new IllegalStateException("Error reading option packet", e);
        }
    }

    @Override
    public void write(ByteArrayDataOutput buf) {
        buf.writeInt(this.option.getType().getId());
        this.option.writePacket(buf);
    }
}
