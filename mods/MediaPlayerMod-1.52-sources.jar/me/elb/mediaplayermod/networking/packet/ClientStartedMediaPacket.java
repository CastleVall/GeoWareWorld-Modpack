package me.elb.mediaplayermod.networking.packet;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import me.elb.mediaplayermod.model.media.MediaType;
import me.elb.mediaplayermod.model.media.Media;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Getter
@NoArgsConstructor
public class ClientStartedMediaPacket implements Packet {
    private UUID id;
    private MediaType type;
    private String parameters;
    /** Id de entrega del {@link ServerPlayMediaPacket} que origino este media (0 = sin seguimiento). */
    private long deliveryId;

    public ClientStartedMediaPacket(UUID id, Media media) {
        this(id, media, 0L);
    }

    public ClientStartedMediaPacket(UUID id, Media media, long deliveryId) {
        this.id = id;
        this.type = media.getType();
        this.parameters = media.toString();
        this.deliveryId = deliveryId;
    }

    @Override
    public void write(final ByteArrayDataOutput buf) {
        buf.writeUTF(this.id.toString());
        buf.writeUTF(this.type.name());
        buf.writeUTF(this.parameters);
        buf.writeLong(this.deliveryId);
    }

    @Override
    public void read(final ByteArrayDataInput buf) {
        this.id = UUID.fromString(buf.readUTF());
        this.type = MediaType.valueOf(buf.readUTF());
        this.parameters = buf.readUTF();
        this.deliveryId = buf.readLong();
    }
}
