package me.elb.mediaplayermod.networking.packet;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import me.elb.mediaplayermod.model.media.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.lang.reflect.Method;

@Getter
@NoArgsConstructor
public class ServerPlayMediaPacket implements Packet {
    private Media media;
    private boolean needConfirmation;
    /**
     * Id de entrega asignado por el servidor para confirmar la recepcion (0 = sin seguimiento).
     * El cliente lo devuelve en {@link ClientStartedMediaPacket}/{@link ClientAckMediaPacket};
     * si no llega confirmacion el servidor reenvia el media a ese jugador.
     */
    @Setter
    private long deliveryId;

    public ServerPlayMediaPacket(Media media) {
        this(media, false);
    }

    public ServerPlayMediaPacket(Media media, boolean needConfirmation) {
        this.media = media;
        this.needConfirmation = needConfirmation;
    }

    @Override
    public void write(final ByteArrayDataOutput buf) {
        buf.writeInt(this.media.getType().getId());
        this.media.writePacket(buf);
        buf.writeBoolean(this.needConfirmation);
        buf.writeLong(this.deliveryId);
    }

    @Override
    public void read(final ByteArrayDataInput buf) {
        final int id = buf.readInt();
        MediaType type = MediaType.fromId(id);
        Class<? extends Media> clazz = type.getClazz();
        try {
            Method method = clazz.getMethod("readPacket", ByteArrayDataInput.class);
            this.media = (Media) method.invoke(null, buf);
        } catch (Exception e) {
            throw new IllegalStateException("Error reading media packet", e);
        }
        this.needConfirmation = buf.readBoolean();
        this.deliveryId = buf.readLong();
    }
}
