package me.elb.mediaplayermod.networking.packet;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public interface Packet {
    void read(final ByteArrayDataInput p0);

    void write(final ByteArrayDataOutput p0);
}
