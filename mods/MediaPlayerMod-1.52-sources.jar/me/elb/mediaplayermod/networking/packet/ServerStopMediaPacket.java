package me.elb.mediaplayermod.networking.packet;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import me.elb.mediaplayermod.model.media.MediaType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ServerStopMediaPacket implements Packet {
    private MediaType mediaType;

    @Override
    public void read(ByteArrayDataInput buf) {
        this.mediaType = MediaType.fromId(buf.readInt());
    }

    @Override
    public void write(ByteArrayDataOutput buf) {
        buf.writeInt(this.mediaType.ordinal());
    }
}
