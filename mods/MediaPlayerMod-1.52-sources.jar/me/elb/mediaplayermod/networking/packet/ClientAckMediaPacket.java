package me.elb.mediaplayermod.networking.packet;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * Confirma la recepcion de un {@link ServerPlayMediaPacket} reenviado que el cliente ya habia
 * reproducido (deduplicado por deliveryId). Solo detiene los reintentos del servidor; no toca
 * el estado de medias en reproduccion.
 */
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ClientAckMediaPacket implements Packet {
    private long deliveryId;

    @Override
    public void write(final ByteArrayDataOutput buf) {
        buf.writeLong(this.deliveryId);
    }

    @Override
    public void read(final ByteArrayDataInput buf) {
        this.deliveryId = buf.readLong();
    }
}
