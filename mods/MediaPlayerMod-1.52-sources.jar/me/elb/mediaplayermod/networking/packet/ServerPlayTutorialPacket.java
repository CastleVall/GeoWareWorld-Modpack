package me.elb.mediaplayermod.networking.packet;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * El servidor pide a los clientes que abran el tutorial de nombre {@code name}. El cliente carga el
 * archivo {@code config/mediaplayer/tutorial/<name>.yml} de su propio juego.
 */
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ServerPlayTutorialPacket implements Packet {
    private String name;

    @Override
    public void read(ByteArrayDataInput buf) {
        this.name = buf.readUTF();
    }

    @Override
    public void write(ByteArrayDataOutput buf) {
        buf.writeUTF(this.name == null ? "" : this.name);
    }
}
