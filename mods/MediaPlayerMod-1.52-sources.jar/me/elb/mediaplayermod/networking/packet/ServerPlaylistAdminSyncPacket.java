package me.elb.mediaplayermod.networking.packet;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import me.elb.mediaplayermod.playlist.ServerPlaylist;
import net.minecraft.class_3222;
import java.util.ArrayList;
import java.util.List;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ServerPlaylistAdminSyncPacket implements Packet {
    private boolean allowed;
    private List<Entry> entries = new ArrayList<>();

    public static ServerPlaylistAdminSyncPacket denied() {
        return new ServerPlaylistAdminSyncPacket(false, new ArrayList<>());
    }

    public static ServerPlaylistAdminSyncPacket fromPlaylists(List<ServerPlaylist<class_3222>> playlists) {
        List<Entry> entries = new ArrayList<>();
        for (ServerPlaylist<class_3222> playlist : playlists) {
            List<Track> tracks = playlist.getAudios().stream()
                    .map(audio -> new Track(
                            audio.url() == null ? "" : audio.url(),
                            audio.name() == null ? "" : audio.name(),
                            audio.lyricsUrl() == null ? "" : audio.lyricsUrl()))
                    .toList();
            List<String> players = playlist.getPlayers().stream()
                    .map(player -> player.getName().getString())
                    .sorted(String::compareToIgnoreCase)
                    .toList();
            entries.add(new Entry(
                    playlist.getId(),
                    tracks,
                    players,
                    playlist.isBroadcastEveryone(),
                    playlist.isPaused(),
                    playlist.isLoop(),
                    playlist.isShuffle()
            ));
        }
        entries.sort((left, right) -> left.getId().compareToIgnoreCase(right.getId()));
        return new ServerPlaylistAdminSyncPacket(true, entries);
    }

    @Override
    public void read(ByteArrayDataInput buf) {
        this.allowed = buf.readBoolean();
        int size = buf.readInt();
        this.entries = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            Entry entry = new Entry();
            entry.read(buf);
            this.entries.add(entry);
        }
    }

    @Override
    public void write(ByteArrayDataOutput buf) {
        buf.writeBoolean(this.allowed);
        buf.writeInt(this.entries.size());
        for (Entry entry : this.entries) {
            entry.write(buf);
        }
    }

    @Getter
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Entry {
        private String id = "";
        private List<Track> tracks = new ArrayList<>();
        private List<String> players = new ArrayList<>();
        private boolean broadcastEveryone;
        private boolean paused;
        private boolean loop;
        private boolean shuffle;

        private void read(ByteArrayDataInput buf) {
            this.id = buf.readUTF();
            int trackCount = buf.readInt();
            this.tracks = new ArrayList<>(trackCount);
            for (int i = 0; i < trackCount; i++) {
                this.tracks.add(new Track(buf.readUTF(), buf.readUTF(), buf.readUTF()));
            }
            this.players = readStringList(buf);
            this.broadcastEveryone = buf.readBoolean();
            this.paused = buf.readBoolean();
            this.loop = buf.readBoolean();
            this.shuffle = buf.readBoolean();
        }

        private void write(ByteArrayDataOutput buf) {
            buf.writeUTF(this.id);
            buf.writeInt(this.tracks.size());
            for (Track track : this.tracks) {
                buf.writeUTF(track.getUrl());
                buf.writeUTF(track.getName() != null ? track.getName() : "");
                buf.writeUTF(track.getLyricsUrl() != null ? track.getLyricsUrl() : "");
            }
            writeStringList(buf, this.players);
            buf.writeBoolean(this.broadcastEveryone);
            buf.writeBoolean(this.paused);
            buf.writeBoolean(this.loop);
            buf.writeBoolean(this.shuffle);
        }

        private static List<String> readStringList(ByteArrayDataInput buf) {
            int size = buf.readInt();
            List<String> values = new ArrayList<>(size);
            for (int i = 0; i < size; i++) {
                values.add(buf.readUTF());
            }
            return values;
        }

        private static void writeStringList(ByteArrayDataOutput buf, List<String> values) {
            buf.writeInt(values.size());
            for (String value : values) {
                buf.writeUTF(value);
            }
        }
    }

    @Getter
    @AllArgsConstructor
    public static class Track {
        private final String url;
        private final String name;
        private final String lyricsUrl;

        public Track(String url, String name) {
            this(url, name, "");
        }
    }
}
