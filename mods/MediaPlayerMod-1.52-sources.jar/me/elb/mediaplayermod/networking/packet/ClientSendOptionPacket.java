package me.elb.mediaplayermod.networking.packet;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ClientSendOptionPacket implements Packet {
    private String sender;
    private String option;
    private String value;

    @Override
    public void read(ByteArrayDataInput buf) {
        this.sender = buf.readUTF();
        this.option = buf.readUTF();
        this.value = buf.readUTF();
    }

    @Override
    public void write(ByteArrayDataOutput buf) {
        buf.writeUTF(this.sender);
        buf.writeUTF(this.option);
        buf.writeUTF(this.value);
    }
}
