package me.elb.mediaplayermod.networking.packet;

public class ServerReloadChunksPacket extends EmptyPacket {

}
