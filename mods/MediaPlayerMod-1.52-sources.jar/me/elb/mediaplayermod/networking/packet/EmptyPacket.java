package me.elb.mediaplayermod.networking.packet;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public abstract class EmptyPacket implements Packet {
    @Override
    public void write(final ByteArrayDataOutput buf) {
    }

    @Override
    public void read(final ByteArrayDataInput buf) {
    }
}
