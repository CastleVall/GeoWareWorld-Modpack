package me.elb.mediaplayermod.networking.packet;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ClientFinishedMediaPacket implements Packet {
    private UUID id;

    @Override
    public void write(final ByteArrayDataOutput buf) {
        buf.writeUTF(this.id.toString());
    }

    @Override
    public void read(final ByteArrayDataInput buf) {
        this.id = UUID.fromString(buf.readUTF());
    }
}
