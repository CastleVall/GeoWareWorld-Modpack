package me.elb.mediaplayermod.networking.packet;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import lombok.NoArgsConstructor;

/** El servidor pide a los clientes que cierren el tutorial activo (con su fundido de salida). */
@NoArgsConstructor
public class ServerStopTutorialPacket implements Packet {
    @Override
    public void read(ByteArrayDataInput buf) {
    }

    @Override
    public void write(ByteArrayDataOutput buf) {
    }
}
