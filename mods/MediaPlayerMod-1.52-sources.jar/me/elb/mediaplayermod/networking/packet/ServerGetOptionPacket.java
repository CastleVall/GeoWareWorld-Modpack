package me.elb.mediaplayermod.networking.packet;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import me.elb.mediaplayermod.model.option.ClientOptions;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ServerGetOptionPacket implements Packet {
    private String sender;
    private ClientOptions option;

    @Override
    public void read(ByteArrayDataInput buf) {
        this.sender = buf.readUTF();
        this.option = ClientOptions.valueOf(buf.readUTF().toUpperCase());
    }

    @Override
    public void write(ByteArrayDataOutput buf) {
        buf.writeUTF(sender);
        buf.writeUTF(option.name());
    }
}
