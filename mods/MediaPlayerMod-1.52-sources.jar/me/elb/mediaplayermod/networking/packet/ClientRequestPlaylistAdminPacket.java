package me.elb.mediaplayermod.networking.packet;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ClientRequestPlaylistAdminPacket implements Packet {
    private boolean openScreen;

    @Override
    public void read(ByteArrayDataInput buf) {
        this.openScreen = buf.readBoolean();
    }

    @Override
    public void write(ByteArrayDataOutput buf) {
        buf.writeBoolean(this.openScreen);
    }
}
