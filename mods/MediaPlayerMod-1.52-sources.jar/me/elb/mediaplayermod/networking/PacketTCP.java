package me.elb.mediaplayermod.networking;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import me.elb.mediaplayermod.networking.packet.*;
import lombok.experimental.UtilityClass;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

@UtilityClass
public class PacketTCP {
    private static final Map<Integer, Class<? extends Packet>> packetRegistry;

    private static int getPacketType(final Packet packet) {
        for (final Map.Entry<Integer, Class<? extends Packet>> entry : PacketTCP.packetRegistry.entrySet()) {
            if (packet.getClass().equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return -1;
    }

    public static byte[] write(final Packet packet){
        final ByteArrayDataOutput out = ByteStreams.newDataOutput();
        out.writeByte(getPacketType(packet));
        packet.write(out);
        return out.toByteArray();
    }

    public static Packet read(final ByteArrayDataInput buf) throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
        final int packetType = buf.readByte();
        final Class<? extends Packet> packetClass = PacketTCP.packetRegistry.get(packetType);
        if (packetClass == null) {
            throw new InstantiationException("Could not find packet with ID " + packetType);
        }
        final Packet packet = packetClass.getDeclaredConstructor().newInstance();
        packet.read(buf);
        return packet;
    }

    static {
        packetRegistry = new HashMap<>();
        packetRegistry.put(0, ServerPlayMediaPacket.class);
        packetRegistry.put(1, ServerStopMediaPacket.class);
        packetRegistry.put(2, ClientStartedMediaPacket.class);
        packetRegistry.put(3, ClientFinishedMediaPacket.class);
        packetRegistry.put(4, ClientAckMediaPacket.class);
        packetRegistry.put(20, ServerGetOptionPacket.class);
        packetRegistry.put(21, ClientSendOptionPacket.class);
        packetRegistry.put(22, ServerSetOptionPacket.class);
        packetRegistry.put(35, ServerReloadChunksPacket.class);
        packetRegistry.put(36, ClientRequestPlaylistAdminPacket.class);
        packetRegistry.put(37, ServerPlaylistAdminSyncPacket.class);
        packetRegistry.put(40, ServerPlayTutorialPacket.class);
        packetRegistry.put(41, ServerStopTutorialPacket.class);
    }
}
