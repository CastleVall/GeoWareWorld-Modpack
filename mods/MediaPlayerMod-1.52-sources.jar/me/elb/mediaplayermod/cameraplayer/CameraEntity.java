package me.elb.mediaplayermod.cameraplayer;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2602;
import net.minecraft.class_2604;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;

public class CameraEntity extends class_1297 {
    private static final class_2940<String> CAMERA_NAME = class_2945.method_12791(CameraEntity.class,
            class_2943.field_13326);

    public CameraEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        builder.method_56912(CAMERA_NAME, "Unnamed Camera");
    }

    public void setCameraName(String name) {
        this.field_6011.method_12778(CAMERA_NAME, name);
    }

    public String getCameraName() {
        return this.field_6011.method_12789(CAMERA_NAME);
    }

    @Override
    protected void method_5749(class_2487 nbt) {
        if (nbt.method_10545("CameraName")) {
            setCameraName(nbt.method_10558("CameraName"));
        }
    }

    @Override
    protected void method_5652(class_2487 nbt) {
        nbt.method_10582("CameraName", getCameraName());
    }

    @Override
    public net.minecraft.class_2596<class_2602> method_18002(net.minecraft.class_3231 entityTrackerEntry) {
        return new class_2604(this, entityTrackerEntry);
    }

    @Override
    public boolean method_5863() {
        return true;
    }

    @Override
    public void method_5773() {
        super.method_5773();
        this.field_6014 = this.method_23317();
        this.field_6036 = this.method_23318();
        this.field_5969 = this.method_23321();
        this.field_5982 = this.method_36454();
        this.field_6004 = this.method_36455();
        this.field_6038 = this.method_23317();
        this.field_5971 = this.method_23318();
        this.field_5989 = this.method_23321();
        if (!this.method_5740()) {
            this.method_5875(true);
        }
    }
}
