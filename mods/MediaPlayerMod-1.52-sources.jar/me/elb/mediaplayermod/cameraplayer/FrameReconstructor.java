package me.elb.mediaplayermod.cameraplayer;

class FrameReconstructor {
    public final long frameId;
    private final byte[][] chunks;
    private int count = 0;

    public FrameReconstructor(long frameId, int total) {
        this.frameId = frameId;
        this.chunks = new byte[total][];
    }

    public void addChunk(int i, byte[] d) {
        if (i >= 0 && i < chunks.length && chunks[i] == null) {
            chunks[i] = d;
            count++;
        }
    }

    public boolean isComplete() {
        return count == chunks.length;
    }

    public byte[] getFullFrame() {
        int size = 0;
        for (byte[] c : chunks) if (c != null) size += c.length;
        byte[] f = new byte[size];
        int cur = 0;
        for (byte[] c : chunks) {
            if (c != null) {
                System.arraycopy(c, 0, f, cur, c.length);
                cur += c.length;
            }
        }
        return f;
    }
}
