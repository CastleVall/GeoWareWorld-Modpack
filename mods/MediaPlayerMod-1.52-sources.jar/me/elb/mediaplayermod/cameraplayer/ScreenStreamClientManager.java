package me.elb.mediaplayermod.cameraplayer;

import me.elb.mediaplayermod.cameraplayer.client.render.OverlayManager;
import me.elb.mediaplayermod.cameraplayer.client.render.WorldCameraRenderer;
import me.elb.mediaplayermod.cameraplayer.client.video.VideoManager;
import org.java_websocket.server.WebSocketServer;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.WebSocket;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import me.elb.mediaplayermod.cameraplayer.ScreenNetworkPayloads.*;

public class ScreenStreamClientManager {
    public static class_1043 localStreamTexture;
    public static final class_2960 STREAM_TEXTURE_ID = class_2960.method_60655("mediaplayermod", "stream_texture");
    private static StreamWebSocketServer wsServer;
    private static final ExecutorService executor = Executors.newFixedThreadPool(2);
    private static boolean isProcessing = false;

    private static final int TARGET_WIDTH = 854;
    private static final int TARGET_HEIGHT = 480;
    private static long lastCaptureTime = 0;
    private static final long CAPTURE_INTERVAL = 16;
    private static long lastServerSendTime = 0;
    private static final long SERVER_SEND_INTERVAL = 33;
    private static final float NETWORK_JPEG_QUALITY = 0.6f;
    private static long frameCounter = 0;
    private static final Map<UUID, FrameReconstructor> remoteReconstructors = new HashMap<>();
    private static final Map<UUID, Long> lastRemoteFrameId = new HashMap<>();
    public static final Map<UUID, class_1043> remoteTextures = new HashMap<>();
    public static boolean isStreamingToServer = false;
    public static String activeCameraName = null;

    public static boolean rgbTrailEnabled = false;
    public static int trailLayers = 5;
    public static int trailBpm = 25;
    private static final ArrayList<class_1011> frameBuffer = new ArrayList<>();
    private static final int MAX_BUFFER_SIZE = 30;
    public static boolean shouldOpenMenu = false;
    public static boolean visualizerEnabled = false;
    private static final java.util.List<VisualizerWave> activeWaves = java.util.Collections.synchronizedList(new java.util.ArrayList<>());
    private static long lastWaveTime = 0;
    private static float avgIntensity = 0.1f;

    private static class VisualizerWave {
        float radius;
        float maxRadius;
        float speed;
        boolean isPeak;

        public VisualizerWave(float maxRadius, float speed, boolean isPeak) {
            this.radius = 0;
            this.maxRadius = maxRadius;
            this.speed = speed;
            this.isPeak = isPeak;
        }

        public boolean update() {
            radius += speed;
            return radius < maxRadius;
        }
    }

    public static void startWebSocket() {
        try {
            wsServer = new StreamWebSocketServer(new InetSocketAddress(8887));
            wsServer.setReuseAddr(true);
            wsServer.start();
        } catch (Exception e) {
            System.err.println("[MediaPlayer] WebSocket port 8887 unavailable. Web streaming disabled.");
        }
    }

    public static void handleRemoteFrame(UUID streamerUuid, long frameId, int index, int total, byte[] chunk) {
        Long lastId = lastRemoteFrameId.get(streamerUuid);
        if (lastId != null && frameId < lastId) return;
        FrameReconstructor recon = remoteReconstructors.get(streamerUuid);
        if (recon == null || recon.frameId < frameId) {
            recon = new FrameReconstructor(frameId, total);
            remoteReconstructors.put(streamerUuid, recon);
        } else if (recon.frameId > frameId) {
            return;
        }
        recon.addChunk(index, chunk);
        if (recon.isComplete()) {
            byte[] fullFrame = recon.getFullFrame();
            remoteReconstructors.remove(streamerUuid);
            lastRemoteFrameId.put(streamerUuid, frameId);
            class_1011 img = decodeFrameBytes(fullFrame);
            if (img != null) updateRemoteTexture(streamerUuid, img);
        }
    }

    private static class_1011 decodeFrameBytes(byte[] data) {
        try {
            class_1011 img = class_1011.method_4309(new java.io.ByteArrayInputStream(data));
            if (img != null) return img;
        } catch (Exception ignored) {}
        try {
            BufferedImage bi = ImageIO.read(new java.io.ByteArrayInputStream(data));
            if (bi == null) return null;
            int w = bi.getWidth(), h = bi.getHeight();
            int[] pixels = new int[w * h];
            bi.getRGB(0, 0, w, h, pixels, 0, w);
            class_1011 img = new class_1011(w, h, false);
            for (int y = 0; y < h; y++) {
                int row = y * w;
                for (int x = 0; x < w; x++) {
                    int argb = pixels[row + x];
                    int r = (argb >> 16) & 0xFF;
                    int g = (argb >> 8) & 0xFF;
                    int b = argb & 0xFF;
                    img.method_4305(x, y, 0xFF000000 | (b << 16) | (g << 8) | r);
                }
            }
            return img;
        } catch (Exception e) {
            System.err.println("[MediaPlayer] Failed to decode stream frame: " + e.getMessage());
            return null;
        }
    }

    public static void captureFrameInternal() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastCaptureTime < CAPTURE_INTERVAL || isProcessing) return;
        class_310 client = class_310.method_1551();
        if (client.method_1522() == null) return;
        isProcessing = true;
        lastCaptureTime = currentTime;
        try {
            class_1011 nativeImage = null;
            if (VideoManager.isActive) {
                nativeImage = VideoManager.getFrame();
            }
            if (nativeImage == null) {
                if (activeCameraName != null && client.field_1687 != null) {
                    CameraEntity targetCam = null;
                    for (net.minecraft.class_1297 e : client.field_1687.method_18112()) {
                        if (e instanceof CameraEntity cam && cam.getCameraName().equalsIgnoreCase(activeCameraName)) {
                            targetCam = cam;
                            break;
                        }
                    }
                    if (targetCam != null) {
                        nativeImage = WorldCameraRenderer.captureCamera(targetCam, client.method_60646().method_60637(true));
                    }
                }
                if (nativeImage == null) {
                    nativeImage = new class_1011(client.method_1522().field_1482, client.method_1522().field_1481, false);
                    client.method_1522().method_35610();
                    nativeImage.method_4327(0, false);
                    client.method_1522().method_1242();
                }
            }
            final class_1011 imageToProcess = nativeImage;
            executor.execute(() -> {
                try {
                    if (wsServer != null) broadcastToWeb(imageToProcess);
                    class_1011 processed = prepareGameFrame(imageToProcess);
                    OverlayManager.applyOverlayToImage(processed);
                    if (isStreamingToServer) {
                        long sendNow = System.currentTimeMillis();
                        if (sendNow - lastServerSendTime >= SERVER_SEND_INTERVAL) {
                            lastServerSendTime = sendNow;
                            try { sendChunkedFrameToServer(compressToJpeg(processed, NETWORK_JPEG_QUALITY)); } catch (Exception ignored) {}
                        }
                    }
                    client.execute(() -> {
                        try {
                            updateLocalTexture(processed);
                        } finally {
                            processed.close();
                            imageToProcess.close();
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                    imageToProcess.close();
                } finally {
                    isProcessing = false;
                }
            });
        } catch (Exception e) {
            isProcessing = false;
        }
    }

    private static byte[] compressToJpeg(class_1011 img, float quality) throws Exception {
        int w = img.method_4307(), h = img.method_4323();
        BufferedImage bufferedImage = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        int[] pixels = new int[w * h];
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                int c = img.method_4315(x, y);
                int r = c & 0xFF, g = (c >> 8) & 0xFF, b = (c >> 16) & 0xFF;
                pixels[row + x] = (r << 16) | (g << 8) | b;
            }
        }
        bufferedImage.setRGB(0, 0, w, h, pixels, 0, w);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        java.util.Iterator<javax.imageio.ImageWriter> writers = ImageIO.getImageWritersByFormatName("jpeg");
        if (!writers.hasNext()) {
            ImageIO.write(bufferedImage, "jpg", baos);
            return baos.toByteArray();
        }
        javax.imageio.ImageWriter writer = writers.next();
        javax.imageio.ImageWriteParam param = writer.getDefaultWriteParam();
        param.setCompressionMode(javax.imageio.ImageWriteParam.MODE_EXPLICIT);
        param.setCompressionQuality(Math.max(0.1f, Math.min(1.0f, quality)));
        try (javax.imageio.stream.ImageOutputStream ios = ImageIO.createImageOutputStream(baos)) {
            writer.setOutput(ios);
            writer.write(null, new javax.imageio.IIOImage(bufferedImage, null, null), param);
        } finally {
            writer.dispose();
        }
        return baos.toByteArray();
    }

    private static void updateLocalTexture(class_1011 processed) {
        if (localStreamTexture == null || localStreamTexture.method_4525().method_4307() != processed.method_4307() || localStreamTexture.method_4525().method_4323() != processed.method_4323()) {
            if (localStreamTexture != null) localStreamTexture.close();
            localStreamTexture = new class_1043(processed.method_4307(), processed.method_4323(), false);
            class_310.method_1551().method_1531().method_4616(STREAM_TEXTURE_ID, localStreamTexture);
            if (class_310.method_1551().field_1724 != null)
                remoteTextures.put(class_310.method_1551().field_1724.method_5667(), localStreamTexture);
        }
        localStreamTexture.method_4525().method_4317(processed);
        localStreamTexture.method_4524();
    }

    private static void updateRemoteTexture(UUID uuid, class_1011 img) {
        class_1043 tex = remoteTextures.get(uuid);
        if (tex == null || tex.method_4525().method_4307() != img.method_4307() || tex.method_4525().method_4323() != img.method_4323()) {
            if (tex != null) tex.close();
            tex = new class_1043(img.method_4307(), img.method_4323(), false);
            class_310.method_1551().method_1531().method_4616(class_2960.method_60655("mediaplayermod", "stream_" + uuid.toString()), tex);
            remoteTextures.put(uuid, tex);
        }
        tex.method_4525().method_4317(img);
        tex.method_4524();
        img.close();
    }

    private static class_1011 prepareGameFrame(class_1011 src) {
        int srcW = src.method_4307(), srcH = src.method_4323();
        int destW = Math.min(srcW, TARGET_WIDTH), destH = Math.min(srcH, TARGET_HEIGHT);
        class_1011 dest = new class_1011(destW, destH, false);
        float stepX = (float) srcW / destW, stepY = (float) srcH / destH;
        if (rgbTrailEnabled) {
            class_1011 currentResized = new class_1011(destW, destH, false);
            for (int y = 0; y < destH; y++)
                for (int x = 0; x < destW; x++)
                    currentResized.method_4305(x, y, src.method_4315((int) (x * stepX), srcH - 1 - (int) (y * stepY)));
            synchronized (frameBuffer) {
                frameBuffer.add(0, currentResized);
                if (frameBuffer.size() > MAX_BUFFER_SIZE) frameBuffer.remove(frameBuffer.size() - 1).close();
            }
        } else if (!frameBuffer.isEmpty()) {
            synchronized (frameBuffer) {
                for (class_1011 img : frameBuffer) img.close();
                frameBuffer.clear();
            }
        }
        double pulse = Math.abs(Math.sin(System.currentTimeMillis() * Math.PI * (trailBpm / 60000.0)));
        for (int y = 0; y < destH; y++) {
            for (int x = 0; x < destW; x++) {
                int color;
                if (rgbTrailEnabled && !frameBuffer.isEmpty()) {
                    synchronized (frameBuffer) {
                        int baseC = src.method_4315((int) (x * stepX), srcH - 1 - (int) (y * stepY));
                        int r = baseC & 0xFF, g = (baseC >> 8) & 0xFF, b = (baseC >> 16) & 0xFF;
                        int layers = Math.min(trailLayers, frameBuffer.size());
                        for (int i = 0; i < layers; i++) {
                            int trailC = frameBuffer.get(Math.min(i * 3, frameBuffer.size() - 1)).method_4315(x, y);
                            double intensity = (1.0 - (double) i / layers) * pulse;
                            r = Math.min(255, (int) (r + (trailC & 0xFF) * intensity));
                            g = Math.min(255, (int) (g + ((trailC >> 8) & 0xFF) * intensity));
                            b = Math.min(255, (int) (b + ((trailC >> 16) & 0xFF) * intensity));
                        }
                        color = 0xFF000000 | (b << 16) | (g << 8) | r;
                    }
                } else {
                    color = 0xFF000000 | src.method_4315((int) (x * stepX), srcH - 1 - (int) (y * stepY));
                }
                dest.method_4305(x, y, color);
            }
        }
        if (visualizerEnabled) applyVisualizer(dest);
        return dest;
    }

    private static void applyVisualizer(class_1011 img) {
        int centerX = img.method_4307() / 2;
        int centerY = img.method_4323() / 2;
        float intensity = VideoManager.audioLevel;
        long now = System.currentTimeMillis();
        float hue = (now % 3000) / 3000.0f;
        avgIntensity = avgIntensity * 0.98f + intensity * 0.02f;
        float factor = 0.3f / Math.max(0.01f, avgIntensity);
        float boostedIntensity = Math.min(1.2f, intensity * factor);
        if (boostedIntensity > 0.8 && now - lastWaveTime > 120) {
            activeWaves.add(new VisualizerWave(Math.min(img.method_4307(), img.method_4323()) * 1.3f, 10.0f + boostedIntensity * 12.0f, true));
            activeWaves.add(new VisualizerWave(Math.min(img.method_4307(), img.method_4323()) * 1.0f, 7.0f + boostedIntensity * 8.0f, false));
            lastWaveTime = now;
        } else if (boostedIntensity > 0.25 && now - lastWaveTime > 200) {
            activeWaves.add(new VisualizerWave(Math.min(img.method_4307(), img.method_4323()) * 0.8f, 4.0f + boostedIntensity * 6.0f, false));
            lastWaveTime = now;
        }
        if (boostedIntensity > 0.05 && now - lastWaveTime > 500) {
            activeWaves.add(new VisualizerWave(Math.min(img.method_4307(), img.method_4323()) * 0.5f, 2.0f, false));
        }
        synchronized (activeWaves) {
            java.util.Iterator<VisualizerWave> it = activeWaves.iterator();
            while (it.hasNext()) {
                VisualizerWave wave = it.next();
                if (!wave.update()) { it.remove(); continue; }
                float alpha = 1.0f - (wave.radius / wave.maxRadius);
                float thickness = wave.isPeak ? 4.0f : 2.0f;
                int ghostCount = wave.isPeak ? 8 : 4;
                float ghostSpacing = wave.speed * 0.6f;
                for (int g = 0; g < ghostCount; g++) {
                    float currentR = wave.radius - (g * ghostSpacing);
                    if (currentR < 0) break;
                    float ghostAlpha = alpha * (1.0f - (float) g / ghostCount) * boostedIntensity;
                    if (ghostAlpha <= 0) continue;
                    float gHue = (hue + g * 0.05f) % 1.0f;
                    int gRgb = java.awt.Color.HSBtoRGB(gHue, 0.8f, 1.0f);
                    int wr = (gRgb >> 16) & 0xFF, wg = (gRgb >> 8) & 0xFF, wb = gRgb & 0xFF;
                    for (float rOff = 0; rOff < thickness; rOff += 0.5f) {
                        float drawR = currentR + rOff;
                        double angleStep = wave.isPeak ? 1.0 : 2.5;
                        for (double angle = 0; angle < 360; angle += angleStep) {
                            int px = (int) (centerX + drawR * Math.cos(Math.toRadians(angle)));
                            int py = (int) (centerY + drawR * Math.sin(Math.toRadians(angle)));
                            if (px >= 0 && px < img.method_4307() && py >= 0 && py < img.method_4323()) {
                                int currentC = img.method_4315(px, py);
                                int r = Math.min(255, ((currentC >> 0) & 0xFF) + (int) (wr * ghostAlpha));
                                int gC = Math.min(255, ((currentC >> 8) & 0xFF) + (int) (wg * ghostAlpha));
                                int b = Math.min(255, ((currentC >> 16) & 0xFF) + (int) (wb * ghostAlpha));
                                img.method_4305(px, py, 0xFF000000 | (b << 16) | (gC << 8) | r);
                            }
                        }
                    }
                }
            }
        }
    }

    private static void broadcastToWeb(class_1011 nativeImage) {
        if (wsServer == null || wsServer.getConnections().isEmpty()) return;
        try {
            int w = 640, h = 360;
            BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
            float stepX = (float) nativeImage.method_4307() / w, stepY = (float) nativeImage.method_4323() / h;
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++) {
                    int c = nativeImage.method_4315((int) (x * stepX), (int) (nativeImage.method_4323() - 1 - y * stepY));
                    img.setRGB(x, y, ((c & 0xFF) << 16) | (((c >> 8) & 0xFF) << 8) | ((c >> 16) & 0xFF));
                }
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(img, "jpg", baos);
            byte[] bytes = baos.toByteArray();
            for (WebSocket conn : wsServer.getConnections()) conn.send(bytes);
        } catch (Exception ignored) {}
    }

    private static void sendChunkedFrameToServer(byte[] data) {
        long id = frameCounter++;
        int max = 30000, total = (int) Math.ceil((double) data.length / max);
        for (int i = 0; i < total; i++) {
            int start = i * max, end = Math.min(data.length, start + max);
            ClientPlayNetworking.send(new FrameC2SPayload(id, i, total, java.util.Arrays.copyOfRange(data, start, end)));
        }
    }

    private static class StreamWebSocketServer extends WebSocketServer {
        public StreamWebSocketServer(InetSocketAddress address) { super(address); }
        @Override public void onOpen(WebSocket conn, ClientHandshake h) {}
        @Override public void onClose(WebSocket conn, int c, String r, boolean rem) {}
        @Override public void onMessage(WebSocket conn, String m) {}
        @Override public void onError(WebSocket conn, Exception ex) {}
        @Override public void onStart() {}
    }
}
