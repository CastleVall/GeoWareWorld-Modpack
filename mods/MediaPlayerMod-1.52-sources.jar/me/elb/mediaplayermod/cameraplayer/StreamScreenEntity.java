package me.elb.mediaplayermod.cameraplayer;

import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2602;
import net.minecraft.class_2604;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;

public class StreamScreenEntity extends class_1297 {
    private static final class_2940<Float> WIDTH = class_2945.method_12791(StreamScreenEntity.class,
            class_2943.field_13320);
    private static final class_2940<Float> HEIGHT = class_2945.method_12791(StreamScreenEntity.class,
            class_2943.field_13320);
    private static final class_2940<String> STREAMER_UUID = class_2945.method_12791(StreamScreenEntity.class,
            class_2943.field_13326);
    private static final class_2940<String> SCREEN_NAME = class_2945.method_12791(StreamScreenEntity.class,
            class_2943.field_13326);

    public StreamScreenEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        builder.method_56912(WIDTH, 1.6f);
        builder.method_56912(HEIGHT, 0.9f);
        builder.method_56912(STREAMER_UUID, "");
        builder.method_56912(SCREEN_NAME, "");
    }

    @Override
    protected void method_5749(class_2487 nbt) {
        if (nbt.method_10545("ScreenWidth"))
            this.setScreenWidth(nbt.method_10583("ScreenWidth"));
        if (nbt.method_10545("ScreenHeight"))
            this.setScreenHeight(nbt.method_10583("ScreenHeight"));
        if (nbt.method_10545("ScreenName"))
            this.setScreenName(nbt.method_10558("ScreenName"));
        if (nbt.method_10545("StreamerUuid")) {
            if (nbt.method_10540("StreamerUuid") == net.minecraft.class_2520.field_33261) {
                this.setStreamerUuid(nbt.method_25926("StreamerUuid"));
            } else {
                try {
                    this.setStreamerUuid(UUID.fromString(nbt.method_10558("StreamerUuid")));
                } catch (Exception e) {}
            }
        }
    }

    @Override
    protected void method_5652(class_2487 nbt) {
        nbt.method_10548("ScreenWidth", this.getScreenWidth());
        nbt.method_10548("ScreenHeight", this.getScreenHeight());
        nbt.method_10582("ScreenName", this.getScreenName());
        String uuidStr = this.field_6011.method_12789(STREAMER_UUID);
        if (!uuidStr.isEmpty()) nbt.method_10582("StreamerUuid", uuidStr);
    }

    @Override
    public net.minecraft.class_2596<class_2602> method_18002(net.minecraft.class_3231 entityTrackerEntry) {
        return new class_2604(this, entityTrackerEntry);
    }

    public float getScreenWidth() { return this.field_6011.method_12789(WIDTH); }
    public void setScreenWidth(float width) { this.field_6011.method_12778(WIDTH, width); this.updateScreenBoundingBox(); }
    public float getScreenHeight() { return this.field_6011.method_12789(HEIGHT); }
    public void setScreenHeight(float height) { this.field_6011.method_12778(HEIGHT, height); this.updateScreenBoundingBox(); }

    public String getScreenName() { return this.field_6011.method_12789(SCREEN_NAME); }
    public void setScreenName(String name) { this.field_6011.method_12778(SCREEN_NAME, name == null ? "" : name); }

    public Optional<UUID> getStreamerUuid() {
        String s = this.field_6011.method_12789(STREAMER_UUID);
        if (s == null || s.isEmpty()) return Optional.empty();
        try { return Optional.of(UUID.fromString(s)); } catch (Exception e) { return Optional.empty(); }
    }

    public void setStreamerUuid(UUID uuid) {
        this.field_6011.method_12778(STREAMER_UUID, uuid == null ? "" : uuid.toString());
    }

    @Override
    public void method_5674(class_2940<?> data) {
        super.method_5674(data);
        if (WIDTH.equals(data) || HEIGHT.equals(data)) {
            updateScreenBoundingBox();
        }
    }

    private void updateScreenBoundingBox() {
        float w = getScreenWidth();
        float h = getScreenHeight();
        double yawRad = Math.toRadians(method_36454());
        double cos = Math.abs(Math.cos(yawRad));
        double sin = Math.abs(Math.sin(yawRad));
        double halfW = w / 2.0;
        double thickness = 0.05;
        double dx = (cos * halfW) + (sin * thickness);
        double dz = (sin * halfW) + (cos * thickness);
        this.method_5857(new class_238(
                method_23317() - dx, method_23318(), method_23321() - dz,
                method_23317() + dx, method_23318() + h, method_23321() + dz));
    }

    @Override
    public void method_5773() {
        super.method_5773();
        updateScreenBoundingBox();
    }

    @Override
    public boolean method_5863() { return true; }

    @Override
    public boolean method_5640(double distance) { return distance < 1024.0 * 1024.0; }
}
