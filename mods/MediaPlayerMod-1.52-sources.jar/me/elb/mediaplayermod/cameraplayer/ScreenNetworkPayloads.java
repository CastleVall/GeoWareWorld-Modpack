package me.elb.mediaplayermod.cameraplayer;

import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public class ScreenNetworkPayloads {

    public record FrameC2SPayload(long frameId, int chunkIndex, int totalChunks, byte[] data) implements class_8710 {
        public static final class_9154<FrameC2SPayload> ID = new class_9154<>(class_2960.method_60655("mediaplayermod", "screen_frame_c2s"));
        public static final class_9139<class_9129, FrameC2SPayload> CODEC = class_8710.method_56484(
                (payload, buf) -> { buf.method_52974(payload.frameId()); buf.method_53002(payload.chunkIndex()); buf.method_53002(payload.totalChunks()); buf.method_10813(payload.data()); },
                buf -> new FrameC2SPayload(buf.readLong(), buf.readInt(), buf.readInt(), buf.method_10795())
        );
        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record FrameS2CPayload(UUID streamer, long frameId, int index, int total, byte[] chunk) implements class_8710 {
        public static final class_9154<FrameS2CPayload> ID = new class_9154<>(class_2960.method_60655("mediaplayermod", "screen_frame_s2c"));
        public static final class_9139<class_9129, FrameS2CPayload> CODEC = class_8710.method_56484(
                (payload, buf) -> { buf.method_10797(payload.streamer()); buf.method_52974(payload.frameId()); buf.method_53002(payload.index()); buf.method_53002(payload.total()); buf.method_10813(payload.chunk()); },
                buf -> new FrameS2CPayload(buf.method_10790(), buf.readLong(), buf.readInt(), buf.readInt(), buf.method_10795())
        );
        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record SyncStreamPayload() implements class_8710 {
        public static final class_9154<SyncStreamPayload> ID = new class_9154<>(class_2960.method_60655("mediaplayermod", "screen_sync_stream"));
        public static final class_9139<class_9129, SyncStreamPayload> CODEC = class_8710.method_56484(
                (payload, buf) -> {}, buf -> new SyncStreamPayload()
        );
        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record VideoSyncPayload(String url, boolean loop) implements class_8710 {
        public static final class_9154<VideoSyncPayload> ID = new class_9154<>(class_2960.method_60655("mediaplayermod", "screen_video_sync"));
        public static final class_9139<class_9129, VideoSyncPayload> CODEC = class_8710.method_56484(
                (payload, buf) -> { buf.method_10814(payload.url()); buf.method_52964(payload.loop()); },
                buf -> new VideoSyncPayload(buf.method_19772(), buf.readBoolean())
        );
        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record CameraPovPayload(String name) implements class_8710 {
        public static final class_9154<CameraPovPayload> ID = new class_9154<>(class_2960.method_60655("mediaplayermod", "screen_camera_pov"));
        public static final class_9139<class_9129, CameraPovPayload> CODEC = class_8710.method_56484(
                (payload, buf) -> buf.method_10814(payload.name()),
                buf -> new CameraPovPayload(buf.method_19772())
        );
        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record OverlayPayload(String fileName) implements class_8710 {
        public static final class_9154<OverlayPayload> ID = new class_9154<>(class_2960.method_60655("mediaplayermod", "screen_overlay"));
        public static final class_9139<class_9129, OverlayPayload> CODEC = class_8710.method_56484(
                (payload, buf) -> buf.method_10814(payload.fileName()),
                buf -> new OverlayPayload(buf.method_19772())
        );
        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record EffectsPayload() implements class_8710 {
        public static final class_9154<EffectsPayload> ID = new class_9154<>(class_2960.method_60655("mediaplayermod", "screen_effects"));
        public static final class_9139<class_9129, EffectsPayload> CODEC = class_8710.method_56484(
                (payload, buf) -> {}, buf -> new EffectsPayload()
        );
        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }
}
