package me.elb.mediaplayermod.cameraplayer;

import me.elb.mediaplayermod.cameraplayer.ScreenNetworkPayloads.*;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ScreenStreamManager {
    private static final Map<UUID, FrameReconstructor> frameReconstructors = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> lastBroadcastTime = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> lastChunkTime = new ConcurrentHashMap<>();
    private static final Map<UUID, RecipientCache> recipientCache = new ConcurrentHashMap<>();
    public static final Map<UUID, class_2338[]> selectionMap = new HashMap<>();

    private static final long MIN_BROADCAST_INTERVAL_MS = 20L;
    private static final double MAX_VIEW_DISTANCE_SQ = 256.0 * 256.0;
    private static final long RECON_STALE_MS = 4000L;
    private static final long RECIPIENT_CACHE_TTL_MS = 1000L;
    private static final int OUT_CHUNK_SIZE = 30000;

    private static final ExecutorService broadcastExecutor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "MediaPlayer-StreamBroadcast");
        t.setDaemon(true);
        return t;
    });

    private static long lastCleanup = 0L;

    public static class_2338[] getSelection(UUID uuid) {
        return selectionMap.computeIfAbsent(uuid, k -> new class_2338[2]);
    }

    public static void handleFrameChunk(class_3222 sender, long frameId, int chunkIndex, int totalChunks, byte[] data) {
        UUID streamerUuid = sender.method_5667();
        long now = System.currentTimeMillis();

        FrameReconstructor recon = frameReconstructors.get(streamerUuid);
        if (recon == null || recon.frameId < frameId) {
            recon = new FrameReconstructor(frameId, totalChunks);
            frameReconstructors.put(streamerUuid, recon);
        } else if (recon.frameId > frameId) {
            return;
        }
        lastChunkTime.put(streamerUuid, now);
        recon.addChunk(chunkIndex, data);

        if (recon.isComplete()) {
            byte[] fullFrame = recon.getFullFrame();
            frameReconstructors.remove(streamerUuid);

            Long lastBcast = lastBroadcastTime.get(streamerUuid);
            if (lastBcast != null && now - lastBcast < MIN_BROADCAST_INTERVAL_MS) {
                cleanupStale(now);
                return;
            }
            lastBroadcastTime.put(streamerUuid, now);

            List<class_3222> recipients = resolveRecipients(sender, now);
            if (!recipients.isEmpty()) {
                broadcastExecutor.execute(() -> broadcastFrame(recipients, streamerUuid, frameId, fullFrame));
            }
        }
        cleanupStale(now);
    }

    private static List<class_3222> resolveRecipients(class_3222 sender, long now) {
        UUID streamerUuid = sender.method_5667();
        RecipientCache cached = recipientCache.get(streamerUuid);
        if (cached != null && now - cached.timestamp < RECIPIENT_CACHE_TTL_MS) {
            return filterAlive(cached.players);
        }
        List<class_3222> recipients = collectRecipients(sender);
        recipientCache.put(streamerUuid, new RecipientCache(now, recipients));
        return recipients;
    }

    private static List<class_3222> filterAlive(List<class_3222> in) {
        List<class_3222> out = new ArrayList<>(in.size());
        for (class_3222 p : in) {
            if (p.field_13987 != null && !p.method_14239()) out.add(p);
        }
        return out;
    }

    private static List<class_3222> collectRecipients(class_3222 sender) {
        UUID streamerUuid = sender.method_5667();
        MinecraftServer server = sender.method_5682();
        if (server == null) return List.of();

        Map<String, List<double[]>> screensByDim = new HashMap<>();
        for (class_3218 world : server.method_3738()) {
            String dim = world.method_27983().method_29177().toString();
            for (net.minecraft.class_1297 entity : world.method_27909()) {
                if (entity instanceof StreamScreenEntity screen) {
                    var uuidOpt = screen.getStreamerUuid();
                    if (uuidOpt.isPresent() && uuidOpt.get().equals(streamerUuid)) {
                        screensByDim.computeIfAbsent(dim, k -> new ArrayList<>())
                                .add(new double[]{ entity.method_23317(), entity.method_23318(), entity.method_23321() });
                    }
                }
            }
        }
        if (screensByDim.isEmpty()) return List.of();

        List<class_3222> recipients = new ArrayList<>();
        for (class_3222 p : server.method_3760().method_14571()) {
            if (p == sender) continue;
            String dim = p.method_37908().method_27983().method_29177().toString();
            List<double[]> screens = screensByDim.get(dim);
            if (screens == null) continue;
            for (double[] pos : screens) {
                double dx = p.method_23317() - pos[0];
                double dy = p.method_23318() - pos[1];
                double dz = p.method_23321() - pos[2];
                if (dx * dx + dy * dy + dz * dz <= MAX_VIEW_DISTANCE_SQ) {
                    recipients.add(p);
                    break;
                }
            }
        }
        return recipients;
    }

    private static void broadcastFrame(List<class_3222> recipients, UUID streamer, long frameId, byte[] data) {
        int total = (int) Math.ceil((double) data.length / OUT_CHUNK_SIZE);
        if (total <= 0) return;
        byte[][] chunks = new byte[total][];
        for (int i = 0; i < total; i++) {
            int start = i * OUT_CHUNK_SIZE;
            int end = Math.min(data.length, start + OUT_CHUNK_SIZE);
            chunks[i] = Arrays.copyOfRange(data, start, end);
        }
        for (class_3222 p : recipients) {
            if (p.field_13987 == null || p.method_14239()) continue;
            for (int i = 0; i < total; i++) {
                try {
                    ServerPlayNetworking.send(p, new FrameS2CPayload(streamer, frameId, i, total, chunks[i]));
                } catch (Exception ignored) {
                    break;
                }
            }
        }
    }

    private static void cleanupStale(long now) {
        if (now - lastCleanup < 2000L) return;
        lastCleanup = now;
        frameReconstructors.entrySet().removeIf(e -> {
            Long t = lastChunkTime.get(e.getKey());
            return t == null || now - t > RECON_STALE_MS;
        });
        lastChunkTime.entrySet().removeIf(e -> now - e.getValue() > RECON_STALE_MS * 4);
        recipientCache.entrySet().removeIf(e -> now - e.getValue().timestamp > RECIPIENT_CACHE_TTL_MS * 8);
    }

    public static void onStreamerDisconnect(UUID streamerUuid) {
        frameReconstructors.remove(streamerUuid);
        lastBroadcastTime.remove(streamerUuid);
        lastChunkTime.remove(streamerUuid);
        recipientCache.remove(streamerUuid);
    }

    private static final class RecipientCache {
        final long timestamp;
        final List<class_3222> players;
        RecipientCache(long timestamp, List<class_3222> players) {
            this.timestamp = timestamp;
            this.players = players;
        }
    }
}
