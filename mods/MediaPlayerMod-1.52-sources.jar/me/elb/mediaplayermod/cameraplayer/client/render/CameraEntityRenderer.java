package me.elb.mediaplayermod.cameraplayer.client.render;

import me.elb.mediaplayermod.cameraplayer.CameraEntity;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_897;

public class CameraEntityRenderer extends class_897<CameraEntity> {
    public CameraEntityRenderer(class_5617.class_5618 ctx) {
        super(ctx);
    }

    @Override
    public class_2960 getTexture(CameraEntity entity) {
        return null;
    }

    @Override
    public void render(CameraEntity entity, float yaw, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light) {
        matrices.method_22903();
        method_3926(entity, net.minecraft.class_2561.method_43470(entity.getCameraName()), matrices, vertexConsumers, light, tickDelta);
        matrices.method_22909();
        super.method_3936(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }
}
