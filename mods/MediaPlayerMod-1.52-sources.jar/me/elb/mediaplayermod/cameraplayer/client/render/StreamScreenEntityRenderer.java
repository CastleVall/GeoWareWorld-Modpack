package me.elb.mediaplayermod.cameraplayer.client.render;

import me.elb.mediaplayermod.cameraplayer.ScreenStreamClientManager;
import me.elb.mediaplayermod.cameraplayer.StreamScreenEntity;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_7833;
import net.minecraft.class_897;
import org.joml.Matrix4f;

public class StreamScreenEntityRenderer extends class_897<StreamScreenEntity> {
    public StreamScreenEntityRenderer(class_5617.class_5618 ctx) {
        super(ctx);
    }

    @Override
    public boolean shouldRender(StreamScreenEntity entity, net.minecraft.class_4604 frustum, double x, double y, double z) {
        return true;
    }

    @Override
    public class_2960 getTexture(StreamScreenEntity entity) {
        return ScreenStreamClientManager.STREAM_TEXTURE_ID;
    }

    @Override
    public void render(StreamScreenEntity entity, float yaw, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light) {
        class_2960 textureId = ScreenStreamClientManager.STREAM_TEXTURE_ID;
        java.util.UUID streamerUuid = entity.getStreamerUuid().orElse(null);
        boolean isBlack = false;

        if (streamerUuid != null) {
            if (class_310.method_1551().field_1724 != null && streamerUuid.equals(class_310.method_1551().field_1724.method_5667())) {
                if (ScreenStreamClientManager.localStreamTexture == null) isBlack = true;
                else textureId = ScreenStreamClientManager.STREAM_TEXTURE_ID;
            } else if (ScreenStreamClientManager.remoteTextures.containsKey(streamerUuid)) {
                textureId = class_2960.method_60655("mediaplayermod", "stream_" + streamerUuid.toString());
            } else {
                isBlack = true;
            }
        } else {
            isBlack = true;
        }

        if (isBlack) {
            textureId = class_2960.method_60655("mediaplayer", "textures/black.png");
        }

        matrices.method_22903();
        matrices.method_22907(class_7833.field_40716.rotationDegrees(-entity.method_36454()));
        class_4588 consumer = vertexConsumers.getBuffer(class_1921.method_23028(textureId));
        Matrix4f modelMatrix = matrices.method_23760().method_23761();
        float w = entity.getScreenWidth();
        float h = entity.getScreenHeight();
        float x = -w / 2f;
        float y = 0;
        drawFace(modelMatrix, consumer, 15728880, x, y, w, h);
        matrices.method_22909();
        super.method_3936(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }

    private void drawFace(Matrix4f model, class_4588 consumer, int light, float x, float y, float w, float h) {
        consumer.method_22918(model, x, y, 0.005f).method_1336(255, 255, 255, 255).method_22913(0, 1).method_60803(light);
        consumer.method_22918(model, x + w, y, 0.005f).method_1336(255, 255, 255, 255).method_22913(1, 1).method_60803(light);
        consumer.method_22918(model, x + w, y + h, 0.005f).method_1336(255, 255, 255, 255).method_22913(1, 0).method_60803(light);
        consumer.method_22918(model, x, y + h, 0.005f).method_1336(255, 255, 255, 255).method_22913(0, 0).method_60803(light);
    }
}
