package me.elb.mediaplayermod.cameraplayer.client.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;

@Environment(EnvType.CLIENT)
public class OverlayManager {
    private static class_1043 currentOverlayTexture;
    private static final class_2960 OVERLAY_ID = class_2960.method_60655("mediaplayermod", "hud_overlay");
    public static boolean isVisible = false;
    private static int imageWidth = 0;
    private static int imageHeight = 0;
    private static class_1011 currentOverlayImage;

    public static void setupFolders() {
        Path overlayDir = FabricLoader.getInstance().getConfigDir().resolve("mediaplayer").resolve("overlays_player").resolve("overlays");
        overlayDir.toFile().mkdirs();
    }

    public static void loadOverlay(String fileName) {
        if (!fileName.endsWith(".png")) fileName += ".png";
        Path overlayDir = FabricLoader.getInstance().getConfigDir().resolve("mediaplayer").resolve("overlays_player").resolve("overlays");
        overlayDir.toFile().mkdirs();
        File overlayFile = overlayDir.resolve(fileName).toFile();
        if (!overlayFile.exists()) {
            if (class_310.method_1551().field_1724 != null) {
                class_310.method_1551().field_1724.method_7353(class_2561.method_43470("§cFile not found: §7" + overlayFile.getName()), false);
                class_310.method_1551().field_1724.method_7353(class_2561.method_43470("§eFolder: §7config/mediaplayer/overlays_player/overlays/"), false);
            }
            return;
        }
        try {
            FileInputStream fis = new FileInputStream(overlayFile);
            class_1011 image = class_1011.method_4309(fis);
            fis.close();
            if (currentOverlayTexture != null) currentOverlayTexture.close();
            imageWidth = image.method_4307();
            imageHeight = image.method_4323();
            if (currentOverlayImage != null) currentOverlayImage.close();
            currentOverlayImage = new class_1011(image.method_4307(), image.method_4323(), false);
            currentOverlayImage.method_4317(image);
            currentOverlayTexture = new class_1043(image);
            class_310.method_1551().method_1531().method_4616(OVERLAY_ID, currentOverlayTexture);
            isVisible = true;
            if (class_310.method_1551().field_1724 != null) {
                class_310.method_1551().field_1724.method_7353(class_2561.method_43470("§b[MediaPlayer] §aOverlay §6" + fileName + " §aloaded."), false);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void render(class_332 context, float tickDelta) {
        if (!isVisible || currentOverlayTexture == null) return;
        int screenWidth = context.method_51421();
        int screenHeight = context.method_51443();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        context.method_25293(OVERLAY_ID, 0, 0, screenWidth, screenHeight, 0, 0, imageWidth, imageHeight, imageWidth, imageHeight);
        RenderSystem.disableBlend();
    }

    public static void applyOverlayToImage(class_1011 frame) {
        if (!isVisible || currentOverlayImage == null) return;
        int frameW = frame.method_4307(), frameH = frame.method_4323();
        int overlayW = currentOverlayImage.method_4307(), overlayH = currentOverlayImage.method_4323();
        for (int y = 0; y < frameH; y++) {
            for (int x = 0; x < frameW; x++) {
                int ox = (int) ((float) x / frameW * overlayW);
                int oy = (int) ((float) y / frameH * overlayH);
                int overlayColor = currentOverlayImage.method_4315(ox, oy);
                int overlayAlpha = (overlayColor >> 24) & 0xFF;
                if (overlayAlpha == 0) continue;
                if (overlayAlpha == 255) {
                    frame.method_4305(x, y, overlayColor);
                } else {
                    int frameColor = frame.method_4315(x, y);
                    float alpha = overlayAlpha / 255.0f;
                    int r = (int) (((overlayColor & 0xFF) * alpha) + ((frameColor & 0xFF) * (1 - alpha)));
                    int g = (int) ((((overlayColor >> 8) & 0xFF) * alpha) + (((frameColor >> 8) & 0xFF) * (1 - alpha)));
                    int b = (int) ((((overlayColor >> 16) & 0xFF) * alpha) + (((frameColor >> 16) & 0xFF) * (1 - alpha)));
                    frame.method_4305(x, y, 0xFF000000 | (b << 16) | (g << 8) | r);
                }
            }
        }
    }

    public static void clear() {
        isVisible = false;
        if (currentOverlayTexture != null) { currentOverlayTexture.close(); currentOverlayTexture = null; }
        if (currentOverlayImage != null) { currentOverlayImage.close(); currentOverlayImage = null; }
        imageWidth = 0;
        imageHeight = 0;
    }
}
