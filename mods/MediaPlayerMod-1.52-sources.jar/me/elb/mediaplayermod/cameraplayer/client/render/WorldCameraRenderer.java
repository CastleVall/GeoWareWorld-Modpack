package me.elb.mediaplayermod.cameraplayer.client.render;

import me.elb.mediaplayermod.cameraplayer.CameraEntity;
import net.minecraft.class_1011;
import net.minecraft.class_276;
import net.minecraft.class_310;
import net.minecraft.class_5365;
import net.minecraft.class_6367;
import com.mojang.blaze3d.systems.RenderSystem;

public class WorldCameraRenderer {
    public static class_276 cameraFramebuffer;
    public static boolean isCapturing = false;
    private static final int WIDTH = 854;
    private static final int HEIGHT = 480;

    public static class_1011 captureCamera(CameraEntity cameraEntity, float tickDelta) {
        if (isCapturing) return null;
        class_310 client = class_310.method_1551();
        if (cameraFramebuffer == null) {
            cameraFramebuffer = new class_6367(WIDTH, HEIGHT, true, class_310.field_1703);
        }
        if (client.field_1687 == null || client.field_1724 == null) return null;

        class_276 originalBuffer = client.method_1522();
        net.minecraft.class_1297 oldCamera = client.field_1719;
        net.minecraft.class_5498 oldPerspective = client.field_1690.method_31044();
        boolean oldHudHidden = client.field_1690.field_1842;
        class_5365 oldGraphics = client.field_1690.method_42534().method_41753();

        me.elb.mediaplayermod.mixin.cameraplayer.WorldRendererAccessor wra =
                (me.elb.mediaplayermod.mixin.cameraplayer.WorldRendererAccessor) client.field_1769;
        net.minecraft.class_279 oldTransparency = wra.getTransparencyPostProcessor();
        net.minecraft.class_279 oldEntityOutline = wra.getEntityOutlinePostProcessor();
        double pLastX = wra.getLastCameraX();
        double pLastY = wra.getLastCameraY();
        double pLastZ = wra.getLastCameraZ();

        isCapturing = true;
        ((me.elb.mediaplayermod.mixin.cameraplayer.MinecraftClientAccessor) client).setFramebuffer(cameraFramebuffer);

        try {
            client.method_1504(cameraEntity);
            client.field_1690.method_31043(net.minecraft.class_5498.field_26665);
            client.field_1690.field_1842 = true;
            client.field_1690.method_42534().method_41748(class_5365.field_25428);
            cameraFramebuffer.method_1235(true);
            RenderSystem.viewport(0, 0, WIDTH, HEIGHT);
            RenderSystem.clearColor(0.0f, 0.0f, 0.0f, 1.0f);
            RenderSystem.clear(16640, class_310.field_1703);
            wra.setLastCameraX(cameraEntity.method_23317());
            wra.setLastCameraY(cameraEntity.method_23318());
            wra.setLastCameraZ(cameraEntity.method_23321());
            wra.setTransparencyPostProcessor(null);
            wra.setEntityOutlinePostProcessor(null);
            client.field_1773.method_3188(client.method_60646());
            class_1011 image = new class_1011(WIDTH, HEIGHT, false);
            cameraFramebuffer.method_35610();
            image.method_4327(0, false);
            cameraFramebuffer.method_1240();
            return image;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            wra.setLastCameraX(pLastX);
            wra.setLastCameraY(pLastY);
            wra.setLastCameraZ(pLastZ);
            wra.setTransparencyPostProcessor(oldTransparency);
            wra.setEntityOutlinePostProcessor(oldEntityOutline);
            ((me.elb.mediaplayermod.mixin.cameraplayer.MinecraftClientAccessor) client).setFramebuffer(originalBuffer);
            client.field_1690.method_42534().method_41748(oldGraphics);
            client.field_1690.field_1842 = oldHudHidden;
            client.field_1690.method_31043(oldPerspective);
            client.method_1504(oldCamera == null ? client.field_1724 : oldCamera);
            isCapturing = false;
            originalBuffer.method_1235(false);
            RenderSystem.viewport(0, 0, client.method_22683().method_4489(), client.method_22683().method_4506());
        }
    }
}
