package me.elb.mediaplayermod.cameraplayer.client.video;

import com.sun.jna.Pointer;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1011;
import uk.co.caprica.vlcj.factory.MediaPlayerFactory;
import uk.co.caprica.vlcj.player.base.MediaPlayer;
import uk.co.caprica.vlcj.player.base.callback.AudioCallback;
import uk.co.caprica.vlcj.player.embedded.EmbeddedMediaPlayer;
import uk.co.caprica.vlcj.player.embedded.videosurface.CallbackVideoSurface;
import uk.co.caprica.vlcj.player.embedded.videosurface.callback.BufferFormat;
import uk.co.caprica.vlcj.player.embedded.videosurface.callback.BufferFormatCallback;
import uk.co.caprica.vlcj.player.embedded.videosurface.callback.RenderCallback;
import uk.co.caprica.vlcj.player.embedded.videosurface.callback.format.RV32BufferFormat;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.SourceDataLine;
import java.io.File;
import java.nio.ByteBuffer;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicReference;

public class VideoManager {
    public static boolean isActive = false;
    public static boolean isLooping = false;
    public static float audioLevel = 0;

    private static MediaPlayerFactory factory;
    private static EmbeddedMediaPlayer mediaPlayer;
    private static AtomicReference<class_1011> currentFrame = new AtomicReference<>();

    private static SourceDataLine audioLine;
    private static float lastAppliedGainDb = Float.NaN;

    /**
     * Aplica el volumen de Minecraft (master x categoria, 0..1) a la linea de audio Java.
     * Sin esto el reproductor de overlays suena SIEMPRE al 100%: su audio no pasa por el motor
     * de sonido de Minecraft ni por VLC, asi que ningun slider le afectaba.
     */
    public static void applyVolume(float volume) {
        SourceDataLine line = audioLine;
        if (line == null || !line.isOpen()) {
            return;
        }
        try {
            FloatControl gain = (FloatControl) line.getControl(FloatControl.Type.MASTER_GAIN);
            float clamped = Math.clamp(volume, 0f, 1f);
            float db = clamped <= 0.001f
                    ? gain.getMinimum()
                    : (float) Math.max(gain.getMinimum(), Math.min(gain.getMaximum(), 20.0 * Math.log10(clamped)));
            if (db != lastAppliedGainDb) {
                gain.setValue(db);
                lastAppliedGainDb = db;
            }
        } catch (IllegalArgumentException ignored) {
            // La linea no expone MASTER_GAIN en este sistema; no hay control de volumen posible.
        }
    }

    public static void setupFolders() {
        Path videoDir = FabricLoader.getInstance().getConfigDir().resolve("mediaplayer").resolve("overlays_player").resolve("videos");
        Path songDir = FabricLoader.getInstance().getConfigDir().resolve("mediaplayer").resolve("overlays_player").resolve("songs");
        videoDir.toFile().mkdirs();
        songDir.toFile().mkdirs();
    }

    public static void init() {
        if (factory != null)
            return;
        try {
            factory = new MediaPlayerFactory();
            mediaPlayer = factory.mediaPlayers().newEmbeddedMediaPlayer();

            AudioFormat format = new AudioFormat(44100, 16, 2, true, false);
            DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);
            audioLine = (SourceDataLine) AudioSystem.getLine(info);
            audioLine.open(format);
            audioLine.start();

            mediaPlayer.videoSurface().set(new CallbackVideoSurface(
                    new BufferFormatCallback() {
                        @Override
                        public BufferFormat getBufferFormat(int sourceWidth, int sourceHeight) {
                            return new RV32BufferFormat(sourceWidth, sourceHeight);
                        }

                        @Override
                        public void allocatedBuffers(ByteBuffer[] buffers) {
                        }

                        @Override
                        public void newFormatSize(int width, int height, int pitch, int lines) {
                        }
                    },
                    new RenderCallback() {
                        @Override
                        public void display(MediaPlayer mediaPlayer, ByteBuffer[] nativeBuffers,
                                            BufferFormat bufferFormat, int width, int height) {
                            ByteBuffer buffer = nativeBuffers[0];
                            if (width <= 0 || height <= 0)
                                return;

                            class_1011 img = new class_1011(width, height, false);
                            for (int y = 0; y < height; y++) {
                                for (int x = 0; x < width; x++) {
                                    int pixel = buffer.getInt((y * width + x) * 4);
                                    int a = (pixel >> 24) & 0xFF;
                                    int r = (pixel >> 16) & 0xFF;
                                    int g = (pixel >> 8) & 0xFF;
                                    int b = pixel & 0xFF;
                                    img.method_4305(x, y, (a << 24) | (b << 16) | (g << 8) | r);
                                }
                            }
                            class_1011 old = currentFrame.getAndSet(img);
                            if (old != null)
                                old.close();
                        }

                        @Override
                        public void lock(MediaPlayer mediaPlayer) {
                        }

                        @Override
                        public void unlock(MediaPlayer mediaPlayer) {
                        }
                    },
                    true,
                    null));

            mediaPlayer.audio().callback("S16N", 44100, 2, new AudioCallback() {
                @Override
                public void play(MediaPlayer mediaPlayer, Pointer samples, int count, long pts) {
                    int length = count * 4;
                    byte[] data = samples.getByteArray(0, length);

                    if (audioLine != null && audioLine.isOpen()) {
                        audioLine.write(data, 0, length);
                    }

                    float max = 0;
                    for (int i = 0; i < length; i += 2) {
                        short s = (short) ((data[i] & 0xFF) | (data[i + 1] << 8));
                        float abs = Math.abs(s) / 32768f;
                        if (abs > max)
                            max = abs;
                    }

                    if (max > audioLevel) {
                        audioLevel = max;
                    } else {
                        audioLevel *= 0.95f;
                    }
                }

                @Override
                public void pause(MediaPlayer mediaPlayer, long pts) {
                    if (audioLine != null)
                        audioLine.stop();
                }

                @Override
                public void resume(MediaPlayer mediaPlayer, long pts) {
                    if (audioLine != null)
                        audioLine.start();
                }

                @Override
                public void flush(MediaPlayer mediaPlayer, long pts) {
                    if (audioLine != null)
                        audioLine.flush();
                }

                @Override
                public void drain(MediaPlayer mediaPlayer) {
                    if (audioLine != null)
                        audioLine.drain();
                }

                @Override
                public void setVolume(float volume, boolean mute) {
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void play(String input, boolean loop) {
        if (mediaPlayer == null)
            init();
        isLooping = loop;
        isActive = true;

        File file = new File(input);
        if (!file.exists()) {
            Path configPath = FabricLoader.getInstance().getConfigDir().resolve("mediaplayer").resolve("overlays_player");
            File localVideo = configPath.resolve("videos").resolve(input).toFile();
            File localSong = configPath.resolve("songs").resolve(input).toFile();
            if (localVideo.exists())
                input = localVideo.getAbsolutePath();
            else if (localSong.exists())
                input = localSong.getAbsolutePath();
        }

        mediaPlayer.media().play(input);
        if (loop) {
            mediaPlayer.controls().setRepeat(true);
        }
    }

    public static void stop() {
        if (mediaPlayer != null) {
            mediaPlayer.controls().stop();
        }
        if (audioLine != null) {
            audioLine.flush();
            audioLine.stop();
        }
        isActive = false;
        audioLevel = 0;
        class_1011 old = currentFrame.getAndSet(null);
        if (old != null)
            old.close();
    }

    public static class_1011 getFrame() {
        return currentFrame.get();
    }

    public static void cleanup() {
        if (mediaPlayer != null)
            mediaPlayer.release();
        if (factory != null)
            factory.release();
        if (audioLine != null) {
            audioLine.close();
        }
    }
}
