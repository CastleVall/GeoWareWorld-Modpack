package me.elb.mediaplayermod.cameraplayer.client.gui;

import me.elb.mediaplayermod.cameraplayer.ScreenStreamClientManager;
import me.elb.mediaplayermod.cameraplayer.client.video.VideoManager;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.io.File;

public class EffectsScreen extends class_437 {
    public EffectsScreen() {
        super(class_2561.method_43470("Screen Effects"));
    }

    @Override
    protected void method_25426() {
        int buttonWidth = 200;
        int buttonHeight = 20;

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("RGB Trail: " + (ScreenStreamClientManager.rgbTrailEnabled ? "§aON" : "§cOFF")),
                button -> {
                    ScreenStreamClientManager.rgbTrailEnabled = !ScreenStreamClientManager.rgbTrailEnabled;
                    button.method_25355(class_2561.method_43470("RGB Trail: " + (ScreenStreamClientManager.rgbTrailEnabled ? "§aON" : "§cOFF")));
                })
                .method_46434(this.field_22789 / 2 - buttonWidth / 2, this.field_22790 / 2 - 60, buttonWidth, buttonHeight)
                .method_46431());

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Trail Layers: " + ScreenStreamClientManager.trailLayers),
                button -> {
                    ScreenStreamClientManager.trailLayers = (ScreenStreamClientManager.trailLayers % 10) + 1;
                    button.method_25355(class_2561.method_43470("Trail Layers: " + ScreenStreamClientManager.trailLayers));
                })
                .method_46434(this.field_22789 / 2 - buttonWidth / 2, this.field_22790 / 2 - 35, buttonWidth, buttonHeight)
                .method_46431());

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("BPM Pulse: " + ScreenStreamClientManager.trailBpm),
                button -> {
                    ScreenStreamClientManager.trailBpm = (ScreenStreamClientManager.trailBpm >= 120) ? 10 : ScreenStreamClientManager.trailBpm + 10;
                    button.method_25355(class_2561.method_43470("BPM Pulse: " + ScreenStreamClientManager.trailBpm));
                })
                .method_46434(this.field_22789 / 2 - buttonWidth / 2, this.field_22790 / 2 - 10, buttonWidth, buttonHeight)
                .method_46431());

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Wave Visualizer: " + (ScreenStreamClientManager.visualizerEnabled ? "§aON" : "§cOFF")),
                button -> {
                    ScreenStreamClientManager.visualizerEnabled = !ScreenStreamClientManager.visualizerEnabled;
                    button.method_25355(class_2561.method_43470("Wave Visualizer: " + (ScreenStreamClientManager.visualizerEnabled ? "§aON" : "§cOFF")));
                })
                .method_46434(this.field_22789 / 2 - buttonWidth / 2, this.field_22790 / 2 + 15, buttonWidth, buttonHeight)
                .method_46431());

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Play Audio..."),
                button -> {
                    File audioDir = FabricLoader.getInstance().getConfigDir().resolve("mediaplayer").resolve("overlays_player").resolve("audio").toFile();
                    audioDir.mkdirs();
                    File[] files = audioDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".mp3") || name.toLowerCase().endsWith(".wav"));
                    if (files != null && files.length > 0) {
                        VideoManager.play(files[0].getAbsolutePath(), true);
                        button.method_25355(class_2561.method_43470("§aPlaying: §f" + files[0].getName()));
                    } else {
                        button.method_25355(class_2561.method_43470("§cNo files in config/mediaplayer/overlays_player/audio/"));
                    }
                })
                .method_46434(this.field_22789 / 2 - buttonWidth / 2, this.field_22790 / 2 + 40, buttonWidth, buttonHeight)
                .method_46431());

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Stop Audio"),
                button -> VideoManager.stop())
                .method_46434(this.field_22789 / 2 - buttonWidth / 2, this.field_22790 / 2 + 65, buttonWidth, buttonHeight)
                .method_46431());

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Close"),
                button -> this.method_25419())
                .method_46434(this.field_22789 / 2 - buttonWidth / 2, this.field_22790 / 2 + 100, buttonWidth, buttonHeight)
                .method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 0xFFFFFF);
        super.method_25394(context, mouseX, mouseY, delta);
    }
}
