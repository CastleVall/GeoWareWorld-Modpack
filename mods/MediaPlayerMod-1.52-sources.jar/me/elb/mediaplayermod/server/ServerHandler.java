package me.elb.mediaplayermod.server;

import me.elb.mediaplayermod.model.media.Audio;
import me.elb.mediaplayermod.model.media.Cinematic;
import me.elb.mediaplayermod.model.media.MediaType;
import me.elb.mediaplayermod.model.media.Playlist;
import me.elb.mediaplayermod.networking.packet.*;
import me.elb.mediaplayermod.playlist.ServerPlaylist;
import lombok.Getter;

import java.util.*;

@Getter
public abstract class ServerHandler<P> {
    private static final long REPLAY_TIMEOUT = 600000L;
    /** Tiempo sin confirmacion del cliente tras el cual se reenvia un ServerPlayMediaPacket. */
    private static final long DELIVERY_RETRY_MS = 3000L;
    /** Reintentos maximos por jugador antes de darlo por perdido (ademas del envio original). */
    private static final int DELIVERY_MAX_RETRIES = 4;
    private final List<MediaEntry<P>> mediaHistory = new ArrayList<>();
    private final List<ServerPlaylist<P>> playlists = new ArrayList<>();
    private final Map<P, List<MediaPlayerInfo<P>>> playerInfoMap = new HashMap<>();
    private final Map<String, Cinematic> cinematics = new HashMap<>();
    private final java.util.concurrent.atomic.AtomicLong deliverySeq =
            new java.util.concurrent.atomic.AtomicLong(System.currentTimeMillis());
    private final List<PendingDelivery<P>> pendingDeliveries = new ArrayList<>();

    /** Envio de media a un jugador aun sin confirmar por su cliente. */
    private static final class PendingDelivery<P> {
        final P player;
        final long deliveryId;
        final ServerPlayMediaPacket packet;
        long sentAt;
        int retries;

        PendingDelivery(P player, long deliveryId, ServerPlayMediaPacket packet) {
            this.player = player;
            this.deliveryId = deliveryId;
            this.packet = packet;
            this.sentAt = System.currentTimeMillis();
        }
    }

    @SuppressWarnings("unchecked")
    public final void sendPacket(P player, Packet packet) {
        P[] players = (P[]) new Object[]{player};
        sendPacket(players, packet);
    }

    @SuppressWarnings("unchecked")
    public final void sendPacket(Collection<P> players, Packet packet) {
        sendPacket((P[]) players.toArray(), packet);
    }

    public final void sendPacket(P[] players, Packet packet) {
        sendPacket(players, packet, false);
    }

    public final void sendPacket(P[] players, Packet packet, boolean broadcastEveryone) {
        if (packet instanceof ServerPlayMediaPacket pkt) {
            mediaHistory.add(new MediaEntry<>(System.currentTimeMillis(), pkt.getMedia(), broadcastEveryone, players));
            // Entrega con confirmacion: si el cliente no confirma (packet perdido, cliente ocupado,
            // excepcion al reproducir...) se reenvia en tickDeliveries(). Los packets con
            // confirmacion manual del usuario no se reintentan (reabririan el dialogo).
            if (!pkt.isNeedConfirmation()) {
                pkt.setDeliveryId(deliverySeq.incrementAndGet());
                for (P player : players) {
                    // Un media nuevo del mismo tipo sustituye al anterior: cancelar sus reintentos
                    // para no reenviar contenido viejo por encima del nuevo.
                    pendingDeliveries.removeIf(pd -> pd.player.equals(player)
                            && pd.packet.getMedia().getType() == pkt.getMedia().getType());
                    pendingDeliveries.add(new PendingDelivery<>(player, pkt.getDeliveryId(), pkt));
                }
            }
        } else if (packet instanceof ServerStopMediaPacket stop) {
            // Un stop cancela los reintentos del tipo detenido: no tiene sentido reenviar un media
            // que el servidor ya mando parar.
            for (P player : players) {
                pendingDeliveries.removeIf(pd -> pd.player.equals(player)
                        && (stop.getMediaType() == MediaType.ANY
                        || pd.packet.getMedia().getType() == stop.getMediaType()));
            }
        }
        for (P player : players) {
            sendPlayerPacket(player, packet);
        }
    }

    /**
     * Reenvia los medias no confirmados por sus clientes. Debe llamarse periodicamente desde el
     * hilo del servidor (una vez por tick es suficiente; sin pendientes no hace nada).
     */
    public final void tickDeliveries() {
        if (pendingDeliveries.isEmpty()) {
            return;
        }
        long now = System.currentTimeMillis();
        Iterator<PendingDelivery<P>> iterator = pendingDeliveries.iterator();
        while (iterator.hasNext()) {
            PendingDelivery<P> pending = iterator.next();
            if (now - pending.sentAt < DELIVERY_RETRY_MS) {
                continue;
            }
            if (pending.retries >= DELIVERY_MAX_RETRIES) {
                me.elb.mediaplayermod.MediaPlayerMod.LOGGER.warn(
                        "Media {} (delivery {}) sin confirmar por {} tras {} reintentos",
                        pending.packet.getMedia().getType(), pending.deliveryId, pending.player, pending.retries);
                iterator.remove();
                continue;
            }
            pending.retries++;
            pending.sentAt = now;
            sendPlayerPacket(pending.player, pending.packet);
        }
    }

    private void ackDelivery(P player, long deliveryId) {
        if (deliveryId == 0) {
            return;
        }
        pendingDeliveries.removeIf(pd -> pd.deliveryId == deliveryId && pd.player.equals(player));
    }

    public void handlePacket(P player, Packet packet) {
        if (packet instanceof ClientStartedMediaPacket pkt) {
            ackDelivery(player, pkt.getDeliveryId());
            addPlayerInfo(player, pkt.getId(), pkt.getType(), pkt.getParameters());
        } else if (packet instanceof ClientAckMediaPacket pkt) {
            ackDelivery(player, pkt.getDeliveryId());
        } else if (packet instanceof ClientFinishedMediaPacket pkt) {
            removePlayerInfo(player, pkt.getId());
        } else if (packet instanceof ClientSendOptionPacket pkt) {
            sendOptionInfo(pkt.getSender(), player, pkt.getOption(), pkt.getValue());
        }
    }

    protected void addPlayerInfo(P player, UUID uuid, MediaType type, String parameters) {
        if (type != MediaType.PLAYLIST) {
            List<MediaPlayerInfo<P>> playerInfoList = playerInfoMap.computeIfAbsent(player, k -> new ArrayList<>());
            playerInfoList.add(new MediaPlayerInfo<>(player, uuid, type, parameters));
        }
        // Solo se pasa a espectador cuando el video congela la pantalla (freezeScreen=true).
        // Con false el jugador conserva su modo de juego y el control normal.
        if (type == MediaType.VIDEO && parameters != null && parameters.contains("freezeScreen=true")) {
            preparePlayer(player);
        }
    }

    protected void removePlayerInfo(P player, UUID uuid) {
        Iterator<MediaPlayerInfo<P>> iterator = playerInfoMap.get(player).iterator();
        while (iterator.hasNext()) {
            MediaPlayerInfo<P> playerInfo = iterator.next();
            if (playerInfo.getUuid().equals(uuid)) {
                iterator.remove();
                if (playerInfo.getType() == MediaType.VIDEO) {
                    restorePlayer(player);
                }
                return;
            }
        }
    }

    public void joinPlayer(P player) {
        long now = System.currentTimeMillis();
        mediaHistory.stream()
                .filter(mediaEntry -> mediaEntry.broadcastEveryone() && now - mediaEntry.start() < REPLAY_TIMEOUT
                        && Arrays.asList(mediaEntry.targets()).contains(player))
                .min(Comparator.comparingLong(MediaEntry::start))
                .ifPresent(mediaEntry -> sendPlayerPacket(player, new ServerPlayMediaPacket(mediaEntry.media(), true)));
    }

    public void disconnectPlayer(P player) {
        playerInfoMap.remove(player);
        pendingDeliveries.removeIf(pd -> pd.player.equals(player));
        restorePlayer(player);
    }

    public boolean isPlayerPlayingType(P player, MediaType type) {
        List<MediaPlayerInfo<P>> playerInfoList = playerInfoMap.get(player);
        if (playerInfoList == null) {
            return false;
        }
        for (MediaPlayerInfo<P> playerInfo : playerInfoList) {
            if (playerInfo.getType() == type) {
                return true;
            }
        }
        return false;
    }

    protected abstract void preparePlayer(P player);

    protected abstract void restorePlayer(P player);

    protected abstract void sendPlayerPacket(P player, Packet packet);

    protected abstract void sendPacketToAll(Packet packet);

    protected abstract void sendOptionInfo(String receiver, P target, String option, String value);

    protected void onPlaylistStateChanged() {
    }

    public ServerPlaylist<P> getPlaylist(String id) {
        for (ServerPlaylist<P> playlist : playlists) {
            if (playlist.getId().equals(id)) {
                return playlist;
            }
        }
        return null;
    }

    private void sendPlaylistPacket(ServerPlaylist<P> playlist, Packet packet) {
        if (playlist.isBroadcastEveryone()) {
            sendPacketToAll(packet);
        } else {
            for (P player : playlist.getPlayers()) {
                sendPlayerPacket(player, packet);
            }
        }
    }

    public ServerPlaylist<P> createPlaylist(String id) {
        if (getPlaylist(id) != null) {
            return null;
        }
        ServerPlaylist<P> serverPlaylist = new ServerPlaylist<>(id);
        playlists.add(serverPlaylist);
        onPlaylistStateChanged();
        return serverPlaylist;
    }

    public boolean deletePlaylist(String id) {
        ServerPlaylist<P> playlist = getPlaylist(id);
        if (playlist != null) {
            playlists.remove(playlist);
            Packet packet = new ServerPlayMediaPacket(new Playlist.Delete(id));
            sendPlaylistPacket(playlist, packet);
            onPlaylistStateChanged();
            return true;
        }
        return false;
    }

    public boolean addAudioToPlaylist(String id, String url, String name) {
        return addAudioToPlaylist(id, url, name, null);
    }

    public boolean addAudioToPlaylist(String id, String url, String name, String lyricsUrl) {
        ServerPlaylist<P> playlist = getPlaylist(id);
        if (playlist == null) return false;
        Audio audio = new Audio(url, null, name, lyricsUrl);
        playlist.addAudio(audio);
        Packet packet = new ServerPlayMediaPacket(new Playlist.Add(id, audio));
        sendPlaylistPacket(playlist, packet);
        onPlaylistStateChanged();
        return true;
    }

    public boolean setLyricsForTrack(String id, int index, String lyricsUrl) {
        ServerPlaylist<P> playlist = getPlaylist(id);
        if (playlist == null) return false;
        List<Audio> audios = playlist.getAudios();
        if (index < 0 || index >= audios.size()) return false;
        Audio old = audios.get(index);
        audios.set(index, new Audio(old.url(), old.backupUrl(), old.name(), lyricsUrl));
        onPlaylistStateChanged();
        return true;
    }

    public boolean removeAudioFromPlaylist(ServerPlaylist<P> playlist, int index) {
        if (playlist.removeAudio(index)) {
            Packet packet = new ServerPlayMediaPacket(new Playlist.Remove(playlist.getId(), index));
            sendPlaylistPacket(playlist, packet);
            onPlaylistStateChanged();
            return true;
        }
        return false;
    }

    public boolean moveAudioInPlaylist(ServerPlaylist<P> playlist, int from, int to) {
        if (playlist.moveAudio(from, to)) {
            Packet packet = new ServerPlayMediaPacket(new Playlist.Move(playlist.getId(), from, to));
            sendPlaylistPacket(playlist, packet);
            onPlaylistStateChanged();
            return true;
        }
        return false;
    }

    public void setPlaylistToPlayers(ServerPlaylist<P> playlist, P[] targets, boolean broadcastToEveryone) {
        playlist.setBroadcastEveryone(broadcastToEveryone);
        Set<P> newTargets = new HashSet<>(Arrays.asList(targets));
        Iterator<P> iterator = playlist.getPlayers().iterator();
        while (iterator.hasNext()) {
            P player = iterator.next();
            if (!newTargets.contains(player)) {
                iterator.remove();
                Packet packet = new ServerPlayMediaPacket(new Playlist.Delete(playlist.getId()));
                sendPlayerPacket(player, packet);
            }
        }
        for (P player : newTargets) {
            playlist.addPlayer(player);
            Packet packet = new ServerPlayMediaPacket(new Playlist.Tracks(playlist.getId(), playlist.getAudios(),
                    playlist.isPaused() || playlist.isStopped(), playlist.isLoop(), playlist.isShuffle()));
            sendPlayerPacket(player, packet);
        }
        onPlaylistStateChanged();
    }

    public void removePlayerFromPlaylist(ServerPlaylist<P> playlist, P player) {
        if (playlist.getPlayers().remove(player)) {
            sendPlayerPacket(player, new ServerPlayMediaPacket(new Playlist.Delete(playlist.getId())));
            onPlaylistStateChanged();
        }
    }

    public void pausePlaylist(ServerPlaylist<P> playlist, boolean paused) {
        playlist.setPaused(paused);
        Packet packet = new ServerPlayMediaPacket(new Playlist.Paused(playlist.getId(), paused));
        sendPlaylistPacket(playlist, packet);
        onPlaylistStateChanged();
    }

    public void shufflePlaylist(ServerPlaylist<P> playlist, boolean shuffle) {
        playlist.setShuffle(shuffle);
        Packet packet = new ServerPlayMediaPacket(new Playlist.Shuffled(playlist.getId(), shuffle));
        sendPlaylistPacket(playlist, packet);
        onPlaylistStateChanged();
    }

    public void loopPlaylist(ServerPlaylist<P> playlist, boolean loop) {
        playlist.setLoop(loop);
        Packet packet = new ServerPlayMediaPacket(new Playlist.Loop(playlist.getId(), loop));
        sendPlaylistPacket(playlist, packet);
        onPlaylistStateChanged();
    }

    public void skipPlaylist(ServerPlaylist<P> playlist, int direction) {
        Packet packet = new ServerPlayMediaPacket(new Playlist.Skip(playlist.getId(), direction));
        sendPlaylistPacket(playlist, packet);
    }

    public boolean jumpPlaylistToTrack(ServerPlaylist<P> playlist, int index) {
        if (index < 0 || index >= playlist.getAudios().size()) {
            return false;
        }
        Packet packet = new ServerPlayMediaPacket(new Playlist.Jump(playlist.getId(), index));
        sendPlaylistPacket(playlist, packet);
        return true;
    }
}
