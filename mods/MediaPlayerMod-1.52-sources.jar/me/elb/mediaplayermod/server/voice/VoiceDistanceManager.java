package me.elb.mediaplayermod.server.voice;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import me.elb.mediaplayermod.MediaPlayerMod;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Distancia maxima (en bloques) a la que cada jugador escucha el chat de proximidad. Es un ajuste
 * de SERVIDOR: no viaja al cliente, se aplica cancelando los paquetes de voz que vienen de mas
 * lejos (ver {@code MediaplayerVoicechatPlugin}).
 *
 * <p>El plugin lo lee desde sus hilos de audio (muchos paquetes por segundo con 100 jugadores), asi
 * que la consulta va contra un mapa inmutable publicado por {@code volatile}: leer nunca bloquea y
 * con el mapa vacio el filtro sale en la primera comprobacion. Las escrituras (comandos) ocurren en
 * el hilo del servidor.
 *
 * <p>Se persiste en {@code config/mediaplayer/voicedistance.json} para sobrevivir reinicios: cada
 * jugador conserva su limite al reconectar.
 */
public final class VoiceDistanceManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** Fuente de verdad: distancia en bloques por jugador. Solo se toca desde el hilo del servidor. */
    private static final Map<UUID, Double> distances = new HashMap<>();
    /** Cache publicada para los hilos de audio: distancia AL CUADRADO por jugador. */
    private static volatile Map<UUID, Double> squared = Map.of();
    private static File dataFile;

    private VoiceDistanceManager() {
    }

    /** Llamado al arrancar el servidor: fija el fichero y carga lo guardado. */
    public static void init(Path gameDir) {
        File dir = gameDir.resolve("config/mediaplayer").toFile();
        if (!dir.exists()) {
            dir.mkdirs();
        }
        dataFile = new File(dir, "voicedistance.json");
        load();
    }

    /** Fija el limite de escucha de un jugador. */
    public static void set(UUID player, double blocks) {
        distances.put(player, blocks);
        rebuild();
        persist();
    }

    /** Quita el limite de un jugador (vuelve al maximo del servidor). */
    public static void clear(UUID player) {
        if (distances.remove(player) != null) {
            rebuild();
            persist();
        }
    }

    /** ¿No hay ningun limite configurado? Permite al filtro salir en la primera comprobacion. */
    public static boolean isEmpty() {
        return squared.isEmpty();
    }

    /** Distancia al cuadrado a la que este jugador escucha, o null si no tiene limite. */
    public static Double squaredDistance(UUID player) {
        return squared.get(player);
    }

    /** Limite en bloques de un jugador, o null si no tiene. Para mostrarlo en feedback. */
    public static Double blocks(UUID player) {
        return distances.get(player);
    }

    private static void rebuild() {
        if (distances.isEmpty()) {
            squared = Map.of();
            return;
        }
        Map<UUID, Double> map = new HashMap<>();
        distances.forEach((uuid, blocks) -> map.put(uuid, blocks * blocks));
        squared = map;
    }

    private static void load() {
        if (dataFile == null || !dataFile.exists()) {
            return;
        }
        try (FileReader reader = new FileReader(dataFile)) {
            Type type = new TypeToken<Map<String, Double>>() {}.getType();
            Map<String, Double> saved = GSON.fromJson(reader, type);
            distances.clear();
            if (saved != null) {
                saved.forEach((key, value) -> {
                    if (value == null) {
                        return;
                    }
                    try {
                        distances.put(UUID.fromString(key), value);
                    } catch (IllegalArgumentException ignored) {
                        // uuid invalido en el json: se descarta
                    }
                });
            }
            rebuild();
            MediaPlayerMod.LOGGER.info("Loaded voice distance limits ({} players)", distances.size());
        } catch (IOException e) {
            MediaPlayerMod.LOGGER.error("Failed to load voicedistance.json", e);
        }
    }

    private static void persist() {
        if (dataFile == null) {
            return;
        }
        try (FileWriter writer = new FileWriter(dataFile)) {
            Map<String, Double> out = new HashMap<>();
            distances.forEach((uuid, blocks) -> out.put(uuid.toString(), blocks));
            GSON.toJson(out, writer);
        } catch (IOException e) {
            MediaPlayerMod.LOGGER.error("Failed to save voicedistance.json", e);
        }
    }
}
