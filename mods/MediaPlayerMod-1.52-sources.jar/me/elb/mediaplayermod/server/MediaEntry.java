package me.elb.mediaplayermod.server;

import me.elb.mediaplayermod.model.media.Media;

public record MediaEntry<P>(long start, Media media, boolean broadcastEveryone, P[] targets) {
}
