package me.elb.mediaplayermod.server;

import me.elb.mediaplayermod.model.media.MediaType;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.UUID;

@Getter
@RequiredArgsConstructor
public class MediaPlayerInfo<P> {
    protected final P player;
    protected final UUID uuid;
    protected final long startTime = System.currentTimeMillis();
    protected final MediaType type;
    protected final String parameters;
}
