package me.elb.mediaplayermod.server;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_9334;

public final class ProjectionWandManager {
    private ProjectionWandManager() {}

    private static final Map<UUID, class_2338> pos1Map = new HashMap<>();
    private static final Map<UUID, class_2338> pos2Map = new HashMap<>();

    public static class_1799 createWand() {
        class_1799 wand = new class_1799(class_1802.field_8894);
        wand.method_57379(class_9334.field_49631,
                class_2561.method_43470("Projection Wand").method_27694(s -> s.method_10977(class_124.field_1075).method_10978(false)));
        return wand;
    }

    public static boolean isWand(class_1799 stack) {
        if (!stack.method_31574(class_1802.field_8894)) return false;
        class_2561 name = stack.method_57824(class_9334.field_49631);
        return name != null && name.getString().equals("Projection Wand");
    }

    public static void setPos1(UUID player, class_2338 pos) {
        pos1Map.put(player, pos);
    }

    public static void setPos2(UUID player, class_2338 pos) {
        pos2Map.put(player, pos);
    }

    public static class_2338 getPos1(UUID player) {
        return pos1Map.get(player);
    }

    public static class_2338 getPos2(UUID player) {
        return pos2Map.get(player);
    }

    public static boolean hasSelection(UUID player) {
        return pos1Map.containsKey(player) && pos2Map.containsKey(player);
    }

    public static void clear(UUID player) {
        pos1Map.remove(player);
        pos2Map.remove(player);
    }
}
