package me.elb.mediaplayermod.server;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.model.media.Projection;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Path;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class
ServerProjectionManager {
    private ServerProjectionManager() {}

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Map<String, Projection> active = new LinkedHashMap<>();
    /** Estado de reproduccion en tiempo real por proyeccion (no es la geometria). */
    private static final Map<String, PlaybackState> states = new LinkedHashMap<>();
    private static File dataFile;

    /**
     * Estado de reproduccion de una proyeccion. {@code startEpochMs} es el instante de reloj
     * que corresponde a la posicion 0 del video; asi la posicion actual = now - startEpochMs.
     */
    private static final class PlaybackState {
        boolean stopped;
        boolean paused;
        boolean loop;
        long startEpochMs;       // epoch correspondiente a la posicion 0
        long pausedPositionMs;   // posicion congelada mientras esta en pausa

        long elapsedMs(long now) {
            if (stopped) return 0;
            return paused ? pausedPositionMs : Math.max(0, now - startEpochMs);
        }
    }

    public static void init(Path gameDir) {
        File dir = gameDir.resolve("config/mediaplayer").toFile();
        if (!dir.exists()) dir.mkdirs();
        dataFile = new File(dir, "projections.json");
        load();
    }

    public static void add(Projection projection) {
        active.put(projection.id(), projection);
        persist();
    }

    /** Marca que el video de una proyeccion arranca ahora desde el inicio (create / play). */
    public static void markStarted(String id) {
        PlaybackState s = states.computeIfAbsent(id, k -> new PlaybackState());
        s.stopped = false;
        s.paused = false;
        s.pausedPositionMs = 0;
        s.startEpochMs = System.currentTimeMillis();
        persist();
    }

    public static void markStopped(String id) {
        PlaybackState s = states.get(id);
        if (s == null) return;
        s.stopped = true;
        s.paused = false;
        persist();
    }

    public static void markAllStopped() {
        states.values().forEach(s -> { s.stopped = true; s.paused = false; });
        persist();
    }

    public static void markPaused(String id) {
        PlaybackState s = states.get(id);
        if (s == null || s.stopped || s.paused) return;
        s.pausedPositionMs = Math.max(0, System.currentTimeMillis() - s.startEpochMs);
        s.paused = true;
        persist();
    }

    public static void markResumed(String id) {
        PlaybackState s = states.get(id);
        // Tras un stop la pantalla queda sin video en los clientes; para volver a reproducir
        // se usa /playprojection play. Aqui solo reanudamos una pausa real.
        if (s == null || s.stopped || !s.paused) return;
        s.startEpochMs = System.currentTimeMillis() - s.pausedPositionMs;
        s.paused = false;
        persist();
    }

    public static void setLoop(String id, boolean loop) {
        PlaybackState s = states.computeIfAbsent(id, k -> new PlaybackState());
        s.loop = loop;
        persist();
    }

    public static void remove(String id) {
        active.remove(id);
        states.remove(id);
        persist();
    }

    public static void removeAll() {
        active.clear();
        states.clear();
        persist();
    }

    public static Collection<Projection> getAll() {
        return Collections.unmodifiableCollection(active.values());
    }

    public static boolean has(String id) {
        return active.containsKey(id);
    }

    public static List<String> listIds() {
        return List.copyOf(active.keySet());
    }

    // --- Consultas de estado para la sincronizacion en el JOIN ---

    public static boolean hasState(String id) {
        return states.containsKey(id);
    }

    public static boolean isStopped(String id) {
        PlaybackState s = states.get(id);
        return s != null && s.stopped;
    }

    public static boolean isPaused(String id) {
        PlaybackState s = states.get(id);
        return s != null && s.paused;
    }

    public static boolean isLoop(String id) {
        PlaybackState s = states.get(id);
        return s != null && s.loop;
    }

    /** Tiempo real transcurrido (ms) desde el inicio del video; el cliente decide como aplicarlo. */
    public static long elapsedMs(String id) {
        PlaybackState s = states.get(id);
        return s == null ? 0 : s.elapsedMs(System.currentTimeMillis());
    }

    private static void load() {
        if (dataFile == null || !dataFile.exists()) return;
        try (FileReader reader = new FileReader(dataFile)) {
            Type type = new TypeToken<List<ProjectionJson>>() {}.getType();
            List<ProjectionJson> list = GSON.fromJson(reader, type);
            if (list != null) {
                long now = System.currentTimeMillis();
                for (ProjectionJson pj : list) {
                    active.put(pj.id, new Projection(pj.id, pj.url, pj.x1, pj.y1, pj.z1, pj.x2, pj.y2, pj.z2,
                            pj.rotX, pj.rotY, pj.rotZ, pj.chromaKey, pj.chromaColor == 0 ? 0x00FF00 : pj.chromaColor, pj.chromaTolerance <= 0 ? 0.25f : pj.chromaTolerance));
                    PlaybackState s = new PlaybackState();
                    s.stopped = pj.stopped;
                    s.paused = pj.paused;
                    s.loop = pj.loop;
                    s.pausedPositionMs = Math.max(0, pj.positionMs);
                    // Al recargar (p.ej. reentrar al mundo) se retoma desde la posicion guardada.
                    s.startEpochMs = now - Math.max(0, pj.positionMs);
                    states.put(pj.id, s);
                }
            }
            MediaPlayerMod.LOGGER.info("Loaded {} saved projections", active.size());
        } catch (IOException e) {
            MediaPlayerMod.LOGGER.error("Failed to load projections.json", e);
        }
    }

    private static void persist() {
        if (dataFile == null) return;
        long now = System.currentTimeMillis();
        try (FileWriter writer = new FileWriter(dataFile)) {
            List<ProjectionJson> list = active.values().stream()
                    .map(p -> {
                        PlaybackState s = states.get(p.id());
                        boolean stopped = s != null && s.stopped;
                        boolean paused = s != null && s.paused;
                        boolean loop = s != null && s.loop;
                        long pos = s == null ? 0 : s.elapsedMs(now);
                        return new ProjectionJson(p.id(), p.url(), p.x1(), p.y1(), p.z1(), p.x2(), p.y2(), p.z2(),
                                p.rotX(), p.rotY(), p.rotZ(), stopped, paused, loop, pos,
                                p.chromaKey(), p.chromaColor(), p.chromaTolerance());
                    })
                    .toList();
            GSON.toJson(list, writer);
        } catch (IOException e) {
            MediaPlayerMod.LOGGER.error("Failed to save projections.json", e);
        }
    }

    private static class ProjectionJson {
        String id, url;
        int x1, y1, z1, x2, y2, z2, rotX, rotY, rotZ;
        boolean stopped, paused, loop;
        long positionMs;
        boolean chromaKey;
        int chromaColor;
        float chromaTolerance;
        ProjectionJson(String id, String url, int x1, int y1, int z1, int x2, int y2, int z2, int rotX, int rotY, int rotZ,
                       boolean stopped, boolean paused, boolean loop, long positionMs,
                       boolean chromaKey, int chromaColor, float chromaTolerance) {
            this.id = id; this.url = url;
            this.x1 = x1; this.y1 = y1; this.z1 = z1;
            this.x2 = x2; this.y2 = y2; this.z2 = z2;
            this.rotX = rotX; this.rotY = rotY; this.rotZ = rotZ;
            this.stopped = stopped; this.paused = paused; this.loop = loop;
            this.positionMs = positionMs;
            this.chromaKey = chromaKey; this.chromaColor = chromaColor; this.chromaTolerance = chromaTolerance;
        }
    }
}
