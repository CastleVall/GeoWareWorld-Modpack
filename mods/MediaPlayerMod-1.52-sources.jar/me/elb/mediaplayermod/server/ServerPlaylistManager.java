package me.elb.mediaplayermod.server;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.model.media.Audio;
import me.elb.mediaplayermod.playlist.ServerPlaylist;
import net.minecraft.class_3222;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

public final class ServerPlaylistManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static File dataDir;

    private ServerPlaylistManager() {
    }

    public static void init(Path gameDir) {
        dataDir = gameDir.resolve("config/mediaplayer/playlists").toFile();
        if (!dataDir.exists()) {
            dataDir.mkdirs();
        }
    }

    public static List<ServerPlaylist<class_3222>> load() {
        List<ServerPlaylist<class_3222>> playlists = new ArrayList<>();
        if (dataDir == null || !dataDir.exists()) {
            return playlists;
        }

        File[] files = dataDir.listFiles((dir, name) -> name.endsWith(".json"));
        if (files == null) {
            return playlists;
        }

        for (File file : files) {
            try (FileReader reader = new FileReader(file)) {
                PlaylistJson json = GSON.fromJson(reader, PlaylistJson.class);
                if (json == null || json.id == null) continue;
                ServerPlaylist<class_3222> playlist = new ServerPlaylist<>(json.id);
                if (json.tracks != null) {
                    for (AudioJson track : json.tracks) {
                        playlist.addAudio(new Audio(track.url, track.backupUrl, track.name));
                    }
                }
                playlist.setBroadcastEveryone(json.broadcastEveryone);
                playlist.setPaused(json.paused);
                playlist.setLoop(json.loop);
                playlist.setShuffle(json.shuffle);
                playlists.add(playlist);
            } catch (IOException e) {
                MediaPlayerMod.LOGGER.error("Failed to load playlist file: {}", file.getName(), e);
            }
        }

        MediaPlayerMod.LOGGER.info("Loaded {} saved playlists", playlists.size());
        return playlists;
    }

    public static void persist(Collection<ServerPlaylist<class_3222>> playlists) {
        if (dataDir == null) return;

        File[] existing = dataDir.listFiles((dir, name) -> name.endsWith(".json"));
        if (existing != null) {
            for (File f : existing) {
                String fileId = f.getName().replace(".json", "");
                boolean found = playlists.stream().anyMatch(p -> sanitize(p.getId()).equals(fileId));
                if (!found) {
                    f.delete();
                }
            }
        }
        for (ServerPlaylist<class_3222> playlist : playlists) {
            persistOne(playlist);
        }
    }

    public static void persistOne(ServerPlaylist<class_3222> playlist) {
        if (dataDir == null) return;
        File file = new File(dataDir, sanitize(playlist.getId()) + ".json");
        try (FileWriter writer = new FileWriter(file)) {
            PlaylistJson json = new PlaylistJson();
            json.id = playlist.getId();
            json.broadcastEveryone = playlist.isBroadcastEveryone();
            json.paused = playlist.isPaused();
            json.loop = playlist.isLoop();
            json.shuffle = playlist.isShuffle();
            json.tracks = new LinkedList<>();
            for (Audio audio : playlist.getAudios()) {
                AudioJson track = new AudioJson();
                track.url = audio.url();
                track.backupUrl = audio.backupUrl();
                track.name = audio.name();
                json.tracks.add(track);
            }
            GSON.toJson(json, writer);
        } catch (IOException e) {
            MediaPlayerMod.LOGGER.error("Failed to save playlist: {}", playlist.getId(), e);
        }
    }

    public static void delete(String id) {
        if (dataDir == null) return;
        File file = new File(dataDir, sanitize(id) + ".json");
        if (file.exists()) {
            file.delete();
        }
    }

    private static String sanitize(String id) {
        return id.replaceAll("[^a-zA-Z0-9_\\-]", "_");
    }

    private static class PlaylistJson {
        String id;
        List<AudioJson> tracks = new ArrayList<>();
        boolean broadcastEveryone;
        boolean paused;
        boolean loop;
        boolean shuffle;
    }

    private static class AudioJson {
        String url;
        String backupUrl;
        String name;
    }
}
