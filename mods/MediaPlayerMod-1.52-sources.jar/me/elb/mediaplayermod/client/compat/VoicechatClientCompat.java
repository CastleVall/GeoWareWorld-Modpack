package me.elb.mediaplayermod.client.compat;

import de.maxhenkel.voicechat.VoicechatClient;
import de.maxhenkel.voicechat.config.ClientConfig;
import de.maxhenkel.voicechat.voice.client.KeyEvents;
import de.maxhenkel.voicechat.voice.client.MicrophoneActivationType;
import me.elb.mediaplayermod.MediaPlayerMod;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import java.util.Locale;

/**
 * Aplica ajustes de Simple Voice Chat en el cliente. Referencia clases del mod "voicechat"
 * directamente, asi que SOLO debe llamarse tras comprobar que ese mod esta cargado.
 */
public final class VoicechatClientCompat {

    private VoicechatClientCompat() {
    }

    public static void apply(class_310 client, String setting, String value) {
        try {
            ClientConfig cfg = VoicechatClient.CLIENT_CONFIG;
            if (cfg == null) {
                return; // voicechat presente pero todavia sin inicializar
            }
            switch (setting) {
                case "mode" -> cfg.microphoneActivationType.set(
                        "freevoice".equals(value) ? MicrophoneActivationType.VOICE : MicrophoneActivationType.PTT).save();
                case "key" -> setPttKey(client, value);
                case "volume" -> cfg.voiceChatVolume.set(Integer.parseInt(value) / 100D).save();
                case "gain" -> cfg.microphoneGain.set(gainPercentToDb(Integer.parseInt(value))).save();
                case "sensitivity" -> cfg.voiceActivationThreshold.set(Double.parseDouble(value)).save();
                case "vad" -> cfg.vad.set(Boolean.parseBoolean(value)).save();
                case "mute" -> cfg.muted.set(Boolean.parseBoolean(value)).save();
                case "enabled" -> cfg.disabled.set(!Boolean.parseBoolean(value)).save();
                case "denoiser" -> cfg.denoiser.set(Boolean.parseBoolean(value)).save();
                case "reset" -> reset(client, cfg);
                default -> MediaPlayerMod.LOGGER.warn("Ajuste de voicechat desconocido: {}", setting);
            }
        } catch (Throwable e) {
            MediaPlayerMod.LOGGER.error("Error aplicando ajuste de voicechat '{}'", setting, e);
        }
    }

    /** Valores actuales de los ajustes que controla el mod, para responder a /clientoptions get. */
    public static String describe() {
        try {
            ClientConfig cfg = VoicechatClient.CLIENT_CONFIG;
            if (cfg == null) {
                return "(voicechat aun sin inicializar)";
            }
            return "\n - mode : " + (cfg.microphoneActivationType.get() == MicrophoneActivationType.VOICE
                    ? "freevoice" : "pushtotalk")
                    + "\n - key : " + KeyEvents.KEY_PTT.method_16007().getString()
                    + "\n - volume : " + Math.round(cfg.voiceChatVolume.get() * 100) + "%"
                    + "\n - gain : " + gainDbToPercent(cfg.microphoneGain.get()) + "%"
                    + "\n - sensitivity : " + cfg.voiceActivationThreshold.get() + " dB"
                    + "\n - vad : " + cfg.vad.get()
                    + "\n - mute : " + cfg.muted.get()
                    + "\n - enabled : " + !cfg.disabled.get()
                    + "\n - denoiser : " + cfg.denoiser.get();
        } catch (Throwable e) {
            MediaPlayerMod.LOGGER.error("Error leyendo ajustes de voicechat", e);
            return "(error leyendo los ajustes)";
        }
    }

    /**
     * SVC guarda la ganancia del microfono en decibelios (-40 = mudo, 0 = normal, +24 = maximo),
     * pero el comando la expone como porcentaje (100 = normal). Conversion: dB = 20*log10(pct/100).
     */
    private static double gainPercentToDb(int percent) {
        if (percent <= 0) {
            return -40.0D;
        }
        return Math.clamp(20.0D * Math.log10(percent / 100.0D), -40.0D, 24.0D);
    }

    private static long gainDbToPercent(double db) {
        if (db <= -40.0D) {
            return 0L;
        }
        return Math.round(Math.pow(10.0D, db / 20.0D) * 100.0D);
    }

    /** Vuelve a los valores por defecto de Simple Voice Chat (no a los que tenia el jugador antes). */
    private static void reset(class_310 client, ClientConfig cfg) {
        cfg.microphoneActivationType.reset().save();
        cfg.voiceChatVolume.reset().save();
        cfg.microphoneGain.reset().save();
        cfg.voiceActivationThreshold.reset().save();
        cfg.vad.reset().save();
        cfg.muted.reset().save();
        cfg.disabled.reset().save();
        cfg.denoiser.reset().save();
        KeyEvents.KEY_PTT.method_1422(KeyEvents.KEY_PTT.method_1429());
        class_304.method_1426();
        client.field_1690.method_1640();
    }

    private static void setPttKey(class_310 client, String name) {
        class_3675.class_306 key;
        try {
            key = parseKey(name);
        } catch (IllegalArgumentException e) {
            MediaPlayerMod.LOGGER.warn("Tecla desconocida para voicechat: {}", name);
            if (client.field_1724 != null) {
                client.field_1724.method_7353(class_2561.method_43470("§c[MediaPlayer] Tecla desconocida: §7" + name), false);
            }
            return;
        }
        KeyEvents.KEY_PTT.method_1422(key);
        class_304.method_1426();
        client.field_1690.method_1640();
    }

    /** Acepta "v", "f4", "left.shift", "mouse4", "mouse.left", "none" o una translation key completa. */
    private static class_3675.class_306 parseKey(String name) {
        String n = name.toLowerCase(Locale.ROOT).trim();
        if (n.equals("none")) {
            return class_3675.field_16237;
        }
        if (n.startsWith("key.")) {
            return class_3675.method_15981(n);
        }
        if (n.startsWith("mouse")) {
            String button = n.substring("mouse".length());
            if (button.startsWith(".")) {
                button = button.substring(1);
            }
            return class_3675.method_15981("key.mouse." + button);
        }
        return class_3675.method_15981("key.keyboard." + n);
    }
}
