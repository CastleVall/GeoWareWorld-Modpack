package me.elb.mediaplayermod.client.sound;

import dev.stashy.soundcategories.CategoryLoader;
import net.minecraft.class_3419;

public class MediaSoundCategory implements CategoryLoader {
    @Register(master = true, id = "video")
    public static class_3419 VIDEO;

    @Register(master = true, id = "audio")
    public static class_3419 AUDIO;

    @Register(master = true, id = "projection")
    public static class_3419 PROJECTION;
}
