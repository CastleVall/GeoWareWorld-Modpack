package me.elb.mediaplayermod.client.sound;

import lombok.experimental.UtilityClass;
import net.minecraft.class_310;
import net.minecraft.class_3419;

@UtilityClass
public class VolumeUtil {
    public static float getMediaVolume(class_310 client, class_3419 soundCategory) {
        return client.field_1690.method_1630(class_3419.field_15250) * client.field_1690.method_1630(soundCategory);
    }

    /**
     * Volumen para reproductores VLC en escala 0..100. En VLC 100 es el volumen normal y valores
     * mayores AMPLIFICAN por encima del original: la antigua escala 0..200 hacia que todo el rango
     * de sliders entre 50% y 100% sonara igual de fuerte (>=100) y no se percibiera ningun cambio.
     */
    public static int getPlayerVolume(class_310 client, class_3419 soundCategory) {
        return Math.round(getMediaVolume(client, soundCategory) * 100);
    }

    public static void updateVolume(class_310 client, class_3419 soundCategory, float volume) {
        client.field_1690.method_45578(soundCategory).method_41748((double) volume);
        client.method_1483().method_4865(soundCategory, volume);
    }
}
