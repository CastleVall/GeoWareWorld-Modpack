package me.elb.mediaplayermod.client.sound;

import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.client.ClientHandler;
import me.elb.mediaplayermod.client.URLUtil;
import me.elb.mediaplayermod.client.VLCUtil;
import me.elb.mediaplayermod.client.search.SongSearchClient;
import me.elb.mediaplayermod.model.media.Audio;
import net.minecraft.class_310;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.watermedia.api.player.videolan.MusicPlayer;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

@Getter
@RequiredArgsConstructor
public class ClientPlaylist {
    private static final long END_TOLERANCE_MS = 1500L;

    private final String id;
    private final LinkedList<Audio> audios;
    private final MusicPlayer musicPlayer = VLCUtil.createMusicPlayer();
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    private ScheduledFuture<?> nextScheduledTask;
    private final AtomicInteger currentAudioIndex = new AtomicInteger(0);
    private boolean loop = false;
    private boolean finished = false;
    private boolean started = false;
    private volatile boolean loading = false;
    private int customVolumeFactor = 100;
    private volatile long lastKnownDuration = 0L;
    private volatile long lastKnownPosition = 0L;

    private long getShufflerSeed() {
        return id.hashCode();
    }

    public void start() {
        MediaPlayerMod.LOGGER.info("Iniciando la cola de reproducción: {}", id);
        if (audios.isEmpty()) {
            MediaPlayerMod.LOGGER.warn("Se ha intentado iniciar una cola de reproducción vacía");
            return;
        }
        started = true;
        finished = false;
        currentAudioIndex.set(0);
        playCurrentAudio();
    }

    private void playCurrentAudio() {
        try {
            cancelPlaybackMonitor();
            loading = true;
            lastKnownDuration = 0L;
            lastKnownPosition = 0L;
            Audio current = audios.get(currentAudioIndex.get());
            URI uri = URLUtil.loadUri(current.url());
            musicPlayer.start(uri);
            musicPlayer.setRepeatMode(loop && audios.size() == 1);
            class_310.method_1551().execute(ClientHandler::hidePlaylistLyrics);
            String lyricsUrl = current.lyricsUrl();
            if (lyricsUrl != null && !lyricsUrl.isEmpty()) {
                class_310.method_1551().execute(() -> ClientHandler.showPlaylistLyrics(lyricsUrl, 0L));
            }
            final ScheduledFuture<?>[] checkReadyTask = new ScheduledFuture<?>[1];
            checkReadyTask[0] = scheduler.scheduleAtFixedRate(() -> {
                if (musicPlayer.isReady()) {
                    loading = false;
                    lastKnownDuration = Math.max(lastKnownDuration, musicPlayer.getMediaInfoDuration());
                    lastKnownPosition = Math.max(0L, musicPlayer.getTime());
                    MediaPlayerMod.LOGGER.info("Reproduciendo '{}' con duración de {} ms",
                            uri.getPath(), musicPlayer.getMediaInfoDuration());
                    class_310.method_1551().execute(ClientHandler::notifyPlaylistLyricsReady);
                    if ((lyricsUrl == null || lyricsUrl.isEmpty())
                            && current.name() != null && !current.name().isBlank()) {
                        int durSecs = lastKnownDuration > 0 ? (int) (lastKnownDuration / 1000) : 0;
                        String trackName = current.name();
                        int indexSnapshot = currentAudioIndex.get();
                        SongSearchClient.fetchAndSaveLyrics(trackName, "", durSecs)
                                .thenAccept(path -> {
                                    if (path != null && currentAudioIndex.get() == indexSnapshot) {
                                        class_310.method_1551().execute(
                                                () -> ClientHandler.showPlaylistLyrics(path, 0L));
                                    }
                                });
                    }
                    startPlaybackMonitor();
                    checkReadyTask[0].cancel(true);
                }
            }, 0, 30, TimeUnit.MILLISECONDS);
        } catch (MalformedURLException | URISyntaxException e) {
            loading = false;
            MediaPlayerMod.LOGGER.error("Error al cargar la siguiente canción", e);
        }
    }

    public void stop() {
        musicPlayer.stop();
        cancelPlaybackMonitor();
        scheduler.shutdownNow();
        class_310.method_1551().execute(ClientHandler::hidePlaylistLyrics);
    }

    public void addAudio(Audio audio) {
        MediaPlayerMod.LOGGER.info("Añadiendo canción a la cola: {}", audio.url());
        audios.add(audio);
    }

    public void removeAudio(int index) {
        if (index < 0 || index >= audios.size()) {
            MediaPlayerMod.LOGGER.warn("Índice fuera de rango: {}", index);
            return;
        }
        MediaPlayerMod.LOGGER.info("Eliminando canción de la cola: {}", audios.get(index).url());
        audios.remove(index);
        if (audios.isEmpty()) {
            currentAudioIndex.set(0);
            finished = true;
            musicPlayer.stop();
            cancelPlaybackMonitor();
            return;
        }
        int current = currentAudioIndex.get();
        if (index < current) {
            currentAudioIndex.decrementAndGet();
        } else if (index == current) {
            cancelPlaybackMonitor();
            currentAudioIndex.set(Math.min(current, audios.size() - 1));
            musicPlayer.stop();
            playCurrentAudio();
        }
    }

    public void moveAudio(int from, int to) {
        if (from < 0 || from >= audios.size() || to < 0 || to >= audios.size() || from == to) {
            MediaPlayerMod.LOGGER.warn("Movimiento fuera de rango: {} -> {}", from, to);
            return;
        }
        Audio audio = audios.remove(from);
        audios.add(to, audio);
        int current = currentAudioIndex.get();
        if (current == from) {
            currentAudioIndex.set(to);
        } else if (from < current && to >= current) {
            currentAudioIndex.decrementAndGet();
        } else if (from > current && to <= current) {
            currentAudioIndex.incrementAndGet();
        }
    }

    public void setPaused(boolean paused) {
        if (paused) {
            if (started) {
                musicPlayer.pause();
                cancelPlaybackMonitor();
            }
        } else {
            if (!started) {
                start();
            } else {
                musicPlayer.play();
                startPlaybackMonitor();
            }
        }
    }

    public void setShuffle(boolean shuffle) {
        if (shuffle) {
            MediaPlayerMod.LOGGER.info("Lista de reproducción reorganizada");
            audios.sort((a, b) -> {
                long seed = getShufflerSeed();
                return Long.compare(a.hashCode() * seed, b.hashCode() * seed);
            });
        }
    }

    public void setLoop(boolean loop) {
        MediaPlayerMod.LOGGER.info("Reproducción en bucle: {}", loop);
        this.loop = loop;
        musicPlayer.setRepeatMode(loop && audios.size() == 1);
    }

    public boolean isFinished() {
        if (audios.isEmpty() || musicPlayer.isBroken()) {
            return true;
        }
        if (audios.size() == 1) {
            return hasTrackEnded();
        }
        return finished;
    }

    public void skipNext() {
        if (audios.isEmpty()) return;
        cancelPlaybackMonitor();
        int next = currentAudioIndex.get() + 1;
        if (next < audios.size()) {
            currentAudioIndex.set(next);
        } else if (loop) {
            currentAudioIndex.set(0);
        } else {
            return;
        }
        started = true;
        finished = false;
        musicPlayer.stop();
        playCurrentAudio();
    }

    public void skipPrev() {
        if (audios.isEmpty()) return;
        cancelPlaybackMonitor();
        int prev = currentAudioIndex.get() - 1;
        if (prev >= 0) {
            currentAudioIndex.set(prev);
        } else if (loop) {
            currentAudioIndex.set(audios.size() - 1);
        } else {
            return;
        }
        started = true;
        finished = false;
        musicPlayer.stop();
        playCurrentAudio();
    }

    public void playIndex(int index) {
        if (index < 0 || index >= audios.size()) {
            MediaPlayerMod.LOGGER.warn("Indice fuera de rango para reproducir: {}", index);
            return;
        }
        cancelPlaybackMonitor();
        started = true;
        currentAudioIndex.set(index);
        finished = false;
        musicPlayer.stop();
        playCurrentAudio();
    }

    public void seekTo(long position) {
        if (!started || !musicPlayer.isReady()) {
            return;
        }
        long duration = musicPlayer.getMediaInfoDuration();
        if (duration <= 0) {
            return;
        }
        long clamped = Math.max(0L, Math.min(position, duration));
        musicPlayer.seekTo(clamped);
    }

    public void setCustomVolumeFactor(int factor) {
        customVolumeFactor = Math.max(0, Math.min(200, factor));
    }

    public void applyGlobalVolume(int globalVolume) {
        musicPlayer.setVolume(Math.min(200, globalVolume * customVolumeFactor / 100));
    }

    public void updateTracks(List<Audio> list) {
        MediaPlayerMod.LOGGER.info("Actualizando la lista de reproducción");
        audios.clear();
        audios.addAll(list);
        currentAudioIndex.set(0);
    }

    private void startPlaybackMonitor() {
        cancelPlaybackMonitor();
        nextScheduledTask = scheduler.scheduleAtFixedRate(() -> {
            if (musicPlayer.isBroken()) {
                finished = true;
                cancelPlaybackMonitor();
                return;
            }
            if (musicPlayer.isReady()) {
                lastKnownDuration = Math.max(lastKnownDuration, musicPlayer.getMediaInfoDuration());
                lastKnownPosition = Math.max(lastKnownPosition, musicPlayer.getTime());
            }
            if (hasTrackEnded()) {
                cancelPlaybackMonitor();
                advanceAfterTrackEnd();
            }
        }, 100, 100, TimeUnit.MILLISECONDS);
    }

    private void advanceAfterTrackEnd() {
        cancelPlaybackMonitor();
        MediaPlayerMod.LOGGER.info("Reproducción de la canción terminada, decidiendo la siguiente acción");
        if (audios.isEmpty()) {
            finished = true;
            return;
        }
        if (currentAudioIndex.get() + 1 < audios.size()) {
            MediaPlayerMod.LOGGER.info("Reproduciendo la siguiente canción");
            currentAudioIndex.incrementAndGet();
            playCurrentAudio();
        } else if (loop) {
            MediaPlayerMod.LOGGER.info("Reproduciendo la primera canción de nuevo");
            currentAudioIndex.set(0);
            playCurrentAudio();
        } else {
            MediaPlayerMod.LOGGER.info("Reproducción terminada");
            finished = true;
        }
    }

    private void cancelPlaybackMonitor() {
        if (nextScheduledTask != null) {
            nextScheduledTask.cancel(true);
            nextScheduledTask = null;
        }
    }

    private boolean hasTrackEnded() {
        if (musicPlayer.isBroken()) {
            return true;
        }
        if (musicPlayer.isEnded()) {
            return true;
        }
        if (!musicPlayer.isReady() && lastKnownDuration > 0L && lastKnownPosition > 0L) {
            return (lastKnownDuration - lastKnownPosition) <= END_TOLERANCE_MS;
        }
        return false;
    }
}
