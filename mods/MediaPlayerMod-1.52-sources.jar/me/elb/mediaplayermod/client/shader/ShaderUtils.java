package me.elb.mediaplayermod.client.shader;

import com.mojang.blaze3d.systems.RenderSystem;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.model.option.ShaderOption;
import net.minecraft.class_279;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import lombok.Getter;
import lombok.experimental.UtilityClass;
import java.io.IOException;

@UtilityClass
public class ShaderUtils {
    @Getter
    private static ShaderOption.Shaders currentShader = ShaderOption.Shaders.NONE;
    private static class_279 postEffectProcessor;

    public static void loadShader(ShaderOption.Shaders shader) {
        currentShader = shader;
        class_310 client = class_310.method_1551();
        client.execute(() -> {
            if (postEffectProcessor != null) {
                postEffectProcessor.close();
                postEffectProcessor = null;
            }
            if (shader == ShaderOption.Shaders.NONE) {
                return;
            }
            try {
                postEffectProcessor = new class_279(client.method_1531(), client.method_1478(),
                        client.method_1522(), class_2960.method_60654(shader.getPath()));
                updateDimensions();
            } catch (IOException e) {
                MediaPlayerMod.LOGGER.error("Error loading shader", e);
                currentShader = ShaderOption.Shaders.NONE;
            }
        });
    }

    public static void render() {
        if (postEffectProcessor != null) {
            RenderSystem.disableBlend();
            RenderSystem.disableDepthTest();
            RenderSystem.resetTextureMatrix();
            postEffectProcessor.method_1258(class_310.method_1551().method_60646().method_60637(false));
        }
    }

    public static void updateDimensions() {
        if (postEffectProcessor != null) {
            class_310 client = class_310.method_1551();
            postEffectProcessor.method_1259(client.method_22683().method_4489(),
                    client.method_22683().method_4506());
        }
    }
}
