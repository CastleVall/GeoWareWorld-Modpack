package me.elb.mediaplayermod.client.shader;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_284;
import net.minecraft.class_5944;

/**
 * Core shader que elimina un color de fondo (chroma key / pantalla verde) de los frames de video.
 * Se registra en {@code MediaPlayerModClient} via CoreShaderRegistrationCallback.
 */
public final class ChromaShader {
    private ChromaShader() {}

    /** Programa cargado por Minecraft; null hasta que se registra. */
    public static volatile class_5944 program;

    public static boolean isReady() {
        return program != null;
    }

    /**
     * Activa el shader con el color clave (RGB empaquetado), la tolerancia y el alpha global.
     * Debe llamarse justo antes de dibujar el quad del video.
     */
    public static void bind(int rgb, float tolerance, float alpha) {
        class_5944 p = program;
        if (p == null) return;
        float r = ((rgb >> 16) & 0xFF) / 255f;
        float g = ((rgb >> 8) & 0xFF) / 255f;
        float b = (rgb & 0xFF) / 255f;

        RenderSystem.setShader(() -> p);
        class_284 key = p.method_34582("ChromaKey");
        if (key != null) key.method_1249(r, g, b);
        class_284 params = p.method_34582("ChromaParams");
        if (params != null) params.method_1255(Math.max(0f, tolerance), 0.08f);
        RenderSystem.setShaderColor(1f, 1f, 1f, alpha);
    }
}
