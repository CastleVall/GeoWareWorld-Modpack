package me.elb.mediaplayermod.client;

import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.client.ClientHandler;
import me.elb.mediaplayermod.client.fog.FogUtils;
import me.elb.mediaplayermod.client.render.ProjectionHandler;
import me.elb.mediaplayermod.client.playlist.PlaylistAdminState;
import me.elb.mediaplayermod.client.sound.MediaSoundCategory;
import me.elb.mediaplayermod.client.sound.VolumeUtil;
import me.elb.mediaplayermod.model.media.MediaType;
import me.elb.mediaplayermod.model.option.*;
import me.elb.mediaplayermod.networking.packet.*;
import me.elb.mediaplayermod.client.gui.screen.PlaylistAdminScreen;
import me.elb.mediaplayermod.client.shader.ShaderUtils;
import me.elb.mediaplayermod.payload.MediaPayload;
import me.elb.mediaplayermod.cameraplayer.ScreenStreamClientManager;
import me.elb.mediaplayermod.cameraplayer.ScreenNetworkPayloads.*;
import me.elb.mediaplayermod.cameraplayer.client.render.OverlayManager;
import me.elb.mediaplayermod.cameraplayer.client.render.StreamScreenEntityRenderer;
import me.elb.mediaplayermod.cameraplayer.client.render.CameraEntityRenderer;
import me.elb.mediaplayermod.cameraplayer.client.gui.EffectsScreen;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1659;
import net.minecraft.class_1664;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3283;
import net.minecraft.class_3419;
import net.minecraft.class_3675;
import net.minecraft.class_4063;
import net.minecraft.class_4066;
import net.minecraft.class_410;
import net.minecraft.class_5498;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MediaPlayerModClient implements ClientModInitializer {
    public static final class_3419[] ALL_SOUND_CATEGORIES;
    public static class_304 volumeUpKeyBinding;
    public static class_304 volumeDownKeyBinding;
    private class_304 toggleSubtitlesKeyBinding;
    private class_304 openPlaylistKeyBinding;

    static {
        List<class_3419> list = new ArrayList<>(Stream.of(class_3419.values()).toList());
        list.add(MediaSoundCategory.VIDEO);
        list.add(MediaSoundCategory.AUDIO);
        list.add(MediaSoundCategory.PROJECTION);
        ALL_SOUND_CATEGORIES = list.toArray(new class_3419[0]);
    }

    @Override
    public void onInitializeClient() {
        createLocalMediaFolders();
        setupSubtitleExample();
        setupTutorialExample();
        setupCountdownDefaults();

        // Core shader de chroma key (videos con fondo transparente).
        net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback.EVENT.register(context ->
                context.register(
                        net.minecraft.class_2960.method_60655(MediaPlayerMod.MOD_ID, "chroma_key"),
                        net.minecraft.class_290.field_1585,
                        program -> me.elb.mediaplayermod.client.shader.ChromaShader.program = program));

        ScreenStreamClientManager.startWebSocket();
        OverlayManager.setupFolders();
        me.elb.mediaplayermod.cameraplayer.client.video.VideoManager.setupFolders();

        EntityRendererRegistry.register(MediaPlayerMod.STREAM_SCREEN_ENTITY, StreamScreenEntityRenderer::new);
        EntityRendererRegistry.register(MediaPlayerMod.CAMERA_ENTITY, CameraEntityRenderer::new);

        net.minecraft.class_3929.method_17542(
                me.elb.mediaplayermod.screenhandler.ModScreenHandlers.SHARED_INVENTORY,
                me.elb.mediaplayermod.client.gui.screen.SharedInventoryScreen::new);

        ClientPlayNetworking.registerGlobalReceiver(FrameS2CPayload.ID, (payload, context) -> {
            context.client().execute(() -> ScreenStreamClientManager.handleRemoteFrame(
                    payload.streamer(), payload.frameId(), payload.index(), payload.total(), payload.chunk()));
        });

        ClientPlayNetworking.registerGlobalReceiver(CameraPovPayload.ID, (payload, context) -> {
            context.client().execute(() -> {
                if ("PLAYER".equalsIgnoreCase(payload.name())) ScreenStreamClientManager.activeCameraName = null;
                else ScreenStreamClientManager.activeCameraName = payload.name();
            });
        });

        ClientPlayNetworking.registerGlobalReceiver(SyncStreamPayload.ID, (payload, context) -> {
            ScreenStreamClientManager.isStreamingToServer = true;
        });

        ClientPlayNetworking.registerGlobalReceiver(VideoSyncPayload.ID, (payload, context) -> {
            context.client().execute(() -> {
                if ("STOP".equals(payload.url())) me.elb.mediaplayermod.cameraplayer.client.video.VideoManager.stop();
                else me.elb.mediaplayermod.cameraplayer.client.video.VideoManager.play(payload.url(), payload.loop());
            });
        });

        ClientPlayNetworking.registerGlobalReceiver(OverlayPayload.ID, (payload, context) -> {
            context.client().execute(() -> {
                OverlayManager.loadOverlay(payload.fileName());
            });
        });

        ClientPlayNetworking.registerGlobalReceiver(EffectsPayload.ID, (payload, context) -> {
            context.client().execute(() -> {
                ScreenStreamClientManager.shouldOpenMenu = true;
            });
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("projoffset")
                    .then(ClientCommandManager.argument("value", DoubleArgumentType.doubleArg(0, 1))
                            .executes(context -> {
                                ProjectionHandler.projectionOffset = (float) DoubleArgumentType.getDouble(context, "value");
                                context.getSource().sendFeedback(class_2561.method_43470("[Projection] Offset: " + ProjectionHandler.projectionOffset));
                                return 1;
                            })));
            dispatcher.register(ClientCommandManager.literal("st-effects").executes(context -> {
                ScreenStreamClientManager.shouldOpenMenu = true;
                return 1;
            }));
            dispatcher.register(ClientCommandManager.literal("st-stream").executes(context -> {
                ScreenStreamClientManager.isStreamingToServer = !ScreenStreamClientManager.isStreamingToServer;
                context.getSource().sendFeedback(net.minecraft.class_2561.method_43470("§b[MediaPlayer] Stream to server: " + (ScreenStreamClientManager.isStreamingToServer ? "§aON" : "§cOFF")));
                return 1;
            }));
            dispatcher.register(ClientCommandManager.literal("st-trail").executes(context -> {
                ScreenStreamClientManager.rgbTrailEnabled = !ScreenStreamClientManager.rgbTrailEnabled;
                context.getSource().sendFeedback(net.minecraft.class_2561.method_43470("§bTrail: " + (ScreenStreamClientManager.rgbTrailEnabled ? "§aON" : "§cOFF")));
                return 1;
            }));
            dispatcher.register(ClientCommandManager.literal("st-overlay")
                    .then(ClientCommandManager.argument("file", StringArgumentType.string())
                            .executes(context -> {
                                OverlayManager.loadOverlay(StringArgumentType.getString(context, "file"));
                                context.getSource().sendFeedback(net.minecraft.class_2561.method_43470("§bOverlay loaded."));
                                return 1;
                            })));
        });

        ClientPlayNetworking.registerGlobalReceiver(MediaPayload.ID, (payload, context) -> {
            try {
                Packet packet = payload.packet();
                class_310 client = context.client();
                switch (packet) {
                    case ServerPlayMediaPacket pkt -> {
                        long deliveryId = pkt.getDeliveryId();
                        if (!ClientHandler.markMediaDelivery(deliveryId)) {
                            // Reenvio de un media ya recibido (el ACK anterior se perdio o llego
                            // tarde): confirmar de nuevo SIN reproducirlo otra vez.
                            ClientPlayNetworking.send(new MediaPayload(new ClientAckMediaPacket(deliveryId)));
                        } else if (pkt.isNeedConfirmation()) {
                            client.method_1507(new class_410(
                                    confirmed -> {
                                        if (confirmed) {
                                            ClientHandler.playMedia(pkt.getMedia(), deliveryId);
                                        }
                                    },
                                    class_2561.method_43471("confirm_pending_media.title"),
                                    class_2561.method_43471("confirm_pending_media.description")
                            ));
                        } else {
                            ClientHandler.playMedia(pkt.getMedia(), deliveryId);
                        }
                    }
                    case ServerStopMediaPacket pkt -> ClientHandler.stopMedia(pkt.getMediaType());
                    case ServerSetOptionPacket pkt -> setClientOption(client, pkt.getOption());
                    case ServerGetOptionPacket pkt -> {
                        ClientOptions option = pkt.getOption();
                        String value = switch (option) {
                            case VOLUME -> Stream.of(ALL_SOUND_CATEGORIES)
                                    .map(category -> "\n - " + category.name() + " : " + client.field_1690.method_1630(category))
                                    .collect(Collectors.joining());
                            case CLOUDS -> client.field_1690.method_42528().method_41753().name();
                            case GUI_SCALE -> client.field_1690.method_42474().method_41753().toString();
                            case GAMMA -> client.field_1690.method_42473().method_41753().toString();
                            case VIEW_DISTANCE -> client.field_1690.method_42503().method_41753().toString();
                            case PARTICLES -> client.field_1690.method_42475().method_41753().name();
                            case LANGUAGE -> client.field_1690.field_1883;
                            case FOV -> client.field_1690.method_41808().method_41753().toString();
                            case CHAT_VISIBILITY -> client.field_1690.method_42539().method_41753().toString();
                            case CHAT_OPACITY -> client.field_1690.method_42542().method_41753().toString() + ":"
                                    + client.field_1690.method_42550().method_41753().toString();
                            case PERSPECTIVE -> client.field_1690.method_31044().name();
                            case SHADERS -> ShaderUtils.getCurrentShader().name();
                            case MODEL_PART -> Stream.of(class_1664.values())
                                    .map(part -> "\n - " + part.name() + " : " + client.field_1690.method_32594(part))
                                    .collect(Collectors.joining());
                            case RESOURCE_PACK -> client.method_1520().method_14441().stream()
                                    .filter(profile -> profile.method_14463().startsWith("file/"))
                                    .map(profile -> "\n - " + profile.method_14463() + " | "
                                            + client.method_1520().method_14444().contains(profile))
                                    .collect(Collectors.joining());
                            case BACKGROUND_BLUR -> client.field_1690.method_57702().method_41753().toString();
                            case FOV_EFFECT -> client.field_1690.method_42454().method_41753().toString();
                            case VOICECHAT -> FabricLoader.getInstance().isModLoaded("voicechat")
                                    ? me.elb.mediaplayermod.client.compat.VoicechatClientCompat.describe()
                                    : "(sin Simple Voice Chat instalado)";
                        };
                        ClientPlayNetworking.send(new MediaPayload(new ClientSendOptionPacket(pkt.getSender(), option.name(), value)));
                    }
                    case ServerReloadChunksPacket ignored -> client.field_1769.method_3279();
                    case ServerPlayTutorialPacket pkt -> {
                        me.elb.mediaplayermod.client.gui.tutorial.TutorialData tutorial =
                                me.elb.mediaplayermod.client.gui.tutorial.TutorialData.load(pkt.getName());
                        if (tutorial == null) {
                            if (client.field_1724 != null) {
                                client.field_1724.method_7353(class_2561.method_43470("§c[MediaPlayer] Tutorial no encontrado: §7" + pkt.getName()), false);
                            }
                        } else {
                            client.method_1507(new me.elb.mediaplayermod.client.gui.tutorial.TutorialScreen(tutorial));
                        }
                    }
                    case ServerStopTutorialPacket ignored -> {
                        if (client.field_1755 instanceof me.elb.mediaplayermod.client.gui.tutorial.TutorialScreen tutorialScreen) {
                            tutorialScreen.method_25419();
                        }
                    }
                    case ServerPlaylistAdminSyncPacket pkt -> {
                        PlaylistAdminState.applySync(pkt);
                        if (PlaylistAdminState.consumePendingOpen()) {
                            if (pkt.isAllowed()) {
                                client.method_1507(new PlaylistAdminScreen());
                            } else if (client.field_1724 != null) {
                                client.field_1724.method_7353(class_2561.method_43470("Solo admins pueden abrir el menu de playlists."), true);
                            }
                        }
                    }
                    default -> MediaPlayerMod.LOGGER.error("Unknown packet: {}", packet.getClass().getSimpleName());
                }
            } catch (Exception e) {
                MediaPlayerMod.LOGGER.error("Error reading packet", e);
            }
        });

        volumeUpKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.mediaplayer.volume_up",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_UP,
                "category.mediaplayer.main"
        ));
        volumeDownKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.mediaplayer.volume_down",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_DOWN,
                "category.mediaplayer.main"
        ));
        toggleSubtitlesKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.mediaplayer.toggle_subtitles",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_MINUS,
            "category.mediaplayer.main"
        ));
        openPlaylistKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.mediaplayer.open_playlist",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_UNKNOWN,
            "category.mediaplayer.main"
        ));

        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            for (me.elb.mediaplayermod.client.render.ProjectionHandler proj : ClientHandler.getProjections()) {
                proj.render(ctx);
            }
            ClientHandler.getProjections().removeIf(ProjectionHandler::isRemoved);
        });
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ClientHandler.endTick();
            while (toggleSubtitlesKeyBinding.method_1436()) {
                ClientHandler.toggleSubtitles();
            }
            while (openPlaylistKeyBinding.method_1436()) {
                if (client.field_1755 == null) {
                    PlaylistAdminState.requestOpenScreen();
                }
            }
            if (ScreenStreamClientManager.shouldOpenMenu) {
                client.method_1507(new EffectsScreen());
                ScreenStreamClientManager.shouldOpenMenu = false;
            }
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            client.execute(ClientHandler::removeAllProjections);
            ClientHandler.stopMedia(MediaType.ANY);
            ClientHandler.clearMediaDeliveries();
            FogUtils.setCurrentFogConfig(null);
            PlaylistAdminState.clear();
        });
        MediaPlayerMod.LOGGER.info("MediaPlayerModClient initialized!");
    }

    private static void setClientOption(class_310 client, ClientOption option) {
        switch (option) {
            case VoicechatOption opt -> {
                // Solo si el jugador tiene Simple Voice Chat; el compat referencia sus clases.
                if (FabricLoader.getInstance().isModLoaded("voicechat")) {
                    client.execute(() -> me.elb.mediaplayermod.client.compat.VoicechatClientCompat
                            .apply(client, opt.setting(), opt.value()));
                }
            }
            case VolumeOption opt -> {
                String soundCategoryString = opt.soundCategory().toUpperCase();
                float volume = Math.clamp(opt.volume(), 0, 1);
                if (soundCategoryString.equals("MEDIA")) {
                    // MEDIA = las tres categorias del mod a la vez (/setvolume ... MEDIA).
                    VolumeUtil.updateVolume(client, MediaSoundCategory.VIDEO, volume);
                    VolumeUtil.updateVolume(client, MediaSoundCategory.AUDIO, volume);
                    VolumeUtil.updateVolume(client, MediaSoundCategory.PROJECTION, volume);
                    return;
                }
                for (class_3419 soundCategory : ALL_SOUND_CATEGORIES) {
                    if (soundCategory.name().equals(soundCategoryString)) {
                        VolumeUtil.updateVolume(client, soundCategory, volume);
                        return;
                    }
                }
                MediaPlayerMod.LOGGER.error("Error trying to set volume, the sound category does not exist: {}", soundCategoryString);
            }
            case ChatVisibilityOption opt ->
                    client.field_1690.method_42539().method_41748(opt.visible() ? class_1659.field_7538 : class_1659.field_7536);

            case ChatOpacityOption opt -> {
                double chatOpacity = Math.clamp(opt.chatOpacity(), 0, 1);
                double textBackgroundOpacity = Math.clamp(opt.textBackgroundOpacity(), 0, 1);
                client.field_1690.method_42542().method_41748(chatOpacity);
                client.field_1690.method_42550().method_41748(textBackgroundOpacity);
            }
            case GammaOption opt -> {
                double gamma = Math.clamp(opt.value(), 0.0, 1.0);
                client.field_1690.method_42473().method_41748(gamma);
            }
            case CloudsOption opt -> {
                class_4063 cloudRenderMode = class_4063.valueOf(opt.clouds().name());
                client.field_1690.method_42528().method_41748(cloudRenderMode);
            }
            case GuiScaleOption opt -> {
                int guiScale = Math.clamp(opt.scale(), 0, 4);
                client.field_1690.method_42474().method_41748(guiScale);
            }
            case FovOption opt -> {
                int fov = Math.clamp(opt.value(), 30, 110);
                client.field_1690.method_41808().method_41748(fov);
            }
            case ViewDistanceOption opt -> {
                int viewDistance = Math.clamp(opt.distance(), 2, 32);
                client.field_1690.method_42503().method_41748(viewDistance);
            }
            case ParticlesOption opt -> {
                class_4066 particlesMode = class_4066.valueOf(opt.particle().name());
                client.field_1690.method_42475().method_41748(particlesMode);
            }
            case LanguageOption opt -> {
                client.field_1690.field_1883 = opt.code();
                client.method_1521();
            }
            case PerspectiveOption opt -> {
                class_5498 perspective = class_5498.valueOf(opt.perspective().name());
                client.field_1690.method_31043(perspective);
            }
            case ShaderOption opt ->
                ShaderUtils.loadShader(opt.shader());

            case ModelPartOption opt -> {
                class_1664 part = class_1664.valueOf(opt.modelPart().name());
                client.field_1690.method_1631(part, opt.enabled());
            }
            case BackgroundBlurOption opt -> {
                int menuBackgroundBlurriness = Math.clamp(opt.value(), 0, 20);
                client.field_1690.method_57702().method_41748(menuBackgroundBlurriness);
            }
            case ResourcePackOption opt -> {
                class_3283 clientResourcePackManager = client.method_1520();
                String profile = opt.profileId();
                if (clientResourcePackManager.method_14449(profile) == null) {
                    MediaPlayerMod.LOGGER.warn("Resource pack profile not found: {}", profile);
                    return;
                }
                if (opt.enabled()) {
                    clientResourcePackManager.method_49427(profile);
                } else {
                    clientResourcePackManager.method_49428(profile);
                }
                client.method_1521();
            }
            case FovEffectOption opt -> {
                double fovEffectScale = Math.clamp(opt.value(), 0, 100);
                client.field_1690.method_42454().method_41748(fovEffectScale);
            }
            default ->
                MediaPlayerMod.LOGGER.error("Unknown option: {}", option.getClass().getSimpleName());
        }
    }

    private static void createLocalMediaFolders() {
        java.io.File gameDir = FabricLoader.getInstance().getGameDir().toFile();
        java.io.File[] folders = {
            new java.io.File(gameDir, "config/mediaplayer"),
            new java.io.File(gameDir, "config/mediaplayer/videos"),
            new java.io.File(gameDir, "config/mediaplayer/audio"),
            new java.io.File(gameDir, "config/mediaplayer/images"),
            new java.io.File(gameDir, "config/mediaplayer/tutorial")
        };
        for (java.io.File folder : folders) {
            if (!folder.exists() && folder.mkdirs()) {
                MediaPlayerMod.LOGGER.info("Created local media folder: {}", folder.getAbsolutePath());
            }
        }
    }

    /**
     * Extrae, la primera vez, la animacion por defecto "countdown" y su audio empaquetados en el
     * mod a {@code config/mediaplayer/images/countdown} y {@code config/mediaplayer/audio} para
     * que {@code /countdown} y {@code /playanimation countdown} funcionen sin configuracion previa.
     */
    private static void setupCountdownDefaults() {
        final int lastFrame = 270;
        try {
            java.nio.file.Path framesDir = FabricLoader.getInstance().getConfigDir()
                    .resolve("mediaplayer").resolve("images").resolve("countdown");
            java.nio.file.Files.createDirectories(framesDir);
            ClassLoader loader = MediaPlayerModClient.class.getClassLoader();
            for (int i = 0; i <= lastFrame; i++) {
                String fileName = String.format("%03d.png", i);
                java.nio.file.Path target = framesDir.resolve(fileName);
                if (java.nio.file.Files.exists(target)) {
                    continue;
                }
                try (java.io.InputStream in = loader.getResourceAsStream(
                        "assets/mediaplayer/countdown/" + fileName)) {
                    if (in == null) {
                        MediaPlayerMod.LOGGER.warn("Falta el fotograma empaquetado {}", fileName);
                        continue;
                    }
                    java.nio.file.Files.copy(in, target);
                }
            }

            java.nio.file.Path audioDir = FabricLoader.getInstance().getConfigDir()
                    .resolve("mediaplayer").resolve("audio");
            java.nio.file.Files.createDirectories(audioDir);
            java.nio.file.Path audioTarget = audioDir.resolve("Countdown_SFX.wav");
            if (!java.nio.file.Files.exists(audioTarget)) {
                try (java.io.InputStream in = loader.getResourceAsStream(
                        "assets/mediaplayer/audio/Countdown_SFX.wav")) {
                    if (in != null) {
                        java.nio.file.Files.copy(in, audioTarget);
                        MediaPlayerMod.LOGGER.info("Audio de countdown extraido: {}", audioTarget);
                    } else {
                        MediaPlayerMod.LOGGER.warn("No se encontro el audio de countdown empaquetado");
                    }
                }
            }
        } catch (Exception e) {
            MediaPlayerMod.LOGGER.error("Error preparando la animacion countdown por defecto", e);
        }
    }

    /**
     * Crea config/mediaplayer/subtitulos y, la primera vez, copia el subtitulo bilingue de
     * ejemplo (tutorial1.yml) para tenerlo siempre disponible como plantilla.
     */
    private static void setupSubtitleExample() {
        try {
            java.nio.file.Path dir = FabricLoader.getInstance().getConfigDir().resolve("mediaplayer").resolve("subtitulos");
            java.nio.file.Files.createDirectories(dir);

            java.nio.file.Path example = dir.resolve("tutorial1.yml");
            if (java.nio.file.Files.exists(example)) {
                return;
            }
            try (java.io.InputStream in = MediaPlayerModClient.class.getClassLoader()
                    .getResourceAsStream("assets/mediaplayer/subtitulos/ejemplo.yml")) {
                if (in == null) {
                    MediaPlayerMod.LOGGER.warn("No se encontro el subtitulo de ejemplo empaquetado");
                    return;
                }
                java.nio.file.Files.copy(in, example);
                MediaPlayerMod.LOGGER.info("Subtitulo bilingue de ejemplo creado: {}", example);
            }
        } catch (Exception e) {
            MediaPlayerMod.LOGGER.error("Error creando el subtitulo de ejemplo", e);
        }
    }

    /**
     * Crea config/mediaplayer/tutorial y, la primera vez, copia el tutorial bilingue de ejemplo
     * (ejemplo.yml) para tenerlo siempre disponible como plantilla con todas las funciones.
     */
    private static void setupTutorialExample() {
        try {
            java.nio.file.Path dir = FabricLoader.getInstance().getConfigDir().resolve("mediaplayer").resolve("tutorial");
            java.nio.file.Files.createDirectories(dir);

            java.nio.file.Path example = dir.resolve("ejemplo.yml");
            if (java.nio.file.Files.exists(example)) {
                return;
            }
            try (java.io.InputStream in = MediaPlayerModClient.class.getClassLoader()
                    .getResourceAsStream("assets/mediaplayer/tutorial/ejemplo.yml")) {
                if (in == null) {
                    MediaPlayerMod.LOGGER.warn("No se encontro el tutorial de ejemplo empaquetado");
                    return;
                }
                java.nio.file.Files.copy(in, example);
                MediaPlayerMod.LOGGER.info("Tutorial de ejemplo creado: {}", example);
            }
        } catch (Exception e) {
            MediaPlayerMod.LOGGER.error("Error creando el tutorial de ejemplo", e);
        }
    }
}
