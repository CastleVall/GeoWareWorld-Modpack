package me.elb.mediaplayermod.client.playlist;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import me.elb.mediaplayermod.networking.packet.ClientRequestPlaylistAdminPacket;
import me.elb.mediaplayermod.networking.packet.ServerPlaylistAdminSyncPacket;
import me.elb.mediaplayermod.payload.MediaPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class PlaylistAdminState {
    private static final List<ServerPlaylistAdminSyncPacket.Entry> entries = new ArrayList<>();
    private static boolean pendingOpen;

    public static void requestOpenScreen() {
        pendingOpen = true;
        ClientPlayNetworking.send(new MediaPayload(new ClientRequestPlaylistAdminPacket(true)));
    }

    public static void requestRefresh() {
        ClientPlayNetworking.send(new MediaPayload(new ClientRequestPlaylistAdminPacket(false)));
    }

    public static void applySync(ServerPlaylistAdminSyncPacket packet) {
        entries.clear();
        if (packet.isAllowed()) {
            entries.addAll(packet.getEntries());
        }
    }

    public static boolean consumePendingOpen() {
        boolean wasPending = pendingOpen;
        pendingOpen = false;
        return wasPending;
    }

    public static List<ServerPlaylistAdminSyncPacket.Entry> getEntries() {
        return Collections.unmodifiableList(entries);
    }

    public static Optional<ServerPlaylistAdminSyncPacket.Entry> getEntry(String id) {
        return entries.stream().filter(entry -> entry.getId().equals(id)).findFirst();
    }

    public static void clear() {
        entries.clear();
        pendingOpen = false;
    }
}
