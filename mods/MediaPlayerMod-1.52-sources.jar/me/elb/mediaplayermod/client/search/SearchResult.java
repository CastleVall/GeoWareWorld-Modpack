package me.elb.mediaplayermod.client.search;

public record SearchResult(String url, String title, String artist, int durationSeconds, String lyricsLocalPath) {

    public SearchResult(String url, String title, String artist, int durationSeconds) {
        this(url, title, artist, durationSeconds, null);
    }

    public SearchResult withLyrics(String path) {
        return new SearchResult(url, title, artist, durationSeconds, path);
    }

    public boolean hasLyrics() {
        return lyricsLocalPath != null && !lyricsLocalPath.isEmpty();
    }

    public String formattedDuration() {
        if (durationSeconds <= 0) return "";
        return (durationSeconds / 60) + ":" + String.format("%02d", durationSeconds % 60);
    }
}
