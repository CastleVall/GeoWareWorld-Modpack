package me.elb.mediaplayermod.client.search;

import com.google.gson.*;
import me.elb.mediaplayermod.MediaPlayerMod;
import net.minecraft.class_310;
import java.io.File;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class SongSearchClient {
    private SongSearchClient() {}

    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(8))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();
    private static final Gson GSON = new Gson();

    private static final String INNERTUBE_URL = "https://www.youtube.com/youtubei/v1/search";
    private static final String INNERTUBE_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
    private static final String INNERTUBE_CLIENT_VERSION = "2.20240814.00.00";

    private static final List<String> PIPED_APIS = List.of(
            "https://pipedapi.kavin.rocks",
            "https://api.piped.yt",
            "https://piped-api.garudalinux.org",
            "https://pipedapi.adminforge.de"
    );
    private static final List<String> INVIDIOUS_APIS = List.of(
            "https://inv.nadeko.net",
            "https://invidious.nerdvpn.de",
            "https://yt.artemislena.eu",
            "https://iv.ggtyler.dev",
            "https://invidious.privacydev.net",
            "https://invidious.drgns.space",
            "https://invidious.perennialte.ch"
    );
    private static final String LRCLIB_API = "https://lrclib.net/api";
    private static final String NETEASE_API = "https://music.163.com";

    private static final Pattern BRACKET_TITLE_PATTERN = Pattern.compile("[「『]([^」』]{1,80})[」』]");

    public static CompletableFuture<List<SearchResult>> searchYouTube(String query) {
        return CompletableFuture.supplyAsync(() -> {
            String enc = URLEncoder.encode(query, StandardCharsets.UTF_8);
            Exception lastError = null;

            
            try {
                List<SearchResult> results = searchViaInnerTube(query);
                if (!results.isEmpty()) return results;
                lastError = new RuntimeException("InnerTube returned no results");
            } catch (Exception e) {
                lastError = e;
            }

            
            for (String base : PIPED_APIS) {
                try {
                    HttpRequest req = HttpRequest.newBuilder()
                            .uri(URI.create(base + "/search?q=" + enc + "&filter=music_songs"))
                            .header("User-Agent", "MediaPlayerMod/1.0")
                            .GET().build();
                    HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
                    if (resp.statusCode() != 200) throw new RuntimeException("HTTP " + resp.statusCode());
                    requireJson(resp.body());
                    return parsePipedResults(resp.body());
                } catch (Exception e) {
                    lastError = e;
                }
            }

            
            for (String base : INVIDIOUS_APIS) {
                try {
                    HttpRequest req = HttpRequest.newBuilder()
                            .uri(URI.create(base + "/api/v1/search?q=" + enc + "&type=video"))
                            .header("User-Agent", "MediaPlayerMod/1.0")
                            .GET().build();
                    HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
                    if (resp.statusCode() != 200) throw new RuntimeException("HTTP " + resp.statusCode());
                    requireJson(resp.body());
                    return parseInvidiousResults(resp.body());
                } catch (Exception e) {
                    lastError = e;
                }
            }

            String errMsg = lastError != null
                    ? lastError.getClass().getSimpleName() + (lastError.getMessage() != null ? ": " + lastError.getMessage() : "")
                    : "unknown";
            MediaPlayerMod.LOGGER.warn("YouTube search failed on all instances: {}", errMsg);
            throw new RuntimeException(lastError);
        });
    }

    private static List<SearchResult> searchViaInnerTube(String query) throws Exception {
        JsonObject clientCtx = new JsonObject();
        clientCtx.addProperty("clientName", "WEB");
        clientCtx.addProperty("clientVersion", INNERTUBE_CLIENT_VERSION);
        clientCtx.addProperty("hl", "en");
        JsonObject context = new JsonObject();
        context.add("client", clientCtx);
        JsonObject body = new JsonObject();
        body.add("context", context);
        body.addProperty("query", query);

        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(INNERTUBE_URL))
                .header("Content-Type", "application/json")
                .header("User-Agent", INNERTUBE_UA)
                .header("X-YouTube-Client-Name", "1")
                .header("X-YouTube-Client-Version", INNERTUBE_CLIENT_VERSION)
                .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(body)))
                .build();
        HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() != 200) throw new RuntimeException("InnerTube HTTP " + resp.statusCode());
        requireJson(resp.body());
        return parseInnerTubeResults(resp.body());
    }

    private static List<SearchResult> parseInnerTubeResults(String json) {
        List<SearchResult> out = new ArrayList<>();
        try {
            JsonElement root = GSON.fromJson(json, JsonElement.class);
            collectVideoRenderers(root, out);
        } catch (Exception e) {
            throw new RuntimeException("InnerTube parse error: " + e.getMessage(), e);
        }
        return out;
    }

    private static void collectVideoRenderers(JsonElement el, List<SearchResult> out) {
        if (out.size() >= 8 || el == null || el.isJsonNull() || el.isJsonPrimitive()) return;
        if (el.isJsonArray()) {
            for (JsonElement child : el.getAsJsonArray()) {
                if (out.size() >= 8) return;
                collectVideoRenderers(child, out);
            }
        } else {
            JsonObject obj = el.getAsJsonObject();
            if (obj.has("videoRenderer")) {
                JsonObject vr = obj.getAsJsonObject("videoRenderer");
                String videoId = vr.has("videoId") ? vr.get("videoId").getAsString() : null;
                if (videoId != null && !videoId.isEmpty()) {
                    String url = "https://www.youtube.com/watch?v=" + videoId;
                    String title = getRunsText(vr, "title");
                    String author = getRunsText(vr, "ownerText");
                    if (author.isEmpty()) author = getRunsText(vr, "shortBylineText");
                    int duration = parseInnerTubeDuration(vr);
                    out.add(new SearchResult(url, title.isEmpty() ? "Unknown" : title, author, duration));
                    return;
                }
            }
            for (var entry : obj.entrySet()) {
                if (out.size() >= 8) return;
                collectVideoRenderers(entry.getValue(), out);
            }
        }
    }

    private static String getRunsText(JsonObject obj, String key) {
        try {
            return obj.getAsJsonObject(key).getAsJsonArray("runs").get(0)
                    .getAsJsonObject().get("text").getAsString();
        } catch (Exception e) {
            return "";
        }
    }

    private static int parseInnerTubeDuration(JsonObject vr) {
        try {
            String text = vr.getAsJsonObject("lengthText").get("simpleText").getAsString();
            String[] parts = text.split(":");
            if (parts.length == 2) return Integer.parseInt(parts[0]) * 60 + Integer.parseInt(parts[1]);
            if (parts.length == 3) return Integer.parseInt(parts[0]) * 3600 + Integer.parseInt(parts[1]) * 60 + Integer.parseInt(parts[2]);
        } catch (Exception ignored) {}
        return 0;
    }

    private static void requireJson(String body) {
        if (body == null || body.isBlank()) throw new RuntimeException("Empty response");
        char first = body.stripLeading().charAt(0);
        if (first != '{' && first != '[') throw new RuntimeException("Non-JSON response (starts with '" + first + "')");
    }

    private static List<SearchResult> parsePipedResults(String json) {
        JsonElement root = GSON.fromJson(json, JsonElement.class);
        if (root == null || !root.isJsonObject()) {
            throw new RuntimeException("Unexpected Piped response: " + json.substring(0, Math.min(80, json.length())));
        }
        JsonArray items = root.getAsJsonObject().getAsJsonArray("items");
        if (items == null) throw new RuntimeException("Piped response missing 'items'");
        List<SearchResult> out = new ArrayList<>();
        for (JsonElement el : items) {
            if (out.size() >= 8) break;
            try {
                JsonObject obj = el.getAsJsonObject();
                String rel = obj.has("url") ? obj.get("url").getAsString() : "";
                if (!rel.startsWith("/watch")) continue;
                String url = "https://www.youtube.com" + rel;
                String title = obj.has("title") ? obj.get("title").getAsString() : "Unknown";
                String uploader = obj.has("uploaderName") ? obj.get("uploaderName").getAsString() : "";
                int duration = obj.has("duration") && !obj.get("duration").isJsonNull()
                        ? obj.get("duration").getAsInt() : 0;
                out.add(new SearchResult(url, title, uploader, duration));
            } catch (Exception ignored) {}
        }
        return out;
    }

    private static List<SearchResult> parseInvidiousResults(String json) {
        JsonElement root = GSON.fromJson(json, JsonElement.class);
        if (root == null || !root.isJsonArray()) {
            throw new RuntimeException("Unexpected Invidious response: " + json.substring(0, Math.min(80, json.length())));
        }
        List<SearchResult> out = new ArrayList<>();
        for (JsonElement el : root.getAsJsonArray()) {
            if (out.size() >= 8) break;
            try {
                JsonObject obj = el.getAsJsonObject();
                if (!"video".equals(obj.has("type") ? obj.get("type").getAsString() : "")) continue;
                String videoId = obj.has("videoId") ? obj.get("videoId").getAsString() : null;
                if (videoId == null || videoId.isEmpty()) continue;
                String url = "https://www.youtube.com/watch?v=" + videoId;
                String title = obj.has("title") ? obj.get("title").getAsString() : "Unknown";
                String author = obj.has("author") ? obj.get("author").getAsString() : "";
                int duration = obj.has("lengthSeconds") && !obj.get("lengthSeconds").isJsonNull()
                        ? obj.get("lengthSeconds").getAsInt() : 0;
                out.add(new SearchResult(url, title, author, duration));
            } catch (Exception ignored) {}
        }
        return out;
    }

    public static CompletableFuture<String> fetchAndSaveLyrics(String title, String artist, int durationSecs) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                String lrc = fetchLrcWithFallbacks(title, artist, durationSecs);
                if (lrc == null || lrc.isBlank()) return null;
                String srt = lrcToSrt(lrc);
                if (srt == null || srt.isBlank()) return null;
                return saveSrt(srt, title, artist);
            } catch (Exception e) {
                MediaPlayerMod.LOGGER.warn("Lyrics fetch failed for '{}': {}", title, e.getMessage());
                return null;
            }
        });
    }

    private static String extractBracketTitle(String title) {
        if (title == null) return null;
        Matcher m = BRACKET_TITLE_PATTERN.matcher(title);
        String result = m.find() ? m.group(1).trim() : null;
        return (result == null || result.isEmpty()) ? null : result;
    }

    private static String cleanArtistName(String artist) {
        if (artist == null || artist.isBlank()) return artist;
        String clean = artist
                .replaceAll("(?i)\\s*-\\s*Topic$", "")
                .replaceAll("(?i)VEVO$", "")
                .replaceAll("(?i)\\s*-\\s*Official(?:\\s+Channel)?$", "")
                .replaceAll("(?i)\\s+Official(?:\\s+Channel)?$", "")
                .trim();
        return clean.isEmpty() ? artist : clean;
    }

    private static String cleanTitle(String title) {
        if (title == null || title.isBlank()) return title;
        String bracketContent = extractBracketTitle(title);
        if (bracketContent != null) return bracketContent;
        String clean = title
                .replaceAll("(?i)\\s*\\(official[^)]*\\)", "")
                .replaceAll("(?i)\\s*\\[[^\\]]*official[^\\]]*\\]", "")
                .replaceAll("(?i)\\s*\\(.*?(?:video|audio|lyric|clip|hd|4k|mv)[^)]*\\)", "")
                .replaceAll("(?i)\\s*\\[.*?(?:video|audio|lyric|clip)[^\\]]*\\]", "")
                .replaceAll("(?i)\\s+(?:official\\s+)?music\\s+video$", "")
                .replaceAll("(?i)\\s+official\\s+(?:mv|clip|video|audio)$", "")
                .replaceAll("\\s+", " ")
                .trim();
        return clean.isEmpty() ? title : clean;
    }

    private static String fetchLrcWithFallbacks(String title, String artist, int durationSecs) {
        String cleanArtist = cleanArtistName(artist);
        String cleanTitle = cleanTitle(title);

        MediaPlayerMod.LOGGER.info("[Lyrics] '{}' / '{}' / {}s  (clean: '{}' / '{}')",
                title, artist, durationSecs, cleanTitle, cleanArtist);

        if (cleanArtist != null && !cleanArtist.isBlank()) {
            try {
                String lrc = fetchLrcSearch(cleanTitle, cleanArtist, durationSecs);
                if (lrc != null) { MediaPlayerMod.LOGGER.info("[Lyrics] Encontrado"); return lrc; }
            } catch (Exception e) { MediaPlayerMod.LOGGER.warn("[Lyrics] Error LRCLIB: {}", e.getMessage()); }
        }

        if (cleanArtist != null && !cleanArtist.isBlank() && durationSecs > 0) {
            try {
                String lrc = fetchLrcSearch(cleanTitle, cleanArtist, 0);
                if (lrc != null) { MediaPlayerMod.LOGGER.info("[Lyrics] Encontrado"); return lrc; }
            } catch (Exception e) { MediaPlayerMod.LOGGER.warn("[Lyrics] Error LRCLIB: {}", e.getMessage()); }
        }

        if (cleanArtist != null && !cleanArtist.isBlank()) {
            try {
                String lrc = fetchLrcFreeText(cleanTitle + " " + cleanArtist, durationSecs);
                if (lrc != null) { MediaPlayerMod.LOGGER.info("[Lyrics] Encontrado"); return lrc; }
            } catch (Exception e) { MediaPlayerMod.LOGGER.warn("[Lyrics] Error LRCLIB: {}", e.getMessage()); }
        }

        try {
            String lrc = fetchLrcFreeText(cleanTitle, durationSecs);
            if (lrc != null) { MediaPlayerMod.LOGGER.info("[Lyrics] Encontrado"); return lrc; }
        } catch (Exception e) { MediaPlayerMod.LOGGER.warn("[Lyrics] Error LRCLIB: {}", e.getMessage()); }

        if (durationSecs > 0) {
            try {
                String lrc = fetchLrcFreeText(cleanTitle, 0);
                if (lrc != null) { MediaPlayerMod.LOGGER.info("[Lyrics] Encontrado"); return lrc; }
            } catch (Exception e) { MediaPlayerMod.LOGGER.warn("[Lyrics] Error LRCLIB: {}", e.getMessage()); }
        }

        if (cleanArtist != null && !cleanArtist.isBlank()) {
            try {
                String lrc = fetchNeteaseLyrics(cleanTitle, cleanArtist, durationSecs);
                if (lrc != null) { MediaPlayerMod.LOGGER.info("[Lyrics] Encontrado (NetEase)"); return lrc; }
            } catch (Exception e) { MediaPlayerMod.LOGGER.warn("[Lyrics] Error NetEase: {}", e.getMessage()); }
        }

        try {
            String lrc = fetchNeteaseLyrics(cleanTitle, null, durationSecs);
            if (lrc != null) { MediaPlayerMod.LOGGER.info("[Lyrics] Encontrado (NetEase)"); return lrc; }
        } catch (Exception e) { MediaPlayerMod.LOGGER.warn("[Lyrics] Error NetEase: {}", e.getMessage()); }

        MediaPlayerMod.LOGGER.info("[Lyrics] No encontrado");
        return null;
    }

    private static String fetchNeteaseLyrics(String title, String artist, int durationSecs) throws Exception {
        String query = (title + (artist != null && !artist.isBlank() ? " " + artist : "")).trim();
        MediaPlayerMod.LOGGER.info("[Lyrics]  NetEase '{}'", query);
        String body = "s=" + URLEncoder.encode(query, StandardCharsets.UTF_8) + "&type=1&limit=10";
        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(NETEASE_API + "/api/search/get"))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .header("User-Agent", INNERTUBE_UA)
                .header("Referer", "https://music.163.com")
                .header("Cookie", "os=pc; osver=Microsoft-Windows-10")
                .timeout(Duration.ofSeconds(6))
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .build();
        HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() != 200) return null;
        JsonObject root = GSON.fromJson(resp.body(), JsonObject.class);
        if (root == null || !root.has("result")) return null;
        JsonObject result = root.getAsJsonObject("result");
        if (!result.has("songs")) return null;
        JsonArray songs = result.getAsJsonArray("songs");
        if (songs == null || songs.isEmpty()) return null;
        MediaPlayerMod.LOGGER.info("[Lyrics]   {} canciones", songs.size());
        long bestId = findBestNeteaseMatch(songs, durationSecs);
        if (bestId <= 0) return null;
        return fetchNeteaseTrackLyrics(bestId);
    }

    private static long findBestNeteaseMatch(JsonArray songs, int durationSecs) {
        long targetMs = (long) durationSecs * 1000;
        long bestId = -1;
        long bestDiff = Long.MAX_VALUE;
        for (JsonElement el : songs) {
            try {
                JsonObject song = el.getAsJsonObject();
                long songId = song.has("id") ? song.get("id").getAsLong() : -1;
                if (songId <= 0) continue;
                if (targetMs <= 0) return songId;
                long songDuration = song.has("duration") ? song.get("duration").getAsLong() : 0;
                if (songDuration <= 0) {
                    if (bestId < 0) bestId = songId;
                    continue;
                }
                long diff = Math.abs(songDuration - targetMs);
                if (diff < bestDiff) {
                    bestDiff = diff;
                    bestId = songId;
                }
            } catch (Exception ignored) {}
        }
        if (targetMs > 0 && bestDiff > 15_000) {
            MediaPlayerMod.LOGGER.info("[Lyrics]   rechazado: diff={}ms > 15000ms", bestDiff);
            return -1;
        }
        return bestId;
    }

    private static String fetchNeteaseTrackLyrics(long id) throws Exception {
        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(NETEASE_API + "/api/song/lyric?id=" + id + "&lv=1&kv=1&tv=-1"))
                .header("User-Agent", INNERTUBE_UA)
                .header("Referer", "https://music.163.com")
                .header("Cookie", "os=pc; osver=Microsoft-Windows-10")
                .timeout(Duration.ofSeconds(6))
                .GET().build();
        HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() != 200) return null;
        JsonObject root = GSON.fromJson(resp.body(), JsonObject.class);
        if (root == null) return null;
        if (root.has("lrc")) {
            JsonObject lrc = root.getAsJsonObject("lrc");
            if (lrc.has("lyric") && !lrc.get("lyric").isJsonNull()) {
                String lrcText = lrc.get("lyric").getAsString();
                if (isValidNeteaseLrc(lrcText)) return lrcText;
            }
        }
        return null;
    }

    private static boolean isValidNeteaseLrc(String lrc) {
        if (lrc == null || lrc.isBlank()) return false;
        if (lrc.contains("纯音乐，请欣赏") || lrc.contains("此歌曲为没有填词的纯音乐")) return false;
        return lrc.contains("[");
    }

    private static String fetchLrcSearch(String title, String artist, int durationSecs) throws Exception {
        StringBuilder params = new StringBuilder("track_name=")
                .append(URLEncoder.encode(title, StandardCharsets.UTF_8));
        if (artist != null && !artist.isBlank())
            params.append("&artist_name=").append(URLEncoder.encode(artist, StandardCharsets.UTF_8));
        String url = LRCLIB_API + "/search?" + params;
        MediaPlayerMod.LOGGER.info("[Lyrics]  GET {}", url);
        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("User-Agent", "MediaPlayerMod/1.0 (https://github.com/elbgg139/mediaplayermod)")
                .GET().build();
        HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() != 200) {
            MediaPlayerMod.LOGGER.info("[Lyrics]  HTTP {}", resp.statusCode());
            return null;
        }
        JsonArray arr = GSON.fromJson(resp.body(), JsonArray.class);
        if (arr == null || arr.isEmpty()) {
            MediaPlayerMod.LOGGER.info("[Lyrics]  0 resultados");
            return null;
        }
        return extractBestSynced(arr, durationSecs);
    }

    private static String fetchLrcFreeText(String query, int durationSecs) throws Exception {
        String url = LRCLIB_API + "/search?q=" + URLEncoder.encode(query, StandardCharsets.UTF_8);
        MediaPlayerMod.LOGGER.info("[Lyrics]  GET {}", url);
        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("User-Agent", "MediaPlayerMod/1.0 (https://github.com/elbgg139/mediaplayermod)")
                .GET().build();
        HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() != 200) {
            MediaPlayerMod.LOGGER.info("[Lyrics]  HTTP {}", resp.statusCode());
            return null;
        }
        JsonArray arr = GSON.fromJson(resp.body(), JsonArray.class);
        if (arr == null || arr.isEmpty()) {
            MediaPlayerMod.LOGGER.info("[Lyrics]  0 resultados");
            return null;
        }
        return extractBestSynced(arr, durationSecs);
    }

    private static String extractBestSynced(JsonArray arr, int durationSecs) {
        String bestLrc = null;
        long bestDiff = Long.MAX_VALUE;
        for (JsonElement el : arr) {
            try {
                JsonObject obj = el.getAsJsonObject();
                if (obj.has("instrumental") && obj.get("instrumental").getAsBoolean()) continue;
                String lrc = null;
                if (obj.has("syncedLyrics") && !obj.get("syncedLyrics").isJsonNull()) {
                    String s = obj.get("syncedLyrics").getAsString();
                    if (s != null && !s.isBlank()) lrc = s;
                }
                if (lrc == null) continue;
                if (durationSecs <= 0) return lrc;
                String track = obj.has("trackName") ? obj.get("trackName").getAsString() : "?";
                String artist = obj.has("artistName") ? obj.get("artistName").getAsString() : "?";
                long dur = obj.has("duration") && !obj.get("duration").isJsonNull()
                        ? obj.get("duration").getAsLong() : 0;
                if (dur <= 0) {
                    if (bestLrc == null) bestLrc = lrc;
                    continue;
                }
                long diff = Math.abs(dur - durationSecs);
                MediaPlayerMod.LOGGER.info("[Lyrics]   '{}' by '{}' diff={}s", track, artist, diff);
                if (diff < bestDiff) {
                    bestDiff = diff;
                    bestLrc = lrc;
                }
            } catch (Exception ignored) {}
        }
        if (durationSecs > 0 && bestLrc != null && bestDiff > 10) {
            MediaPlayerMod.LOGGER.info("[Lyrics]   rechazado: diff={}s > 10s", bestDiff);
            return null;
        }
        return bestLrc;
    }

    public static String lrcToSrt(String lrc) {
        List<long[]> times = new ArrayList<>();
        List<String> lines = new ArrayList<>();
        for (String raw : lrc.split("\n")) {
            String line = raw.trim();
            if (line.isEmpty() || !line.startsWith("[")) continue;
            int close = line.indexOf(']');
            if (close < 0) continue;
            String ts = line.substring(1, close);
            if (ts.isEmpty() || !Character.isDigit(ts.charAt(0))) continue;
            String text = line.substring(close + 1).trim();
            long ms = parseLrcTime(ts);
            if (ms < 0) continue;
            times.add(new long[]{ms});
            lines.add(text);
        }
        if (times.isEmpty()) return null;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            long start = times.get(i)[0];
            long end = (i + 1 < times.size()) ? times.get(i + 1)[0] : start + 3000;
            if (end <= start) end = start + 1500;
            sb.append(i + 1).append('\n');
            sb.append(formatSrtTime(start)).append(" --> ").append(formatSrtTime(end)).append('\n');
            sb.append(lines.get(i)).append('\n').append('\n');
        }
        return sb.toString();
    }

    private static long parseLrcTime(String ts) {
        try {
            int colon = ts.indexOf(':');
            if (colon < 0) return -1;
            int minutes = Integer.parseInt(ts.substring(0, colon));
            double secs = Double.parseDouble(ts.substring(colon + 1));
            return (long) (minutes * 60_000L + secs * 1000);
        } catch (Exception e) {
            return -1;
        }
    }

    private static String formatSrtTime(long ms) {
        long h = ms / 3_600_000;
        long m = (ms % 3_600_000) / 60_000;
        long s = (ms % 60_000) / 1000;
        long mil = ms % 1000;
        return String.format("%02d:%02d:%02d,%03d", h, m, s, mil);
    }

    private static String saveSrt(String srt, String title, String artist) throws Exception {
        File dir = new File(class_310.method_1551().field_1697, "config/mediaplayer/lyrics");
        dir.mkdirs();
        String hash = String.format("%08x", (title + artist).hashCode() & 0xFFFFFFFFL);
        File file = new File(dir, hash + ".srt");
        Files.writeString(file.toPath(), srt, StandardCharsets.UTF_8);
        return "local://" + file.getAbsolutePath().replace("\\", "/");
    }
}
