package me.elb.mediaplayermod.client;

import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.client.gui.display.*;
import me.elb.mediaplayermod.client.render.ProjectionHandler;
import me.elb.mediaplayermod.client.sound.ClientPlaylist;
import me.elb.mediaplayermod.client.sound.MediaSoundCategory;
import me.elb.mediaplayermod.client.sound.VolumeUtil;
import me.elb.mediaplayermod.model.media.*;
import me.elb.mediaplayermod.client.gui.screen.FadeScreen;
import me.elb.mediaplayermod.client.gui.MediaHudOverlay;
import me.elb.mediaplayermod.client.gui.screen.VideoScreen;
import me.elb.mediaplayermod.networking.packet.ClientFinishedMediaPacket;
import me.elb.mediaplayermod.networking.packet.ClientStartedMediaPacket;
import me.elb.mediaplayermod.payload.MediaPayload;
import me.elb.mediaplayermod.utils.FileEncryption;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.watermedia.api.player.videolan.MusicPlayer;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;
import java.util.function.Predicate;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ClientHandler {
    private static final Map<UUID, Media> playingMedia = new HashMap<>();

    @Getter
    @Setter
    private static VideoScreen currentVideoScreen;
    @Setter
    private static FadeScreen currentFadeScreen;
    private static final Map<MusicPlayer, UUID> playingAudios = new HashMap<>();
    /**
     * Momento (ms) en que cada audio llego a su fin. Tras terminar se mantiene la referencia al
     * reproductor un breve margen para que VLC vacie su buffer de salida (si no, al quedar sin
     * referencias el GC lo libera de golpe y corta el final del audio).
     */
    private static final Map<MusicPlayer, Long> finishedAudioAt = new HashMap<>();
    private static final long AUDIO_DRAIN_GRACE_MS = 1500L;
    private static UUID lyricsDisplayUuid = null;
    private static volatile boolean playlistReady = false;
    private static volatile long playlistReadyTime = 0L;
    @Getter
    private static final MediaHudOverlay mediaOverlay = new MediaHudOverlay();
    @Getter
    private static boolean subtitles = true;
    @Getter
    private static final ZoomTracker zoomTracker = new ZoomTracker();
    @Getter
    private static final CameraHandler cameraHandler = new CameraHandler();
    @Getter
    private static final List<ProjectionHandler> projections = new ArrayList<>();
    private static final Map<ClientPlaylist, UUID> playlists = new HashMap<>();

    public static Optional<ProjectionHandler> getProjection(class_2338 pos) {
        return projections.stream()
                .filter(projection -> projection.getPos1().equals(pos))
                .findFirst();
    }

    public static Optional<ProjectionHandler> getProjectionById(String id) {
        return projections.stream()
                .filter(p -> p.getId().equals(id))
                .findFirst();
    }

    /**
     * Ids de entrega ya recibidos del servidor. Permite que los reenvios (reintentos de entrega)
     * se confirmen sin volver a reproducir el mismo media dos veces.
     */
    private static final LinkedHashSet<Long> receivedDeliveries = new LinkedHashSet<>();
    private static final int MAX_TRACKED_DELIVERIES = 256;

    /** true si es la primera vez que llega este deliveryId (0 = sin seguimiento, siempre true). */
    public static boolean markMediaDelivery(long deliveryId) {
        if (deliveryId == 0) {
            return true;
        }
        if (!receivedDeliveries.add(deliveryId)) {
            return false;
        }
        Iterator<Long> iterator = receivedDeliveries.iterator();
        while (receivedDeliveries.size() > MAX_TRACKED_DELIVERIES) {
            iterator.next();
            iterator.remove();
        }
        return true;
    }

    public static void clearMediaDeliveries() {
        receivedDeliveries.clear();
    }

    public static void playMedia(Media media) {
        playMedia(media, 0L);
    }

    public static void playMedia(Media media, long deliveryId) {
        UUID uuid = UUID.randomUUID();
        switch (media.getType()) {
            case ANY -> playUrl(uuid, (GenericMedia) media);
            case VIDEO -> playVideo(uuid, (Video) media);
            case AUDIO -> playAudio(uuid, (Audio) media);
            case IMAGE -> playImage(uuid, (Image) media);
            case INTERACTIVE_IMAGE -> playInteractiveImage(uuid, (InteractiveImage) media);
            case ANIMATION -> playAnimation(uuid, (Animation) media);
            case FADE -> playFade(uuid, (Fade) media);
            case GLOW -> playGlow(uuid, (Glow) media);
            case COLOR -> playColor(uuid, (Color) media);
            case BLINK -> playBlink(uuid, (Blink) media);
            case PROJECTION -> playProjection((Projection) media);
            case PROJECTION_OP -> playProjectionOperation((ProjectionOperation) media);
            case SUBTITLES -> playSubtitles(uuid, (Subtitles) media);
            case ZOOM -> playZoom((Zoom) media);
            case CAMERA -> playCamera((Camera.Movement) media);
            case CAMERA_LIMIT -> playCameraLimit((Camera.Limit) media);
            case CAMERA_ROTATION -> playCameraRotation((Camera.Rotation) media);
            case TEXT -> playText((Text) media);
            case PLAYLIST -> playPlaylistOperation(uuid, (Playlist) media);
        }
        playingMedia.put(uuid, media);
        ClientPlayNetworking.send(new MediaPayload(new ClientStartedMediaPacket(uuid, media, deliveryId)));
    }

    public static void setPlaylistVolume(String playlistId, int factor) {
        playlists.keySet().stream()
                .filter(p -> p.getId().equals(playlistId))
                .findFirst()
                .ifPresent(p -> p.setCustomVolumeFactor(factor));
    }

    public static int getPlaylistVolume(String playlistId) {
        return playlists.keySet().stream()
                .filter(p -> p.getId().equals(playlistId))
                .findFirst()
                .map(ClientPlaylist::getCustomVolumeFactor)
                .orElse(100);
    }

    public static void removeAllProjections() {
        projections.forEach(ProjectionHandler::remove);
        projections.clear();
    }

    public static void stopMedia(MediaType mediaType) {
        Predicate<AbstractDisplay> mediaPredicate = null;
        switch (mediaType) {
            case VIDEO -> {
                closeCurrentVideoScreen();
                mediaPredicate = VideoDisplay.class::isInstance;
            }
            case AUDIO -> {
                playingAudios.keySet().forEach(audio -> {
                    audio.stop();
                    audio.release();
                });
                playingAudios.clear();
                finishedAudioAt.clear();
            }
            case IMAGE -> mediaPredicate = ImageDisplay.class::isInstance;
            case INTERACTIVE_IMAGE -> closeCurrentInspectScreen();
            case ANIMATION -> mediaPredicate = AnimationDisplay.class::isInstance;
            case FADE -> {
                closeCurrentFadeScreen();
                mediaPredicate = FadeDisplay.class::isInstance;
            }
            case GLOW -> mediaPredicate = GlowDisplay.class::isInstance;
            case COLOR -> mediaPredicate = ColorDisplay.class::isInstance;
            case BLINK -> mediaPredicate = BlinkDisplay.class::isInstance;
            case PROJECTION -> {
                projections.forEach(ProjectionHandler::stop);
            }
            case SUBTITLES -> mediaPredicate = SubtitlesDisplay.class::isInstance;
            case PLAYLIST -> {
                playlists.keySet().forEach(ClientPlaylist::stop);
                playlists.clear();
            }
            case ZOOM -> zoomTracker.reset();
            case CAMERA -> cameraHandler.reset();
            case CAMERA_LIMIT -> cameraHandler.resetLimits();
            case TEXT -> mediaPredicate = TextDisplay.class::isInstance;
            case ANY -> {
                for (MediaType type : MediaType.values()) {
                    if (type != MediaType.ANY) {
                        stopMedia(type);
                    }
                }
            }
        }
        if (mediaPredicate != null) {
            Predicate<AbstractDisplay> finalMediaPredicate = mediaPredicate;
            mediaOverlay.getDisplays().removeIf(m -> {
                if (finalMediaPredicate.test(m)) {
                    m.forceEnd();
                    m.dispose();
                    return true;
                }
                return false;
            });
        }
        playingMedia.entrySet().removeIf(entry -> {
            try {
                ClientPlayNetworking.send(new MediaPayload(new ClientFinishedMediaPacket(entry.getKey())));
            } catch (Exception ignored) {}
            return entry.getValue().getType() == mediaType;
        });
    }

    private static void playUrl(UUID uuid, GenericMedia media) {
        String url = URLUtil.decryptUrlFile(media.url());
        if (url.endsWith(".mp3") || url.endsWith(".wav") || url.endsWith(".flac") || url.endsWith(".ogg")) {
            playAudio(uuid, new Audio(url, null));
        } else if (url.endsWith(".mp4") || url.endsWith(".mov") || url.endsWith(".avi") || url.endsWith(".mkv")
                || url.endsWith(".wmv") || url.endsWith(".flv") || url.endsWith(".webm") || url.endsWith(FileEncryption.EXTENSION)
                || url.contains("youtube.com") || url.contains("youtu.be") || url.contains("twitch.tv")) {
            playVideo(uuid, new Video(url, null, Video.FadeMode.BLACK, 1000L, 1000L, true));
        } else if (url.endsWith(".png") || url.endsWith(".jpg") || url.endsWith(".jpeg") || url.endsWith(".gif")) {
            playImage(uuid, new Image(url, 1f, 0f, 0f, 1000L, 3000L, 1000L));
        } else {
            MediaPlayerMod.LOGGER.error("Unknown media type: {}", url);
        }
    }

    private static void playVideo(UUID uuid, Video video) {
        try {
            URI uri = URLUtil.loadUri(video.url());
            MediaPlayerMod.LOGGER.info("Playing video: {}", uri);
            if (video.freezeScreen()) {
                closeCurrentVideoScreen();
                class_310 client = class_310.method_1551();
                client.execute(() -> {
                    VideoScreen videoScreen = new VideoScreen(uuid, video, uri);
                    currentVideoScreen = videoScreen;
                    client.method_1507(videoScreen);
                });
            } else {
                mediaOverlay.addDisplay(new VideoDisplay(uuid, video, uri));
            }
        } catch (MalformedURLException | URISyntaxException e) {
            MediaPlayerMod.LOGGER.error("Error loading video from URL", e);
        }
    }

    private static void playAudio(UUID uuid, Audio audio) {
        try {
            URI uri = URLUtil.loadUri(audio.url());
            MediaPlayerMod.LOGGER.info("Playing audio: {} (offset {} ms)", uri, audio.startOffset());
            MusicPlayer musicPlayer = new MusicPlayer();
            playingAudios.put(musicPlayer, uuid);
            long offset = audio.startOffset();
            if (offset > 0) {
                // Arranca en pausa, espera a que el reproductor este listo, salta al punto exacto
                // y reproduce. Asi el audio empieza ya sincronizado (sin oirse el principio).
                musicPlayer.startPaused(uri);
                Thread seekThread = new Thread(() -> {
                    long deadline = System.currentTimeMillis() + 5000L;
                    while (System.currentTimeMillis() < deadline) {
                        if (musicPlayer.isBroken()) {
                            return;
                        }
                        if (musicPlayer.isReady()) {
                            break;
                        }
                        try {
                            Thread.sleep(20L);
                        } catch (InterruptedException e) {
                            return;
                        }
                    }
                    musicPlayer.seekTo(offset);
                    musicPlayer.play();
                }, "MediaPlayer-Audio-Seek");
                seekThread.setDaemon(true);
                seekThread.start();
            } else {
                musicPlayer.start(uri);
            }
        } catch (MalformedURLException | URISyntaxException e) {
            MediaPlayerMod.LOGGER.error("Error loading audio from URL", e);
        }
    }

    private static void playImage(UUID uuid, Image image) {
        String finalUrl = URLUtil.fixUrl(image.url());
        MediaPlayerMod.LOGGER.info("Playing image: {}", finalUrl);
        class_310 client = class_310.method_1551();
        client.execute(() -> mediaOverlay.addDisplay(new ImageDisplay(uuid, image, finalUrl)));
    }

    private static void playInteractiveImage(UUID uuid, InteractiveImage image) {
        MediaPlayerMod.LOGGER.info("Inspecting image: {}", image.url());
        class_310 client = class_310.method_1551();
        me.elb.mediaplayermod.api.InspectImageSource back =
                image.backUrl() == null || image.backUrl().isBlank()
                        ? null : me.elb.mediaplayermod.api.InspectImageSource.url(image.backUrl());
        client.execute(() -> client.method_1507(new me.elb.mediaplayermod.client.gui.screen.ImageInspectScreen(
                me.elb.mediaplayermod.api.InspectImageSource.url(image.url()), back, null, uuid, image.bilinear())));
    }

    /** Cierra el inspeccionador de imagenes si esta abierto (stopmedia / desconexion). */
    private static void closeCurrentInspectScreen() {
        class_310 client = class_310.method_1551();
        client.execute(() -> {
            if (client.field_1755 instanceof me.elb.mediaplayermod.client.gui.screen.ImageInspectScreen inspectScreen) {
                inspectScreen.method_25419();
            }
        });
    }

    private static void playAnimation(UUID uuid, Animation animation) {
        class_310 client = class_310.method_1551();
        java.io.File dir = new java.io.File(client.field_1697, "config/mediaplayer/images/" + animation.folder());
        java.util.List<java.io.File> frames =
                AnimationDisplay.resolveFrames(dir, animation.firstFrame(), animation.lastFrame());
        if (frames.isEmpty()) {
            MediaPlayerMod.LOGGER.warn("No se encontraron fotogramas para la animacion '{}' ({}..{}) en {}",
                    animation.folder(), animation.firstFrame(), animation.lastFrame(), dir.getAbsolutePath());
            return;
        }
        int fps = Math.max(1, animation.fps());
        long frameMs = Math.max(1L, Math.round(1000.0 / fps));
        MediaPlayerMod.LOGGER.info("Playing animation '{}' ({} fotogramas a {} fps, {})",
                animation.folder(), frames.size(), fps, animation.position());
        client.execute(() -> mediaOverlay.addDisplay(
                new AnimationDisplay(uuid, frames, frameMs, animation.position())));
    }

    private static void playFade(UUID uuid, Fade fade) {
        MediaPlayerMod.LOGGER.info("Playing fade");
        if (fade.freezeScreen()) {
            closeCurrentFadeScreen();
            class_310 client = class_310.method_1551();
            client.execute(() -> {
                FadeScreen fadeScreen = new FadeScreen(uuid, fade);
                currentFadeScreen = fadeScreen;
                client.method_1507(fadeScreen);
            });
        } else {
            mediaOverlay.addDisplay(new FadeDisplay(uuid, fade));
        }
    }

    public static void playGlow(UUID uuid, Glow glow) {
        MediaPlayerMod.LOGGER.info("Playing glow");
        class_310.method_1551().execute(() -> mediaOverlay.addDisplay(new GlowDisplay(uuid, glow)));
    }

    private static void playColor(UUID uuid, Color color) {
        MediaPlayerMod.LOGGER.info("Playing color");
        class_310.method_1551().execute(() -> mediaOverlay.addDisplay(new ColorDisplay(uuid, color)));
    }

    private static void playBlink(UUID uuid, Blink blink) {
        MediaPlayerMod.LOGGER.info("Playing blink");
        class_310.method_1551().execute(() -> mediaOverlay.addDisplay(new BlinkDisplay(uuid, blink)));
    }

    private static void playSubtitles(UUID uuid, Subtitles subtitles) {
        String finalUrl = URLUtil.fixUrl(subtitles.url());
        MediaPlayerMod.LOGGER.info("Playing subtitles from: {}", finalUrl);
        class_310.method_1551().execute(() -> mediaOverlay.addDisplay(new SubtitlesDisplay(uuid, subtitles, finalUrl)));
    }

    private static void playProjection(Projection projection) {
        try {
            boolean hasVideo = projection.url() != null && !projection.url().isBlank();
            URI uri = hasVideo ? URLUtil.loadUri(projection.url()) : null;
            MediaPlayerMod.LOGGER.info("Starting projection '{}': {}", projection.id(), hasVideo ? uri : "(sin video)");
            class_310 client = class_310.method_1551();
            client.execute(() -> {
                getProjectionById(projection.id()).ifPresent(existing -> {
                    existing.remove();
                    projections.remove(existing);
                });
                ProjectionHandler handler = new ProjectionHandler(projection, uri);
                projections.add(handler);
            });
        } catch (MalformedURLException | URISyntaxException e) {
            MediaPlayerMod.LOGGER.error("Error loading projection from URL", e);
        }
    }

    private static void playProjectionOperation(ProjectionOperation op) {
        class_310.method_1551().execute(() -> {
            getProjectionById(op.id()).ifPresent(handler -> {
                switch (op.op()) {
                    case STOP -> handler.stop();
                    case REMOVE -> {
                        handler.remove();
                        projections.remove(handler);
                    }
                    case PAUSE -> handler.setPaused(true);
                    case RESUME -> handler.setPaused(false);
                    case LOOP_ON -> handler.setLoop(true);
                    case LOOP_OFF -> handler.setLoop(false);
                    case SET_URL -> {
                        try {
                            handler.setUrl(URLUtil.loadUri(op.url()));
                        } catch (MalformedURLException | URISyntaxException e) {
                            MediaPlayerMod.LOGGER.error("Error loading new projection URL", e);
                        }
                    }
                    case SEEK -> {
                        try {
                            handler.seek(Long.parseLong(op.url()));
                        } catch (NumberFormatException e) {
                            MediaPlayerMod.LOGGER.warn("Invalid projection seek value: {}", op.url());
                        }
                    }
                }
            });
        });
    }

    private static void playZoom(Zoom zoom) {
        float to = -zoom.value() / 100f + 1;
        MediaPlayerMod.LOGGER.info("Zooming to: {}", to);
        zoomTracker.setNewZoom(to, zoom.loadTime() / 50L);
    }

    private static void playCamera(Camera.Movement camera) {
        MediaPlayerMod.LOGGER.info("Setting camera perspective");
        cameraHandler.getCameraTransition().setNewObjective(camera, camera.loadTime());
    }

    private static void playCameraLimit(Camera.Limit limit) {
        MediaPlayerMod.LOGGER.info("Setting camera limit");
        cameraHandler.setLimit(limit);
    }

    private static void playCameraRotation(Camera.Rotation rotation) {
        MediaPlayerMod.LOGGER.info("Setting camera rotation");
        if (rotation.horizontal()) {
            cameraHandler.getYawTransition().setNewObjective(rotation.value(), rotation.loadTime());
        } else {
            cameraHandler.getPitchTransition().setNewObjective(rotation.value(), rotation.loadTime());
        }
    }

    private static void playText(Text text) {
        MediaPlayerMod.LOGGER.info("Playing text: {}", text.string());
        class_310.method_1551().execute(() -> mediaOverlay.addDisplay(new TextDisplay(UUID.randomUUID(), text)));
    }

    private static void playPlaylistOperation(UUID uuid, Playlist playlistMedia) {
        MediaPlayerMod.LOGGER.info("Playing playlist operation");
        switch (playlistMedia) {
            case Playlist.Delete delete -> {
                Iterator<ClientPlaylist> it = playlists.keySet().iterator();
                while (it.hasNext()) {
                    ClientPlaylist playlist = it.next();
                    if (playlist.getId().equals(delete.getId())) {
                        playlist.stop();
                        it.remove();
                        return;
                    }
                }
                MediaPlayerMod.LOGGER.warn("Playlist for delete not found: {}", delete.getId());
            }
            case Playlist.Add add -> {
                ClientPlaylist playlist = getPlaylist(add.getId());
                if (playlist != null) {
                    playlist.addAudio(add.getAudio());
                    return;
                }
                MediaPlayerMod.LOGGER.warn("Playlist for add not found: {}", add.getId());
            }
            case Playlist.Remove remove -> {
                ClientPlaylist playlist = getPlaylist(remove.getId());
                if (playlist != null) {
                    playlist.removeAudio(remove.getIndex());
                    return;
                }
                MediaPlayerMod.LOGGER.warn("Playlist for remove not found: {}", remove.getId());
            }
            case Playlist.Move move -> {
                ClientPlaylist playlist = getPlaylist(move.getId());
                if (playlist != null) {
                    playlist.moveAudio(move.getFromIndex(), move.getToIndex());
                    return;
                }
                MediaPlayerMod.LOGGER.warn("Playlist for move not found: {}", move.getId());
            }
            case Playlist.Tracks tracks -> {
                ClientPlaylist playlist = getPlaylist(tracks.getId());
                if (playlist != null) {
                    MediaPlayerMod.LOGGER.info("Playlist already exists, updating tracks");
                    playlist.updateTracks(tracks.getList());
                    playlist.setPaused(tracks.isPaused());
                    playlist.setLoop(tracks.isLoop());
                    playlist.setShuffle(tracks.isShuffle());
                    return;
                }
                playlist = new ClientPlaylist(tracks.getId(), (LinkedList<Audio>) tracks.getList());
                playlists.put(playlist, uuid);
                playlist.start();
                playlist.setPaused(tracks.isPaused());
                playlist.setLoop(tracks.isLoop());
                playlist.setShuffle(tracks.isShuffle());
            }
            case Playlist.Loop loop -> {
                ClientPlaylist playlist = getPlaylist(loop.getId());
                if (playlist != null) {
                    playlist.setLoop(loop.isLoop());
                    return;
                }
                MediaPlayerMod.LOGGER.warn("Playlist for loop not found: {}", loop.getId());
            }
            case Playlist.Paused paused -> {
                ClientPlaylist playlist = getPlaylist(paused.getId());
                if (playlist != null) {
                    playlist.setPaused(paused.isPaused());
                    return;
                }
                MediaPlayerMod.LOGGER.warn("Playlist for pause not found: {}", paused.getId());
            }
            case Playlist.Shuffled shuffled -> {
                ClientPlaylist playlist = getPlaylist(shuffled.getId());
                if (playlist != null) {
                    playlist.setShuffle(shuffled.isShuffle());
                    return;
                }
                MediaPlayerMod.LOGGER.warn("Playlist for shuffle not found: {}", shuffled.getId());
            }
            case Playlist.Skip skip -> {
                ClientPlaylist playlist = getPlaylist(skip.getId());
                if (playlist != null) {
                    if (skip.getDirection() < 0) {
                        playlist.skipPrev();
                    } else {
                        playlist.skipNext();
                    }
                    return;
                }
                MediaPlayerMod.LOGGER.warn("Playlist for skip not found: {}", skip.getId());
            }
            case Playlist.Jump jump -> {
                ClientPlaylist playlist = getPlaylist(jump.getId());
                if (playlist != null) {
                    playlist.playIndex(jump.getIndex());
                    return;
                }
                MediaPlayerMod.LOGGER.warn("Playlist for jump not found: {}", jump.getId());
            }
            default -> throw new IllegalStateException("Unexpected value: " + playlistMedia.getClass());
        }
    }
    private static ClientPlaylist getPlaylist(String id) {
        for (ClientPlaylist playlist : playlists.keySet()) {
            if (playlist.getId().equals(id)) {
                return playlist;
            }
        }
        return null;
    }

    public static java.util.Collection<ClientPlaylist> getActivePlaylists() {
        return java.util.Collections.unmodifiableSet(playlists.keySet());
    }

    private static void closeCurrentVideoScreen() {
        VideoScreen screen = currentVideoScreen;
        currentVideoScreen = null;
        if (screen != null) {
            // close() ya quita la pantalla de forma segura (solo si sigue siendo la actual);
            // el setScreen(null) incondicional que habia aqui tiraba pantallas nuevas de otros
            // medias cuando dos /playvideo llegaban seguidos.
            class_310.method_1551().execute(screen::method_25419);
        }
    }

    private static void closeCurrentFadeScreen() {
        class_310 client = class_310.method_1551();
        if (currentFadeScreen != null) {
            class_310.method_1551().execute(() -> {
                currentFadeScreen.method_25419();
                client.method_1507(null);
                currentFadeScreen = null;
            });
        }
    }

    public static void showPlaylistLyrics(String lyricsUrl, long startOffsetMs) {
        boolean wasReady = playlistReady;
        long readyTime = playlistReadyTime;
        hidePlaylistLyrics();
        String finalUrl = URLUtil.fixUrl(lyricsUrl);
        me.elb.mediaplayermod.model.media.Subtitles data =
                new me.elb.mediaplayermod.model.media.Subtitles(
                        finalUrl, "", 22.0, new java.awt.Color(255, 248, 210),
                        me.elb.mediaplayermod.model.media.Subtitles.Background.KARAOKE);
        lyricsDisplayUuid = UUID.randomUUID();
        UUID id = lyricsDisplayUuid;
        me.elb.mediaplayermod.client.gui.display.SubtitlesDisplay display =
                new me.elb.mediaplayermod.client.gui.display.SubtitlesDisplay(id, data, finalUrl, true, startOffsetMs);
        mediaOverlay.addDisplay(display);
        if (wasReady) {
            display.notifyLyricsReady(System.currentTimeMillis() - readyTime);
        }
    }

    public static void hidePlaylistLyrics() {
        if (lyricsDisplayUuid != null) {
            UUID toRemove = lyricsDisplayUuid;
            lyricsDisplayUuid = null;
            mediaOverlay.getDisplays().removeIf(d -> d.getUuid().equals(toRemove));
        }
        playlistReady = false;
        playlistReadyTime = 0L;
    }

    public static void notifyPlaylistLyricsReady() {
        playlistReady = true;
        playlistReadyTime = System.currentTimeMillis();
        if (lyricsDisplayUuid == null) return;
        UUID target = lyricsDisplayUuid;
        mediaOverlay.getDisplays().stream()
                .filter(d -> d.getUuid().equals(target))
                .filter(d -> d instanceof me.elb.mediaplayermod.client.gui.display.SubtitlesDisplay)
                .findFirst()
                .ifPresent(d -> ((me.elb.mediaplayermod.client.gui.display.SubtitlesDisplay) d).notifyLyricsReady(0L));
    }

    public static void notifyFinishedMediaToServer(UUID uuid) {
        // Al terminar un media deja de existir en la lista local de reproduccion.
        playingMedia.remove(uuid);
        ClientPlayNetworking.send(new MediaPayload(new ClientFinishedMediaPacket(uuid)));
    }

    public static void toggleSubtitles() {
        subtitles = !subtitles;
        class_746 player = class_310.method_1551().field_1724;
        if (player != null) {
            player.method_7353(subtitles ? net.minecraft.class_2561.method_43471("player.enabled_subtitles")
                : net.minecraft.class_2561.method_43471("player.disabled_subtitles"), true);
        }
    }

    public static void endTick() {
        class_310 client = class_310.method_1551();
        int audioVolume = VolumeUtil.getPlayerVolume(client, MediaSoundCategory.AUDIO);
        int videoVolume = VolumeUtil.getPlayerVolume(client, MediaSoundCategory.VIDEO);
        // El reproductor de overlays (VideoManager) suena por una linea de audio Java propia:
        // hay que aplicarle el volumen aqui cada tick o ignora todos los sliders.
        me.elb.mediaplayermod.cameraplayer.client.video.VideoManager.applyVolume(
                VolumeUtil.getMediaVolume(client, MediaSoundCategory.VIDEO));
        playingAudios.entrySet().removeIf(entry -> {
            MusicPlayer player = entry.getKey();
            long now = System.currentTimeMillis();
            if (player.isBroken()) {
                notifyFinishedMediaToServer(entry.getValue());
                finishedAudioAt.remove(player);
                try { player.release(); } catch (Exception ignored) {}
                return true;
            }
            if (player.isEnded()) {
                Long endedAt = finishedAudioAt.get(player);
                if (endedAt == null) {
                    // Primer tick tras terminar: avisa al servidor pero conserva el reproductor
                    // para que termine de sonar la cola pendiente (el "GO" del countdown, etc.).
                    finishedAudioAt.put(player, now);
                    notifyFinishedMediaToServer(entry.getValue());
                    return false;
                }
                if (now - endedAt >= AUDIO_DRAIN_GRACE_MS) {
                    finishedAudioAt.remove(player);
                    try { player.release(); } catch (Exception ignored) {}
                    return true;
                }
            }
            return false;
        });
        playingAudios.keySet().forEach(audioPlayer -> audioPlayer.setVolume(audioVolume));
        if (currentVideoScreen != null) {
            currentVideoScreen.setVolume(videoVolume);
        }
        mediaOverlay.getDisplays().forEach(display -> {
            if (display instanceof VideoDisplay videoDisplay) {
                videoDisplay.setVolume(videoVolume);
            }
        });
        playlists.keySet().removeIf(playlist -> {
            if (playlist.isFinished()) {
                notifyFinishedMediaToServer(playlists.get(playlist));
                return true;
            }
            return false;
        });
        playlists.keySet().forEach(playlist -> playlist.applyGlobalVolume(audioVolume));
    }
}
