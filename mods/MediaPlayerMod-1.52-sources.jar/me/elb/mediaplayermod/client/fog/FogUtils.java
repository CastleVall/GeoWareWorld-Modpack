package me.elb.mediaplayermod.client.fog;

import com.mojang.blaze3d.systems.RenderSystem;
import me.elb.mediaplayermod.model.fog.ExponentialFogConfig;
import me.elb.mediaplayermod.model.fog.FogConfig;
import me.elb.mediaplayermod.model.fog.FogType;
import me.elb.mediaplayermod.model.fog.LinearFogConfig;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.minecraft.class_758;
import lombok.experimental.UtilityClass;

@UtilityClass
public class FogUtils {
    private static FogConfig currentFogConfig;

    public static void setCurrentFogConfig(FogConfig fogConfig) {
        FogUtils.currentFogConfig = fogConfig;
    }

    public static void setFogFalloff(class_4184 camera, class_758.class_4596 fogType, float viewDistance) {
        class_5636 cameraSubmersionType = camera.method_19334();
        class_1297 entity = camera.method_19331();
        if (fogType == class_758.class_4596.field_20945) {
            RenderSystem.setShaderFogStart(0.0f);
            RenderSystem.setShaderFogEnd(viewDistance);
        } else if (cameraSubmersionType == class_5636.field_27888
                && !((entity instanceof class_1309 livingEntity) && livingEntity.method_6059(class_1294.field_5919))) {
            changeFalloff(viewDistance);
        }
    }

    private static void changeFalloff(float viewDistance) {
        if (currentFogConfig instanceof LinearFogConfig(float startMultiplier, float endMultiplier)) {
            RenderSystem.setShaderFogStart(viewDistance * startMultiplier);
            RenderSystem.setShaderFogEnd(viewDistance * endMultiplier);
        } else if (currentFogConfig instanceof ExponentialFogConfig(FogType fogType, float multiplier)) {
            if (fogType == FogType.EXPONENTIAL) {
                RenderSystem.setShaderFogStart(-512.0F);
                RenderSystem.setShaderFogEnd(multiplier / (0.3F * viewDistance));
            } else if (fogType == FogType.EXPONENTIAL_TWO) {
                RenderSystem.setShaderFogStart(-1024.0F);
                RenderSystem.setShaderFogEnd(multiplier / (50.0F * viewDistance));
            }
        } else if (currentFogConfig != null) {
            RenderSystem.setShaderFogStart(990000.0F);
            RenderSystem.setShaderFogEnd(1000000.0F);
        }
    }
}
