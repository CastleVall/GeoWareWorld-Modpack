package me.elb.mediaplayermod.client.gui.display;

import com.mojang.blaze3d.systems.RenderSystem;
import me.elb.mediaplayermod.model.media.Glow;
import net.minecraft.class_1921;
import net.minecraft.class_332;
import net.minecraft.class_4588;
import org.joml.Matrix4f;

import java.util.UUID;

public class GlowDisplay extends AbstractDisplay {
    private final Glow glow;

    public GlowDisplay(UUID uuid, Glow glow) {
        super(uuid, glow.fadeIn(), glow.duration(), glow.fadeOut());
        this.glow = glow;
    }

    @Override
    public void render(class_332 drawContext, float tickDelta, int width, int height) {
        int finalColor = (int) (getAlpha() * glow.opacity() * 255) << 24 | (glow.color() & 0x00FFFFFF);
        RenderSystem.enableBlend();
        float radius = glow.radius();
        drawContext.method_25296(0, 0, width, (int) ((height / 2f) * radius), finalColor, 0);
        drawContext.method_25296(0, (int) (height - (height / 2f) * radius), width, height, 0, finalColor);
        fillGradientVertical(drawContext, 0, 0, (int) ((width / 2f) * radius), height, finalColor, 0);
        fillGradientVertical(drawContext, (int) (width - (width / 2f) * radius), 0, width, height, 0, finalColor);
        RenderSystem.disableBlend();
    }

    public void fillGradientVertical(class_332 drawContext, int startX, int startY, int endX, int endY, int colorStart, int colorEnd) {
        class_4588 vertexConsumer = drawContext.method_51450().getBuffer(class_1921.method_51784());
        Matrix4f matrix4f = drawContext.method_51448().method_23760().method_23761();
        vertexConsumer.method_22918(matrix4f, startX, startY, 0).method_39415(colorStart);
        vertexConsumer.method_22918(matrix4f, endX, startY, 0).method_39415(colorEnd);
        vertexConsumer.method_22918(matrix4f, endX, endY, 0).method_39415(colorEnd);
        vertexConsumer.method_22918(matrix4f, startX, endY, 0).method_39415(colorStart);
        drawContext.method_51452();
    }
}
