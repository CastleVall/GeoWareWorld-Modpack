package me.elb.mediaplayermod.client.gui.display;

import com.mojang.blaze3d.systems.RenderSystem;
import me.elb.mediaplayermod.model.media.Color;
import net.minecraft.class_332;
import java.util.UUID;

public class ColorDisplay extends AbstractDisplay {
    private static final long FADE_TIME = 1000L;
    private final Color color;

    public ColorDisplay(UUID uuid, Color color) {
        super(uuid, FADE_TIME, color.duration(), FADE_TIME);
        this.color = color;
    }

    @Override
    public void render(class_332 drawContext, float tickDelta, int width, int height) {
        int finalColor = (int) (getAlpha() * color.opacity() * 255) << 24 | (color.color() & 0x00FFFFFF);
        RenderSystem.enableBlend();
        drawContext.method_25294(0, 0, width, height, finalColor);
        RenderSystem.disableBlend();
    }
}
