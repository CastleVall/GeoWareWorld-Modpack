package me.elb.mediaplayermod.client.gui.display;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.client.URLUtil;
import me.elb.mediaplayermod.model.media.Image;
import me.elb.mediaplayermod.utils.ImageUtils;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_332;
import net.minecraft.class_757;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.watermedia.api.image.ImageAPI;
import org.watermedia.api.image.ImageRenderer;
import org.watermedia.api.image.decoders.GifDecoder;

import javax.imageio.*;
import javax.imageio.stream.ImageInputStream;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.UUID;

public class ImageDisplay extends AbstractDisplay {
    private final Image image;
    private ImageRenderer imageRenderer;

    public ImageDisplay(UUID uuid, Image image, String url) {
        super(uuid, image.fadeIn(), image.duration(), image.fadeOut());
        this.image = image;
        try {
            URL imageURL = URLUtil.loadUrl(url);
            ImageInputStream imageInputStream = ImageIO.createImageInputStream(imageURL.openStream());
            if (ImageUtils.isGifImage(imageInputStream)) {
                GifDecoder gifDecoder = new GifDecoder();
                gifDecoder.read(imageURL.openStream());
                this.imageRenderer = ImageAPI.renderer(gifDecoder);
            } else {
                BufferedImage bufferedImage = ImageUtils.scaleImage(ImageIO.read(imageURL), image.size());
                this.imageRenderer = ImageAPI.renderer(bufferedImage);
            }
        } catch (IOException e) {
            MediaPlayerMod.LOGGER.error("Error loading image from URL", e);
        }
    }

    @Override
    public boolean hasEnded() {
        return imageRenderer == null || super.hasEnded();
    }

    @Override
    public void render(class_332 drawContext, float tickDelta, int width, int height) {
        long start = getStart();
        long startDiff = System.currentTimeMillis() - start;
        int tick = (int) (startDiff / 50);
        int texture = imageRenderer.texture(tick, 0, true);
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, getAlpha());
        RenderSystem.bindTexture(texture);
        RenderSystem.setShaderTexture(0, texture);
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);

        int imageWidth = imageRenderer.width;
        int imageHeight = imageRenderer.height;

        int renderWidth;
        int renderHeight;

        if (imageWidth > width) {
            renderWidth = width;
            renderHeight = (int) (width / (1F * imageWidth) * imageHeight);
        } else if (imageHeight > height) {
            renderHeight = height;
            renderWidth = (int) (height / (1F * imageHeight) * imageWidth);
        } else {
            renderWidth = imageWidth;
            renderHeight = imageHeight;
        }

        int xOffset = (int) (((image.xOffset() + 1) * width - renderWidth) / 2);
        int yOffset = (int) (((image.yOffset() + 1) * height - renderHeight) / 2);

        Matrix4f matrix4f = drawContext.method_51448().method_23760().method_23761();
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1585);
        bufferBuilder.method_22918(matrix4f, xOffset, yOffset, 0).method_22913(0, 0);
        bufferBuilder.method_22918(matrix4f, xOffset, (yOffset + renderHeight), 0).method_22913(0, 1);
        bufferBuilder.method_22918(matrix4f, (xOffset + renderWidth), (yOffset + renderHeight), 0).method_22913(1, 1);
        bufferBuilder.method_22918(matrix4f, (xOffset + renderWidth), yOffset, 0).method_22913(1, 0);
        class_286.method_43433(bufferBuilder.method_60800());
        RenderSystem.disableBlend();
    }
}
