package me.elb.mediaplayermod.client.gui.display;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.client.ClientHandler;
import me.elb.mediaplayermod.client.URLUtil;
import me.elb.mediaplayermod.client.gui.display.subtitle.BilingualSubtitles;
import me.elb.mediaplayermod.utils.ImageUtils;
import io.github.gusthavosouza.srt.SRTParser;
import io.github.gusthavosouza.srt.Subtitle;
import io.github.gusthavosouza.srt.Subtitles;
import net.minecraft.class_2561;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5481;
import net.minecraft.class_757;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.watermedia.api.image.ImageAPI;
import org.watermedia.api.image.ImageRenderer;

import java.awt.*;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

public class SubtitlesDisplay extends me.elb.mediaplayermod.client.gui.display.AbstractDisplay {
    private final me.elb.mediaplayermod.model.media.Subtitles subtitlesData;
    private final Font font;
    private final Font smallFont;
    private final boolean lyricsMode;
    private final long startOffset;

    /** Subtitulo bilingue (es/en) cargado desde .yml; null para el modo SRT clasico. */
    private final BilingualSubtitles script;
    /** true cuando el .yml usa la fuente nativa de Minecraft (render rapido). */
    private final boolean useNativeFont;

    private BilingualSubtitles.Cue biCue;
    private boolean biEnglish;
    private ImageRenderer biRenderer;

    private Subtitles subtitles;
    private List<SrtEntry> srtEntries = Collections.emptyList();

    private ImageRenderer imageRenderer;
    private ImageRenderer nextImageRenderer;
    private Subtitle lastSubtitleGenerated;
    private String lastNextText;

    private volatile boolean lyricsReady = false;
    private volatile long lyricsStart = 0L;

    public void notifyLyricsReady(long elapsedMs) {
        if (!lyricsReady) {
            lyricsReady = true;
            lyricsStart = System.currentTimeMillis() - elapsedMs;
        }
    }

    private record SrtEntry(long startMs, long endMs, String text) {}

    public SubtitlesDisplay(UUID uuid, me.elb.mediaplayermod.model.media.Subtitles subtitlesData, String url) {
        this(uuid, subtitlesData, url, false, 0L);
    }

    public SubtitlesDisplay(UUID uuid, me.elb.mediaplayermod.model.media.Subtitles subtitlesData, String url, boolean lyricsMode) {
        this(uuid, subtitlesData, url, lyricsMode, 0L);
    }

    public SubtitlesDisplay(UUID uuid, me.elb.mediaplayermod.model.media.Subtitles subtitlesData, String url, boolean lyricsMode, long startOffsetMs) {
        super(uuid, 500L, 0L, 500L);
        this.lyricsMode = lyricsMode;
        this.startOffset = startOffsetMs;
        this.subtitlesData = subtitlesData;

        // Detecta un archivo bilingue config/mediaplayer/subtitulos/<nombre>.yml
        java.nio.file.Path scriptPath = BilingualSubtitles.resolveFile(url);
        if (scriptPath == null) scriptPath = BilingualSubtitles.resolveFile(subtitlesData.url());
        this.script = scriptPath != null ? BilingualSubtitles.load(scriptPath) : null;

        String rawFont = subtitlesData.fontName();
        this.useNativeFont = script != null && isNativeFont(rawFont);

        if (this.useNativeFont) {
            // Modo nativo: no se carga ninguna fuente AWT.
            this.font = null;
            this.smallFont = null;
        } else {
            String fontName = rawFont == null ? "" : rawFont;
            if (!fontName.contains(".ttf") && !fontName.contains(".otf")) {
                fontName += ".ttf";
            }
            this.font = loadFont(fontName, (float) subtitlesData.size());
            this.smallFont = this.font.deriveFont((float) subtitlesData.size() * 0.62f);
        }

        if (this.script != null) {
            long dur = script.durationMs();
            this.duration = dur > 0 ? dur + 800L : -1;
        } else {
            loadSubtitles(url);
            if (subtitles != null) {
                long dur = subtitles.getDuration();
                this.duration = dur > 0 ? dur : -1;
            } else {
                this.duration = -1;
            }
        }
    }

    private static boolean isNativeFont(String f) {
        if (f == null) return true;
        String s = f.trim().toLowerCase();
        return s.isEmpty() || s.equals("minecraft") || s.equals("mc")
                || s.equals("default") || s.equals("vanilla") || s.equals("minecraft.otf");
    }

    private static Font loadFont(String name, float size) {
        String[] candidates = {name, Character.toUpperCase(name.charAt(0)) + name.substring(1)};
        for (String candidate : candidates) {
            String path = "assets/mediaplayer/fonts/" + candidate;
            try (InputStream in = SubtitlesDisplay.class.getClassLoader().getResourceAsStream(path)) {
                if (in != null) {
                    return Font.createFont(Font.TRUETYPE_FONT, in).deriveFont(size);
                }
            } catch (IOException | FontFormatException ignored) {
            }
        }
        MediaPlayerMod.LOGGER.warn("Font not found: {}, using fallback", name);
        return new Font(Font.SANS_SERIF, Font.PLAIN, (int) size);
    }

    private void loadSubtitles(String url) {
        try {
            URL subtitlesURL = URLUtil.loadUrl(url);
            byte[] bytes = subtitlesURL.openStream().readAllBytes();
            this.subtitles = SRTParser.loadSubtitles(new ByteArrayInputStream(bytes), true);
            this.srtEntries = parseSrtEntries(new String(bytes, StandardCharsets.UTF_8));
        } catch (IOException e) {
            MediaPlayerMod.LOGGER.error("Error loading subtitles from URL", e);
        }
    }

    private static List<SrtEntry> parseSrtEntries(String raw) {
        if (raw.startsWith("\uFEFF")) raw = raw.substring(1);
        List<SrtEntry> list = new ArrayList<>();
        for (String block : raw.split("\\n{2,}")) {
            String[] lines = block.trim().split("\\r?\\n");
            if (lines.length < 3) continue;
            String[] timeParts = lines[1].split("-->");
            if (timeParts.length < 2) continue;
            long start = parseSrtTime(timeParts[0].trim());
            long end   = parseSrtTime(timeParts[1].trim());
            if (start < 0 || end < 0) continue;
            StringBuilder sb = new StringBuilder();
            for (int i = 2; i < lines.length; i++) {
                if (i > 2) sb.append(' ');
                sb.append(lines[i].trim());
            }
            list.add(new SrtEntry(start, end, sb.toString()));
        }
        return list;
    }

    private static long parseSrtTime(String s) {
        try {
            String[] parts = s.trim().replace(',', '.').split(":");
            if (parts.length != 3) return -1;
            long h = Long.parseLong(parts[0].trim());
            long m = Long.parseLong(parts[1].trim());
            double sec = Double.parseDouble(parts[2].trim());
            return h * 3_600_000L + m * 60_000L + (long) (sec * 1000);
        } catch (Exception e) {
            return -1;
        }
    }

    private String getNextSubtitleText(long currentMs) {
        for (int i = 0; i < srtEntries.size() - 1; i++) {
            SrtEntry e = srtEntries.get(i);
            if (currentMs >= e.startMs() && currentMs <= e.endMs()) {
                return srtEntries.get(i + 1).text();
            }
        }
        return null;
    }

    @Override
    public void render(class_332 drawContext, float tickDelta, int width, int height) {
        if (!lyricsMode && !ClientHandler.isSubtitles()) return;

        // Ruta bilingue (.yml). El modo SRT clasico queda intacto mas abajo.
        if (script != null) {
            long t = System.currentTimeMillis() - getStart() + startOffset;
            float alpha = getAlpha();
            if (useNativeFont) renderBilingualNative(drawContext, t, width, height, alpha);
            else renderBilingualImage(drawContext, t, width, height, alpha);
            return;
        }

        if (subtitles == null) return;

        long startDiff;
        if (lyricsMode) {
            if (lyricsReady) {
                startDiff = System.currentTimeMillis() - lyricsStart;
            } else if (System.currentTimeMillis() - getStart() > 15_000L) {
                lyricsReady = true;
                lyricsStart = getStart();
                startDiff = System.currentTimeMillis() - lyricsStart;
            } else {
                return;
            }
        } else {
            startDiff = System.currentTimeMillis() - getStart() + startOffset;
        }
        Subtitle subtitle = subtitles.getSubtitle(startDiff);
        float alpha = getAlpha();

        me.elb.mediaplayermod.model.media.Subtitles.Background bg = subtitlesData.background();
        boolean isKaraoke = bg == me.elb.mediaplayermod.model.media.Subtitles.Background.KARAOKE;

        int imageHeight;
        int imageWidth;
        int nextLineH = isKaraoke ? (int) (height * 0.08) : 0;

        switch (bg) {
            case BUBBLE -> {
                imageHeight = (int) (height * 0.14);
                imageWidth  = (int) (width  * 0.60);
            }
            case KARAOKE -> {
                imageHeight = (int) (height * 0.12);
                imageWidth  = (int) (width  * 0.78);
            }
            default -> {
                imageHeight = (int) (height * 0.18);
                imageWidth  = (int) (width  * 0.85);
            }
        }

        int xOffset  = (width - imageWidth) / 2;
        int yOffset  = height - imageHeight - 16;

        RenderSystem.enableBlend();

        switch (bg) {
            case FADED -> {
                int transparent = 0;
                int gradMid  = ((int) (alpha * 105)) << 24;
                int gradFull = ((int) (alpha * 205)) << 24;
                int fadeStart = (int) (height * 0.59f);
                int midPoint  = (int) (height * 0.71f);
                drawContext.method_25296(0, fadeStart, width, midPoint, transparent, gradMid);
                drawContext.method_25296(0, midPoint,  width, height,   gradMid, gradFull);
            }
            case BUBBLE -> {
                int px = 20, py = 13;
                int shadow = ((int) (alpha * 0.36f * 255)) << 24;
                drawContext.method_25294(xOffset - px - 3, yOffset - py - 1, xOffset + imageWidth + px + 3, yOffset + imageHeight + py + 3, shadow);
                int bgTop    = ((int) (alpha * 0.68f * 255)) << 24;
                int bgBottom = ((int) (alpha * 0.88f * 255)) << 24;
                drawContext.method_25296(xOffset - px, yOffset - py, xOffset + imageWidth + px, yOffset + imageHeight + py, bgTop, bgBottom);
                int highlight = ((int) (alpha * 0.42f * 255)) << 24 | 0xC0C0C0;
                drawContext.method_25294(xOffset - px, yOffset - py, xOffset + imageWidth + px, yOffset - py + 1, highlight);
                int bottomLine = ((int) (alpha * 0.95f * 255)) << 24;
                drawContext.method_25294(xOffset - px, yOffset + imageHeight + py - 1, xOffset + imageWidth + px, yOffset + imageHeight + py, bottomLine);
            }
            case KARAOKE -> {
                int barTop = height - imageHeight - nextLineH - 50;

                int transparent = 0;
                int semiDark = ((int) (alpha * 0.38f * 255)) << 24;
                int fullDark = ((int) (alpha * 0.82f * 255)) << 24 | 0x000008;

                drawContext.method_25296(0, barTop - 20, width, barTop,      transparent, semiDark);
                drawContext.method_25296(0, barTop,      width, barTop + 10, semiDark, fullDark);
                drawContext.method_25294       (0, barTop + 10,  width, height,      fullDark);

                int accent = ((int) (alpha * 0.75f * 255)) << 24 | 0x4466DD;
                drawContext.method_25294(0, barTop - 1, width, barTop + 2, accent);
            }
            case NONE -> {}
        }

        if (subtitle != null) {
            if (imageRenderer == null || imageRenderer.width != width
                    || imageRenderer.height != imageHeight
                    || subtitle != lastSubtitleGenerated) {
                this.imageRenderer = ImageAPI.renderer(
                        ImageUtils.createTextImage(width, imageHeight, subtitle.getText(), font, subtitlesData.color()));
                this.lastSubtitleGenerated = subtitle;
            }

            int tick = (int) (startDiff / 50);
            renderTexture(drawContext, imageRenderer.texture(tick, 0, true), alpha, xOffset, yOffset, imageWidth, imageHeight);

            if (isKaraoke && nextLineH > 0) {
                String nextText = getNextSubtitleText(startDiff);
                if (nextText != null && !nextText.isBlank()) {
                    if (nextImageRenderer == null || nextImageRenderer.height != nextLineH
                            || !nextText.equals(lastNextText)) {
                        nextImageRenderer = ImageAPI.renderer(
                                ImageUtils.createTextImage(width, nextLineH, nextText, smallFont,
                                        new Color(185, 185, 210)));
                        lastNextText = nextText;
                    }
                    int nextY = yOffset - nextLineH - 6;
                    renderTexture(drawContext, nextImageRenderer.texture(tick, 0, true),
                            alpha * 0.52f, xOffset, nextY, imageWidth, nextLineH);
                } else {
                    nextImageRenderer = null;
                    lastNextText = null;
                }
            }
        } else {
            imageRenderer     = null;
            nextImageRenderer = null;
            lastNextText      = null;
        }

        RenderSystem.disableBlend();
    }

    private static boolean isEnglishClient() {
        try {
            String lang = class_310.method_1551().method_1526().method_4669();
            return lang != null && lang.toLowerCase().startsWith("en");
        } catch (Exception e) {
            return false;
        }
    }

    private static int clampByte(int v) {
        return v < 0 ? 0 : Math.min(v, 255);
    }

    /** Y de la action bar de Minecraft (sobre la hotbar/vida); +14 si no hay barras de estado. */
    private static float actionBarY(int height) {
        int y = height - 68;
        try {
            var im = class_310.method_1551().field_1761;
            if (im != null && !im.method_2908()) y += 14;
        } catch (Exception ignored) {
        }
        return y;
    }

    /** Render bilingue con la fuente nativa de Minecraft: rapido, nitido y estilo vanilla. */
    private void renderBilingualNative(class_332 ctx, long t, int width, int height, float alpha) {
        BilingualSubtitles.Cue cue = script.active(t);
        if (cue == null) return;
        String text = cue.text(isEnglishClient());
        if (text.isBlank()) return;

        class_327 tr = class_310.method_1551().field_1772;
        float scale = Math.max(0.5f, (float) subtitlesData.size() / 16f);

        int maxTextWidth = Math.max(60, (int) ((width * 0.78f) / scale));
        List<class_5481> lines = tr.method_1728(class_2561.method_43470(text), maxTextWidth);
        if (lines.size() > 3) lines = lines.subList(0, 3);

        int lineH = tr.field_2000 + 2;
        int textBlockH = lines.size() * lineH - 2;
        int maxLineW = 0;
        for (class_5481 ot : lines) maxLineW = Math.max(maxLineW, tr.method_30880(ot));

        int padX = 8, padY = 5;
        int boxW = maxLineW + padX * 2;
        int boxH = textBlockH + padY * 2;

        float screenCenterX = width / 2f;
        float marginY = height * 0.06f;
        float boxScreenH = boxH * scale;
        float boxTopScreen = switch (script.position()) {
            case TOP -> marginY;
            case CENTER -> (height - boxScreenH) / 2f;
            // 'abajo' = misma altura que la action bar de Minecraft (sobre la hotbar/vida).
            // La ultima linea queda en la linea de la action bar y las extra crecen hacia arriba.
            default -> actionBarY(height) - (padY + (lines.size() - 1) * lineH) * scale;
        };

        int textColor = (clampByte((int) (alpha * 255)) << 24) | (subtitlesData.color().getRGB() & 0xFFFFFF);

        var matrices = ctx.method_51448();
        matrices.method_22903();
        matrices.method_22904((double) screenCenterX, (double) boxTopScreen, 0.0);
        matrices.method_22905(scale, scale, 1f);

        int left = -boxW / 2, right = boxW / 2;

        me.elb.mediaplayermod.model.media.Subtitles.Background bg = subtitlesData.background();
        if (bg != me.elb.mediaplayermod.model.media.Subtitles.Background.NONE) {
            int fillAlpha = clampByte((int) (alpha * (bg == me.elb.mediaplayermod.model.media.Subtitles.Background.FADED ? 110 : 175)));
            ctx.method_25294(left, 0, right, boxH, fillAlpha << 24);
            int edgeAlpha = clampByte((int) (alpha * 70));
            ctx.method_25294(left, 0, right, 1, (edgeAlpha << 24) | 0xFFFFFF);
            ctx.method_25294(left, boxH - 1, right, boxH, (clampByte((int) (alpha * 120)) << 24));
        }

        int y = padY;
        for (class_5481 ot : lines) {
            int x = -tr.method_30880(ot) / 2;
            ctx.method_35720(tr, ot, x, y, textColor);
            y += lineH;
        }
        matrices.method_22909();
    }

    /** Render bilingue con una fuente TTF custom (camino por imagen AWT). */
    private void renderBilingualImage(class_332 ctx, long t, int width, int height, float alpha) {
        BilingualSubtitles.Cue cue = script.active(t);
        if (cue == null) {
            biRenderer = null;
            biCue = null;
            return;
        }
        boolean english = isEnglishClient();
        String text = cue.text(english);
        if (text.isBlank()) {
            biRenderer = null;
            biCue = null;
            return;
        }

        int imageHeight = (int) (height * 0.16);
        int imageWidth = (int) (width * 0.85);
        if (biRenderer == null || cue != biCue || english != biEnglish || biRenderer.width != imageWidth) {
            biRenderer = ImageAPI.renderer(
                    ImageUtils.createTextImage(imageWidth, imageHeight, text, font, subtitlesData.color()));
            biCue = cue;
            biEnglish = english;
        }

        int xOffset = (width - imageWidth) / 2;
        float marginY = height * 0.06f;
        int yOffset = switch (script.position()) {
            case TOP -> (int) marginY;
            case CENTER -> (height - imageHeight) / 2;
            // 'abajo' = a la altura de la action bar (el texto va centrado en la imagen).
            default -> (int) (actionBarY(height) - imageHeight / 2f);
        };

        RenderSystem.enableBlend();
        int tick = (int) (t / 50);
        renderTexture(ctx, biRenderer.texture(tick, 0, true), alpha, xOffset, yOffset, imageWidth, imageHeight);
        RenderSystem.disableBlend();
    }

    private static void renderTexture(class_332 drawContext, int texture, float alpha,
                                      int x, int y, int w, int h) {
        RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
        RenderSystem.setShaderColor(1f, 1f, 1f, alpha);
        RenderSystem.bindTexture(texture);
        RenderSystem.setShaderTexture(0, texture);
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        Matrix4f mat = drawContext.method_51448().method_23760().method_23761();
        class_287 buf = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1585);
        buf.method_22918(mat, x,     y,     0).method_22913(0, 0);
        buf.method_22918(mat, x,     y + h, 0).method_22913(0, 1);
        buf.method_22918(mat, x + w, y + h, 0).method_22913(1, 1);
        buf.method_22918(mat, x + w, y,     0).method_22913(1, 0);
        class_286.method_43433(buf.method_60800());
    }
}
