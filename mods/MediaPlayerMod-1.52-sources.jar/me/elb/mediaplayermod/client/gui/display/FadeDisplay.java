package me.elb.mediaplayermod.client.gui.display;

import com.mojang.blaze3d.systems.RenderSystem;
import me.elb.mediaplayermod.model.media.Fade;
import net.minecraft.class_332;
import java.util.UUID;

public class FadeDisplay extends AbstractDisplay {
    private final Fade fade;

    public FadeDisplay(UUID uuid, Fade fade) {
        super(uuid, fade.fadeIn(), fade.duration(), fade.fadeOut());
        this.fade = fade;
    }

    @Override
    public void render(class_332 drawContext, float tickDelta, int width, int height) {
        renderFade(drawContext, fade, getAlpha(), width, height);
    }

    /**
     * Dibuja el fade segun su estilo. {@code alpha} (0-1) es la curva fadeIn/duration/fadeOut de
     * siempre: en FULL es la opacidad; en las barras es cuanto se cerraron (1 = pantalla cubierta).
     * Lo comparte FadeScreen (freezeScreen) para que ambos caminos se vean identicos.
     */
    public static void renderFade(class_332 drawContext, Fade fade, float alpha, int width, int height) {
        RenderSystem.enableBlend();
        switch (fade.style()) {
            case FULL -> {
                int finalColor = (int) (alpha * 255) << 24 | (fade.color() & 0x00FFFFFF);
                drawContext.method_25294(0, 0, width, height, finalColor);
            }
            case BAR_VERTICAL -> {
                // Barras opacas tipo cine desde arriba y abajo; ceil evita una linea sin cubrir
                // en el medio con alturas impares cuando alpha llega a 1.
                int opaque = 0xFF000000 | (fade.color() & 0x00FFFFFF);
                int barHeight = (int) Math.ceil(alpha * height / 2f);
                if (barHeight > 0) {
                    drawContext.method_25294(0, 0, width, barHeight, opaque);
                    drawContext.method_25294(0, height - barHeight, width, height, opaque);
                }
            }
            case BAR_HORIZONTAL -> {
                int opaque = 0xFF000000 | (fade.color() & 0x00FFFFFF);
                int barWidth = (int) Math.ceil(alpha * width / 2f);
                if (barWidth > 0) {
                    drawContext.method_25294(0, 0, barWidth, height, opaque);
                    drawContext.method_25294(width - barWidth, 0, width, height, opaque);
                }
            }
        }
        RenderSystem.disableBlend();
    }
}
