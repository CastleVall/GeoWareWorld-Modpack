package me.elb.mediaplayermod.client.gui.display;

import com.mojang.blaze3d.systems.RenderSystem;
import me.elb.mediaplayermod.model.media.Blink;
import net.minecraft.class_332;
import java.util.UUID;

public class BlinkDisplay extends AbstractDisplay {

    public BlinkDisplay(UUID uuid, Blink blink) {
        super(uuid, blink.fadeIn(), blink.duration(), blink.fadeOut());
    }

    @Override
    public void render(class_332 drawContext, float tickDelta, int width, int height) {
        float alpha = getAlpha();
        if (alpha <= 0) return;
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        int color = ((int) (alpha * 255) << 24);
        drawContext.method_25294(0, 0, width, height, color);
        RenderSystem.disableBlend();
    }
}
