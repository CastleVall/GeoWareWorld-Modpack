package me.elb.mediaplayermod.client.gui.display;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.model.media.Text;
import me.elb.mediaplayermod.utils.ImageUtils;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_332;
import net.minecraft.class_757;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.watermedia.api.image.ImageAPI;
import org.watermedia.api.image.ImageRenderer;

import java.awt.*;
import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

public class TextDisplay extends AbstractDisplay {
    private final Text text;
    private final Font font;
    private ImageRenderer imageRenderer;

    public TextDisplay(UUID uuid, Text text) {
        super(uuid, text.fadeIn(), text.duration(), text.fadeOut());
        this.text = text;
        String fontName = text.fontName();
        if (!fontName.contains(".ttf") && !fontName.contains(".otf")) {
            fontName += ".ttf";
        }
        this.font = loadFont(fontName, (float) text.size());
    }

    private static Font loadFont(String name, float size) {
        String[] candidates = {name, Character.toUpperCase(name.charAt(0)) + name.substring(1)};
        for (String candidate : candidates) {
            String path = "assets/mediaplayer/fonts/" + candidate;
            try (InputStream in = TextDisplay.class.getClassLoader().getResourceAsStream(path)) {
                if (in != null) {
                    return Font.createFont(Font.TRUETYPE_FONT, in).deriveFont(size);
                }
            } catch (IOException | FontFormatException ignored) {
            }
        }
        MediaPlayerMod.LOGGER.warn("Font not found: {}, using fallback", name);
        return new Font(Font.SANS_SERIF, Font.PLAIN, (int) size);
    }

    @Override
    public void render(class_332 drawContext, float tickDelta, int width, int height) {
        if (imageRenderer == null) {
            this.imageRenderer = ImageAPI.renderer(ImageUtils.createTextImage(width, height, text.string(),
                    font, text.color()));
        }
        long start = getStart();
        long startDiff = System.currentTimeMillis() - start;
        int tick = (int) (startDiff / 50);
        int texture = imageRenderer.texture(tick, 0, true);

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, getAlpha());
        RenderSystem.bindTexture(texture);
        RenderSystem.setShaderTexture(0, texture);
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);

        int imageWidth = imageRenderer.width;
        int imageHeight = imageRenderer.height;
        int xOffset = (int) (((text.xOffset() + 1) * width - imageWidth) / 2);
        int yOffset = (int) (((text.yOffset() + 1) * height - imageHeight) / 2);

        Matrix4f matrix4f = drawContext.method_51448().method_23760().method_23761();
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1585);
        bufferBuilder.method_22918(matrix4f, xOffset, yOffset, 0).method_22913(0, 0);
        bufferBuilder.method_22918(matrix4f, xOffset, (yOffset + imageHeight), 0).method_22913(0, 1);
        bufferBuilder.method_22918(matrix4f, (xOffset + imageWidth), (yOffset + imageHeight), 0).method_22913(1, 1);
        bufferBuilder.method_22918(matrix4f, (xOffset + imageWidth), yOffset, 0).method_22913(1, 0);
        class_286.method_43433(bufferBuilder.method_60800());
        RenderSystem.disableBlend();
    }
}
