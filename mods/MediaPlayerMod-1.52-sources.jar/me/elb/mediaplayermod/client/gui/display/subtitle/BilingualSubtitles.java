package me.elb.mediaplayermod.client.gui.display.subtitle;

import me.elb.mediaplayermod.MediaPlayerMod;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Subtitulo bilingue (es/en) cargado desde un archivo .yml friendly ubicado en
 * {@code config/mediaplayer/subtitulos/<nombre>.yml}.
 *
 * <p>Esquema:
 * <pre>
 * posicion: abajo      # arriba | centro | abajo  (opcional, default abajo)
 * lineas:
 *   - start: 1.0       # segundos (admite decimales)
 *     end: 3.0
 *     es: "Hola mundo"
 *     en: "Hello world"
 * </pre>
 *
 * Cada cliente elige el idioma segun el idioma de su juego: cualquier variante de
 * ingles ({@code en_*}) muestra {@code en}; el resto muestra {@code es}.
 */
public final class BilingualSubtitles {

    public enum Position {
        TOP, CENTER, BOTTOM;

        public static Position fromString(String s) {
            if (s == null) return BOTTOM;
            return switch (s.trim().toLowerCase()) {
                case "arriba", "top", "up", "encima" -> TOP;
                case "centro", "center", "middle", "medio" -> CENTER;
                default -> BOTTOM;
            };
        }
    }

    public record Cue(long startMs, long endMs, String es, String en) {
        /** Texto para el idioma pedido, con fallback al otro idioma si falta. */
        public String text(boolean english) {
            String primary = english ? en : es;
            if (primary != null && !primary.isBlank()) return primary;
            String fallback = english ? es : en;
            return fallback == null ? "" : fallback;
        }
    }

    private final Position position;
    private final List<Cue> cues;

    public BilingualSubtitles(Position position, List<Cue> cues) {
        this.position = position;
        this.cues = cues;
    }

    public Position position() {
        return position;
    }

    public List<Cue> cues() {
        return cues;
    }

    public long durationMs() {
        long max = 0;
        for (Cue c : cues) max = Math.max(max, c.endMs());
        return max;
    }

    /** Cue activo para el instante {@code t} (ms desde el inicio); el ultimo en empezar gana. */
    public Cue active(long t) {
        Cue best = null;
        for (Cue c : cues) {
            if (t >= c.startMs() && t <= c.endMs()) best = c;
        }
        return best;
    }

    /** Resuelve el nombre de un subtitulo a su archivo .yml; null si no es un nombre valido o no existe. */
    public static Path resolveFile(String name) {
        if (name == null) return null;
        String n = name.trim();
        if (n.isEmpty()) return null;
        // Solo nombres simples: descarta urls, rutas y caracteres ilegales.
        if (n.contains("/") || n.contains("\\") || n.contains(":") || n.contains("..")) return null;
        String lower = n.toLowerCase();
        if (lower.endsWith(".yml")) n = n.substring(0, n.length() - 4);
        else if (lower.endsWith(".yaml")) n = n.substring(0, n.length() - 5);
        try {
            Path dir = FabricLoader.getInstance().getConfigDir().resolve("mediaplayer").resolve("subtitulos");
            Path yml = dir.resolve(n + ".yml");
            if (Files.exists(yml)) return yml;
            Path yaml = dir.resolve(n + ".yaml");
            if (Files.exists(yaml)) return yaml;
        } catch (InvalidPathException ignored) {
        }
        return null;
    }

    public static BilingualSubtitles load(Path file) {
        try {
            return parse(Files.readAllLines(file, StandardCharsets.UTF_8));
        } catch (IOException e) {
            MediaPlayerMod.LOGGER.error("Error cargando subtitulos bilingues: {}", file, e);
            return null;
        }
    }

    // ------------------------------------------------------------------
    // Parser YAML minimo, hecho a medida del esquema fijo de arriba.
    // ------------------------------------------------------------------

    private static BilingualSubtitles parse(List<String> raw) {
        Position position = Position.BOTTOM;
        List<Cue> cues = new ArrayList<>();
        boolean inList = false;

        Double start = null, end = null;
        String es = null, en = null;
        boolean haveCue = false;

        for (String original : raw) {
            String line = stripComment(original);
            if (line.trim().isEmpty()) continue;
            String trimmed = line.trim();

            if (!inList) {
                if (trimmed.equalsIgnoreCase("lineas:") || trimmed.equalsIgnoreCase("lines:")) {
                    inList = true;
                    continue;
                }
                Kv kv = splitKv(trimmed);
                if (kv == null) continue;
                String k = kv.key().toLowerCase();
                if (k.equals("posicion") || k.equals("position")) {
                    position = Position.fromString(unquote(kv.value()));
                }
                continue;
            }

            boolean isItemStart = trimmed.startsWith("-");
            String content = trimmed;
            if (isItemStart) {
                if (haveCue) addCue(cues, start, end, es, en);
                start = null; end = null; es = null; en = null;
                haveCue = true;
                content = trimmed.substring(1).trim();
                if (content.isEmpty()) continue;
            }

            Kv kv = splitKv(content);
            if (kv == null) continue;
            switch (kv.key().toLowerCase()) {
                case "start", "inicio" -> start = parseSeconds(kv.value());
                case "end", "fin" -> end = parseSeconds(kv.value());
                case "es", "espanol", "español" -> es = unquote(kv.value());
                case "en", "ingles", "inglés", "english" -> en = unquote(kv.value());
                default -> { /* ignorado */ }
            }
        }
        if (haveCue) addCue(cues, start, end, es, en);

        if (cues.isEmpty()) return null;
        return new BilingualSubtitles(position, cues);
    }

    private static void addCue(List<Cue> cues, Double start, Double end, String es, String en) {
        if (start == null) return;
        long s = (long) (start * 1000);
        long e = end == null ? s + 3000 : (long) (end * 1000);
        if (e < s) e = s + 3000;
        cues.add(new Cue(s, e, es == null ? "" : es, en == null ? "" : en));
    }

    private static Double parseSeconds(String v) {
        try {
            return Double.parseDouble(unquote(v).trim());
        } catch (Exception e) {
            return null;
        }
    }

    private record Kv(String key, String value) {}

    /** Separa {@code key: value} por el primer ':' fuera de comillas. */
    private static Kv splitKv(String s) {
        boolean inSingle = false, inDouble = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\'' && !inDouble) inSingle = !inSingle;
            else if (c == '"' && !inSingle) inDouble = !inDouble;
            else if (c == ':' && !inSingle && !inDouble) {
                String key = s.substring(0, i).trim();
                if (key.isEmpty()) return null;
                return new Kv(key, s.substring(i + 1).trim());
            }
        }
        return null;
    }

    /** Quita comentarios {@code #} que esten fuera de comillas y precedidos por espacio/al inicio. */
    private static String stripComment(String s) {
        boolean inSingle = false, inDouble = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\'' && !inDouble) inSingle = !inSingle;
            else if (c == '"' && !inSingle) inDouble = !inDouble;
            else if (c == '#' && !inSingle && !inDouble && (i == 0 || Character.isWhitespace(s.charAt(i - 1)))) {
                return s.substring(0, i);
            }
        }
        return s;
    }

    private static String unquote(String v) {
        if (v == null) return null;
        String t = v.trim();
        if (t.length() >= 2) {
            char f = t.charAt(0), l = t.charAt(t.length() - 1);
            if ((f == '"' && l == '"') || (f == '\'' && l == '\'')) {
                t = t.substring(1, t.length() - 1);
            }
        }
        return t.replace("\\n", "\n");
    }
}
