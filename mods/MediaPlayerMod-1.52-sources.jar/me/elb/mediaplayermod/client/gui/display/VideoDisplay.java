package me.elb.mediaplayermod.client.gui.display;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import me.elb.mediaplayermod.client.VLCUtil;
import me.elb.mediaplayermod.client.sound.MediaSoundCategory;
import me.elb.mediaplayermod.client.sound.VolumeUtil;
import me.elb.mediaplayermod.model.media.Video;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_757;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.watermedia.api.math.MathAPI;
import org.watermedia.api.player.videolan.VideoPlayer;

import java.awt.*;
import java.net.URI;
import java.util.UUID;

public class VideoDisplay extends AbstractDisplay {
    private final VideoPlayer videoPlayer;
    private final Video video;
    private Long end;
    private boolean fadingPhase;
    private boolean released;

    public VideoDisplay(UUID uuid, Video video, URI url) {
        super(uuid);
        this.video = video;
        class_310 client = class_310.method_1551();
        this.videoPlayer = VLCUtil.createVideoPlayer(client);
        if (client == null || videoPlayer.isBroken())
            return;
        client.method_1483().method_4881();
        if (video.fadeMode() != null && video.fadeMode() != Video.FadeMode.NONE && video.fadeIn() > 0) {
            videoPlayer.startPaused(url, VLCUtil.CLOCK_OPTIONS);
        } else {
            videoPlayer.start(url, VLCUtil.CLOCK_OPTIONS);
        }
        videoPlayer.setVolume(VolumeUtil.getPlayerVolume(client, MediaSoundCategory.VIDEO));
    }

    @Override
    public boolean hasEnded() {
        if (videoPlayer.isBroken()) {
            releasePlayer();
            return true;
        }
        Video.FadeMode fadeMode = video != null ? video.fadeMode() : null;
        if (fadeMode != null && fadeMode != Video.FadeMode.NONE && video.fadeOut() > 0) {
            if (end == null) return false;
            boolean done = System.currentTimeMillis() - end >= video.fadeOut();
            if (done) releasePlayer();
            return done;
        }
        boolean ended = videoPlayer.isEnded();
        if (ended) releasePlayer();
        return ended;
    }

    private void releasePlayer() {
        if (!released) {
            released = true;
            videoPlayer.stop();
            videoPlayer.release();
        }
    }

    @Override
    public long getTotalDuration() {
        return videoPlayer.getDuration();
    }

    public void setVolume(int volume) {
        if (!videoPlayer.isBroken()) {
            videoPlayer.setVolume(volume);
        }
    }

    @Override
    public void forceEnd() {
        super.forceEnd();
        videoPlayer.stop();
    }

    @Override
    public void dispose() {
        // Al quitar el display (fin natural o /stopmedia) hay que liberar el reproductor:
        // sin esto la instancia de VLC quedaba viva para siempre.
        releasePlayer();
    }

    @Override
    public void render(class_332 drawContext, float tickDelta, int width, int height) {
        // Tras liberar el reproductor no se puede volver a usar su textura: OpenGL recicla el id
        // liberado y podria dibujarse otra textura (p. ej. la skin de un jugador) en su lugar.
        if (released) return;
        Video.FadeMode fadeMode = video != null ? video.fadeMode() : Video.FadeMode.NONE;
        long fadeOutMs = video != null ? video.fadeOut() : 0;

        if ((fadeMode == null || fadeMode == Video.FadeMode.NONE || fadeOutMs <= 0)
                && (videoPlayer.isEnded() || videoPlayer.isStopped() || videoPlayer.isBroken())) {
            return;
        }

        float alpha = 1f;
        if (fadeMode != null && fadeMode != Video.FadeMode.NONE) {
            long now = System.currentTimeMillis();
            long startDiff = now - getStart();
            long fadeInMs = video.fadeIn();
            if (fadeInMs > 0 && startDiff < fadeInMs) {
                alpha = startDiff / (1f * fadeInMs);
                fadeOverlay(drawContext, alpha, fadeMode, width, height);
                fadingPhase = true;
            } else if (fadeOutMs > 0 && (videoPlayer.isEnded() || videoPlayer.isStopped())) {
                if (end == null) end = now;
                long endDiff = now - end;
                if (endDiff > fadeOutMs) return;
                alpha = 1 - (endDiff / (1f * fadeOutMs));
                fadeOverlay(drawContext, alpha, fadeMode, width, height);
                fadingPhase = true;
            } else if (fadingPhase) {
                if (videoPlayer.dimension() != null) {
                    fadingPhase = false;
                    videoPlayer.play();
                } else {
                    fadeOverlay(drawContext, 1f, fadeMode, width, height);
                }
            }
        }

        if (!fadingPhase || fadeMode == Video.FadeMode.TRANSPARENT) {
            if (videoPlayer.dimension() == null) return;
            int texture = videoPlayer.texture();
            if (texture <= 0 || !GL11.glIsTexture(texture)) return;
            RenderSystem.enableBlend();
            RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
            float texAlpha = fadeMode == Video.FadeMode.TRANSPARENT ? alpha : 1f;
            boolean useChroma = video != null && video.chromaKey()
                    && me.elb.mediaplayermod.client.shader.ChromaShader.isReady();
            RenderSystem.bindTexture(texture);
            RenderSystem.setShaderTexture(0, texture);
            RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST);
            RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);
            // Rectángulo destino en pixeles a partir de la región normalizada del vídeo.
            int regionX = Math.round(video.regionX() * width);
            int regionY = Math.round(video.regionY() * height);
            int regionW = Math.max(1, Math.round(video.regionW() * width));
            int regionH = Math.max(1, Math.round(video.regionH() * height));

            // Fondo negro solo dentro de la región (y solo si background=true);
            // si es false se deja transparente para que se vea el overlay/HUD detras.
            if (video.background()) {
                drawContext.method_25294(regionX, regionY, regionX + regionW, regionY + regionH, MathAPI.argb(255, 0, 0, 0));
            }

            Dimension videoDimensions = videoPlayer.dimension();
            double videoWidth = videoDimensions.getWidth();
            double videoHeight = videoDimensions.getHeight();

            float regionAspectRatio = (float) regionW / regionH;
            float videoAspectRatio = (float) ((float) videoWidth / videoHeight);

            int renderWidth;
            int renderHeight;

            // Letterbox: el vídeo se ajusta dentro de la región conservando su aspecto.
            if (videoAspectRatio > regionAspectRatio) {
                renderWidth = regionW;
                renderHeight = (int) (regionW / videoAspectRatio);
            } else {
                renderWidth = (int) (regionH * videoAspectRatio);
                renderHeight = regionH;
            }

            int xOffset = regionX + (regionW - renderWidth) / 2;
            int yOffset = regionY + (regionH - renderHeight) / 2;

            RenderSystem.setShaderTexture(0, texture);
            if (useChroma) {
                me.elb.mediaplayermod.client.shader.ChromaShader.bind(video.chromaColor(), video.chromaTolerance(), texAlpha);
            } else {
                RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, texAlpha);
                RenderSystem.setShader(class_757::method_34542);
            }
            RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
            RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);

            Matrix4f matrix4f = drawContext.method_51448().method_23760().method_23761();
            class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1585);
            bufferBuilder.method_22918(matrix4f, xOffset, yOffset, 0).method_22913(0, 0);
            bufferBuilder.method_22918(matrix4f, xOffset, (yOffset + renderHeight), 0).method_22913(0, 1);
            bufferBuilder.method_22918(matrix4f, (xOffset + renderWidth), (yOffset + renderHeight), 0).method_22913(1, 1);
            bufferBuilder.method_22918(matrix4f, (xOffset + renderWidth), yOffset, 0).method_22913(1, 0);
            class_286.method_43433(bufferBuilder.method_60800());
            RenderSystem.disableBlend();
        }
    }

    private void fadeOverlay(class_332 drawContext, float alpha, Video.FadeMode mode, int width, int height) {
        // El fundido se aplica dentro de la región del vídeo, no en toda la pantalla.
        int rx = Math.round(video.regionX() * width);
        int ry = Math.round(video.regionY() * height);
        int rw = Math.max(1, Math.round(video.regionW() * width));
        int rh = Math.max(1, Math.round(video.regionH() * height));
        if (mode == Video.FadeMode.BLACK) {
            int color = (int) (alpha * 255);
            drawContext.method_25294(rx, ry, rx + rw, ry + rh, color << 24);
        } else if (mode == Video.FadeMode.WHITE) {
            int color = (int) (alpha * 255);
            drawContext.method_25294(rx, ry, rx + rw, ry + rh, color << 24 | 0xFFFFFF);
        }
    }
}
