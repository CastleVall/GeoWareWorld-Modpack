package me.elb.mediaplayermod.client.gui.display;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.model.media.AnimationPosition;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_757;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Reproduce una animacion fotograma a fotograma usando el sistema de imagenes a pantalla.
 *
 * <p>Cada fotograma dura exactamente 1 tick (50&nbsp;ms = 20&nbsp;fps) y NO hay fundidos.
 * Los fotogramas se decodifican en un hilo de fondo con una cola acotada (look-ahead)
 * para no cargar toda la animacion en memoria de golpe, y se suben a una unica textura
 * de GPU que se reutiliza en cada fotograma.
 */
public class AnimationDisplay extends AbstractDisplay {
    private static final int LOOK_AHEAD = 16;

    private final List<File> frames;
    private final long frameMs;
    private final AnimationPosition position;
    private final BlockingQueue<class_1011> queue = new ArrayBlockingQueue<>(LOOK_AHEAD);
    private class_1043 texture;
    private int consumedFrames = 0;
    private int frameWidth = 0;
    private int frameHeight = 0;
    private volatile boolean disposed = false;
    private Thread loader;

    public AnimationDisplay(UUID uuid, List<File> frames, long frameMs, AnimationPosition position) {
        // Sin fade: fadeIn = 0, fadeOut = 0. La duracion total son N fotogramas a frameMs cada uno.
        super(uuid, 0L, frames.size() * frameMs, 0L);
        this.frames = frames;
        this.frameMs = frameMs;
        this.position = position;
        startLoader();
    }

    private void startLoader() {
        loader = new Thread(() -> {
            for (File file : frames) {
                if (disposed) break;
                class_1011 img;
                try (FileInputStream in = new FileInputStream(file)) {
                    img = class_1011.method_4309(in);
                } catch (Exception e) {
                    MediaPlayerMod.LOGGER.error("Error cargando fotograma {}", file, e);
                    continue;
                }
                boolean queued = false;
                while (!disposed && !queued) {
                    try {
                        queued = queue.offer(img, 100, TimeUnit.MILLISECONDS);
                    } catch (InterruptedException e) {
                        break;
                    }
                }
                if (!queued) {
                    img.close();
                    break;
                }
            }
        }, "MediaPlayer-Animation-Loader");
        loader.setDaemon(true);
        loader.start();
    }

    @Override
    public void render(class_332 drawContext, float tickDelta, int width, int height) {
        long elapsed = System.currentTimeMillis() - getStart();
        int desired = (int) (elapsed / frameMs);
        if (desired >= frames.size()) {
            desired = frames.size() - 1;
        }

        // Avanza hasta el fotograma deseado; si vamos por detras saltamos los intermedios
        // y subimos solo el ultimo para no malgastar uploads de GPU.
        class_1011 toUpload = null;
        while (consumedFrames <= desired) {
            class_1011 img = queue.poll();
            if (img == null) {
                break;
            }
            consumedFrames++;
            if (toUpload != null) {
                toUpload.close();
            }
            toUpload = img;
        }
        if (toUpload != null) {
            frameWidth = toUpload.method_4307();
            frameHeight = toUpload.method_4323();
            if (texture == null) {
                texture = new class_1043(toUpload);
            } else {
                texture.method_4526(toUpload); // cierra la imagen anterior
            }
            texture.method_4524();
        }
        if (texture == null || frameWidth <= 0 || frameHeight <= 0) {
            return; // aun no hay primer fotograma disponible
        }

        // Encaja la imagen conservando proporcion. El tamano y el anclaje vertical dependen
        // de la zona elegida: CENTER (grande, centro), TOP (bossbar) y BOTTOM (actionbar).
        float maxW;
        float maxH;
        switch (position) {
            case TOP, BOTTOM -> {
                maxW = width * 0.9f;
                maxH = height * 0.30f;
            }
            default -> {
                // CENTER: tamano moderado (no ocupa toda la pantalla), tipo title.
                maxW = width * 0.5f;
                maxH = height * 0.5f;
            }
        }
        float scale = Math.min(maxW / frameWidth, maxH / frameHeight);
        int renderWidth = Math.round(frameWidth * scale);
        int renderHeight = Math.round(frameHeight * scale);
        int xOffset = (width - renderWidth) / 2;
        int yOffset = switch (position) {
            case TOP -> Math.round(height * 0.02f);
            case BOTTOM -> height - renderHeight - Math.round(height * 0.06f);
            default -> (height - renderHeight) / 2;
        };

        int glId = texture.method_4624();
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.bindTexture(glId);
        RenderSystem.setShaderTexture(0, glId);
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);

        Matrix4f matrix4f = drawContext.method_51448().method_23760().method_23761();
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1585);
        bufferBuilder.method_22918(matrix4f, xOffset, yOffset, 0).method_22913(0, 0);
        bufferBuilder.method_22918(matrix4f, xOffset, (yOffset + renderHeight), 0).method_22913(0, 1);
        bufferBuilder.method_22918(matrix4f, (xOffset + renderWidth), (yOffset + renderHeight), 0).method_22913(1, 1);
        bufferBuilder.method_22918(matrix4f, (xOffset + renderWidth), yOffset, 0).method_22913(1, 0);
        class_286.method_43433(bufferBuilder.method_60800());
        RenderSystem.disableBlend();
    }

    @Override
    public void dispose() {
        disposed = true;
        if (loader != null) {
            loader.interrupt();
        }
        class_1011 img;
        while ((img = queue.poll()) != null) {
            img.close();
        }
        class_310.method_1551().execute(() -> {
            // por si el hilo cargador dejo algo en cola tras el primer drenado
            class_1011 pending;
            while ((pending = queue.poll()) != null) {
                pending.close();
            }
            if (texture != null) {
                texture.close();
                texture = null;
            }
        });
    }

    /**
     * Resuelve los ficheros de fotogramas dentro de {@code dir}, ordenados por su numero.
     *
     * <p>Acepta cualquier nombre cuyo numero (los digitos del nombre) sea valido, con o sin ceros
     * a la izquierda (p.ej. {@code 000.png}, {@code 5.png}). Si {@code first} es negativo (o si
     * {@code last} es negativo) devuelve TODOS los fotogramas; en caso contrario solo los del
     * rango {@code first..last} (inclusive).
     */
    public static List<File> resolveFrames(File dir, int first, int last) {
        List<File> result = new ArrayList<>();
        if (!dir.isDirectory()) {
            return result;
        }
        File[] files = dir.listFiles();
        if (files == null) {
            return result;
        }
        java.util.TreeMap<Integer, File> byNumber = new java.util.TreeMap<>();
        for (File file : files) {
            if (!file.isFile()) {
                continue;
            }
            String name = file.getName().toLowerCase(java.util.Locale.ROOT);
            int dot = name.lastIndexOf('.');
            if (dot < 0) {
                continue;
            }
            String ext = name.substring(dot + 1);
            if (!ext.equals("png") && !ext.equals("jpg") && !ext.equals("jpeg")) {
                continue;
            }
            String digits = name.substring(0, dot).replaceAll("[^0-9]", "");
            if (digits.isEmpty()) {
                continue;
            }
            try {
                byNumber.putIfAbsent(Integer.parseInt(digits), file);
            } catch (NumberFormatException ignored) {
            }
        }
        boolean allFrames = first < 0 || last < 0;
        for (java.util.Map.Entry<Integer, File> entry : byNumber.entrySet()) {
            int number = entry.getKey();
            if (allFrames || (number >= first && number <= last)) {
                result.add(entry.getValue());
            }
        }
        return result;
    }
}
