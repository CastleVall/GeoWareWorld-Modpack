package me.elb.mediaplayermod.client.gui.display;

import me.elb.mediaplayermod.utils.GLUtil;
import net.minecraft.class_332;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import java.util.UUID;

@Getter
@RequiredArgsConstructor
public abstract class AbstractDisplay {
    private final UUID uuid;
    protected long fadeIn = 0;
    protected long duration = 0;
    protected long fadeOut = 0;
    private long start;
    private Long forceEnd;

    protected AbstractDisplay(UUID uuid, long fadeIn, long duration, long fadeOut) {
        this.uuid = uuid;
        this.fadeIn = fadeIn;
        this.duration = duration;
        this.fadeOut = fadeOut;
    }

    public void start() {
        this.start = System.currentTimeMillis();
    }

    public void forceEnd() {
        this.forceEnd = System.currentTimeMillis();
    }

    protected boolean isInfinite() {
        return duration < 0;
    }

    public long getTotalDuration() {
        if (isInfinite()) {
            return Long.MAX_VALUE;
        }
        return fadeIn + duration + fadeOut;
    }

    protected float getAlpha() {
        if (forceEnd != null) {
            long endDiff = forceEnd - start;
            return endDiff / (1F * fadeOut);
        }
        if (fadeIn < 0) {
            fadeIn = 1000;
        }
        if (isInfinite()) {
            return GLUtil.calculateAlpha(start, fadeIn, Long.MAX_VALUE, 0);
        }
        return GLUtil.calculateAlpha(start, fadeIn, duration, fadeOut);
    }

    public boolean hasEnded() {
        if (forceEnd != null) {
            return System.currentTimeMillis() - forceEnd >= fadeOut;
        }
        return System.currentTimeMillis() - start >= getTotalDuration();
    }

    public abstract void render(class_332 drawContext, float tickDelta, int width, int height);

    /**
     * Se invoca cuando el display deja de mostrarse (termina o se detiene). Las subclases que
     * reserven recursos (texturas de GPU, hilos, etc.) deben liberarlos aqui.
     */
    public void dispose() {
    }
}
