package me.elb.mediaplayermod.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.client.ClientHandler;
import me.elb.mediaplayermod.client.gui.display.AbstractDisplay;
import lombok.Getter;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import java.util.*;

@Getter
public class MediaHudOverlay implements HudRenderCallback {
    private final List<AbstractDisplay> displays = new ArrayList<>();

    @Override
    public void onHudRender(class_332 drawContext, class_9779 tickCounter) {
        class_310 client = class_310.method_1551();
        if (client != null) {
            int height = client.method_22683().method_4502();
            int width = client.method_22683().method_4486();
            Iterator<AbstractDisplay> iterator = displays.iterator();
            while (iterator.hasNext()) {
                AbstractDisplay display = iterator.next();
                if (display.hasEnded()) {
                    iterator.remove();
                    MediaPlayerMod.LOGGER.info("Removing display {} ({})", display.getUuid(), display.getClass().getSimpleName());
                    display.dispose();
                    RenderSystem.enableBlend();
                    RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1F);
                    RenderSystem.disableBlend();
                    ClientHandler.notifyFinishedMediaToServer(display.getUuid());
                    continue;
                }
                display.render(drawContext, tickCounter.method_60637(false), width, height);
            }
        }
    }

    public void addDisplay(AbstractDisplay display) {
        display.start();
        displays.add(display);
    }
}
