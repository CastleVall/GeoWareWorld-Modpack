package me.elb.mediaplayermod.client.gui.tutorial;

import me.elb.mediaplayermod.MediaPlayerMod;
import net.minecraft.class_2960;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Registro de iconos internos del mod que se pueden incrustar en cualquier texto del tutorial
 * usando tokens del estilo {@code {w}}, {@code {lclick}} o {@code {music}}.
 *
 * <p>Cada icono guarda su {@link class_2960} de textura y su tamano nativo en pixeles, para poder
 * escalarlo a la altura de la linea de texto conservando su proporcion al pintarlo.
 *
 * <p>Para anadir un icono nuevo basta con dejar el PNG en
 * {@code assets/mediaplayer/textures/tutorial/icons/} y registrar aqui el token correspondiente.
 */
public final class TutorialIcons {

    /** Un icono incrustable: textura + tamano nativo. */
    public record Icon(class_2960 texture, int width, int height) {}

    /** Trozo del resultado de {@link #parse(String)}: o texto plano, o un icono. */
    public record Segment(String text, Icon icon) {
        public boolean isIcon() {
            return icon != null;
        }
    }

    private static final Map<String, Icon> ICONS = new LinkedHashMap<>();

    private TutorialIcons() {}

    private static void register(String token, String file, int w, int h) {
        ICONS.put(token, new Icon(
                class_2960.method_60655(MediaPlayerMod.MOD_ID, "textures/tutorial/icons/" + file + ".png"), w, h));
    }

    static {
        // Teclas de letra (30x30).
        for (char c = 'a'; c <= 'z'; c++) {
            register(String.valueOf(c), "normal_" + c, 30, 30);
        }
        register("enye", "normal_enye", 30, 30); // {enye}
        ICONS.put("ñ", ICONS.get("enye"));        // alias comodo {ñ}

        // Mouse (16x16).
        register("lclick", "left_click", 16, 16);
        register("rclick", "right_click", 16, 16);

        // Simbolos y caras (32x32).
        register("circle", "circle", 32, 32);
        register("cross", "cross", 32, 32);
        register("music", "pk_music", 32, 32);
        register("block", "3d_folder", 32, 32);
        register("steve", "character_folder", 32, 32);
        register("character", "character_folder", 32, 32); // alias
        register("happy", "happy_folder", 32, 32);
        register("angry", "angry_folder", 32, 32);
    }

    /** Devuelve el icono del token (sin llaves), o null si no existe. */
    public static Icon get(String token) {
        if (token == null) return null;
        return ICONS.get(token.trim().toLowerCase());
    }

    /** Todos los tokens registrados (para documentacion/ayuda). */
    public static List<String> tokens() {
        return new ArrayList<>(ICONS.keySet());
    }

    /**
     * Parte un texto en segmentos alternando texto plano e iconos. Un token {@code {xxx}} que no
     * corresponda a ningun icono registrado se deja tal cual como texto (asi no se "comen" llaves
     * usadas por el usuario para otra cosa).
     */
    public static List<Segment> parse(String raw) {
        List<Segment> out = new ArrayList<>();
        if (raw == null || raw.isEmpty()) return out;

        StringBuilder text = new StringBuilder();
        int i = 0;
        int n = raw.length();
        while (i < n) {
            char c = raw.charAt(i);
            if (c == '{') {
                int close = raw.indexOf('}', i + 1);
                if (close > i) {
                    String token = raw.substring(i + 1, close);
                    Icon icon = get(token);
                    if (icon != null) {
                        if (text.length() > 0) {
                            out.add(new Segment(text.toString(), null));
                            text.setLength(0);
                        }
                        out.add(new Segment(null, icon));
                        i = close + 1;
                        continue;
                    }
                }
            }
            text.append(c);
            i++;
        }
        if (text.length() > 0) {
            out.add(new Segment(text.toString(), null));
        }
        return out;
    }
}
