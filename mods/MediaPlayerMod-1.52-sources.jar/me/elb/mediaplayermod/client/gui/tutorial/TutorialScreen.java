package me.elb.mediaplayermod.client.gui.tutorial;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.client.URLUtil;
import me.elb.mediaplayermod.client.VLCUtil;
import me.elb.mediaplayermod.client.sound.MediaSoundCategory;
import me.elb.mediaplayermod.client.sound.VolumeUtil;
import me.elb.mediaplayermod.utils.ImageUtils;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_757;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.watermedia.api.image.ImageAPI;
import org.watermedia.api.image.ImageRenderer;
import org.watermedia.api.image.decoders.GifDecoder;
import org.watermedia.api.player.videolan.VideoPlayer;

import javax.imageio.ImageIO;
import javax.imageio.stream.ImageInputStream;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URI;
import java.net.URL;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Pantalla de tutorial a pantalla completa y bloqueante. Mientras esta abierta el jugador no se
 * mueve ni controla la camara (al ser una {@link class_437}, el cliente no procesa input de juego).
 *
 * <p>Soporta varios estilos: {@code VANILLA} (paleta negro+rojo, lineal, procedural) y los estilos
 * con textura de fondo y hueco para el video ({@code DECORATED}, {@code EIEN}, {@code MIZORE},
 * {@code SANGO}, {@code SUNA}, {@code YOUNGA}). Hace fundido de entrada y salida, muestra una
 * cuenta atras opcional (timer) que la cierra al llegar a 0, incrusta un video en el recuadro
 * (pantalla negra si no hay url) y permite incrustar iconos internos en los textos via {@link TutorialIcons}.
 */
public final class TutorialScreen extends class_437 {

    private static final class_2960 DECORATED_BG =
            class_2960.method_60655(MediaPlayerMod.MOD_ID, "textures/tutorial/styles/decorated.png");
    // Estilos con textura de fondo: comparten el mismo layout que decorated (panel izquierdo, barra
    // de subtitulo, caja de timer, hueco de video y barra de controles); solo cambia el tema.
    private static final class_2960 EIEN_BG =
            class_2960.method_60655(MediaPlayerMod.MOD_ID, "textures/tutorial/styles/eien.png");
    private static final class_2960 MIZORE_BG =
            class_2960.method_60655(MediaPlayerMod.MOD_ID, "textures/tutorial/styles/mizore.png");
    private static final class_2960 SANGO_BG =
            class_2960.method_60655(MediaPlayerMod.MOD_ID, "textures/tutorial/styles/sango.png");
    private static final class_2960 SUNA_BG =
            class_2960.method_60655(MediaPlayerMod.MOD_ID, "textures/tutorial/styles/suna.png");
    private static final class_2960 YOUNGA_BG =
            class_2960.method_60655(MediaPlayerMod.MOD_ID, "textures/tutorial/styles/younga.png");

    // Paleta vanilla.
    private static final int VANILLA_BG = 0xFF0A0A0A;
    private static final int VANILLA_RED = 0xFFCC2222;
    private static final int VANILLA_PANEL = 0xFF161616;
    private static final int VANILLA_TEXT = 0xFFE6E6E6;

    /** Altura de los iconos incrustados, como multiplo de la altura de fuente (para que no se vean diminutos). */
    private static final float ICON_SCALE = 1.85f;

    private final TutorialData data;
    private final boolean english;

    private VideoPlayer videoPlayer;
    private boolean videoStarted;

    private final List<LoadedImage> loadedImages = new ArrayList<>();

    private final long openTime = System.currentTimeMillis();
    private boolean closing;
    private long closeStart;
    private boolean released;

    private record LoadedImage(TutorialData.ImageOverlay spec, ImageRenderer renderer) {}

    public TutorialScreen(TutorialData data) {
        super(class_2561.method_43470("Tutorial"));
        this.data = data;
        class_310 client = class_310.method_1551();
        String lang = client.field_1690.field_1883;
        this.english = lang != null && lang.toLowerCase().startsWith("en");

        for (TutorialData.ImageOverlay img : data.images()) {
            ImageRenderer r = loadImageRenderer(img.src());
            if (r != null) loadedImages.add(new LoadedImage(img, r));
        }

        if (data.hasVideo()) {
            URI uri = resolveVideoUri(data.video());
            if (uri != null) {
                try {
                    this.videoPlayer = VLCUtil.createVideoPlayer(client);
                    if (!videoPlayer.isBroken()) {
                        videoPlayer.start(uri, VLCUtil.CLOCK_OPTIONS);
                        videoPlayer.setVolume(VolumeUtil.getPlayerVolume(client, MediaSoundCategory.VIDEO));
                    }
                } catch (Exception e) {
                    MediaPlayerMod.LOGGER.error("Error iniciando el video del tutorial", e);
                    this.videoPlayer = null;
                }
            }
        }
    }

    private static URI resolveVideoUri(String video) {
        if (video == null || video.isBlank()) return null;
        String v = video.trim();
        if (v.contains("://")) {
            try { return URI.create(v); } catch (Exception e) { return null; }
        }
        Path base = FabricLoader.getInstance().getConfigDir().resolve("mediaplayer");
        File[] candidates = {
                base.resolve("videos").resolve(v).toFile(),
                base.resolve(v).toFile(),
                new File(v)
        };
        for (File f : candidates) {
            if (f.exists()) return f.toURI();
        }
        return null;
    }

    /** Carga una imagen overlay (local o url, png/jpg/gif) a un renderizador de WaterMedia. */
    private static ImageRenderer loadImageRenderer(String src) {
        try {
            URL url = URLUtil.loadUrl(URLUtil.fixUrl(src));
            try (ImageInputStream iis = ImageIO.createImageInputStream(url.openStream())) {
                if (ImageUtils.isGifImage(iis)) {
                    GifDecoder gif = new GifDecoder();
                    gif.read(url.openStream());
                    return ImageAPI.renderer(gif);
                }
            }
            BufferedImage bi = ImageIO.read(url);
            return bi == null ? null : ImageAPI.renderer(bi);
        } catch (Exception e) {
            MediaPlayerMod.LOGGER.error("Error cargando imagen overlay del tutorial: {}", src, e);
            return null;
        }
    }

    // ------------------------------------------------------------------
    // Comportamiento de pantalla bloqueante
    // ------------------------------------------------------------------

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public boolean method_25422() {
        return false; // gestionamos ESC manualmente para hacer el fundido de salida
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        return false;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) { // ESC: solo los OP pueden saltarse el tutorial a mano.
            if (isOperator()) {
                requestClose();
            }
            // Consumimos el ESC siempre: un jugador normal no debe poder cerrar la pantalla.
            // El tutorial solo se cierra para el por el timer o por /playtutorial stop.
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    /** True si el jugador local es OP (nivel de permisos vanilla >= 2, igual que exige el comando). */
    private static boolean isOperator() {
        class_310 client = class_310.method_1551();
        return client.field_1724 != null && client.field_1724.method_5687(2);
    }

    private void requestClose() {
        if (closing) return;
        closing = true;
        closeStart = System.currentTimeMillis();
    }

    @Override
    public void method_25419() {
        requestClose();
    }

    private void realClose() {
        if (released) return;
        released = true;
        if (videoPlayer != null) {
            try {
                videoPlayer.stop();
                videoPlayer.release();
            } catch (Exception ignored) {
            }
            videoPlayer = null;
        }
        class_310 client = class_310.method_1551();
        client.execute(() -> client.method_1507(null));
    }

    // ------------------------------------------------------------------
    // Render
    // ------------------------------------------------------------------

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        long now = System.currentTimeMillis();
        float fadeInMs = data.fadeInSeconds() * 1000f;
        float fadeOutMs = data.fadeOutSeconds() * 1000f;

        // Cuenta atras del timer.
        if (data.timerSeconds() > 0 && !closing) {
            long remaining = data.timerSeconds() * 1000L - (now - openTime);
            if (remaining <= 0) {
                requestClose();
            }
        }

        float alpha;
        if (closing) {
            float t = fadeOutMs > 0 ? (now - closeStart) / fadeOutMs : 1f;
            if (t >= 1f) {
                realClose();
                return;
            }
            alpha = 1f - t;
        } else {
            alpha = fadeInMs > 0 ? Math.min(1f, (now - openTime) / fadeInMs) : 1f;
        }

        if (videoPlayer != null && !videoStarted && !videoPlayer.isBroken() && videoPlayer.dimension() != null) {
            videoStarted = true;
        }

        // Estilos texturizados: mismo layout que decorated, distinta textura y color de texto legible
        // segun el tema (panelInk = texto sobre el panel izquierdo; barInk = texto sobre las barras).
        switch (data.style()) {
            case VANILLA -> renderVanilla(ctx, alpha, now);
            case EIEN -> renderTextured(ctx, alpha, now, EIEN_BG, 0x2E1A47, 0x2E1A47);
            case MIZORE -> renderTextured(ctx, alpha, now, MIZORE_BG, 0x07263F, 0x07263F);
            case SANGO -> renderTextured(ctx, alpha, now, SANGO_BG, 0x2A1D0E, 0x3A1F0A);
            case SUNA -> renderTextured(ctx, alpha, now, SUNA_BG, 0x3B2A14, 0xF5E6C8);
            case YOUNGA -> renderTextured(ctx, alpha, now, YOUNGA_BG, 0xF2E6E6, 0xF2E6E6);
            default -> renderTextured(ctx, alpha, now, DECORATED_BG, 0x2A1D0E, 0x3B2A14);
        }

        // Imagenes superpuestas: por encima de TODO.
        renderImages(ctx, alpha);
    }

    // ---- Estilos con textura de fondo (decorated, eien, mizore, sango, suna, younga) ----

    /**
     * Renderiza un estilo basado en una textura de fondo a pantalla completa con un hueco para el
     * video. Todos comparten el mismo layout (lienzo de diseno 1920x1080); solo cambian {@code bg}
     * (la textura del tema) y los colores de texto: {@code panelInk} para el panel izquierdo
     * (titulo/instrucciones) y {@code barInk} para las barras (subtitulo/timer/controles).
     */
    private void renderTextured(class_332 ctx, float alpha, long now, class_2960 bg, int panelInk, int barInk) {
        // Regiones en el lienzo de diseno 1920x1080.
        int[] video = region(792, 192, 1054, 584);

        // 1) Video (o negro) detras; el fondo tiene el hueco justo aqui.
        drawVideoOrBlack(ctx, video[0], video[1], video[2], video[3], alpha);

        // 2) Fondo del tema a pantalla completa (tapa todo salvo el hueco).
        RenderSystem.enableBlend();
        RenderSystem.setShaderColor(1f, 1f, 1f, alpha);
        ctx.method_25293(bg, 0, 0, field_22789, field_22790, 0, 0, 1920, 1080, 1920, 1080);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.disableBlend();

        // Titulo (encabezado del panel izquierdo).
        int[] titleR = region(55, 70, 610, 110);
        drawRich(ctx, data.titulo().text(english), titleR, data.sizeFor("titulo", 50), panelInk, alpha, Align.CENTER, true, fontId(data.fontFor("titulo")));

        // Instrucciones (cuerpo del panel izquierdo).
        int[] instrR = region(70, 210, 580, 800);
        drawRich(ctx, data.instrucciones().text(english), instrR, data.sizeFor("instrucciones", 31), panelInk, alpha, Align.LEFT, false, fontId(data.fontFor("instrucciones")));

        // Subtitulo (barra superior).
        int[] subR = region(774, 46, 681, 80);
        drawRich(ctx, data.subtitulo().text(english), subR, data.sizeFor("subtitulo", 34), barInk, alpha, Align.CENTER, true, fontId(data.fontFor("subtitulo")));

        // Timer (caja superior derecha).
        if (data.timerSeconds() > 0) {
            int[] timerR = region(1660, 50, 200, 80);
            drawRich(ctx, formatTimer(now), timerR, data.sizeFor("timer", 36), barInk, alpha, Align.CENTER, true, fontId(data.fontFor("timer")));
        }

        // Controles (barra inferior): titulo + cuerpo. Recortado a su casilla.
        int[] ctrlR = region(805, 872, 1041, 132);
        ctx.method_44379(ctrlR[0], ctrlR[1], ctrlR[0] + ctrlR[2], ctrlR[1] + ctrlR[3]);
        String ctrlTitle = data.tituloControles().text(english);
        String ctrlBody = data.controles().text(english);
        int usedH = 0;
        if (!ctrlTitle.isBlank()) {
            usedH = drawRich(ctx, ctrlTitle, new int[]{ctrlR[0], ctrlR[1], ctrlR[2], ctrlR[3]}, data.sizeFor("titulo_controles", 30), barInk, alpha, Align.LEFT, false, fontId(data.fontFor("titulo_controles")));
        }
        drawRich(ctx, ctrlBody, new int[]{ctrlR[0], ctrlR[1] + usedH + 6, ctrlR[2], ctrlR[3] - usedH - 6}, data.sizeFor("controles", 20), barInk, alpha, Align.LEFT, false, fontId(data.fontFor("controles")));
        ctx.method_44380();
    }

    // ---- Estilo vanilla (negro + rojo, lineal) ----

    private void renderVanilla(class_332 ctx, float alpha, long now) {
        int a = (int) (alpha * 255) << 24;
        ctx.method_25294(0, 0, field_22789, field_22790, (a & 0xFF000000) | (VANILLA_BG & 0xFFFFFF));

        // Titulo (arriba izquierda).
        int[] titleR = frac(0.04f, 0.05f, 0.42f, 0.08f);
        panel(ctx, titleR, alpha, false);
        drawRich(ctx, data.titulo().text(english), pad(titleR, 10), data.sizeFor("titulo", 38), withA(VANILLA_RED, alpha), 1f, Align.LEFT, true, fontId(data.fontFor("titulo")));

        // Subtitulo (arriba centro).
        int[] subR = frac(0.50f, 0.05f, 0.30f, 0.08f);
        drawRich(ctx, data.subtitulo().text(english), subR, data.sizeFor("subtitulo", 30), withA(VANILLA_TEXT, alpha), 1f, Align.CENTER, true, fontId(data.fontFor("subtitulo")));

        // Timer (arriba derecha).
        if (data.timerSeconds() > 0) {
            int[] timerR = frac(0.82f, 0.05f, 0.14f, 0.08f);
            panel(ctx, timerR, alpha, false);
            drawRich(ctx, formatTimer(now), timerR, data.sizeFor("timer", 38), withA(VANILLA_RED, alpha), 1f, Align.CENTER, true, fontId(data.fontFor("timer")));
        }

        // Instrucciones (columna izquierda).
        int[] instrR = frac(0.04f, 0.17f, 0.42f, 0.76f);
        panel(ctx, instrR, alpha, true);
        drawRich(ctx, data.instrucciones().text(english), pad(instrR, 14), data.sizeFor("instrucciones", 29), withA(VANILLA_TEXT, alpha), 1f, Align.LEFT, false, fontId(data.fontFor("instrucciones")));

        // Tutorial / video (derecha arriba).
        int[] videoR = frac(0.50f, 0.17f, 0.46f, 0.46f);
        panel(ctx, videoR, alpha, true);
        int[] vIn = pad(videoR, 4);
        drawVideoOrBlack(ctx, vIn[0], vIn[1], vIn[2], vIn[3], alpha);

        // Controles (derecha abajo).
        int[] ctrlR = frac(0.50f, 0.66f, 0.46f, 0.27f);
        panel(ctx, ctrlR, alpha, true);
        int[] ctrlIn = pad(ctrlR, 12);
        int usedH = 0;
        String ctrlTitle = data.tituloControles().text(english);
        if (!ctrlTitle.isBlank()) {
            usedH = drawRich(ctx, ctrlTitle, ctrlIn, data.sizeFor("titulo_controles", 32), withA(VANILLA_RED, alpha), 1f, Align.LEFT, false, fontId(data.fontFor("titulo_controles")));
        }
        drawRich(ctx, data.controles().text(english),
                new int[]{ctrlIn[0], ctrlIn[1] + usedH + 6, ctrlIn[2], ctrlIn[3] - usedH - 6},
                data.sizeFor("controles", 28), withA(VANILLA_TEXT, alpha), 1f, Align.LEFT, false, fontId(data.fontFor("controles")));
    }

    private void panel(class_332 ctx, int[] r, float alpha, boolean fillBg) {
        int aMask = ((int) (alpha * 255) << 24) & 0xFF000000;
        if (fillBg) {
            ctx.method_25294(r[0], r[1], r[0] + r[2], r[1] + r[3], aMask | (VANILLA_PANEL & 0xFFFFFF));
        }
        int red = aMask | (VANILLA_RED & 0xFFFFFF);
        int t = 2;
        ctx.method_25294(r[0], r[1], r[0] + r[2], r[1] + t, red);                       // top
        ctx.method_25294(r[0], r[1] + r[3] - t, r[0] + r[2], r[1] + r[3], red);         // bottom
        ctx.method_25294(r[0], r[1], r[0] + t, r[1] + r[3], red);                       // left
        ctx.method_25294(r[0] + r[2] - t, r[1], r[0] + r[2], r[1] + r[3], red);         // right
    }

    // ------------------------------------------------------------------
    // Video
    // ------------------------------------------------------------------

    private void drawVideoOrBlack(class_332 ctx, int rx, int ry, int rw, int rh, float alpha) {
        int aMask = ((int) (alpha * 255) << 24) & 0xFF000000;
        // Fondo negro siempre (sirve de "pantalla negra" cuando no hay video o aun carga).
        ctx.method_25294(rx, ry, rx + rw, ry + rh, aMask);

        if (videoPlayer == null || videoPlayer.isBroken() || videoPlayer.dimension() == null) {
            return;
        }
        int texture = videoPlayer.texture();
        if (texture <= 0 || !GL11.glIsTexture(texture)) {
            return;
        }

        Dimension dim = videoPlayer.dimension();
        float videoAspect = (float) (dim.getWidth() / dim.getHeight());
        float regionAspect = (float) rw / rh;
        int renderW, renderH;
        if (videoAspect > regionAspect) {
            renderW = rw;
            renderH = (int) (rw / videoAspect);
        } else {
            renderW = (int) (rh * videoAspect);
            renderH = rh;
        }
        int xOff = rx + (rw - renderW) / 2;
        int yOff = ry + (rh - renderH) / 2;

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
        RenderSystem.setShaderColor(1f, 1f, 1f, alpha);
        RenderSystem.setShaderTexture(0, texture);
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);

        Matrix4f m = ctx.method_51448().method_23760().method_23761();
        class_287 bb = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1585);
        bb.method_22918(m, xOff, yOff, 0).method_22913(0, 0);
        bb.method_22918(m, xOff, yOff + renderH, 0).method_22913(0, 1);
        bb.method_22918(m, xOff + renderW, yOff + renderH, 0).method_22913(1, 1);
        bb.method_22918(m, xOff + renderW, yOff, 0).method_22913(1, 0);
        class_286.method_43433(bb.method_60800());

        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.disableBlend();
    }

    private String formatTimer(long now) {
        long remaining = Math.max(0, data.timerSeconds() * 1000L - (now - openTime));
        long totalSec = (remaining + 999) / 1000;
        long h = totalSec / 3600;
        long m = (totalSec % 3600) / 60;
        long s = totalSec % 60;
        return String.format("%02d:%02d:%02d", h, m, s);
    }

    // ------------------------------------------------------------------
    // Rich text (texto + iconos) con ajuste de linea y escalado
    // ------------------------------------------------------------------

    private enum Align { LEFT, CENTER }

    /** text != null para texto (ya con fuente y formato aplicados); icon != null para un icono. */
    private record Atom(class_2561 text, TutorialIcons.Icon icon, boolean spaceBefore) {}

    /**
     * Dibuja texto con iconos incrustados, soporta codigos de formato con {@code &} (colores y
     * efectos de Minecraft), fuente elegible y escalado a un tamano de fuente "de diseno" (px sobre
     * el lienzo de 1080 de alto). Ajusta el texto al ancho de la region. Devuelve la altura usada en px.
     */
    private int drawRich(class_332 ctx, String raw, int[] r, float designFont, int rgb, float alpha,
                         Align align, boolean centerV, class_2960 fontId) {
        if (raw == null || raw.isEmpty()) return 0;
        class_327 tr = this.field_22793;
        float scale = designFont * (field_22790 / 1080f) / tr.field_2000;

        int maxWidthLocal = (int) Math.floor(r[2] / scale);
        if (maxWidthLocal < 8) maxWidthLocal = 8;
        float spaceW = tr.method_27525(buildText(" ", fontId));

        List<List<Atom>> lines = new ArrayList<>();
        boolean anyIcon = false;
        for (String paragraph : raw.split("\n", -1)) {
            layoutParagraph(tr, paragraph, maxWidthLocal, spaceW, lines, fontId);
        }
        for (List<Atom> line : lines) {
            for (Atom a : line) {
                if (a.icon() != null) { anyIcon = true; break; }
            }
            if (anyIcon) break;
        }

        int iconH = iconHeightLocal();
        // Caja de linea: alto del texto, o alto del icono si la linea lleva iconos.
        int lineBox = anyIcon ? Math.max(tr.field_2000, iconH) : tr.field_2000;
        int gap = Math.max(2, Math.round(tr.field_2000 * 0.45f));
        int lineStep = lineBox + gap;
        int textY = (lineBox - tr.field_2000) / 2; // texto centrado verticalmente en la caja

        int contentHeightLocal = lines.isEmpty() ? 0 : (lines.size() - 1) * lineStep + lineBox;
        int totalHeightPx = Math.round(contentHeightLocal * scale);

        int startY = r[1];
        if (centerV) {
            startY = r[1] + Math.max(0, Math.round((r[3] - totalHeightPx) / 2f));
        }

        int color = withA(rgb, alpha);
        if (((color >>> 24) & 0xFF) < 4) return totalHeightPx;

        for (int li = 0; li < lines.size(); li++) {
            List<Atom> line = lines.get(li);
            float lineWidthLocal = lineWidth(tr, line, spaceW);
            float offsetXLocal = align == Align.CENTER ? Math.max(0, (maxWidthLocal - lineWidthLocal) / 2f) : 0f;
            float lineScreenY = startY + li * lineStep * scale;

            ctx.method_51448().method_22903();
            ctx.method_51448().method_46416(r[0], lineScreenY, 0);
            ctx.method_51448().method_22905(scale, scale, 1f);

            float cursor = offsetXLocal;
            boolean first = true;
            for (Atom atom : line) {
                if (atom.spaceBefore() && !first) cursor += spaceW;
                first = false;
                if (atom.icon() != null) {
                    int iw = Math.max(1, Math.round(atom.icon().width() * (iconH / (float) atom.icon().height())));
                    int iconY = (lineBox - iconH) / 2;
                    RenderSystem.enableBlend();
                    RenderSystem.setShaderColor(1f, 1f, 1f, alpha);
                    ctx.method_25293(atom.icon().texture(), Math.round(cursor), iconY, iw, iconH,
                            0, 0, atom.icon().width(), atom.icon().height(), atom.icon().width(), atom.icon().height());
                    RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
                    cursor += iw;
                } else {
                    ctx.method_51439(tr, atom.text(), Math.round(cursor), textY, color, false);
                    cursor += tr.method_27525(atom.text());
                }
            }
            ctx.method_51448().method_22909();
        }
        return totalHeightPx;
    }

    private int iconHeightLocal() {
        return Math.round(this.field_22793.field_2000 * ICON_SCALE);
    }

    private void layoutParagraph(class_327 tr, String paragraph, int maxWidthLocal, float spaceW,
                                 List<List<Atom>> out, class_2960 fontId) {
        List<Atom> atoms = tokenize(paragraph, fontId);
        List<Atom> current = new ArrayList<>();
        float widthLocal = 0;
        boolean firstInLine = true;
        for (Atom atom : atoms) {
            float aw = atomWidth(tr, atom);
            float advance = aw + (atom.spaceBefore() && !firstInLine ? spaceW : 0);
            if (!firstInLine && widthLocal + advance > maxWidthLocal) {
                out.add(current);
                current = new ArrayList<>();
                widthLocal = 0;
                // el atomo arranca la nueva linea sin espacio inicial
                Atom restarted = new Atom(atom.text(), atom.icon(), false);
                current.add(restarted);
                widthLocal += aw;
                firstInLine = false;
            } else {
                current.add(atom);
                widthLocal += advance;
                firstInLine = false;
            }
        }
        out.add(current); // incluso vacia, para respetar lineas en blanco
    }

    /**
     * Convierte un parrafo en atomos (palabras + iconos). Soporta codigos de formato con {@code &}
     * (o {@code §}): cada palabra arrastra el formato activo para que el color/efecto se mantenga
     * aunque haya ajuste de linea. La fuente {@code fontId} se aplica a cada palabra.
     */
    private List<Atom> tokenize(String paragraph, class_2960 fontId) {
        List<Atom> atoms = new ArrayList<>();
        boolean pendingSpace = false;
        StringBuilder style = new StringBuilder(); // codigos § activos (ej "§c§l")
        for (TutorialIcons.Segment seg : TutorialIcons.parse(paragraph)) {
            if (seg.isIcon()) {
                atoms.add(new Atom(null, seg.icon(), pendingSpace));
                pendingSpace = false;
                continue;
            }
            String text = seg.text();
            int i = 0;
            int n = text.length();
            while (i < n) {
                char c = text.charAt(i);
                if ((c == '&' || c == '§') && i + 1 < n && isFormatCode(text.charAt(i + 1))) {
                    char code = Character.toLowerCase(text.charAt(i + 1));
                    if (code == 'r') style.setLength(0);
                    else style.append('§').append(code);
                    i += 2;
                    continue;
                }
                if (c == ' ' || c == '\t') {
                    pendingSpace = true;
                    i++;
                    continue;
                }
                int j = i;
                StringBuilder word = new StringBuilder();
                while (j < n) {
                    char cj = text.charAt(j);
                    if (cj == ' ' || cj == '\t') break;
                    if ((cj == '&' || cj == '§') && j + 1 < n && isFormatCode(text.charAt(j + 1))) break;
                    word.append(cj);
                    j++;
                }
                atoms.add(new Atom(buildText(style + word.toString(), fontId), null, pendingSpace));
                pendingSpace = false;
                i = j;
            }
        }
        return atoms;
    }

    private static boolean isFormatCode(char c) {
        return "0123456789abcdefklmnor".indexOf(Character.toLowerCase(c)) >= 0;
    }

    private static class_2561 buildText(String content, class_2960 fontId) {
        return class_2561.method_43470(content).method_10862(class_2583.field_24360.method_27704(fontId));
    }

    private float atomWidth(class_327 tr, Atom atom) {
        if (atom.icon() != null) {
            int ih = iconHeightLocal();
            return Math.max(1, Math.round(atom.icon().width() * (ih / (float) atom.icon().height())));
        }
        return tr.method_27525(atom.text());
    }

    private float lineWidth(class_327 tr, List<Atom> line, float spaceW) {
        float w = 0;
        boolean first = true;
        for (Atom atom : line) {
            if (atom.spaceBefore() && !first) w += spaceW;
            first = false;
            w += atomWidth(tr, atom);
        }
        return w;
    }

    // ------------------------------------------------------------------
    // Utilidades de coordenadas
    // ------------------------------------------------------------------

    /** Mapea una region del lienzo de diseno 1920x1080 a pixeles de pantalla. */
    private int[] region(double dx, double dy, double dw, double dh) {
        int x = (int) Math.round(dx / 1920.0 * field_22789);
        int y = (int) Math.round(dy / 1080.0 * field_22790);
        int w = (int) Math.round(dw / 1920.0 * field_22789);
        int h = (int) Math.round(dh / 1080.0 * field_22790);
        return new int[]{x, y, w, h};
    }

    /** Region en fracciones de pantalla (0..1). */
    private int[] frac(float fx, float fy, float fw, float fh) {
        return new int[]{Math.round(fx * field_22789), Math.round(fy * field_22790),
                Math.round(fw * field_22789), Math.round(fh * field_22790)};
    }

    private int[] pad(int[] r, int p) {
        return new int[]{r[0] + p, r[1] + p, Math.max(1, r[2] - 2 * p), Math.max(1, r[3] - 2 * p)};
    }

    private static int withA(int rgb, float alpha) {
        int a = (int) (alpha * 255) & 0xFF;
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    /** Resuelve un nombre de fuente del yml al Identifier de la fuente nativa registrada. */
    private static class_2960 fontId(String name) {
        if (name == null) return class_2960.method_60655("minecraft", "default");
        String orig = name.trim().toLowerCase();
        boolean otf = orig.endsWith(".otf");
        String n = orig;
        if (n.endsWith(".ttf")) n = n.substring(0, n.length() - 4);
        else if (n.endsWith(".otf")) n = n.substring(0, n.length() - 5);
        return switch (n) {
            case "arial" -> class_2960.method_60655(MediaPlayerMod.MOD_ID, "arial");
            case "helvetica" -> class_2960.method_60655(MediaPlayerMod.MOD_ID, "helvetica");
            case "verdana" -> class_2960.method_60655(MediaPlayerMod.MOD_ID, "verdana");
            case "poppins" -> class_2960.method_60655(MediaPlayerMod.MOD_ID, "poppins");
            case "saw" -> class_2960.method_60655(MediaPlayerMod.MOD_ID, "saw");
            case "minecraftfont" -> class_2960.method_60655(MediaPlayerMod.MOD_ID, "minecraftfont");
            case "minecraft" -> otf ? class_2960.method_60655(MediaPlayerMod.MOD_ID, "minecraftfont")
                                    : class_2960.method_60655("minecraft", "default");
            default -> class_2960.method_60655("minecraft", "default");
        };
    }

    // ------------------------------------------------------------------
    // Imagenes superpuestas (encima de todo)
    // ------------------------------------------------------------------

    private void renderImages(class_332 ctx, float alpha) {
        if (loadedImages.isEmpty()) return;
        int tick = (int) ((System.currentTimeMillis() - openTime) / 50);
        for (LoadedImage li : loadedImages) {
            int tex = li.renderer().texture(tick, 0, true);
            if (tex <= 0 || !GL11.glIsTexture(tex)) continue;
            int iw = li.renderer().width;
            int ih = li.renderer().height;
            if (iw <= 0 || ih <= 0) continue;
            int wpx = Math.max(1, Math.round(li.spec().w() * field_22789));
            int hpx = li.spec().h() > 0
                    ? Math.max(1, Math.round(li.spec().h() * field_22790))
                    : Math.max(1, Math.round(wpx * (ih / (float) iw)));
            int x = Math.round(li.spec().x() * field_22789 - wpx / 2f);
            int y = Math.round(li.spec().y() * field_22790 - hpx / 2f);
            blit(ctx, tex, x, y, wpx, hpx, alpha);
        }
    }

    private void blit(class_332 ctx, int tex, int x, int y, int w, int h, float alpha) {
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
        RenderSystem.setShaderColor(1f, 1f, 1f, alpha);
        RenderSystem.setShaderTexture(0, tex);
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        Matrix4f m = ctx.method_51448().method_23760().method_23761();
        class_287 bb = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1585);
        bb.method_22918(m, x, y, 0).method_22913(0, 0);
        bb.method_22918(m, x, y + h, 0).method_22913(0, 1);
        bb.method_22918(m, x + w, y + h, 0).method_22913(1, 1);
        bb.method_22918(m, x + w, y, 0).method_22913(1, 0);
        class_286.method_43433(bb.method_60800());
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.disableBlend();
    }
}
