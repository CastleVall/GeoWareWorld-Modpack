package me.elb.mediaplayermod.client.gui.tutorial;

import me.elb.mediaplayermod.MediaPlayerMod;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Tutorial bilingue (es/en) cargado desde {@code config/mediaplayer/tutorial/<nombre>.yml}.
 *
 * <p>Cada campo de texto es bilingue: se escribe en {@code es:} e {@code en:}, y cada cliente
 * elige el idioma segun el idioma de su juego (cualquier variante {@code en_*} muestra ingles).
 * Los campos {@code instrucciones} y {@code controles} admiten varias lineas, ya sea como lista
 * de cadenas o usando {@code \n} dentro del texto. En cualquier texto se pueden incrustar iconos
 * internos con tokens como {@code {w}}, {@code {lclick}} o {@code {music}} (ver {@link TutorialIcons}).
 *
 * <p>Esquema de ejemplo:
 * <pre>
 * estilo: decorado        # decorado | vanilla | eien | mizore | sango | suna | younga
 * cerrable: true          # legado: ESC ya solo lo pueden usar los OP (los demas no se saltan el tutorial)
 * timer: 30               # segundos de cuenta atras (0 = sin timer / no autocierra)
 * fade_in: 0.5            # segundos de fundido de entrada
 * fade_out: 0.5           # segundos de fundido de salida
 * video: tutorial.mp4     # archivo local en config/mediaplayer/tutorial/videos o url; vacio = pantalla negra
 * titulo:
 *   es: "TITULO"
 *   en: "TITLE"
 * subtitulo:
 *   es: "Subtitulo"
 *   en: "Subtitle"
 * titulo_controles:
 *   es: "Controles"
 *   en: "Controls"
 * instrucciones:
 *   es:
 *     - "Primera linea"
 *     - "Segunda linea con {w}{a}{s}{d}"
 *   en:
 *     - "First line"
 * controles:
 *   es: "Muevete con {w}{a}{s}{d} y {lclick}"
 *   en: "Move with {w}{a}{s}{d} and {lclick}"
 * </pre>
 */
public final class TutorialData {

    public enum Style {
        DECORATED, VANILLA, EIEN, MIZORE, SANGO, SUNA, YOUNGA;

        public static Style fromString(String s) {
            if (s == null) return DECORATED;
            return switch (s.trim().toLowerCase()) {
                case "vanilla", "simple", "lineal", "linear", "negro", "rojo" -> VANILLA;
                case "eien" -> EIEN;
                case "mizore" -> MIZORE;
                case "sango" -> SANGO;
                case "suna" -> SUNA;
                case "younga" -> YOUNGA;
                default -> DECORATED;
            };
        }
    }

    /** Texto bilingue: devuelve la variante pedida con fallback al otro idioma. */
    public record Localized(String es, String en) {
        public String text(boolean english) {
            String primary = english ? en : es;
            if (primary != null && !primary.isBlank()) return primary;
            String fallback = english ? es : en;
            return fallback == null ? "" : fallback;
        }
    }

    /**
     * Imagen superpuesta encima de todo. Posicion {@code x,y} = centro en fraccion de pantalla (0..1).
     * {@code w} = ancho en fraccion de pantalla; {@code h} = alto en fraccion (si &lt;= 0 mantiene la
     * proporcion original). {@code src} = archivo local (config/mediaplayer/...) o url.
     */
    public record ImageOverlay(String src, float x, float y, float w, float h) {}

    private final Style style;
    private final boolean closable;
    private final int timerSeconds;
    private final float fadeInSeconds;
    private final float fadeOutSeconds;
    private final String video;
    private final Localized titulo;
    private final Localized subtitulo;
    private final Localized tituloControles;
    private final Localized instrucciones;
    private final Localized controles;
    private final Map<String, String> options;
    private final List<ImageOverlay> images;

    private TutorialData(Style style, boolean closable, int timerSeconds, float fadeInSeconds, float fadeOutSeconds,
                         String video, Localized titulo, Localized subtitulo, Localized tituloControles,
                         Localized instrucciones, Localized controles, Map<String, String> options,
                         List<ImageOverlay> images) {
        this.style = style;
        this.closable = closable;
        this.timerSeconds = timerSeconds;
        this.fadeInSeconds = fadeInSeconds;
        this.fadeOutSeconds = fadeOutSeconds;
        this.video = video;
        this.titulo = titulo;
        this.subtitulo = subtitulo;
        this.tituloControles = tituloControles;
        this.instrucciones = instrucciones;
        this.controles = controles;
        this.options = options;
        this.images = images;
    }

    public List<ImageOverlay> images() {
        return images;
    }

    /**
     * Nombre de fuente para una seccion. Busca {@code <seccion>_font}, luego el global {@code font},
     * y si no hay nada devuelve "minecraft" (la fuente nativa).
     */
    public String fontFor(String section) {
        String v = options.get(section + "_font");
        if (v == null) v = options.get("font");
        return (v == null || v.isBlank()) ? "minecraft" : v.trim();
    }

    /** Tamano de fuente (px de diseno) para una seccion: {@code <seccion>_size}/{@code _tamano} o el default. */
    public float sizeFor(String section, float def) {
        String v = options.get(section + "_size");
        if (v == null) v = options.get(section + "_tamano");
        return parseFloat(v, def);
    }

    public Style style() { return style; }
    public boolean closable() { return closable; }
    public int timerSeconds() { return timerSeconds; }
    public float fadeInSeconds() { return fadeInSeconds; }
    public float fadeOutSeconds() { return fadeOutSeconds; }
    public String video() { return video; }
    public Localized titulo() { return titulo; }
    public Localized subtitulo() { return subtitulo; }
    public Localized tituloControles() { return tituloControles; }
    public Localized instrucciones() { return instrucciones; }
    public Localized controles() { return controles; }

    public boolean hasVideo() {
        return video != null && !video.isBlank();
    }

    // ------------------------------------------------------------------
    // Carga
    // ------------------------------------------------------------------

    /** Carpeta donde viven los .yml de tutorial. */
    public static Path dir() {
        return FabricLoader.getInstance().getConfigDir().resolve("mediaplayer").resolve("tutorial");
    }

    /** Resuelve un nombre simple a su .yml; null si el nombre es invalido o no existe. */
    public static Path resolveFile(String name) {
        if (name == null) return null;
        String n = name.trim();
        if (n.isEmpty()) return null;
        if (n.contains("/") || n.contains("\\") || n.contains(":") || n.contains("..")) return null;
        String lower = n.toLowerCase();
        if (lower.endsWith(".yml")) n = n.substring(0, n.length() - 4);
        else if (lower.endsWith(".yaml")) n = n.substring(0, n.length() - 5);
        try {
            Path d = dir();
            Path yml = d.resolve(n + ".yml");
            if (Files.exists(yml)) return yml;
            Path yaml = d.resolve(n + ".yaml");
            if (Files.exists(yaml)) return yaml;
        } catch (InvalidPathException ignored) {
        }
        return null;
    }

    public static TutorialData load(String name) {
        Path file = resolveFile(name);
        if (file == null) return null;
        try {
            return parse(Files.readAllLines(file, StandardCharsets.UTF_8));
        } catch (IOException e) {
            MediaPlayerMod.LOGGER.error("Error cargando tutorial: {}", file, e);
            return null;
        }
    }

    // ------------------------------------------------------------------
    // Parser YAML minimo (subconjunto): claves escalares de nivel 0, grupos
    // bilingues con es/en, y valores es/en como escalar o lista de lineas.
    // ------------------------------------------------------------------

    private static TutorialData parse(List<String> raw) {
        Map<String, String> scalars = new LinkedHashMap<>();
        // grupo -> idioma -> lineas
        Map<String, Map<String, List<String>>> groups = new LinkedHashMap<>();
        List<Map<String, String>> imageMaps = new ArrayList<>();
        Map<String, String> currentImage = null;

        String currentGroup = null;
        String currentLang = null;

        for (String original : raw) {
            String noComment = stripComment(original);
            if (noComment.trim().isEmpty()) continue;
            int indent = leadingSpaces(noComment);
            String trimmed = noComment.trim();

            if (indent == 0) {
                currentGroup = null;
                currentLang = null;
                currentImage = null;
                Kv kv = splitKv(trimmed);
                if (kv == null) continue;
                String key = kv.key().toLowerCase();
                if (kv.value().isEmpty()) {
                    // Inicio de un grupo (bilingue o de imagenes).
                    currentGroup = key;
                    if (!isImageGroup(key)) {
                        groups.computeIfAbsent(key, k -> new LinkedHashMap<>());
                    }
                } else {
                    scalars.put(key, unquote(kv.value()));
                }
                continue;
            }

            // Lineas indentadas: pertenecen al grupo actual.
            if (currentGroup == null) continue;

            // Grupo de imagenes: lista de mapas (- src: ...  /  x: ...).
            if (isImageGroup(currentGroup)) {
                if (trimmed.startsWith("-")) {
                    currentImage = new LinkedHashMap<>();
                    imageMaps.add(currentImage);
                    String rest = trimmed.substring(1).trim();
                    if (!rest.isEmpty()) {
                        Kv kv = splitKv(rest);
                        if (kv != null) currentImage.put(kv.key().toLowerCase(), unquote(kv.value()));
                    }
                } else if (currentImage != null) {
                    Kv kv = splitKv(trimmed);
                    if (kv != null) currentImage.put(kv.key().toLowerCase(), unquote(kv.value()));
                }
                continue;
            }

            if (trimmed.startsWith("-")) {
                // Item de lista para el idioma actual.
                if (currentLang == null) continue;
                String item = unquote(trimmed.substring(1).trim());
                groups.get(currentGroup).computeIfAbsent(currentLang, k -> new ArrayList<>()).add(item);
                continue;
            }

            Kv kv = splitKv(trimmed);
            if (kv == null) continue;

            // Permite definir tamano/fuente DENTRO de la seccion (lo mas intuitivo):
            //   titulo:
            //     size: 60
            //     font: Poppins
            //     es: "..."
            String gkey = kv.key().trim().toLowerCase();
            if (gkey.equals("size") || gkey.equals("tamano") || gkey.equals("tamaño")) {
                scalars.put(canonicalGroup(currentGroup) + "_size", unquote(kv.value()));
                continue;
            }
            if (gkey.equals("font") || gkey.equals("fuente")) {
                scalars.put(canonicalGroup(currentGroup) + "_font", unquote(kv.value()));
                continue;
            }

            String lang = normalizeLang(kv.key());
            if (lang == null) continue;
            currentLang = lang;
            if (!kv.value().isEmpty()) {
                groups.get(currentGroup)
                        .computeIfAbsent(lang, k -> new ArrayList<>())
                        .add(unquote(kv.value()));
            } else {
                groups.get(currentGroup).computeIfAbsent(lang, k -> new ArrayList<>());
            }
        }

        Style style = Style.fromString(firstOf(scalars, "estilo", "style"));
        boolean closable = parseBool(firstOf(scalars, "cerrable", "closable"), true);
        int timer = parseInt(firstOf(scalars, "timer", "tiempo", "duracion"), 0);
        float fadeIn = parseFloat(firstOf(scalars, "fade_in", "fadein"), 0.5f);
        float fadeOut = parseFloat(firstOf(scalars, "fade_out", "fadeout"), 0.5f);
        String video = firstOf(scalars, "video", "tutorial", "url");

        List<ImageOverlay> images = new ArrayList<>();
        for (Map<String, String> m : imageMaps) {
            String src = firstOf(m, "src", "url", "imagen", "image", "ruta", "path");
            if (src == null || src.isBlank()) continue;
            float x = parseFloat(firstOf(m, "x", "pos_x", "posx"), 0.5f);
            float y = parseFloat(firstOf(m, "y", "pos_y", "posy"), 0.5f);
            float w = parseFloat(firstOf(m, "w", "ancho", "width", "size", "tamano"), 0.2f);
            float h = parseFloat(firstOf(m, "h", "alto", "height"), -1f);
            images.add(new ImageOverlay(src.trim(), x, y, w, h));
        }

        return new TutorialData(style, closable, timer, fadeIn, fadeOut, video,
                localized(groups, "titulo", "title"),
                localized(groups, "subtitulo", "subtitle", "subtexto"),
                localized(groups, "titulo_controles", "controls_title", "titulocontroles"),
                localized(groups, "instrucciones", "instructions"),
                localized(groups, "controles", "controls"),
                scalars, images);
    }

    /** Nombre canonico de seccion (resuelve alias es/en) para las claves de tamaño/fuente. */
    private static String canonicalGroup(String key) {
        return switch (key.trim().toLowerCase()) {
            case "title" -> "titulo";
            case "subtitle", "subtexto" -> "subtitulo";
            case "instructions" -> "instrucciones";
            case "controls" -> "controles";
            case "controls_title", "titulocontroles" -> "titulo_controles";
            default -> key.trim().toLowerCase();
        };
    }

    private static boolean isImageGroup(String key) {
        return switch (key) {
            case "imagenes", "images", "imagen", "image", "overlay", "overlays" -> true;
            default -> false;
        };
    }

    private static Localized localized(Map<String, Map<String, List<String>>> groups, String... keys) {
        Map<String, List<String>> g = null;
        for (String k : keys) {
            g = groups.get(k);
            if (g != null) break;
        }
        if (g == null) return new Localized("", "");
        return new Localized(joinLang(g, "es"), joinLang(g, "en"));
    }

    private static String joinLang(Map<String, List<String>> group, String lang) {
        List<String> lines = group.get(lang);
        if (lines == null || lines.isEmpty()) return "";
        return String.join("\n", lines);
    }

    private static String normalizeLang(String key) {
        return switch (key.trim().toLowerCase()) {
            case "es", "espanol", "español", "spanish" -> "es";
            case "en", "ingles", "inglés", "english" -> "en";
            default -> null;
        };
    }

    private static String firstOf(Map<String, String> map, String... keys) {
        for (String k : keys) {
            String v = map.get(k);
            if (v != null) return v;
        }
        return null;
    }

    private static int leadingSpaces(String s) {
        int n = 0;
        while (n < s.length() && (s.charAt(n) == ' ' || s.charAt(n) == '\t')) n++;
        return n;
    }

    private static boolean parseBool(String v, boolean def) {
        if (v == null) return def;
        return switch (v.trim().toLowerCase()) {
            case "true", "si", "sí", "yes", "1" -> true;
            case "false", "no", "0" -> false;
            default -> def;
        };
    }

    private static int parseInt(String v, int def) {
        if (v == null) return def;
        try {
            return (int) Math.round(Double.parseDouble(v.trim()));
        } catch (Exception e) {
            return def;
        }
    }

    private static float parseFloat(String v, float def) {
        if (v == null) return def;
        try {
            return Float.parseFloat(v.trim());
        } catch (Exception e) {
            return def;
        }
    }

    private record Kv(String key, String value) {}

    private static Kv splitKv(String s) {
        boolean inSingle = false, inDouble = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\'' && !inDouble) inSingle = !inSingle;
            else if (c == '"' && !inSingle) inDouble = !inDouble;
            else if (c == ':' && !inSingle && !inDouble) {
                String key = s.substring(0, i).trim();
                if (key.isEmpty()) return null;
                return new Kv(key, s.substring(i + 1).trim());
            }
        }
        return null;
    }

    private static String stripComment(String s) {
        boolean inSingle = false, inDouble = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\'' && !inDouble) inSingle = !inSingle;
            else if (c == '"' && !inSingle) inDouble = !inDouble;
            else if (c == '#' && !inSingle && !inDouble && (i == 0 || Character.isWhitespace(s.charAt(i - 1)))) {
                return s.substring(0, i);
            }
        }
        return s;
    }

    private static String unquote(String v) {
        if (v == null) return null;
        String t = v.trim();
        if (t.length() >= 2) {
            char f = t.charAt(0), l = t.charAt(t.length() - 1);
            if ((f == '"' && l == '"') || (f == '\'' && l == '\'')) {
                t = t.substring(1, t.length() - 1);
            }
        }
        return t.replace("\\n", "\n");
    }
}
