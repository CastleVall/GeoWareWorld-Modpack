package me.elb.mediaplayermod.client.gui.screen;

import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import net.minecraft.class_2561;
import net.minecraft.class_410;

public class MediaConfirmScreen extends class_410 {

    public MediaConfirmScreen(BooleanConsumer callback, class_2561 title, class_2561 message) {
        super(callback, title, message);
    }
}
