package me.elb.mediaplayermod.client.gui.screen;

import me.elb.mediaplayermod.client.ClientHandler;
import me.elb.mediaplayermod.client.playlist.PlaylistAdminState;
import me.elb.mediaplayermod.client.search.SearchResult;
import me.elb.mediaplayermod.client.search.SongSearchClient;
import me.elb.mediaplayermod.client.sound.ClientPlaylist;
import me.elb.mediaplayermod.networking.packet.ServerPlaylistAdminSyncPacket;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

public class PlaylistAdminScreen extends class_437 {
    private static final int BG = 0xFF090909;
    private static final int PANEL = 0xFF121212;
    private static final int PANEL_ALT = 0xFF181818;
    private static final int PANEL_SOFT = 0xFF202020;
    private static final int BORDER = 0xFF2A2A2A;
    private static final int TEXT = 0xFFF2F2F2;
    private static final int TEXT_DIM = 0xFFA8A8A8;
    private static final int TEXT_FAINT = 0xFF707070;
    private static final int GREEN = 0xFF1ED760;
    private static final int GREEN_DARK = 0xFF0F7A35;
    private static final int RED = 0xFFB04C4C;
    private static final int TRACK_ROW = 28;
    private static final int PLAYLIST_ROW = 52;
    private static final int BOTTOM_BAR = 92;

    private String selectedPlaylistId;
    private int selectedSong = -1;
    private int playlistScroll;
    private int songScroll;
    private int playerScroll;

    private int savedGuiScale = -1;

    private int currentVolume = 100;
    private boolean draggingVolume = false;
    private List<String> autocompleteSuggestions = new ArrayList<>();

    private boolean searchMode = false;
    private int searchScroll = 0;
    private volatile List<SearchResult> searchResults = null;
    private volatile boolean searching = false;
    private volatile String searchError = null;
    private CompletableFuture<?> pendingSearch;
    private volatile String pendingLyricsPath = null;
    private volatile boolean fetchingLyrics = false;
    private CompletableFuture<String> pendingLyricsFetch;

    private class_342 urlField;
    private class_342 nameField;
    private class_342 searchField;
    private class_342 targetsField;
    private class_342 newPlaylistField;

    private class_4185 addTrackButton;
    private class_4185 searchToggleButton;
    private class_4185 playSelectedButton;
    private class_4185 removeTrackButton;
    private class_4185 moveUpButton;
    private class_4185 moveDownButton;
    private class_4185 deletePlaylistButton;
    private class_4185 refreshButton;
    private class_4185 assignButton;
    private class_4185 shuffleButton;
    private class_4185 prevButton;
    private class_4185 playPauseButton;
    private class_4185 nextButton;
    private class_4185 loopButton;
    private class_4185 createPlaylistButton;

    public PlaylistAdminScreen() {
        super(class_2561.method_43470("Gestor de playlists"));
    }

    @Override
    protected void method_25426() {
        class_310 mc = class_310.method_1551();
        int currentScale = mc.field_1690.method_42474().method_41753();
        if (currentScale != 2) {
            if (savedGuiScale == -1) savedGuiScale = currentScale;
            mc.field_1690.method_42474().method_41748(2);
            mc.method_15993();
            return;
        }

        syncSelection();

        int cx = centerX();
        int cw = centerWidth();
        int contentX = centerContentX();
        int contentWidth = centerContentWidth();
        int rx = rightX();
        int rw = rightWidth();
        int addButtonWidth = addButtonWidth();
        int headerButtonWidth = headerButtonWidth();

        int urlY = inputY();
        int searchBtnW = compactMode() ? 52 : 64;
        int urlWidth = Math.max(80, contentWidth - gap() * 2 - searchBtnW - addButtonWidth);
        urlField = method_37063(new class_342(field_22793, contentX, urlY, urlWidth, 20, class_2561.method_43473()));
        urlField.method_47404(class_2561.method_43470("Pega el link de la cancion"));
        urlField.method_1880(1024);

        searchToggleButton = method_37063(class_4185.method_46430(class_2561.method_43470("Buscar"), button -> toggleSearchMode())
                .method_46434(contentX + urlWidth + gap(), urlY, searchBtnW, 20)
                .method_46431());

        addTrackButton = method_37063(class_4185.method_46430(class_2561.method_43470(compactMode() ? "Agre." : "Agregar"), button -> {
            if (searchMode && selectedPlaylistId != null) executeSearch();
            else addTrack();
        }).method_46434(contentX + contentWidth - addButtonWidth, urlY, addButtonWidth, 20).method_46431());

        int nameY = nameY();
        nameField = method_37063(new class_342(field_22793, contentX, nameY, contentWidth, 20, class_2561.method_43473()));
        nameField.method_47404(class_2561.method_43470("Nombre de la cancion (opcional)"));
        nameField.method_1880(128);

        searchField = method_37063(new class_342(field_22793, contentX, nameY, contentWidth, 20, class_2561.method_43473()));
        searchField.method_47404(class_2561.method_43470("Busca canciones en YouTube..."));
        searchField.method_1880(256);
        searchField.field_22764 = false;

        int actionY = actionY();
        if (splitTrackActions()) {
            int buttonWidth = Math.min(112, Math.max(64, (contentWidth - gap()) / 2));
            int secondColumnX = contentX + contentWidth - buttonWidth;
            playSelectedButton = method_37063(class_4185.method_46430(class_2561.method_43470("Repr."), button -> playSelectedTrack())
                    .method_46434(contentX, actionY, buttonWidth, 20)
                    .method_46431());
            removeTrackButton = method_37063(class_4185.method_46430(class_2561.method_43470(compactMode() ? "Quitar" : "Quitar"), button -> removeSelectedTrack())
                    .method_46434(secondColumnX, actionY, buttonWidth, 20)
                    .method_46431());
            moveUpButton = method_37063(class_4185.method_46430(class_2561.method_43470("Subir"), button -> moveSelectedTrack(-1))
                    .method_46434(contentX, actionY + 24, buttonWidth, 20)
                    .method_46431());
            moveDownButton = method_37063(class_4185.method_46430(class_2561.method_43470("Bajar"), button -> moveSelectedTrack(1))
                    .method_46434(secondColumnX, actionY + 24, buttonWidth, 20)
                    .method_46431());
        } else {
            int playWidth = compactMode() ? 84 : 96;
            int removeWidth = compactMode() ? 64 : 72;
            int moveWidth = compactMode() ? 56 : 62;
            playSelectedButton = method_37063(class_4185.method_46430(class_2561.method_43470(compactMode() ? "Repr." : "Reproducir"), button -> playSelectedTrack())
                    .method_46434(contentX, actionY, playWidth, 20)
                    .method_46431());
            removeTrackButton = method_37063(class_4185.method_46430(class_2561.method_43470(compactMode() ? "Quitar" : "Quitar"), button -> removeSelectedTrack())
                    .method_46434(playSelectedButton.method_46426() + playSelectedButton.method_25368() + gap(), actionY, removeWidth, 20)
                    .method_46431());
            moveUpButton = method_37063(class_4185.method_46430(class_2561.method_43470("Subir"), button -> moveSelectedTrack(-1))
                    .method_46434(removeTrackButton.method_46426() + removeTrackButton.method_25368() + gap(), actionY, moveWidth, 20)
                    .method_46431());
            moveDownButton = method_37063(class_4185.method_46430(class_2561.method_43470("Bajar"), button -> moveSelectedTrack(1))
                    .method_46434(moveUpButton.method_46426() + moveUpButton.method_25368() + gap(), actionY, moveWidth, 20)
                    .method_46431());
        }
        refreshButton = method_37063(class_4185.method_46430(class_2561.method_43470("Actualizar"), button -> PlaylistAdminState.requestRefresh())
                .method_46434(contentX + contentWidth - 2 * headerButtonWidth - gap(), gap(), headerButtonWidth, 20)
                .method_46431());
        deletePlaylistButton = method_37063(class_4185.method_46430(class_2561.method_43470("Eliminar"), button -> deleteSelectedPlaylist())
                .method_46434(contentX + contentWidth - headerButtonWidth, gap(), headerButtonWidth, 20)
                .method_46431());

        targetsField = method_37063(new class_342(field_22793, rx + gap(), rightTargetInputY(), rw - gap() * 2, 20, class_2561.method_43473()));
        targetsField.method_47404(class_2561.method_43470("@a o jugador"));
        targetsField.method_1880(256);
        targetsField.method_1852("@a");

        assignButton = method_37063(class_4185.method_46430(class_2561.method_43470("Asignar"), button -> assignTargets())
                .method_46434(rx + gap(), rightTargetButtonY(), rw - gap() * 2, 20)
                .method_46431());

        newPlaylistField = method_37063(new class_342(field_22793, gap(), leftFooterY(), leftWidth() - gap() * 2, 20, class_2561.method_43473()));
        newPlaylistField.method_47404(class_2561.method_43470("id_nueva_playlist"));
        newPlaylistField.method_1880(64);

        createPlaylistButton = method_37063(class_4185.method_46430(class_2561.method_43470(compactMode() ? "+ Crear" : "+ Crear playlist"), button -> createPlaylist())
                .method_46434(gap(), leftFooterY() + 26, leftWidth() - gap() * 2, 20)
                .method_46431());

        int controlGap = compactMode() ? 6 : 8;
        int sideW = veryCompactMode() ? 44 : compactMode() ? 58 : 84;
        int playW = veryCompactMode() ? 62 : compactMode() ? 76 : 96;
        int totalWidth = playW + sideW * 4 + controlGap * 4;
        int controlsX = centerX() + Math.max(gap(), (centerWidth() - totalWidth) / 2);
        int controlsY = bottomControlsY();

        shuffleButton = method_37063(class_4185.method_46430(class_2561.method_43470(compactMode() ? "Mez" : "Mezcla"), button -> toggleShuffle())
                .method_46434(controlsX, controlsY, sideW, 20)
                .method_46431());
        prevButton = method_37063(class_4185.method_46430(class_2561.method_43470(compactMode() ? "<" : "Anterior"), button -> skip(-1))
                .method_46434(controlsX + sideW + controlGap, controlsY, sideW, 20)
                .method_46431());
        playPauseButton = method_37063(class_4185.method_46430(class_2561.method_43470("Repr."), button -> togglePlayPause())
                .method_46434(controlsX + sideW * 2 + controlGap * 2, controlsY, playW, 20)
                .method_46431());
        nextButton = method_37063(class_4185.method_46430(class_2561.method_43470(compactMode() ? ">" : "Siguiente"), button -> skip(1))
                .method_46434(controlsX + sideW * 2 + playW + controlGap * 3, controlsY, sideW, 20)
                .method_46431());
        loopButton = method_37063(class_4185.method_46430(class_2561.method_43470(compactMode() ? "Buc" : "Bucle"), button -> toggleLoop())
                .method_46434(controlsX + sideW * 3 + playW + controlGap * 4, controlsY, sideW, 20)
                .method_46431());
    }

    @Override
    public void method_25432() {
        if (savedGuiScale != -1) {
            int scale = savedGuiScale;
            savedGuiScale = -1;
            class_310 mc = class_310.method_1551();
            mc.field_1690.method_42474().method_41748(scale);
            mc.execute(mc::method_15993);
        }
        super.method_25432();
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        syncSelection();
        clampScrolls();
        updateButtonStates();
        updateAutocomplete();

        context.method_25294(0, 0, field_22789, field_22790, BG);
        renderSidebar(context, mouseX, mouseY);
        renderCenterPanel(context, mouseX, mouseY);
        renderRightPanel(context);
        renderBottomBar(context);

        super.method_25394(context, mouseX, mouseY, delta);
        renderAutocomplete(context, mouseX, mouseY);
    }

    private void updateAutocomplete() {
        if (targetsField == null || !targetsField.method_25370()) {
            autocompleteSuggestions.clear();
            return;
        }
        String input = targetsField.method_1882().trim();
        if (input.isEmpty() || input.startsWith("@")) {
            autocompleteSuggestions.clear();
            return;
        }
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1724.field_3944 == null) {
            autocompleteSuggestions.clear();
            return;
        }
        String lower = input.toLowerCase();
        autocompleteSuggestions = mc.field_1724.field_3944.method_2880().stream()
                .map(entry -> entry.method_2966().getName())
                .filter(name -> name.toLowerCase().startsWith(lower))
                .sorted()
                .limit(5)
                .collect(Collectors.toList());
    }

    private void renderSidebar(class_332 context, int mouseX, int mouseY) {
        int leftW = leftWidth();
        int contentBottom = contentBottom();
        int listTop = leftListTop();
        int rowHeight = playlistRowHeight();
        int listHeight = Math.max(rowHeight, leftFooterY() - gap() - listTop);
        int visible = Math.max(1, listHeight / rowHeight);
        List<ServerPlaylistAdminSyncPacket.Entry> entries = PlaylistAdminState.getEntries();

        context.method_25294(0, 0, leftW, contentBottom, PANEL);
        context.method_25294(leftW - 1, 0, leftW, field_22790, BORDER);
        context.method_51439(field_22793, class_2561.method_43470("Tu biblioteca"), gap(), gap(), TEXT, false);
        context.method_51439(field_22793, class_2561.method_43470("Editor admin"), gap(), gap() + 14, TEXT_DIM, false);
        context.method_51439(field_22793, class_2561.method_43470(entries.size() + " playlists"), gap(), gap() + 28, TEXT_FAINT, false);

        for (int i = playlistScroll; i < Math.min(entries.size(), playlistScroll + visible); i++) {
            ServerPlaylistAdminSyncPacket.Entry entry = entries.get(i);
            int rowY = listTop + (i - playlistScroll) * rowHeight;
            boolean hovered = mouseX >= 0 && mouseX < leftW && mouseY >= rowY && mouseY < rowY + rowHeight - 4;
            boolean selected = entry.getId().equals(selectedPlaylistId);
            int rowColor = selected ? PANEL_SOFT : hovered ? PANEL_ALT : PANEL;
            int accent = accentColor(entry.getId());

            context.method_25294(8, rowY, leftW - 8, rowY + rowHeight - 4, rowColor);
            context.method_25294(gap(), rowY + 8, gap() + 28, rowY + 36, accent);
            context.method_51433(field_22793, class_2561.method_43470(trim(entry.getId(), leftW - 58)), 44, rowY + 8, selected ? TEXT : TEXT_DIM, false);

            String meta = entry.getTracks().size() + " pistas";
            if (entry.isBroadcastEveryone()) {
                meta += " . todos";
            } else if (!entry.getPlayers().isEmpty()) {
                meta += " . " + entry.getPlayers().size() + " jugadores";
            }
            context.method_51439(field_22793, class_2561.method_43470(trim(meta, leftW - 58)), 44, rowY + Math.min(rowHeight - 18, 22), selected ? GREEN : TEXT_FAINT, false);
        }

        if (entries.size() > visible) {
            renderScrollbar(context, leftW - 6, listTop, 4, listHeight, entries.size(), visible, playlistScroll);
        }

        context.method_25294(0, leftFooterY() - gap(), leftW, contentBottom, PANEL_ALT);
        context.method_25294(gap(), leftFooterY() - gap(), leftW - gap(), leftFooterY() - gap() + 1, BORDER);
    }

    private void renderCenterPanel(class_332 context, int mouseX, int mouseY) {
        int cx = centerX();
        int cw = centerWidth();
        int contentX = centerContentX();
        int contentWidth = centerContentWidth();
        int contentBottom = contentBottom();
        ServerPlaylistAdminSyncPacket.Entry selected = selectedEntry();
        int headerHeight = headerHeight();
        int trackRow = trackRowHeight();

        context.method_25294(cx, 0, cx + cw, contentBottom, BG);
        if (selected == null) {
            int emptyY = tableTop() + Math.max(18, (contentBottom - tableTop()) / 3);
            context.method_27534(field_22793, class_2561.method_43470("No hay playlists en el servidor"), cx + cw / 2, emptyY, TEXT_DIM);
            context.method_27534(field_22793, class_2561.method_43470("Crea una desde el panel izquierdo"), cx + cw / 2, emptyY + 18, TEXT_FAINT);
            return;
        }

        int accent = accentColor(selected.getId());
        for (int y = 0; y < headerHeight; y++) {
            int alpha = Math.max(18, 180 - y * 2);
            context.method_25294(cx, y, cx + cw, y + 1, (alpha << 24) | (accent & 0x00FFFFFF));
        }
        int artSize = Math.min(54, Math.max(38, headerHeight - 28));
        context.method_25294(contentX, gap(), contentX + artSize, gap() + artSize, accent);
        context.method_51439(field_22793, class_2561.method_43470("PLAYLIST"), contentX + artSize + 12, gap() + 4, TEXT_DIM, false);
        context.method_51433(field_22793, class_2561.method_43470(trim(selected.getId(), contentWidth - artSize - 44)), contentX + artSize + 12, gap() + 18, TEXT, false);
        context.method_51433(field_22793, class_2561.method_43470(selected.getTracks().size() + " pistas"), contentX + artSize + 12, gap() + 32, TEXT_DIM, false);
        ClientPlaylist active = selectedActivePlaylist();

        String status = playbackStatusLabel(selected, active)
                + " . " + (selected.isLoop() ? "Bucle si" : "Bucle no")
                + " . " + (selected.isShuffle() ? "Mezcla si" : "Mezcla no");
        context.method_51439(field_22793, class_2561.method_43470(trim(status, contentWidth - artSize - 44)), contentX + artSize + 12, gap() + 46, GREEN, false);

        context.method_25294(contentX - 4, headerHeight + 4, contentX + contentWidth + 4, tableTop() - 6, PANEL);
        context.method_25294(contentX - 4, tableTop() - 6, contentX + contentWidth + 4, tableTop() - 5, BORDER);

        int tableTop = tableTop();
        int tableBottom = contentBottom() - gap();
        int tableHeight = Math.max(0, tableBottom - tableTop);
        int visibleRows = Math.max(1, tableHeight / trackRow);
        int titleX = contentX + 26;
        int sourceWidth = Math.min(150, Math.max(88, contentWidth / 4));
        int sourceX = contentX + contentWidth - sourceWidth;
        int playingIndex = isLocallyPlaying(active) ? active.getCurrentAudioIndex().get() : -1;

        context.method_51439(field_22793, class_2561.method_43470("#"), contentX, tableTop - 12, TEXT_FAINT, false);
        context.method_51439(field_22793, class_2561.method_43470("Titulo"), titleX, tableTop - 12, TEXT_FAINT, false);
        context.method_51439(field_22793, class_2561.method_43470("Fuente"), sourceX, tableTop - 12, TEXT_FAINT, false);
        context.method_25294(contentX, tableTop - 2, contentX + contentWidth, tableTop - 1, BORDER);

        for (int i = songScroll; i < Math.min(selected.getTracks().size(), songScroll + visibleRows); i++) {
            int rowY = tableTop + (i - songScroll) * trackRow;
            boolean hovered = mouseX >= contentX && mouseX < contentX + contentWidth && mouseY >= rowY && mouseY < rowY + trackRow - 2;
            boolean rowSelected = i == selectedSong;
            boolean playing = i == playingIndex;
            int fill = playing ? 0xFF16331F : rowSelected ? PANEL_SOFT : hovered ? PANEL_ALT : BG;
            ServerPlaylistAdminSyncPacket.Track track = selected.getTracks().get(i);
            String trackUrl = track.getUrl();
            String trackTitle = track.getName() != null && !track.getName().isEmpty() ? track.getName() : songName(trackUrl);

            context.method_25294(contentX, rowY, contentX + contentWidth, rowY + trackRow - 2, fill);
            if (rowSelected) {
                context.method_25294(contentX, rowY, contentX + 2, rowY + trackRow - 2, GREEN);
            }
            int rowTextY = rowY + Math.max(6, (trackRow - 12) / 2);
            context.method_51439(field_22793, class_2561.method_43470(playing ? ">" : String.valueOf(i + 1)), contentX, rowTextY, playing ? GREEN : TEXT_DIM, false);
            context.method_51439(field_22793, class_2561.method_43470(trim(trackTitle, Math.max(60, sourceX - titleX - 10))), titleX, rowTextY, playing ? GREEN : TEXT, false);
            context.method_51439(field_22793, class_2561.method_43470(trim(sourceLabel(trackUrl), Math.max(44, contentX + contentWidth - sourceX))), sourceX, rowTextY, TEXT_DIM, false);
        }

        if (selected.getTracks().isEmpty()) {
            context.method_27534(field_22793, class_2561.method_43470("La playlist esta vacia"), cx + cw / 2, tableTop + 20, TEXT_DIM);
            context.method_27534(field_22793, class_2561.method_43470("Agrega canciones con el campo superior"), cx + cw / 2, tableTop + 38, TEXT_FAINT);
        } else if (selected.getTracks().size() > visibleRows) {
            renderScrollbar(context, contentX + contentWidth - 4, tableTop, 4, tableHeight, selected.getTracks().size(), visibleRows, songScroll);
        }

        if (searchMode) {
            renderSearchResults(context, mouseX, mouseY, contentX, contentWidth, cx, cw);
        } else {
            renderLyricsStatus(context, contentX);
        }
    }

    private void renderSearchResults(class_332 context, int mouseX, int mouseY,
                                     int contentX, int contentWidth, int cx, int cw) {
        int startY = nameY() + 24;
        int endY = contentBottom() - gap();
        int rowH = 20;
        int visibleRows = Math.max(1, (endY - startY) / rowH);

        context.method_25294(contentX, startY, contentX + contentWidth, endY, PANEL_SOFT);

        if (searching) {
            context.method_27534(field_22793, class_2561.method_43470("Buscando..."),
                    cx + cw / 2, startY + 10, TEXT_DIM);
            return;
        }
        if (searchError != null) {
            context.method_27534(field_22793, class_2561.method_43470(trim(searchError, contentWidth - 8)),
                    cx + cw / 2, startY + 10, RED);
            return;
        }
        if (searchResults == null) {
            context.method_27534(field_22793, class_2561.method_43470("Escribe y pulsa Buscar"),
                    cx + cw / 2, startY + 10, TEXT_FAINT);
            return;
        }
        if (searchResults.isEmpty()) {
            context.method_27534(field_22793, class_2561.method_43470("Sin resultados"),
                    cx + cw / 2, startY + 10, TEXT_DIM);
            return;
        }
        int total = searchResults.size();
        searchScroll = clamp(searchScroll, 0, Math.max(0, total - visibleRows));
        for (int i = 0; i < visibleRows && searchScroll + i < total; i++) {
            SearchResult r = searchResults.get(searchScroll + i);
            int rowY = startY + i * rowH;
            boolean hovered = mouseX >= contentX && mouseX < contentX + contentWidth
                    && mouseY >= rowY && mouseY < rowY + rowH;
            context.method_25294(contentX, rowY, contentX + contentWidth, rowY + rowH - 1,
                    hovered ? PANEL_ALT : PANEL);
            String right = r.formattedDuration();
            int rightW = field_22793.method_1727(right);
            int maxTitleW = contentWidth - rightW - gap() * 3 - 8;
            String display = r.title() + (r.artist().isEmpty() ? "" : " - " + r.artist());
            context.method_51439(field_22793, class_2561.method_43470(trim(display, maxTitleW)), contentX + 4, rowY + (rowH - 8) / 2, TEXT, false);
            context.method_51439(field_22793, class_2561.method_43470(right), contentX + contentWidth - rightW - 4, rowY + (rowH - 8) / 2, TEXT_DIM, false);
        }
        if (total > visibleRows) {
            renderScrollbar(context, contentX + contentWidth - 4, startY, 4, endY - startY, total, visibleRows, searchScroll);
        }
    }

    private void renderLyricsStatus(class_332 context, int contentX) {
        if (fetchingLyrics) {
            context.method_51439(field_22793, class_2561.method_43470("Buscando letras..."), contentX, actionY() - 12, TEXT_DIM, false);
        } else if (pendingLyricsPath != null) {
            context.method_51439(field_22793, class_2561.method_43470("Letras listas"), contentX, actionY() - 12, GREEN, false);
        }
    }

    private void renderRightPanel(class_332 context) {
        int rx = rightX();
        int rw = rightWidth();
        ServerPlaylistAdminSyncPacket.Entry selected = selectedEntry();
        ClientPlaylist active = selectedActivePlaylist();
        int infoTop = rightInfoTop();
        int infoHeight = rightInfoHeight();
        int playersTop = rightPlayersTop();
        int playersBottom = rightPlayersBottom();
        int playersHeight = Math.max(32, playersBottom - playersTop);

        context.method_25294(rx, 0, field_22789, contentBottom(), PANEL);
        context.method_25294(rx, 0, rx + 1, field_22790, BORDER);
        context.method_51439(field_22793, class_2561.method_43470("Detalle"), rx + gap(), gap(), TEXT, false);
        context.method_51439(field_22793, class_2561.method_43470("Asignaciones"), rx + gap(), gap() + 14, TEXT_DIM, false);

        if (selected == null) {
            context.method_51439(field_22793, class_2561.method_43470("Elige una playlist"), rx + gap(), gap() + 42, TEXT_FAINT, false);
            return;
        }

        context.method_25294(rx + gap(), infoTop, rx + rw - gap(), infoTop + infoHeight, PANEL_ALT);
        context.method_51433(field_22793, class_2561.method_43470(trim(selected.getId(), rw - gap() * 3)), rx + gap() + 10, infoTop + 10, TEXT, false);
        context.method_51433(field_22793, class_2561.method_43470(trim("Estado: " + playbackStatusLabel(selected, active), rw - gap() * 3)), rx + gap() + 10, infoTop + 24, selected.isPaused() ? RED : GREEN, false);
        String routing = selected.isBroadcastEveryone() ? "Destino: todos" : selected.getPlayers().isEmpty() ? "Destino: sin asignar" : "Destino: " + selected.getPlayers().size() + " jugadores";
        context.method_51439(field_22793, class_2561.method_43470(trim(routing, rw - gap() * 3)), rx + gap() + 10, infoTop + 38, TEXT_DIM, false);
        if (!veryCompactMode()) {
            context.method_51439(field_22793, class_2561.method_43470(isLocallyPlaying(active) ? "Monitor local: si" : "Monitor local: no"), rx + gap() + 10, infoTop + 52, isLocallyPlaying(active) ? GREEN : TEXT_FAINT, false);
        }

        context.method_51439(field_22793, class_2561.method_43470("Jugadores"), rx + gap(), playersTop - 16, TEXT, false);
        context.method_25294(rx + gap(), playersTop, rx + rw - gap(), playersTop + playersHeight, PANEL_ALT);
        if (selected.isBroadcastEveryone()) {
            context.method_51439(field_22793, class_2561.method_43470("Todos los jugadores"), rx + gap() + 10, playersTop + 12, GREEN, false);
        } else if (selected.getPlayers().isEmpty()) {
            context.method_51439(field_22793, class_2561.method_43470("Sin jugadores asignados"), rx + gap() + 10, playersTop + 12, TEXT_FAINT, false);
        } else {
            int rowH = 14;
            int visiblePlayers = Math.max(1, (playersHeight - 8) / rowH);
            int xBtnX = rx + rw - gap() - 8;
            for (int i = playerScroll; i < Math.min(selected.getPlayers().size(), playerScroll + visiblePlayers); i++) {
                int rowY = playersTop + 4 + (i - playerScroll) * rowH;
                context.method_51433(field_22793, class_2561.method_43470(trim(selected.getPlayers().get(i), rw - gap() * 4 - 14)), rx + gap() + 10, rowY, TEXT_DIM, false);
                context.method_51439(field_22793, class_2561.method_43470("x"), xBtnX, rowY, RED, false);
            }
            if (selected.getPlayers().size() > visiblePlayers) {
                renderScrollbar(context, rx + rw - gap() - 3, playersTop, 3, playersHeight, selected.getPlayers().size(), visiblePlayers, playerScroll);
            }
        }

        context.method_51439(field_22793, class_2561.method_43470("Selector"), rx + gap(), rightTargetInputY() - 14, TEXT, false);
        if (!veryCompactMode()) {
            context.method_51439(field_22793, class_2561.method_43470("Ej: @a, @s, jugador"), rx + gap(), rightTargetButtonY() + 24, TEXT_FAINT, false);
        }
    }

    private void renderAutocomplete(class_332 context, int mouseX, int mouseY) {
        if (autocompleteSuggestions.isEmpty() || targetsField == null || !targetsField.method_25370()) {
            return;
        }
        int acX = targetsField.method_46426();
        int acY = targetsField.method_46427() + targetsField.method_25364();
        int acW = targetsField.method_25368();
        int rowH = 14;
        int totalH = autocompleteSuggestions.size() * rowH;

        context.method_25294(acX - 1, acY - 1, acX + acW + 1, acY + totalH + 1, BORDER);
        context.method_25294(acX, acY, acX + acW, acY + totalH, PANEL);
        for (int i = 0; i < autocompleteSuggestions.size(); i++) {
            int rowY = acY + i * rowH;
            boolean hovered = mouseX >= acX && mouseX < acX + acW && mouseY >= rowY && mouseY < rowY + rowH;
            if (hovered) {
                context.method_25294(acX, rowY, acX + acW, rowY + rowH, PANEL_SOFT);
            }
            context.method_51439(field_22793, class_2561.method_43470(autocompleteSuggestions.get(i)), acX + 6, rowY + 3, TEXT, false);
        }
    }

    private void renderBottomBar(class_332 context) {
        int barY = contentBottom();
        ServerPlaylistAdminSyncPacket.Entry selected = selectedEntry();
        ClientPlaylist active = selectedActivePlaylist();
        int barHeight = bottomBarHeight();

        context.method_25294(0, barY, field_22789, field_22790, PANEL);
        context.method_25294(0, barY, field_22789, barY + 1, BORDER);
        if (selected != null && active != null && active.getMusicPlayer().isReady() && !selected.getTracks().isEmpty()) {
            int current = active.getCurrentAudioIndex().get();
            if (current >= 0 && current < selected.getTracks().size()) {
                ServerPlaylistAdminSyncPacket.Track currentTrack = selected.getTracks().get(current);
                String currentTitle = currentTrack.getName() != null && !currentTrack.getName().isEmpty() ? currentTrack.getName() : songName(currentTrack.getUrl());
                context.method_51439(field_22793, class_2561.method_43470(trim(currentTitle, leftWidth() - gap() * 2)), gap(), barY + 10, TEXT, false);
                context.method_51433(field_22793, class_2561.method_43470(trim(selected.getId(), leftWidth() - gap() * 2)), gap(), barY + 24, TEXT_DIM, false);
            }
        } else if (selected != null) {
            context.method_51433(field_22793, class_2561.method_43470(trim(selected.getId(), leftWidth() - gap() * 2)), gap(), barY + 10, TEXT, false);
            context.method_51439(field_22793, class_2561.method_43470("Control del servidor activo"), gap(), barY + 24, TEXT_DIM, false);
        }

        renderProgressBar(context, active, barY, barHeight);
        renderVolumeSlider(context, active, barY, barHeight);
    }

    private void renderVolumeSlider(class_332 context, ClientPlaylist active, int barY, int barHeight) {
        ServerPlaylistAdminSyncPacket.Entry selected = selectedEntry();
        if (selected == null) return;
        if (!draggingVolume && active != null) {
            currentVolume = ClientHandler.getPlaylistVolume(selected.getId());
        }
        int rx = rightX();
        int rw = rightWidth();
        int sliderW = Math.min(rw - gap() * 4, veryCompactMode() ? 60 : 80);
        int sliderX = rx + (rw - sliderW) / 2;
        int sliderY = barY + barHeight / 2;
        int labelX = sliderX - field_22793.method_1727("Vol") - 4;
        context.method_51439(field_22793, class_2561.method_43470("Vol"), labelX, sliderY - 4, TEXT_FAINT, false);
        context.method_25294(sliderX, sliderY, sliderX + sliderW, sliderY + 4, PANEL_SOFT);
        int filled = currentVolume * sliderW / 200;
        context.method_25294(sliderX, sliderY, sliderX + filled, sliderY + 4, GREEN);
        context.method_25294(sliderX + Math.max(0, filled - 2), sliderY - 2, sliderX + Math.min(sliderW, filled + 2), sliderY + 6, 0xFFF7F7F7);
    }

    private void renderProgressBar(class_332 context, ClientPlaylist active, int barY, int barHeight) {
        int barWidth = progressBarWidth();
        int barX = centerX() + Math.max(gap(), (centerWidth() - barWidth) / 2);
        int barTop = barY + barHeight - (veryCompactMode() ? 12 : 16);
        context.method_25294(barX, barTop, barX + barWidth, barTop + 4, PANEL_SOFT);

        boolean hasActivePlayer = active != null && active.getMusicPlayer().isReady();
        if (!hasActivePlayer) {
            String label = active != null && active.isLoading() ? "Cargando..." : "Sin monitor local";
            context.method_27534(field_22793, class_2561.method_43470(label), barX + barWidth / 2, barTop - 12, TEXT_FAINT);
            return;
        }

        long position = active.getMusicPlayer().getTime();
        long duration = active.getMusicPlayer().getMediaInfoDuration();
        String durationText = formatTime(duration);
        context.method_51439(field_22793, class_2561.method_43470(formatTime(position)), barX, barTop - 12, TEXT_FAINT, false);
        context.method_51439(field_22793, class_2561.method_43470(durationText), barX + barWidth - field_22793.method_1727(durationText), barTop - 12, TEXT_FAINT, false);
        if (duration > 0) {
            int filled = (int) Math.min(barWidth, Math.max(0, (position * barWidth) / duration));
            context.method_25294(barX, barTop, barX + filled, barTop + 4, GREEN);
            context.method_25294(barX + Math.max(0, filled - 2), barTop - 2, barX + Math.min(barWidth, filled + 2), barTop + 6, 0xFFF7F7F7);
        }
    }

    private void updateButtonStates() {
        ServerPlaylistAdminSyncPacket.Entry selected = selectedEntry();
        boolean hasPlaylist = selected != null;
        boolean hasSong = hasPlaylist && selectedSong >= 0 && selectedSong < selected.getTracks().size();
        boolean validNewId = isValidPlaylistId(newPlaylistField.method_1882().trim());

        boolean inSearch = searchMode && hasPlaylist;
        addTrackButton.field_22763 = inSearch ? !searchField.method_1882().trim().isEmpty()
                : (hasPlaylist && !urlField.method_1882().trim().isEmpty());
        addTrackButton.method_25355(class_2561.method_43470(inSearch ? (compactMode() ? "Bus." : "Buscar") : (compactMode() ? "Agre." : "Agregar")));
        searchToggleButton.method_25355(class_2561.method_43470(inSearch ? "< URL" : "Buscar"));
        playSelectedButton.field_22763 = hasSong;
        removeTrackButton.field_22763 = hasSong;
        moveUpButton.field_22763 = hasSong && selectedSong > 0;
        moveDownButton.field_22763 = hasSong && selectedSong < selected.getTracks().size() - 1;
        deletePlaylistButton.field_22763 = hasPlaylist;
        assignButton.field_22763 = hasPlaylist && !targetsField.method_1882().trim().isEmpty();
        shuffleButton.field_22763 = hasPlaylist;
        prevButton.field_22763 = hasPlaylist;
        playPauseButton.field_22763 = hasPlaylist;
        nextButton.field_22763 = hasPlaylist;
        loopButton.field_22763 = hasPlaylist;
        createPlaylistButton.field_22763 = validNewId;

        urlField.field_22764 = hasPlaylist;
        searchToggleButton.field_22764 = hasPlaylist;
        nameField.field_22764 = hasPlaylist && !inSearch;
        searchField.field_22764 = inSearch;
        addTrackButton.field_22764 = hasPlaylist;
        playSelectedButton.field_22764 = hasPlaylist && !inSearch;
        removeTrackButton.field_22764 = hasPlaylist && !inSearch;
        moveUpButton.field_22764 = hasPlaylist && !inSearch;
        moveDownButton.field_22764 = hasPlaylist && !inSearch;
        targetsField.field_22764 = hasPlaylist;
        assignButton.field_22764 = hasPlaylist;
        shuffleButton.field_22764 = hasPlaylist;
        prevButton.field_22764 = hasPlaylist;
        playPauseButton.field_22764 = hasPlaylist;
        nextButton.field_22764 = hasPlaylist;
        loopButton.field_22764 = hasPlaylist;

        if (hasPlaylist) {
            playPauseButton.method_25355(class_2561.method_43470(isServerPlaybackRunning(selected, selectedActivePlaylist()) ? "Pausa" : "Repr."));
            loopButton.method_25355(class_2561.method_43470(compactMode() ? (selected.isLoop() ? "Buc+" : "Buc-") : (selected.isLoop() ? "Bucle si" : "Bucle no")));
            shuffleButton.method_25355(class_2561.method_43470(compactMode() ? (selected.isShuffle() ? "Mez+" : "Mez-") : (selected.isShuffle() ? "Mezcla si" : "Mezcla no")));
        } else {
            playPauseButton.method_25355(class_2561.method_43470("Repr."));
            loopButton.method_25355(class_2561.method_43470("Bucle"));
            shuffleButton.method_25355(class_2561.method_43470("Mezcla"));
        }
    }

    private void addTrack() {
        ServerPlaylistAdminSyncPacket.Entry selected = selectedEntry();
        String url = urlField.method_1882().trim();
        if (selected == null || url.isEmpty()) return;
        String name = nameField.method_1882().trim();
        String lyrics = pendingLyricsPath;
        pendingLyricsPath = null;
        fetchingLyrics = false;
        if (pendingLyricsFetch != null) { pendingLyricsFetch.cancel(true); pendingLyricsFetch = null; }
        if (lyrics != null && !lyrics.isEmpty()) {
            sendCommand("playlist addwithlyrics " + selected.getId() + " " + quote(url) + " " + quote(lyrics)
                    + (name.isEmpty() ? "" : " " + name));
        } else if (name.isEmpty()) {
            sendCommand("playlist add " + selected.getId() + " " + quote(url));
        } else {
            sendCommand("playlist add " + selected.getId() + " " + quote(url) + " " + name);
        }
        urlField.method_1852("");
        nameField.method_1852("");
    }

    private void toggleSearchMode() {
        searchMode = !searchMode;
        if (searchMode) {
            searchResults = null;
            searching = false;
            searchError = null;
            searchField.method_1852("");
            searchField.method_25365(true);
        }
    }

    private void executeSearch() {
        String query = searchField.method_1882().trim();
        if (query.isEmpty()) return;
        searchResults = null;
        searchError = null;
        searchScroll = 0;
        searching = true;
        if (pendingSearch != null) pendingSearch.cancel(true);
        pendingSearch = SongSearchClient.searchYouTube(query)
                .thenAccept(results -> { this.searchResults = results; this.searching = false; })
                .exceptionally(e -> {
                    this.searchError = "Error de conexion";
                    this.searching = false;
                    return null;
                });
    }

    private void selectSearchResult(SearchResult result) {
        urlField.method_1852(result.url());
        String displayName = result.title() + (result.artist().isEmpty() ? "" : " - " + result.artist());
        nameField.method_1852(displayName);
        pendingLyricsPath = null;
        fetchingLyrics = true;
        searchMode = false;
        if (pendingLyricsFetch != null) pendingLyricsFetch.cancel(true);
        pendingLyricsFetch = SongSearchClient.fetchAndSaveLyrics(result.title(), result.artist(), result.durationSeconds())
                .whenComplete((path, e) -> { pendingLyricsPath = path; fetchingLyrics = false; });
    }

    private static String quote(String s) {
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    private void playSelectedTrack() {
        ServerPlaylistAdminSyncPacket.Entry selected = selectedEntry();
        if (selected == null || selectedSong < 0 || selectedSong >= selected.getTracks().size()) {
            return;
        }
        sendCommand("playlist playtrack " + selected.getId() + " " + selectedSong);
    }

    private void removeSelectedTrack() {
        ServerPlaylistAdminSyncPacket.Entry selected = selectedEntry();
        if (selected == null || selectedSong < 0 || selectedSong >= selected.getTracks().size()) {
            return;
        }
        sendCommand("playlist remove " + selected.getId() + " " + selectedSong);
        selectedSong = -1;
    }

    private void moveSelectedTrack(int delta) {
        ServerPlaylistAdminSyncPacket.Entry selected = selectedEntry();
        if (selected == null || selectedSong < 0 || selectedSong >= selected.getTracks().size()) {
            return;
        }
        int to = selectedSong + delta;
        if (to < 0 || to >= selected.getTracks().size()) {
            return;
        }
        sendCommand("playlist move " + selected.getId() + " " + selectedSong + " " + to);
        selectedSong = to;
    }

    private void deleteSelectedPlaylist() {
        ServerPlaylistAdminSyncPacket.Entry selected = selectedEntry();
        if (selected == null) {
            return;
        }
        sendCommand("playlist delete " + selected.getId());
        selectedPlaylistId = null;
        selectedSong = -1;
    }

    private void assignTargets() {
        ServerPlaylistAdminSyncPacket.Entry selected = selectedEntry();
        String targets = targetsField.method_1882().trim();
        if (selected == null || targets.isEmpty()) {
            return;
        }
        sendCommand("playlist setplayers " + selected.getId() + " " + targets);
    }

    private void toggleShuffle() {
        ServerPlaylistAdminSyncPacket.Entry selected = selectedEntry();
        if (selected != null) {
            sendCommand("playlist shuffle " + selected.getId() + " " + !selected.isShuffle());
        }
    }

    private void togglePlayPause() {
        ServerPlaylistAdminSyncPacket.Entry selected = selectedEntry();
        if (selected != null) {
            sendCommand((selected.isPaused() ? "playlist play " : "playlist pause ") + selected.getId());
        }
    }

    private void skip(int direction) {
        ServerPlaylistAdminSyncPacket.Entry selected = selectedEntry();
        if (selected != null) {
            sendCommand((direction < 0 ? "playlist prev " : "playlist next ") + selected.getId());
        }
    }

    private void toggleLoop() {
        ServerPlaylistAdminSyncPacket.Entry selected = selectedEntry();
        if (selected != null) {
            sendCommand("playlist loop " + selected.getId() + " " + !selected.isLoop());
        }
    }

    private void createPlaylist() {
        String id = newPlaylistField.method_1882().trim();
        if (!isValidPlaylistId(id)) {
            return;
        }
        sendCommand("playlist create " + id);
        newPlaylistField.method_1852("");
    }

    private void sendCommand(String command) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null && client.field_1724.field_3944 != null) {
            client.field_1724.field_3944.method_45730(command);
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        int listTop = leftListTop();
        int rowHeight = playlistRowHeight();
        int listHeight = Math.max(rowHeight, leftFooterY() - gap() - listTop);
        List<ServerPlaylistAdminSyncPacket.Entry> entries = PlaylistAdminState.getEntries();

        if (mouseX >= 0 && mouseX < leftWidth() && mouseY >= listTop && mouseY < listTop + listHeight) {
            int index = playlistScroll + (int) ((mouseY - listTop) / rowHeight);
            if (index >= 0 && index < entries.size()) {
                selectedPlaylistId = entries.get(index).getId();
                selectedSong = -1;
                songScroll = 0;
                draggingVolume = false;
                currentVolume = ClientHandler.getPlaylistVolume(selectedPlaylistId);
                return true;
            }
        }

        ServerPlaylistAdminSyncPacket.Entry selected = selectedEntry();
        if (selected != null && !selected.isBroadcastEveryone() && !selected.getPlayers().isEmpty()) {
            int rx = rightX();
            int rw = rightWidth();
            int playersTop = rightPlayersTop();
            int playersHeight = Math.max(32, rightPlayersBottom() - playersTop);
            int playerRowHeight = 14;
            int visiblePlayers = Math.max(1, (playersHeight - 8) / playerRowHeight);
            int xBtnX = rx + rw - gap() - 8;
            for (int i = 0; i < visiblePlayers; i++) {
                int playerIndex = playerScroll + i;
                if (playerIndex >= selected.getPlayers().size()) {
                    break;
                }
                int rowY = playersTop + 4 + i * playerRowHeight;
                if (mouseX >= xBtnX - 2 && mouseX <= xBtnX + 10 && mouseY >= rowY - 1 && mouseY <= rowY + 9) {
                    sendCommand("playlist removeplayer " + selected.getId() + " " + selected.getPlayers().get(playerIndex));
                    return true;
                }
            }
        }

        if (!autocompleteSuggestions.isEmpty() && targetsField != null && targetsField.method_25370()) {
            int acX = targetsField.method_46426();
            int acY = targetsField.method_46427() + targetsField.method_25364();
            int acW = targetsField.method_25368();
            int acRowHeight = 14;
            for (int i = 0; i < autocompleteSuggestions.size(); i++) {
                int rowY = acY + i * acRowHeight;
                if (mouseX >= acX && mouseX <= acX + acW && mouseY >= rowY && mouseY <= rowY + acRowHeight) {
                    targetsField.method_1852(autocompleteSuggestions.get(i));
                    autocompleteSuggestions.clear();
                    return true;
                }
            }
        }

        if (selected != null) {
            int contentX = centerContentX();
            int contentWidth = centerContentWidth();

            if (searchMode && searchResults != null && !searchResults.isEmpty()) {
                int startY = nameY() + 24;
                int endY = contentBottom() - gap();
                int rowH = 20;
                if (mouseX >= contentX && mouseX < contentX + contentWidth && mouseY >= startY && mouseY < endY) {
                    int idx = searchScroll + (int) ((mouseY - startY) / rowH);
                    if (idx >= 0 && idx < searchResults.size()) {
                        selectSearchResult(searchResults.get(idx));
                        return true;
                    }
                }
            }

            int tableTop = tableTop();
            int tableBottom = contentBottom() - gap();
            if (mouseX >= contentX && mouseX < contentX + contentWidth && mouseY >= tableTop && mouseY < tableBottom) {
                int index = songScroll + (int) ((mouseY - tableTop) / trackRowHeight());
                if (index >= 0 && index < selected.getTracks().size()) {
                    if (selectedSong == index) {
                        playSelectedTrack();
                    }
                    selectedSong = index;
                    return true;
                }
            }

            ClientPlaylist active = selectedActivePlaylist();
            if (active != null && isLocallyPlaying(active) && active.getMusicPlayer().isReady()) {
                int barY = contentBottom();
                int barHeight = bottomBarHeight();
                int barWidth = progressBarWidth();
                int barX = centerX() + Math.max(gap(), (centerWidth() - barWidth) / 2);
                int barTop = barY + barHeight - (veryCompactMode() ? 12 : 16);
                if (mouseX >= barX && mouseX <= barX + barWidth && mouseY >= barTop - 4 && mouseY <= barTop + 8) {
                    long duration = active.getMusicPlayer().getMediaInfoDuration();
                    if (duration > 0) {
                        long seekTo = (long) ((mouseX - barX) * duration / barWidth);
                        active.seekTo(seekTo);
                    }
                    return true;
                }
            }
        }

        ServerPlaylistAdminSyncPacket.Entry selected2 = selectedEntry();
        if (selected2 != null) {
            int barY = contentBottom();
            int barHeight = bottomBarHeight();
            int rx = rightX();
            int rw = rightWidth();
            int sliderW = Math.min(rw - gap() * 4, veryCompactMode() ? 60 : 80);
            int sliderX = rx + (rw - sliderW) / 2;
            int sliderY = barY + barHeight / 2;
            if (mouseX >= sliderX && mouseX <= sliderX + sliderW && mouseY >= sliderY - 4 && mouseY <= sliderY + 8) {
                int newVol = clamp((int) ((mouseX - sliderX) * 200.0 / sliderW), 0, 200);
                currentVolume = newVol;
                draggingVolume = true;
                ClientHandler.setPlaylistVolume(selected2.getId(), newVol);
                return true;
            }
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        ServerPlaylistAdminSyncPacket.Entry selected = selectedEntry();
        if (draggingVolume && selected != null) {
            int rx = rightX();
            int rw = rightWidth();
            int sliderW = Math.min(rw - gap() * 4, veryCompactMode() ? 60 : 80);
            int sliderX = rx + (rw - sliderW) / 2;
            int newVol = clamp((int) ((mouseX - sliderX) * 200.0 / sliderW), 0, 200);
            currentVolume = newVol;
            ClientHandler.setPlaylistVolume(selected.getId(), newVol);
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        draggingVolume = false;
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int direction = (int) Math.signum(-verticalAmount);
        if (direction == 0) {
            return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
        }

        int listTop = leftListTop();
        int rowHeight = playlistRowHeight();
        int listHeight = Math.max(rowHeight, leftFooterY() - gap() - listTop);
        if (mouseX >= 0 && mouseX < leftWidth() && mouseY >= listTop && mouseY < listTop + listHeight) {
            int visible = Math.max(1, listHeight / rowHeight);
            playlistScroll = clamp(playlistScroll + direction, 0, Math.max(0, PlaylistAdminState.getEntries().size() - visible));
            return true;
        }

        int contentX = centerContentX();
        int contentWidth = centerContentWidth();

        if (searchMode) {
            int startY = nameY() + 24;
            int endY = contentBottom() - gap();
            if (mouseX >= contentX && mouseX < contentX + contentWidth && mouseY >= startY && mouseY < endY) {
                int visibleRows = Math.max(1, (endY - startY) / 20);
                int total = searchResults != null ? searchResults.size() : 0;
                searchScroll = clamp(searchScroll + direction, 0, Math.max(0, total - visibleRows));
                return true;
            }
        }

        ServerPlaylistAdminSyncPacket.Entry selected = selectedEntry();
        if (selected != null) {
            int tableTop = tableTop();
            int tableBottom = contentBottom() - gap();
            if (mouseX >= contentX && mouseX < contentX + contentWidth && mouseY >= tableTop && mouseY < tableBottom) {
                int visible = Math.max(1, (tableBottom - tableTop) / trackRowHeight());
                songScroll = clamp(songScroll + direction, 0, Math.max(0, selected.getTracks().size() - visible));
                return true;
            }

            int rx = rightX();
            int rw = rightWidth();
            int playersTop = rightPlayersTop();
            int playersBottom = rightPlayersBottom();
            if (mouseX >= rx && mouseX < rx + rw && mouseY >= playersTop && mouseY < playersBottom) {
                int playersHeight = Math.max(32, playersBottom - playersTop);
                int visiblePlayers = Math.max(1, (playersHeight - 8) / 14);
                playerScroll = clamp(playerScroll + direction, 0, Math.max(0, selected.getPlayers().size() - visiblePlayers));
                return true;
            }
        }

        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (searchMode && searchField.method_25370() && keyCode == 257) {
            executeSearch();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private void syncSelection() {
        List<ServerPlaylistAdminSyncPacket.Entry> entries = PlaylistAdminState.getEntries();
        if (entries.isEmpty()) {
            selectedPlaylistId = null;
            selectedSong = -1;
            playlistScroll = 0;
            songScroll = 0;
            playerScroll = 0;
            return;
        }
        if (selectedPlaylistId == null || entries.stream().noneMatch(entry -> entry.getId().equals(selectedPlaylistId))) {
            selectedPlaylistId = entries.get(0).getId();
            selectedSong = -1;
            songScroll = 0;
            playerScroll = 0;
            ClientPlaylist active = selectedActivePlaylist();
            if (active != null && !draggingVolume) {
                currentVolume = active.getCustomVolumeFactor();
            }
        }
    }

    private void clampScrolls() {
        int leftVisible = Math.max(1, Math.max(playlistRowHeight(), leftFooterY() - gap() - leftListTop()) / playlistRowHeight());
        playlistScroll = clamp(playlistScroll, 0, Math.max(0, PlaylistAdminState.getEntries().size() - leftVisible));

        ServerPlaylistAdminSyncPacket.Entry selected = selectedEntry();
        if (selected == null) {
            songScroll = 0;
            playerScroll = 0;
            selectedSong = -1;
            return;
        }

        int visibleTracks = Math.max(1, Math.max(trackRowHeight(), contentBottom() - gap() - tableTop()) / trackRowHeight());
        songScroll = clamp(songScroll, 0, Math.max(0, selected.getTracks().size() - visibleTracks));
        if (selectedSong >= selected.getTracks().size()) {
            selectedSong = selected.getTracks().isEmpty() ? -1 : selected.getTracks().size() - 1;
        }

        int playersHeight = Math.max(32, rightPlayersBottom() - rightPlayersTop());
        int visiblePlayers = Math.max(1, (playersHeight - 8) / 14);
        playerScroll = clamp(playerScroll, 0, Math.max(0, selected.getPlayers().size() - visiblePlayers));
    }

    private ServerPlaylistAdminSyncPacket.Entry selectedEntry() {
        return selectedPlaylistId == null ? null : PlaylistAdminState.getEntry(selectedPlaylistId).orElse(null);
    }

    private ClientPlaylist selectedActivePlaylist() {
        ServerPlaylistAdminSyncPacket.Entry selected = selectedEntry();
        if (selected == null) {
            return null;
        }
        for (ClientPlaylist playlist : ClientHandler.getActivePlaylists()) {
            if (playlist.getId().equals(selected.getId())) {
                return playlist;
            }
        }
        return null;
    }

    private boolean compactMode() {
        return field_22789 < 960 || field_22790 < 520;
    }

    private boolean veryCompactMode() {
        return field_22789 < 700 || field_22790 < 360;
    }

    private boolean splitTrackActions() {
        return centerWidth() < 400;
    }

    private int gap() {
        return veryCompactMode() ? 8 : compactMode() ? 10 : 14;
    }

    private int contentBottom() {
        return field_22790 - bottomBarHeight();
    }

    private int bottomBarHeight() {
        return clamp(field_22790 / (veryCompactMode() ? 6 : 5), veryCompactMode() ? 56 : 68, BOTTOM_BAR);
    }

    private int headerHeight() {
        return clamp(field_22790 / (veryCompactMode() ? 7 : 6), veryCompactMode() ? 40 : 54, compactMode() ? 92 : 108);
    }

    private int inputY() {
        return headerHeight() + gap();
    }

    private int nameY() {
        return inputY() + 26;
    }

    private int actionY() {
        return inputY() + 52;
    }

    private int tableTop() {
        return actionY() + (splitTrackActions() ? 52 : 28);
    }

    private int leftWidth() {
        int preferred = compactMode() ? field_22789 / 4 : field_22789 / 5;
        int min = minimumLeftWidth();
        int max = Math.max(min, field_22789 - minimumRightWidth() - minimumCenterWidth());
        int cap = veryCompactMode() ? 168 : compactMode() ? 196 : 250;
        return clamp(preferred, min, Math.min(cap, max));
    }

    private int rightWidth() {
        int preferred = field_22789 / 4;
        int min = minimumRightWidth();
        int max = Math.max(min, field_22789 - leftWidth() - minimumCenterWidth());
        int cap = veryCompactMode() ? 196 : compactMode() ? 240 : 300;
        return clamp(preferred, min, Math.min(cap, max));
    }

    private int centerWidth() {
        return Math.max(minimumCenterWidth(), field_22789 - leftWidth() - rightWidth());
    }

    private int centerContentWidth() {
        int available = Math.max(180, centerWidth() - gap() * 2);
        int cap = veryCompactMode() ? available : compactMode() ? 760 : 980;
        return Math.min(available, cap);
    }

    private int centerContentX() {
        return centerX() + Math.max(gap(), (centerWidth() - centerContentWidth()) / 2);
    }

    private int centerX() {
        return leftWidth();
    }

    private int rightX() {
        return centerX() + centerWidth();
    }

    private int leftListTop() {
        return gap() + (veryCompactMode() ? 34 : 40);
    }

    private int leftFooterY() {
        return contentBottom() - (veryCompactMode() ? 50 : 58);
    }

    private int rightTargetInputY() {
        return contentBottom() - gap() - (veryCompactMode() ? 44 : 62);
    }

    private int rightTargetButtonY() {
        return rightTargetInputY() + 26;
    }

    private int rightInfoTop() {
        return gap() + (veryCompactMode() ? 28 : 36);
    }

    private int rightInfoHeight() {
        int available = rightTargetInputY() - rightInfoTop() - (veryCompactMode() ? gap() + 20 : gap() + 28);
        int natural = veryCompactMode() ? 56 : 70;
        return clamp(Math.min(available / 2, natural), veryCompactMode() ? 36 : 48, natural);
    }

    private int rightPlayersTop() {
        return rightInfoTop() + rightInfoHeight() + (veryCompactMode() ? gap() : gap() + 8);
    }

    private int rightPlayersBottom() {
        int natural = Math.max(rightPlayersTop() + 32, rightTargetInputY() - gap() - 16);
        return Math.min(natural, rightTargetInputY() - gap());
    }

    private int bottomControlsY() {
        return contentBottom() + (veryCompactMode() ? 7 : 10);
    }

    private int progressBarWidth() {
        int available = Math.max(180, centerWidth() - gap() * 2);
        int cap = veryCompactMode() ? available : compactMode() ? 540 : 760;
        return Math.min(available, cap);
    }

    private int headerButtonWidth() {
        return veryCompactMode() ? 56 : compactMode() ? 66 : 78;
    }

    private int addButtonWidth() {
        return veryCompactMode() ? 58 : compactMode() ? 68 : 84;
    }

    private int playlistRowHeight() {
        return veryCompactMode() ? 40 : compactMode() ? 46 : PLAYLIST_ROW;
    }

    private int trackRowHeight() {
        return veryCompactMode() ? 22 : TRACK_ROW;
    }

    private int minimumLeftWidth() {
        return veryCompactMode() ? 96 : compactMode() ? 140 : 190;
    }

    private int minimumRightWidth() {
        return veryCompactMode() ? 112 : compactMode() ? 172 : 220;
    }

    private int minimumCenterWidth() {
        return veryCompactMode() ? 184 : compactMode() ? 280 : 320;
    }

    private void renderScrollbar(class_332 context, int x, int y, int w, int h, int total, int visible, int scroll) {
        context.method_25294(x, y, x + w, y + h, PANEL_SOFT);
        if (total <= visible) {
            return;
        }
        int thumbHeight = Math.max(18, h * visible / total);
        int thumbY = y + (h - thumbHeight) * scroll / Math.max(1, total - visible);
        context.method_25294(x, thumbY, x + w, thumbY + thumbHeight, GREEN_DARK);
    }

    private boolean isValidPlaylistId(String id) {
        return !id.isEmpty() && !id.contains(" ");
    }

    private boolean isLocallyPlaying(ClientPlaylist playlist) {
        return playlist != null && playlist.getMusicPlayer().isPlaying();
    }

    private boolean isServerPlaybackRunning(ServerPlaylistAdminSyncPacket.Entry entry, ClientPlaylist active) {
        if (isLocallyPlaying(active)) {
            return true;
        }
        boolean hasTargets = entry.isBroadcastEveryone() || !entry.getPlayers().isEmpty();
        return hasTargets && !entry.isPaused() && !entry.getTracks().isEmpty();
    }

    private String playbackStatusLabel(ServerPlaylistAdminSyncPacket.Entry entry, ClientPlaylist active) {
        if (isServerPlaybackRunning(entry, active)) {
            return "Activa";
        }
        if (entry.isPaused()) {
            return "Pausada";
        }
        if (entry.getTracks().isEmpty()) {
            return "Sin pistas";
        }
        if (!entry.isBroadcastEveryone() && entry.getPlayers().isEmpty()) {
            return "Sin iniciar";
        }
        return "Lista";
    }

    private int accentColor(String seed) {
        int hash = seed.hashCode();
        int r = 55 + Math.abs((hash >> 16) & 0x7F);
        int g = 80 + Math.abs((hash >> 8) & 0x7F);
        int b = 90 + Math.abs(hash & 0x7F);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private String songName(String url) {
        if (url == null || url.isEmpty()) {
            return "Cancion desconocida";
        }
        int slash = Math.max(url.lastIndexOf('/'), url.lastIndexOf('\\'));
        String name = slash >= 0 ? url.substring(slash + 1) : url;
        int query = name.indexOf('?');
        if (query >= 0) {
            name = name.substring(0, query);
        }
        return name.isEmpty() ? url : name;
    }

    private String sourceLabel(String url) {
        if (url == null || url.isEmpty()) {
            return "-";
        }
        String compact = url.replace("https://", "").replace("http://", "");
        int slash = compact.indexOf('/');
        return slash >= 0 ? compact.substring(0, slash) : compact;
    }

    private String trim(String text, int maxWidth) {
        if (field_22793.method_1727(text) <= maxWidth) {
            return text;
        }
        String value = text;
        while (!value.isEmpty() && field_22793.method_1727(value + "...") > maxWidth) {
            value = value.substring(0, value.length() - 1);
        }
        return value + "...";
    }

    private String formatTime(long millis) {
        long totalSeconds = Math.max(0L, millis / 1000L);
        return (totalSeconds / 60L) + ":" + String.format("%02d", totalSeconds % 60L);
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
