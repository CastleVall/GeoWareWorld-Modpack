package me.elb.mediaplayermod.client.gui.screen;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.api.InspectImageSource;
import me.elb.mediaplayermod.client.ClientHandler;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;
import org.watermedia.api.image.ImageAPI;
import org.watermedia.api.image.ImageRenderer;
import org.watermedia.api.image.decoders.GifDecoder;

import java.awt.image.BufferedImage;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * Inspeccionador de imagenes estilo Resident Evil ({@code /playinteractiveimage}): muestra una
 * imagen sobre fondo oscuro y permite examinarla libremente.
 *
 * <ul>
 *   <li>Rueda del raton: zoom (anclado al cursor).</li>
 *   <li>Arrastrar con clic izquierdo: mover.</li>
 *   <li>Clic derecho o {@code F}: girar para ver el reverso (animado). Si no se dio imagen de
 *       reverso se muestra el dorso generico (la imagen espejada y oscurecida).</li>
 *   <li>{@code Q} / {@code E}: rotar.</li>
 *   <li>{@code R}: restablecer la vista.</li>
 *   <li>{@code ESC}: cerrar.</li>
 * </ul>
 *
 * <p>Carga con el mismo pipeline de imagenes del mod que {@code /playimage} (soporta GIF animado)
 * pero en segundo plano, mostrando "Cargando..." mientras decodifica. El {@code uuid} es el del
 * media en reproduccion (para avisar al servidor al cerrar); es {@code null} si la pantalla se
 * abrio desde la API de otro mod.</p>
 */
public class ImageInspectScreen extends MediaScreen {
    private static final float MIN_ZOOM = 0.25f;
    private static final float MAX_ZOOM = 12f;
    private static final float ZOOM_STEP = 1.15f;
    private static final float FLIP_SPEED = 540f;   // grados por segundo del giro al reverso
    private static final float ROTATE_SPEED = 150f; // grados por segundo con Q/E
    private static final float FIT_WIDTH = 0.8f;    // fraccion de pantalla que ocupa a zoom 1
    private static final float FIT_HEIGHT = 0.75f;

    private final InspectImageSource frontSource;
    @Nullable
    private final class_2561 customTitle;
    /** Filtrado al escalar: true = bilineal (suavizado); false = vecino mas cercano (pixel art). */
    private final boolean bilinear;

    private final CompletableFuture<Object> frontFuture;
    @Nullable
    private final CompletableFuture<Object> backFuture;

    private ImageRenderer frontRenderer;
    private ImageRenderer backRenderer;
    private boolean frontFailed;
    private boolean backFailed;
    private boolean released;

    private long lastFrameTime;

    private float zoom = 1f;
    private float panX;
    private float panY;
    private float rotation;
    /** 0 = frente, 180 = reverso; se anima hacia el objetivo marcado por {@link #showBack}. */
    private float flipAngle;
    private boolean showBack;

    public ImageInspectScreen(InspectImageSource front, @Nullable InspectImageSource back, @Nullable class_2561 title) {
        this(front, back, title, null);
    }

    public ImageInspectScreen(InspectImageSource front, @Nullable InspectImageSource back,
                              @Nullable class_2561 title, @Nullable UUID uuid) {
        this(front, back, title, uuid, true);
    }

    public ImageInspectScreen(InspectImageSource front, @Nullable InspectImageSource back,
                              @Nullable class_2561 title, @Nullable UUID uuid, boolean bilinear) {
        super(uuid, class_2561.method_43470(front.describe()));
        this.frontSource = front;
        this.customTitle = title;
        this.bilinear = bilinear;
        this.lastFrameTime = start;
        this.frontFuture = CompletableFuture.supplyAsync(() -> decodeSource(front), class_156.method_18349());
        this.backFuture = back == null
                ? null
                : CompletableFuture.supplyAsync(() -> decodeSource(back), class_156.method_18349());
    }

    private static Object decodeSource(InspectImageSource source) {
        try {
            return source.decode();
        } catch (Exception e) {
            throw new IllegalStateException("Error loading image to inspect: " + source.describe(), e);
        }
    }

    @Override
    public boolean method_25421() {
        // Como el resto de pantallas del mod: no pausar el juego en singleplayer.
        return false;
    }

    @Override
    public void method_25394(class_332 drawContext, int mouseX, int mouseY, float delta) {
        // Tras removed() la pantalla puede seguir dibujandose 1-2 frames; las texturas ya estan
        // liberadas y OpenGL recicla los ids, asi que no volver a tocarlas.
        if (released) return;
        long now = System.currentTimeMillis();
        float frameSeconds = Math.min((now - lastFrameTime) / 1000f, 0.1f);
        lastFrameTime = now;

        float openAlpha = Math.min(1f, (now - start) / 200f);
        drawContext.method_25296(0, 0, field_22789, field_22790,
                (int) (openAlpha * 0xC8) << 24, (int) (openAlpha * 0xF0) << 24);

        createPendingRenderers();

        if (frontFailed) {
            drawContext.method_27534(field_22793,
                    class_2561.method_43471("inspect_image.error"), field_22789 / 2, field_22790 / 2 - 4, 0xFF6060);
            drawHint(drawContext, openAlpha);
            return;
        }
        if (frontRenderer == null) {
            drawContext.method_27534(field_22793,
                    class_2561.method_43471("inspect_image.loading"), field_22789 / 2, field_22790 / 2 - 4, 0xA0A0A0);
            return;
        }

        tickHeldKeys(frameSeconds);
        tickFlip(frameSeconds);

        boolean backFace = flipAngle > 90f;
        ImageRenderer renderer = backFace && backRenderer != null ? backRenderer : frontRenderer;
        int tick = (int) ((now - start) / 50);
        int texture = renderer.texture(tick, 0, true);

        // Encaje base sobre las dimensiones del frente para que el "objeto" no cambie de tamano
        // al girarlo aunque el reverso tenga otra resolucion.
        float scaleToFit = Math.min(field_22789 * FIT_WIDTH / frontRenderer.width,
                field_22790 * FIT_HEIGHT / frontRenderer.height);
        float halfW = frontRenderer.width * scaleToFit / 2f;
        float halfH = frontRenderer.height * scaleToFit / 2f;

        // El giro al reverso se simula comprimiendo el eje X con el coseno del angulo. Se usa el
        // valor absoluto + espejado de UV (en vez de escala negativa) para no invertir el winding.
        float flipScale = Math.max(Math.abs((float) Math.cos(Math.toRadians(flipAngle))), 0.02f);
        float u0 = backFace ? 1 : 0;
        float u1 = backFace ? 0 : 1;
        // Dorso generico (sin imagen de reverso): la imagen espejada y oscurecida.
        float shade = backFace && backRenderer == null ? 0.4f : 1f;

        class_4587 matrices = drawContext.method_51448();
        matrices.method_22903();
        matrices.method_46416(field_22789 / 2f + panX, field_22790 / 2f + panY, 0);
        matrices.method_22907(class_7833.field_40718.rotationDegrees(rotation));
        matrices.method_22905(zoom * flipScale, zoom, 1);

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
        RenderSystem.setShaderColor(shade, shade, shade, openAlpha);
        RenderSystem.bindTexture(texture);
        RenderSystem.setShaderTexture(0, texture);
        RenderSystem.setShader(class_757::method_34542);
        int filter = bilinear ? GL11.GL_LINEAR : GL11.GL_NEAREST;
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, filter);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, filter);

        Matrix4f matrix4f = matrices.method_23760().method_23761();
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1585);
        bufferBuilder.method_22918(matrix4f, -halfW, -halfH, 0).method_22913(u0, 0);
        bufferBuilder.method_22918(matrix4f, -halfW, halfH, 0).method_22913(u0, 1);
        bufferBuilder.method_22918(matrix4f, halfW, halfH, 0).method_22913(u1, 1);
        bufferBuilder.method_22918(matrix4f, halfW, -halfH, 0).method_22913(u1, 0);
        class_286.method_43433(bufferBuilder.method_60800());

        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.disableBlend();
        matrices.method_22909();

        class_2561 titleText = customTitle != null ? customTitle : method_25440();
        drawContext.method_27534(field_22793, titleText, field_22789 / 2, 10, 0xE0E0E0);
        if (zoom != 1f) {
            drawContext.method_27535(field_22793,
                    class_2561.method_43470(String.format("%.0f%%", zoom * 100)), field_22789 - 40, 10, 0xA0A0A0);
        }
        drawHint(drawContext, openAlpha);
    }

    private void drawHint(class_332 drawContext, float alpha) {
        int color = ((int) (alpha * 0xFF) << 24) | 0x909090;
        drawContext.method_27534(field_22793,
                class_2561.method_43471("inspect_image.hint"), field_22789 / 2, field_22790 - 16, color);
    }

    /** Crea los ImageRenderer en el hilo de render cuando las decodificaciones terminan. */
    private void createPendingRenderers() {
        if (frontRenderer == null && !frontFailed && frontFuture.isDone()) {
            try {
                frontRenderer = createRenderer(frontFuture.join());
            } catch (Exception e) {
                frontFailed = true;
                MediaPlayerMod.LOGGER.error("Error loading image to inspect: {}", frontSource.describe(), e);
            }
        }
        if (backFuture != null && backRenderer == null && !backFailed && backFuture.isDone()) {
            try {
                backRenderer = createRenderer(backFuture.join());
            } catch (Exception e) {
                // El reverso es opcional: si falla se usa el dorso generico y se sigue.
                backFailed = true;
                MediaPlayerMod.LOGGER.warn("Error loading back image to inspect", e);
            }
        }
    }

    private static ImageRenderer createRenderer(Object decoded) {
        return decoded instanceof GifDecoder gifDecoder
                ? ImageAPI.renderer(gifDecoder)
                : ImageAPI.renderer((BufferedImage) decoded);
    }

    private void tickHeldKeys(float frameSeconds) {
        long handle = class_310.method_1551().method_22683().method_4490();
        if (class_3675.method_15987(handle, GLFW.GLFW_KEY_Q)) {
            rotation -= ROTATE_SPEED * frameSeconds;
        }
        if (class_3675.method_15987(handle, GLFW.GLFW_KEY_E)) {
            rotation += ROTATE_SPEED * frameSeconds;
        }
    }

    private void tickFlip(float frameSeconds) {
        float target = showBack ? 180f : 0f;
        if (flipAngle < target) {
            flipAngle = Math.min(target, flipAngle + FLIP_SPEED * frameSeconds);
        } else if (flipAngle > target) {
            flipAngle = Math.max(target, flipAngle - FLIP_SPEED * frameSeconds);
        }
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (frontRenderer == null || verticalAmount == 0) {
            return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
        }
        float newZoom = class_3532.method_15363(zoom * (verticalAmount > 0 ? ZOOM_STEP : 1f / ZOOM_STEP), MIN_ZOOM, MAX_ZOOM);
        // Zoom anclado al cursor: el punto de la imagen bajo el raton se queda quieto.
        float factor = newZoom / zoom;
        float cursorX = (float) (mouseX - field_22789 / 2f);
        float cursorY = (float) (mouseY - field_22790 / 2f);
        panX = cursorX - (cursorX - panX) * factor;
        panY = cursorY - (cursorY - panY) * factor;
        zoom = newZoom;
        return true;
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && frontRenderer != null) {
            panX += (float) deltaX;
            panY += (float) deltaY;
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT && frontRenderer != null) {
            showBack = !showBack;
            return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_F && frontRenderer != null) {
            showBack = !showBack;
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_R) {
            zoom = 1f;
            panX = 0;
            panY = 0;
            rotation = 0;
            showBack = false;
            return true;
        }
        // ESC lo gestiona Screen (shouldCloseOnEsc por defecto): cierra la pantalla.
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public void method_25432() {
        if (!released) {
            released = true;
            if (uuid != null) {
                // Abierta via /playinteractiveimage: avisar al servidor de que este media termino.
                try {
                    ClientHandler.notifyFinishedMediaToServer(uuid);
                } catch (Exception ignored) {
                    // Sin conexion (desconexion en curso): no hay a quien avisar.
                }
            }
            ImageRenderer front = frontRenderer;
            ImageRenderer back = backRenderer;
            frontRenderer = null;
            backRenderer = null;
            class_310 client = class_310.method_1551();
            // Liberar las texturas solo cuando la pantalla ya no puede volver a dibujar (mismo
            // patron que VideoScreen: liberar antes deja frames pintando un id reciclado).
            client.execute(() -> RenderSystem.recordRenderCall(() -> {
                if (front != null) front.release();
                if (back != null) back.release();
            }));
        }
        super.method_25432();
    }
}
