package me.elb.mediaplayermod.client.gui.screen;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import me.elb.mediaplayermod.client.ClientHandler;
import me.elb.mediaplayermod.client.VLCUtil;
import me.elb.mediaplayermod.MediaPlayerMod;

import me.elb.mediaplayermod.client.MediaPlayerModClient;
import me.elb.mediaplayermod.client.sound.MediaSoundCategory;
import me.elb.mediaplayermod.client.sound.VolumeUtil;
import me.elb.mediaplayermod.model.media.Video;
import net.minecraft.class_2561;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_757;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.watermedia.api.math.MathAPI;
import org.watermedia.api.player.videolan.VideoPlayer;

import java.awt.*;
import java.net.URI;
import java.util.UUID;

public class VideoScreen extends MediaScreen {
    private final VideoPlayer videoPlayer;
    private final Video video;
    private Long end;
    private boolean fadingPhase;
    private boolean released;
    /** El video ya empezo a decodificar al menos un frame (evita cerrar antes de arrancar). */
    private boolean started;

    @Override
    public boolean method_25421() {
        // No pausar el juego en singleplayer (en multijugador tampoco se pausa): asi las
        // entidades no se congelan y el video se reproduce con normalidad.
        return false;
    }

    public VideoScreen(UUID uuid, Video video, URI url) {
        super(uuid, class_2561.method_30163(""));
        this.video = video;
        class_310 client = class_310.method_1551();
        this.videoPlayer = VLCUtil.createVideoPlayer(client);
        if (client == null || videoPlayer.isBroken())
            return;
        client.method_1483().method_4881();
        if (video.fadeMode() == null || video.fadeMode() == Video.FadeMode.NONE) {
            videoPlayer.start(url, VLCUtil.CLOCK_OPTIONS);
        } else {
            videoPlayer.startPaused(url, VLCUtil.CLOCK_OPTIONS);
        }
        videoPlayer.setVolume(VolumeUtil.getPlayerVolume(client, MediaSoundCategory.VIDEO));
    }

    public void setVolume(int volume) {
        if (videoPlayer != null && !videoPlayer.isBroken()) {
            videoPlayer.setVolume(volume);
        }
    }

    @Override
    protected void method_25426() {
        assert class_310.method_1551().field_1755 != null;
        this.field_22789 = class_310.method_1551().field_1755.field_22789;
        this.field_22790 = class_310.method_1551().field_1755.field_22790;
        super.method_25426();
    }

    @Override
    public void method_25394(class_332 drawContext, int mouseX, int mouseY, float delta) {
        if (videoPlayer == null) return;
        // Tras close() la pantalla puede seguir siendo la actual 1-2 frames: no volver a tocar el
        // reproductor ni su textura (OpenGL recicla el id liberado y podria pintarse otra textura,
        // tipicamente la skin de un jugador, en lugar del video).
        if (released) return;
        if (!started && !videoPlayer.isBroken() && videoPlayer.dimension() != null) {
            started = true;
        }
        Video.FadeMode fadeMode = video.fadeMode();
        long fadeOut = video.fadeOut();
        // Solo se considera "terminado" si ya habia arrancado; asi no se cierra durante la carga.
        boolean ended = videoPlayer.isEnded() || (started && videoPlayer.isStopped());
        if (((fadeMode == Video.FadeMode.NONE || fadeOut <= 0) && ended)
                || videoPlayer.isBroken()) {
            method_25419();
            return;
        }
        RenderSystem.enableBlend();
        float alpha = 1;
        if (fadeMode != Video.FadeMode.NONE) {
            long now = System.currentTimeMillis();
            long startDiff = now - start;
            long fadeIn = video.fadeIn();
            if (fadeIn > 0 && startDiff < fadeIn) {
                alpha = (startDiff / (1F * fadeIn));
                fadeScreen(drawContext, alpha, fadeMode);
                fadingPhase = true;
            } else if (fadeOut > 0 && (videoPlayer.isEnded() || videoPlayer.isStopped())) {
                if (end == null) {
                    end = now;
                }
                long endDiff = now - end;
                if (endDiff > fadeOut) {
                    method_25419();
                    return;
                }
                alpha = 1 - (endDiff / (1F * fadeOut));
                fadeScreen(drawContext, alpha, fadeMode);
                fadingPhase = true;
            } else if (fadingPhase) {
                if (videoPlayer.dimension() != null) {
                    fadingPhase = false;
                    videoPlayer.play();
                } else {
                    fadeScreen(drawContext, 1f, fadeMode);
                }
            }
        }
        if (!fadingPhase || fadeMode == Video.FadeMode.TRANSPARENT) {
            if (videoPlayer.dimension() == null) return;
            int texture = videoPlayer.texture();
            if (texture <= 0 || !GL11.glIsTexture(texture)) return;
            int regionX = Math.round(video.regionX() * field_22789);
            int regionY = Math.round(video.regionY() * field_22790);
            int regionW = Math.max(1, Math.round(video.regionW() * field_22789));
            int regionH = Math.max(1, Math.round(video.regionH() * field_22790));

            if (video.background()) {
                drawContext.method_25294(regionX, regionY, regionX + regionW, regionY + regionH, MathAPI.argb(255, 0, 0, 0));
            }
            RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, alpha);
            RenderSystem.setShaderTexture(0, texture);

            Dimension videoDimensions = videoPlayer.dimension();
            double videoWidth = videoDimensions.getWidth();
            double videoHeight = videoDimensions.getHeight();

            float regionAspectRatio = (float) regionW / regionH;
            float videoAspectRatio = (float) ((float) videoWidth / videoHeight);

            int renderWidth;
            int renderHeight;

            if (videoAspectRatio > regionAspectRatio) {
                renderWidth = regionW;
                renderHeight = (int) (regionW / videoAspectRatio);
            } else {
                renderWidth = (int) (regionH * videoAspectRatio);
                renderHeight = regionH;
            }

            int xOffset = regionX + (regionW - renderWidth) / 2;
            int yOffset = regionY + (regionH - renderHeight) / 2;

            RenderSystem.setShader(class_757::method_34542);
            RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
            RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);

            Matrix4f matrix4f = drawContext.method_51448().method_23760().method_23761();
            class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1585);
            bufferBuilder.method_22918(matrix4f, xOffset, yOffset, 0).method_22913(0, 0);
            bufferBuilder.method_22918(matrix4f, xOffset, (yOffset + renderHeight), 0).method_22913(0, 1);
            bufferBuilder.method_22918(matrix4f, (xOffset + renderWidth), (yOffset + renderHeight), 0).method_22913(1, 1);
            bufferBuilder.method_22918(matrix4f, (xOffset + renderWidth), yOffset, 0).method_22913(1, 0);
            class_286.method_43433(bufferBuilder.method_60800());
        }
        RenderSystem.disableBlend();
    }

    private void fadeScreen(class_332 drawContext, float alpha, Video.FadeMode mode) {
        int rx = Math.round(video.regionX() * field_22789);
        int ry = Math.round(video.regionY() * field_22790);
        int rw = Math.max(1, Math.round(video.regionW() * field_22789));
        int rh = Math.max(1, Math.round(video.regionH() * field_22790));
        if (mode == Video.FadeMode.BLACK) {
            int color = (int) (alpha * 255);
            drawContext.method_25294(rx, ry, rx + rw, ry + rh, color << 24);
        } else if (mode == Video.FadeMode.WHITE) {
            int color = (int) (alpha * 255);
            drawContext.method_25294(rx, ry, rx + rw, ry + rh, color << 24 | 0xFFFFFF);
        }
    }

    @Override
    public boolean method_25404(int pKeyCode, int pScanCode, int pModifiers) {
        if (method_25442() && pKeyCode == 256) {
            MediaPlayerMod.LOGGER.info("Stopping video");
            method_25419();
        }
        if (method_25442() && pKeyCode == 262) {
            videoPlayer.seekTo(videoPlayer.getTime() + 10000);
            MediaPlayerMod.LOGGER.info("Skipped 10 seconds");
        }
        if (method_25442() && pKeyCode == 263) {
            videoPlayer.seekTo(videoPlayer.getTime() - 10000);
            MediaPlayerMod.LOGGER.info("Skipped 10 seconds backwards");
        }
        class_310 client = class_310.method_1551();
        if (MediaPlayerModClient.volumeUpKeyBinding.method_1417(pKeyCode, pScanCode)) {
            float currentVideoVolume = client.field_1690.method_1630(MediaSoundCategory.VIDEO);
            float newVideoVolume = Math.min(currentVideoVolume + 0.05f, 1);
            VolumeUtil.updateVolume(client, MediaSoundCategory.VIDEO, newVideoVolume);

            int newPlayerVolume = VolumeUtil.getPlayerVolume(client, MediaSoundCategory.VIDEO);
            videoPlayer.setVolume(newPlayerVolume);
            MediaPlayerMod.LOGGER.info("Volume up to {}", newPlayerVolume);
        }
        if (MediaPlayerModClient.volumeDownKeyBinding.method_1417(pKeyCode, pScanCode)) {
            float currentVideoVolume = client.field_1690.method_1630(MediaSoundCategory.VIDEO);
            float newVideoVolume = Math.max(currentVideoVolume - 0.05f, 0);
            VolumeUtil.updateVolume(client, MediaSoundCategory.VIDEO, newVideoVolume);

            int newPlayerVolume = VolumeUtil.getPlayerVolume(client, MediaSoundCategory.VIDEO);
            videoPlayer.setVolume(newPlayerVolume);
            MediaPlayerMod.LOGGER.info("Volume down to {}", newPlayerVolume);
        }
        if (method_25442() && pKeyCode == 32) {
            if (!videoPlayer.isPaused()) {
                videoPlayer.pause();
                MediaPlayerMod.LOGGER.info("Media paused");
            } else {
                videoPlayer.play();
                MediaPlayerMod.LOGGER.info("Media resumed");
            }
        }
        return super.method_25404(pKeyCode, pScanCode, pModifiers);
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        return false;
    }

    @Override
    public boolean method_25422() {
        return false;
    }

    @Override
    public void method_25419() {
        if (released) {
            MediaPlayerMod.LOGGER.debug("Video screen already closed");
            return;
        }
        MediaPlayerMod.LOGGER.info("Closing video screen");
        released = true;
        videoPlayer.stop();
        class_310 client = class_310.method_1551();
        client.method_1483().method_4880();
        // Soltar la referencia y avisar al servidor YA: si otro media abre una pantalla nueva
        // antes de que corra el bloque diferido, no hay que pisarle su estado.
        if (ClientHandler.getCurrentVideoScreen() == this) {
            ClientHandler.setCurrentVideoScreen(null);
        }
        ClientHandler.notifyFinishedMediaToServer(uuid);
        client.execute(() -> RenderSystem.recordRenderCall(() -> {
            // Liberar el reproductor (y con el su textura OpenGL) solo cuando la pantalla ya no
            // puede volver a dibujar: liberar antes deja 1-2 frames dibujando un id de textura
            // reciclado, que con muchos jugadores acaba siendo la skin de alguien.
            videoPlayer.release();
            // No cerrar a ciegas: si otro media ya puso su propia pantalla, no tirarla. Este era
            // el origen de los reproductores huerfanos al reenviar /playvideo dos veces seguidas.
            if (client.field_1755 == VideoScreen.this) {
                client.method_1507(null);
            }
        }));
    }

    @Override
    public void method_25432() {
        // setScreen() reemplazo esta pantalla sin pasar por close() (otro media, un menu del mod,
        // la pantalla de muerte...). Sin esto el reproductor quedaba huerfano: seguia sonando a
        // tope y ningun slider de volumen ni /stopmedia podia controlarlo.
        method_25419();
        super.method_25432();
    }
}
