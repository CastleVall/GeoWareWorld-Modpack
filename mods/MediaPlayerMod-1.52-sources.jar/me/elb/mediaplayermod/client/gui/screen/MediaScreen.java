package me.elb.mediaplayermod.client.gui.screen;

import lombok.Getter;
import net.minecraft.class_2561;
import net.minecraft.class_437;
import java.util.UUID;

@Getter
public abstract class MediaScreen extends class_437 {
    protected final UUID uuid;
    protected final long start = System.currentTimeMillis();

    protected MediaScreen(UUID uuid, class_2561 title) {
        super(title);
        this.uuid = uuid;
    }
}
