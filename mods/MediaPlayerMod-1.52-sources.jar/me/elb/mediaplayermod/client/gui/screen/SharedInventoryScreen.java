package me.elb.mediaplayermod.client.gui.screen;

import me.elb.mediaplayermod.screenhandler.SharedInventoryScreenHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_490;
import net.minecraft.class_742;

/**
 * Pantalla del inventario compartido: arriba el inventario del jugador objetivo (armadura, mano
 * secundaria, vista previa, inventario y hotbar) y abajo el del admin, con arrastre entre ambos.
 */
public class SharedInventoryScreen extends class_465<SharedInventoryScreenHandler> {
    private static final int PANEL = 0xFFC6C6C6;
    private static final int PANEL_DARK = 0xFF8B8B8B;
    private static final int SLOT_BG = 0xFF373737;
    private static final int LABEL = 0xFF404040;

    public SharedInventoryScreen(SharedInventoryScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
        this.field_2792 = 256;
        this.field_2779 = 200;
        this.field_25270 = -2000; // ocultamos el titulo por defecto, usamos los nuestros
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        int x = this.field_2776;
        int y = this.field_2800;

        // Panel principal.
        context.method_25294(x, y, x + this.field_2792, y + this.field_2779, PANEL);

        // Fondo de cada slot.
        for (class_1735 slot : this.field_2797.field_7761) {
            int sx = x + slot.field_7873;
            int sy = y + slot.field_7872;
            context.method_25294(sx - 1, sy - 1, sx + 17, sy + 17, PANEL_DARK);
            context.method_25294(sx, sy, sx + 16, sy + 16, SLOT_BG);
        }

        // Vista previa del personaje objetivo.
        drawTargetPreview(context, x, y, mouseX, mouseY);
    }

    private void drawTargetPreview(class_332 context, int x, int y, int mouseX, int mouseY) {
        if (this.field_22787 == null || this.field_22787.field_1687 == null) {
            return;
        }
        class_1297 entity = this.field_22787.field_1687.method_8469(this.field_2797.getTargetEntityId());
        int x1 = x + 28;
        int y1 = y + 16;
        int x2 = x + 76;
        int y2 = y + 96;
        if (entity instanceof class_742 living) {
            class_490.method_2486(context, x1, y1, x2, y2, 30, 0.0625f, mouseX, mouseY, living);
        } else if (entity instanceof class_1309 living) {
            class_490.method_2486(context, x1, y1, x2, y2, 30, 0.0625f, mouseX, mouseY, living);
        } else {
            context.method_51439(this.field_22793, class_2561.method_43470("Fuera de"), x1, y1 + 30, 0xFFFFFFFF, true);
            context.method_51439(this.field_22793, class_2561.method_43470("rango"), x1, y1 + 42, 0xFFFFFFFF, true);
        }
    }

    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        context.method_51439(this.field_22793, this.field_22785, 80, 7, LABEL, false);
        context.method_51439(this.field_22793, class_2561.method_43470("Tu inventario"), 80, 100, LABEL, false);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        this.method_2380(context, mouseX, mouseY);
    }
}
