package me.elb.mediaplayermod.client.gui.screen;

import me.elb.mediaplayermod.client.ClientHandler;
import me.elb.mediaplayermod.model.media.Fade;
import me.elb.mediaplayermod.utils.GLUtil;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import java.util.UUID;

public class FadeScreen extends MediaScreen {
    private final Fade fade;

    public FadeScreen(UUID uuid, Fade fade) {
        super(uuid, class_2561.method_30163(""));
        this.fade = fade;
    }

    @Override
    protected void method_25426() {
        assert class_310.method_1551().field_1755 != null;
        this.field_22789 = class_310.method_1551().field_1755.field_22789;
        this.field_22790 = class_310.method_1551().field_1755.field_22790;
        super.method_25426();
    }

    @Override
    public void method_25394(class_332 drawContext, int mouseX, int mouseY, float delta) {
        long now = System.currentTimeMillis();
        long fadeIn = fade.fadeIn();
        long duration = fade.duration();
        long fadeOut = fade.fadeOut();
        if (now - start >= fadeIn + duration + fadeOut) {
            method_25419();
            return;
        }
        float alpha = GLUtil.calculateAlpha(start, fadeIn, duration, fadeOut);
        me.elb.mediaplayermod.client.gui.display.FadeDisplay.renderFade(drawContext, fade, alpha, field_22789, field_22790);
    }

    @Override
    public boolean method_25404(int pKeyCode, int pScanCode, int pModifiers) {
        if (method_25442() && pKeyCode == 256) {
            method_25419();
        }
        return super.method_25404(pKeyCode, pScanCode, pModifiers);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public boolean method_25422() {
        return false;
    }

    @Override
    public void method_25419() {
        super.method_25419();
        ClientHandler.setCurrentFadeScreen(null);
        ClientHandler.notifyFinishedMediaToServer(uuid);
    }
}
