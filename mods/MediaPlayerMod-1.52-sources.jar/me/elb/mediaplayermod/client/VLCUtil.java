package me.elb.mediaplayermod.client;

import me.elb.mediaplayermod.MediaPlayerMod;
import org.watermedia.api.player.PlayerAPI;
import org.watermedia.api.player.videolan.MusicPlayer;
import org.watermedia.api.player.videolan.VideoPlayer;
import org.watermedia.videolan4j.factory.MediaPlayerFactory;

import java.util.concurrent.Executor;

public final class VLCUtil {
    private VLCUtil() {}

    private static volatile MediaPlayerFactory softwareFactory;
    private static volatile boolean factoryFailed = false;

    public static final String[] CLOCK_OPTIONS = {
        ":clock-master=none",
        ":clock-synchro=0",
        ":clock-jitter=0"
    };

    public static MediaPlayerFactory getSoftwareFactory() {
        if (!System.getProperty("os.name", "").toLowerCase().contains("windows")) return null;
        if (factoryFailed) return null;
        MediaPlayerFactory f = softwareFactory;
        if (f == null) {
            synchronized (VLCUtil.class) {
                f = softwareFactory;
                if (f == null && !factoryFailed) {
                    try {
                        // Args alineados con la factory por defecto de WaterMedia (que SI carga). Antes
                        // esta factory fallaba en TODOS los clientes ("Failed to get a new native library
                        // instance"): 'libvlc_new' rechazaba '--ytdl-format' (opcion inexistente en este
                        // VLC; WaterMedia resuelve YouTube por su cuenta) y '--codec avcodec'. Al fallar,
                        // el mod caia a la factory por defecto y no se aplicaba nada de este tuning.
                        // '--avcodec-hw' pasa a decodificacion por HARDWARE (GPU): mucho menos CPU en PCs
                        // debiles con 100 jugadores viendo YouTube; antes forzaba software ('none').
                        softwareFactory = f = PlayerAPI.registerFactory("mediaplayermod:sw_video", new String[]{
                            "--no-quiet",
                            "--cr-average=5000",
                            "--swscale-mode=0",
                            "--network-caching=3000",
                            "--live-caching=3000",
                            "--file-caching=1000",
                            "--aout", "directsound,waveout,mmdevice",
                            "--vout", "direct3d11,glwin32,gl,any",
                            "--avcodec-hw", "d3d11va,dxva2,any",
                            "--avcodec-skip-idct=4",
                            "--avcodec-fast",
                            "--no-metadata-network-access",
                            "--no-file-logging",
                            "--http-reconnect"
                        });
                    } catch (Exception e) {
                        MediaPlayerMod.LOGGER.warn("Failed to initialize software VLC factory, falling back to default: {}", e.getMessage());
                        factoryFailed = true;
                        return null;
                    }
                }
            }
        }
        return f;
    }

    public static VideoPlayer createVideoPlayer(Executor executor) {
        MediaPlayerFactory factory = getSoftwareFactory();
        return factory != null ? new VideoPlayer(factory, executor) : new VideoPlayer(executor);
    }

    private static volatile MediaPlayerFactory audioFactory;
    private static volatile boolean audioFactoryFailed = false;

    private static MediaPlayerFactory getAudioFactory() {
        if (audioFactoryFailed) return null;
        MediaPlayerFactory f = audioFactory;
        if (f == null) {
            synchronized (VLCUtil.class) {
                f = audioFactory;
                if (f == null && !audioFactoryFailed) {
                    try {
                        audioFactory = f = PlayerAPI.registerFactory("mediaplayermod:audio", new String[]{
                            "--no-quiet",
                            "--no-video",
                            "--file-caching=50",
                            "--network-caching=1500",
                            "--live-caching=1500",
                            "--no-metadata-network-access",
                            "--no-file-logging"
                        });
                    } catch (Exception e) {
                        MediaPlayerMod.LOGGER.warn("Failed to create audio factory, using default: {}", e.getMessage());
                        audioFactoryFailed = true;
                    }
                }
            }
        }
        return f;
    }

    public static MusicPlayer createMusicPlayer() {
        MediaPlayerFactory factory = getAudioFactory();
        return factory != null ? new MusicPlayer(factory) : new MusicPlayer();
    }
}
