package me.elb.mediaplayermod.client.render;

import net.minecraft.class_1044;
import net.minecraft.class_3300;

public class TextureWrapper extends class_1044 {

    public TextureWrapper(int id) {
        this.field_5204 = id;
    }

    /** Reapunta el wrapper al id de textura actual de VLC (el frame cambia de id con el tiempo). */
    public void setGlId(int id) {
        this.field_5204 = id;
    }

    @Override
    public int method_4624() {
        return this.field_5204;
    }

    @Override
    public void method_4625(class_3300 manager) {
    }

    @Override
    public void method_4528() {
    }

    @Override
    public void close() {
    }
}
