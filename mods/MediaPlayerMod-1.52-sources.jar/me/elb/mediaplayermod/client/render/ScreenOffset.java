package me.elb.mediaplayermod.client.render;

public record ScreenOffset(float xOffset, float yOffset, float zOffset, float yRotation) {
}
