package me.elb.mediaplayermod.client.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.client.VLCUtil;
import me.elb.mediaplayermod.client.sound.MediaSoundCategory;
import me.elb.mediaplayermod.client.sound.VolumeUtil;
import me.elb.mediaplayermod.model.media.Projection;
import lombok.Getter;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.watermedia.api.player.videolan.VideoPlayer;

import java.net.URI;

@Getter
public class ProjectionHandler {
    private static final class_2960 BLACK_TEXTURE = class_2960.method_60655(MediaPlayerMod.MOD_ID, "textures/black.png");
    private static final int RENDER_DISTANCE_SQ = 64 * 64;
    /** Sufijo unico por proyeccion para que dos proyecciones nunca compartan el mismo id de textura. */
    private static final java.util.concurrent.atomic.AtomicInteger TEXTURE_SEQ =
            new java.util.concurrent.atomic.AtomicInteger();
    public static volatile float projectionOffset = 0.05f;

    /**
     * Wrapper de textura propio de ESTA proyeccion. Antes habia un mapa estatico compartido entre
     * todas las proyecciones, keyeado por el id de textura de VLC: cuando OpenGL reciclaba un id
     * liberado (casi siempre para la skin de alguien con 100 jugadores) o cuando una proyeccion
     * heredaba el id de otra, se dibujaba una textura ajena. Con un wrapper por instancia, cada
     * proyeccion solo dibuja SU propio frame actual de VLC.
     */
    private TextureWrapper textureWrapper;
    private boolean textureRegistered;

    private final String id;
    private final class_2338 pos1;
    private final VideoPlayer videoPlayer;
    private boolean stopped = false;
    private boolean removed = false;
    private boolean loop = false;
    private boolean paused = false;

    /** Sincronizacion pendiente (ms de tiempo real transcurrido) enviada por el servidor al entrar; -1 = ninguna. */
    private long pendingSyncMs = -1;
    /** La pausa/play debe aplicarse cuando el reproductor este listo (o tras un seek pendiente). */
    private boolean reconcilePlayState = false;

    private final float screenWidth;
    private final float screenHeight;
    private final float[] rightVec;
    private final float[] upVec;
    private final int rotY;
    private final class_2960 textureId;

    private final boolean chromaKey;
    private final int chromaColor;
    private final float chromaTolerance;

    public ProjectionHandler(Projection projection, URI uri) {
        this.id = projection.id();
        this.chromaKey = projection.chromaKey();
        this.chromaColor = projection.chromaColor();
        this.chromaTolerance = projection.chromaTolerance();

        boolean swapY = projection.y1() > projection.y2();
        int anchorX = swapY ? projection.x2() : projection.x1();
        int anchorY = swapY ? projection.y2() : projection.y1();
        int anchorZ = swapY ? projection.z2() : projection.z1();
        int otherX  = swapY ? projection.x1() : projection.x2();
        int otherY  = swapY ? projection.y1() : projection.y2();
        int otherZ  = swapY ? projection.z1() : projection.z2();

        this.pos1 = new class_2338(anchorX, anchorY, anchorZ);

        double dx = otherX - anchorX;
        double dz = otherZ - anchorZ;
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.01) len = 1;

        this.screenWidth = (float) len;
        this.rotY = projection.rotY();

        int dy = Math.abs(otherY - anchorY);
        if (dy > 0) {
            this.screenHeight = dy;
        } else {
            int rot = ((this.rotY % 360) + 360) % 360;
            boolean vertical = uri != null && uri.getPath() != null && uri.getPath().contains("/shorts/");
            boolean portrait = vertical || rot == 90 || rot == 270;
            this.screenHeight = !portrait ? (screenWidth * 9f) / 16f : (screenWidth * 16f) / 9f;
        }

        float[] right = { (float)(dx / len), 0f, (float)(dz / len) };
        float[] upPitched = rotateAround(new float[]{0f, 1f, 0f}, right, (float) Math.toRadians(projection.rotX()));
        float[] normal = cross(right, upPitched);
        normalize3(normal);
        float rollRad = (float) Math.toRadians(projection.rotZ());
        this.rightVec = rotateAround(right, normal, rollRad);
        this.upVec    = rotateAround(upPitched, normal, rollRad);

        this.textureId = class_2960.method_60655(MediaPlayerMod.MOD_ID,
                "proj_" + Math.abs(id.hashCode()) + "_" + TEXTURE_SEQ.incrementAndGet());

        class_310 client = class_310.method_1551();
        this.videoPlayer = VLCUtil.createVideoPlayer(client);
        if (uri != null) {
            client.method_1483().method_4881();
            videoPlayer.start(uri);
            videoPlayer.setRepeatMode(false);
        } else {
            // Proyeccion sin video: no arrancar ningun reproductor (evita heredar la textura
            // reciclada del ultimo video). Queda en negro hasta asignar una url con 'play'.
            this.stopped = true;
        }
    }

    public void render(WorldRenderContext ctx) {
        if (removed) return;
        applyPendingSync();
        if (!stopped) {
            if (videoPlayer.isBroken() || !videoPlayer.isSafeUse()) return;
            if (videoPlayer.isEnded() && !loop) return;
        }

        class_243 camPos = ctx.camera().method_19326();
        // El volumen se actualiza SIEMPRE, aunque la proyeccion no se dibuje por distancia: el audio
        // de VLC no depende de la distancia de render. Antes esto estaba DESPUES del corte por
        // distancia, asi que una proyeccion iniciada lejos (o al alejarse >64 bloques) nunca recibia
        // setVolume y sonaba a tope al 100% por defecto, sin que ningun slider la controlara.
        if (!stopped) setVolumeBasedOnDistance(camPos);

        double distSq = pos1.method_19770(camPos);
        if (distSq > RENDER_DISTANCE_SQ) return;

        class_4587 matrices = ctx.matrixStack();
        if (matrices == null) return;

        class_2960 usedTexture;
        if (!stopped) {
            Integer rawTexture = getVlcTexture();
            if (rawTexture != null) {
                // Apuntar SIEMPRE al frame actual de VLC. Registrar el wrapper una sola vez y luego
                // solo actualizar su id: asi esta proyeccion nunca dibuja un id ajeno/reciclado.
                if (!textureRegistered) {
                    textureWrapper = new TextureWrapper(rawTexture);
                    class_310.method_1551().method_1531().method_4616(textureId, textureWrapper);
                    textureRegistered = true;
                } else {
                    textureWrapper.setGlId(rawTexture);
                }
                usedTexture = textureId;
            } else {
                usedTexture = BLACK_TEXTURE;
            }
        } else {
            usedTexture = BLACK_TEXTURE;
        }

        float[] n = cross(rightVec, upVec);
        normalize3(n);
        boolean backFace = n[0] * (float)(camPos.field_1352 - pos1.method_10263())
                         + n[1] * (float)(camPos.field_1351 - pos1.method_10264())
                         + n[2] * (float)(camPos.field_1350 - pos1.method_10260()) < 0;
        float offsetSign = backFace ? -1f : 1f;

        matrices.method_22903();
        matrices.method_22904(
                pos1.method_10263() - camPos.field_1352 + n[0] * offsetSign * projectionOffset,
                pos1.method_10264() - camPos.field_1351 + n[1] * offsetSign * projectionOffset,
                pos1.method_10260() - camPos.field_1350 + n[2] * offsetSign * projectionOffset
        );

        Matrix4f matrix = matrices.method_23760().method_23761();

        RenderSystem.enableDepthTest();
        GL11.glDepthFunc(GL11.GL_LEQUAL);
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA);
        RenderSystem.disableCull();
        boolean useChroma = chromaKey && !stopped && usedTexture != BLACK_TEXTURE
                && me.elb.mediaplayermod.client.shader.ChromaShader.isReady();
        RenderSystem.setShaderTexture(0, usedTexture);
        if (useChroma) {
            me.elb.mediaplayermod.client.shader.ChromaShader.bind(chromaColor, chromaTolerance, 1.0f);
        } else {
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            RenderSystem.setShader(class_757::method_34542);
        }
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);

        float rx = rightVec[0] * screenWidth;
        float ry = rightVec[1] * screenWidth;
        float rz = rightVec[2] * screenWidth;
        float ux = upVec[0] * screenHeight;
        float uy = upVec[1] * screenHeight;
        float uz = upVec[2] * screenHeight;

        int rot = ((rotY % 360) + 360) % 360;
        float[] uvBL, uvBR, uvTR, uvTL;
        if (rot == 90) {
            uvBL = new float[]{1,1}; uvBR = new float[]{1,0}; uvTR = new float[]{0,0}; uvTL = new float[]{0,1};
        } else if (rot == 180) {
            uvBL = new float[]{1,0}; uvBR = new float[]{0,0}; uvTR = new float[]{0,1}; uvTL = new float[]{1,1};
        } else if (rot == 270) {
            uvBL = new float[]{0,0}; uvBR = new float[]{0,1}; uvTR = new float[]{1,1}; uvTL = new float[]{1,0};
        } else {
            uvBL = new float[]{0,1}; uvBR = new float[]{1,1}; uvTR = new float[]{1,0}; uvTL = new float[]{0,0};
        }
        if (backFace) {
            uvBL[0] = 1f - uvBL[0]; uvBR[0] = 1f - uvBR[0];
            uvTR[0] = 1f - uvTR[0]; uvTL[0] = 1f - uvTL[0];
        }
        class_287 bb = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1585);
        bb.method_22918(matrix, 0,      0,      0     ).method_22913(uvBL[0], uvBL[1]);
        bb.method_22918(matrix, rx,     ry,     rz    ).method_22913(uvBR[0], uvBR[1]);
        bb.method_22918(matrix, rx+ux,  ry+uy,  rz+uz ).method_22913(uvTR[0], uvTR[1]);
        bb.method_22918(matrix, ux,     uy,     uz    ).method_22913(uvTL[0], uvTL[1]);
        class_286.method_43433(bb.method_60800());

        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        matrices.method_22909();
    }

    private void setVolumeBasedOnDistance(class_243 camPos) {
        if (videoPlayer.isBroken()) return;
        double distanceSq = pos1.method_19770(camPos);
        class_310 client = class_310.method_1551();
        // Atenuacion por distancia (con margen extra segun el tamano de la pantalla) MULTIPLICADA
        // por el volumen configurado. La formula anterior era aditiva y saturaba: cualquier slider
        // por encima de ~45% daba siempre 100, y con master a 0 el bono de screenWidth seguia
        // dejando la proyeccion audible.
        double attenuation = Math.clamp((100.0 - distanceSq / 30.0 + screenWidth / 2.0) / 100.0, 0.0, 1.0);
        float media = VolumeUtil.getMediaVolume(client, MediaSoundCategory.PROJECTION);
        int vol = (int) Math.clamp(Math.round(media * 100.0 * attenuation), 0, 100);
        videoPlayer.setVolume(vol);
    }

    public void stop() {
        if (stopped || removed) return;
        stopped = true;
        paused = false;
        MediaPlayerMod.LOGGER.info("Stopping projection '{}'", id);
        try { videoPlayer.stop(); } catch (Exception e) {
            MediaPlayerMod.LOGGER.warn("Error stopping projection player '{}'", id, e);
        }
        class_310 client = class_310.method_1551();
        try { client.method_1483().method_4880(); } catch (Exception e) {
            MediaPlayerMod.LOGGER.warn("Error resuming sounds after projection stop", e);
        }
    }

    public void remove() {
        if (removed) return;
        if (!stopped) stop();
        removed = true;
        try {
            if (!videoPlayer.isBroken()) videoPlayer.release();
        } catch (Exception e) {
            MediaPlayerMod.LOGGER.warn("Error releasing projection player '{}'", id, e);
        }
        Runnable cleanup = () -> {
            // Solo se destruye el wrapper de ESTA proyeccion. VLC ya borro su propia textura GL en
            // release(); aqui solo hay que sacar el wrapper del TextureManager (su close() es no-op).
            if (textureRegistered) {
                try { class_310.method_1551().method_1531().method_4615(textureId); } catch (Exception e) {
                    MediaPlayerMod.LOGGER.warn("Error destroying projection texture '{}'", id, e);
                }
                textureRegistered = false;
            }
        };
        // La limpieza debe ocurrir SIEMPRE; si no estamos en el hilo de render se difiere en vez
        // de saltarsela (antes se omitia y quedaban wrappers registrados sobre ids reciclados).
        if (com.mojang.blaze3d.systems.RenderSystem.isOnRenderThread()) {
            cleanup.run();
        } else {
            class_310.method_1551().execute(cleanup);
        }
    }

    public void setPaused(boolean paused) {
        this.paused = paused;
        if (stopped || videoPlayer.isBroken()) return;
        // Si aun no esta listo o hay un seek pendiente, se aplica luego en applyPendingSync().
        if (videoPlayer.dimension() == null || pendingSyncMs >= 0) {
            reconcilePlayState = true;
        } else {
            if (paused) videoPlayer.pause();
            else videoPlayer.play();
        }
    }

    /**
     * Sincroniza al tiempo real transcurrido en el servidor (ms). Si hay loop, el punto exacto
     * dentro del ciclo se calcula aqui con la duracion que conoce el cliente.
     */
    public void seek(long elapsedMs) {
        this.pendingSyncMs = Math.max(0, elapsedMs);
    }

    /** Aplica el seek pendiente y reconcilia pausa/play una vez que el reproductor esta listo. */
    private void applyPendingSync() {
        if (stopped || removed) return;
        if (videoPlayer.isBroken() || !videoPlayer.isSafeUse()) return;
        if (videoPlayer.dimension() == null) return; // aun no decodifica el primer frame

        if (pendingSyncMs >= 0) {
            long duration = videoPlayer.getDuration();
            long target = pendingSyncMs;
            if (duration > 0) {
                if (loop) {
                    target %= duration; // mismo punto del ciclo para todos
                } else if (target >= duration) {
                    // El video ya deberia haber terminado: no reiniciar desde 0, dejarlo terminado.
                    pendingSyncMs = -1;
                    reconcilePlayState = false;
                    stop();
                    return;
                }
            }
            try { videoPlayer.seekTo(target); } catch (Exception e) {
                MediaPlayerMod.LOGGER.warn("Error seeking projection '{}'", id, e);
            }
            pendingSyncMs = -1;
            reconcilePlayState = true; // tras el seek, aplicar el estado de pausa correcto
        }

        if (reconcilePlayState) {
            try {
                if (paused) videoPlayer.pause();
                else videoPlayer.play();
            } catch (Exception ignored) {
            }
            reconcilePlayState = false;
        }

        // Un video recien iniciado a veces ignora el primer pause(); insistir hasta que lo respete.
        if (paused && !videoPlayer.isPaused()) {
            try { videoPlayer.pause(); } catch (Exception ignored) {
            }
        }
    }

    public void setLoop(boolean loop) {
        this.loop = loop;
        if (!videoPlayer.isBroken()) {
            videoPlayer.setRepeatMode(loop);
        }
    }

    public void setUrl(URI uri) {
        stopped = false;
        paused = false;
        pendingSyncMs = -1;
        reconcilePlayState = false;
        if (!videoPlayer.isBroken()) {
            videoPlayer.stop();
        }
        videoPlayer.start(uri);
        videoPlayer.setRepeatMode(false);
    }

    private Integer getVlcTexture() {
        int tex = videoPlayer.texture();
        if (GL11.glIsTexture(tex)) return tex;
        return null;
    }

    private static float[] rotateAround(float[] v, float[] k, float theta) {
        double cos = Math.cos(theta);
        double sin = Math.sin(theta);
        double dot = k[0]*v[0] + k[1]*v[1] + k[2]*v[2];
        return new float[]{
            (float)(v[0]*cos + (k[1]*v[2] - k[2]*v[1])*sin + k[0]*dot*(1-cos)),
            (float)(v[1]*cos + (k[2]*v[0] - k[0]*v[2])*sin + k[1]*dot*(1-cos)),
            (float)(v[2]*cos + (k[0]*v[1] - k[1]*v[0])*sin + k[2]*dot*(1-cos))
        };
    }

    private static float[] cross(float[] a, float[] b) {
        return new float[]{
            a[1]*b[2] - a[2]*b[1],
            a[2]*b[0] - a[0]*b[2],
            a[0]*b[1] - a[1]*b[0]
        };
    }

    private static void normalize3(float[] v) {
        float len = (float) Math.sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
        if (len > 0.001f) { v[0] /= len; v[1] /= len; v[2] /= len; }
    }
}
