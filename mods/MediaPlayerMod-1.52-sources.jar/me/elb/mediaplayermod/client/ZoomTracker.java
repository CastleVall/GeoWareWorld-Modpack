package me.elb.mediaplayermod.client;

public class ZoomTracker {
    private float from = 1;
    private float to = 1;
    private long totalTicks = 0;
    private long ticks = 0;

    public void tick() {
        if (ticks >= totalTicks) {
            return;
        }
        ticks++;
    }

    public float getCurrentFov() {
        if (from == to) {
            return from;
        }
        float percent = Math.clamp((float) ticks / (float) totalTicks, 0F, 1F);
        if (percent >= 1F) {
            from = to;
            return to;
        }
        return from + (to - from) * percent;
    }

    public void reset() {
        totalTicks = 20;
        ticks = 0;
        to = 1;
    }

    public void setNewZoom(float to, long ticks) {
        this.from = getCurrentFov();
        this.to = to;
        this.ticks = 0;
        this.totalTicks = ticks;
    }
}
