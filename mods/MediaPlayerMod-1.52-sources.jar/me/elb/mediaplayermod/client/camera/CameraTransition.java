package me.elb.mediaplayermod.client.camera;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public abstract class CameraTransition<T> {
    private T from;
    private T to;
    private long start;
    private long end;

    protected abstract T getCurrentFrom();

    public boolean isEnabled() {
        return to != null;
    }

    public boolean isLoading() {
        if (!isEnabled()) {
            return false;
        }
        long now = System.currentTimeMillis();
        return now < end;
    }

    public float getLoadPercent() {
        if (!isLoading()) {
            return 1F;
        }
        long now = System.currentTimeMillis();
        return Math.clamp((now - start) / (float) (end - start), 0F, 1F);
    }

    public void reset(T defaultFrom) {
        this.from = defaultFrom;
        this.to = null;
        this.start = -1;
        this.end = -1;
    }

    public void setNewObjective(T newTo, long duration) {
        this.from = getCurrentFrom();
        this.to = newTo;
        this.start = System.currentTimeMillis();
        this.end = start + duration;
    }
}
