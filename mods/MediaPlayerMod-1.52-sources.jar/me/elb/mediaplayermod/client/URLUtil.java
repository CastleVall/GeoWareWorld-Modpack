package me.elb.mediaplayermod.client;

import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.utils.FileEncryption;
import net.minecraft.class_310;
import lombok.experimental.UtilityClass;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.UUID;

@UtilityClass
public class URLUtil {
    public static String fixUrl(String url) {
        return decryptUrlFile(applyPlaceholders(url));
    }

    public static String decryptUrlFile(String url) {
        if (url.endsWith(FileEncryption.EXTENSION)) {
            try {
                String aux = url.substring(0, url.length() - FileEncryption.EXTENSION.length());
                String extension = aux.substring(aux.lastIndexOf("."));
                File decryptedFile = File.createTempFile("decrypted_" + UUID.randomUUID(), extension);
                FileEncryption.decryptFile(new File(url), decryptedFile);
                decryptedFile.deleteOnExit();
                url = decryptedFile.getAbsolutePath();
                MediaPlayerMod.LOGGER.info("Decrypted file: {} to {}", url, decryptedFile.getAbsolutePath());
            } catch (Exception e) {
                MediaPlayerMod.LOGGER.error("Error decrypting file: {}", url, e);
            }
        }
        return url;
    }

    public static String applyPlaceholders(String url) {

        boolean hasProtocol = url.contains("://");
        boolean isAbsolute = url.startsWith("/")
                || (url.length() >= 2 && Character.isLetter(url.charAt(0)) && url.charAt(1) == ':');
        if (!hasProtocol && !url.startsWith("~") && !isAbsolute) {
            java.io.File mediaRoot = new java.io.File(
                    class_310.method_1551().field_1697, "config/mediaplayer");
            java.io.File candidate = new java.io.File(mediaRoot, url);
            if (candidate.exists()) {
                url = "local://" + candidate.getAbsolutePath().replaceAll("\\\\", "/");
            } else {
                // Nombre limpio (sin ruta ni extension), tal como lo sugiere el autocompletado:
                // se busca en las carpetas de medios un archivo cuyo nombre base coincida.
                java.io.File byName = findLocalMediaByName(mediaRoot, url);
                if (byName != null) {
                    url = "local://" + byName.getAbsolutePath().replaceAll("\\\\", "/");
                }
            }
        }
        if (url.contains("~")) {
            url = url.replace("~", "local://" + class_310.method_1551().field_1697.getAbsolutePath()
                    .replaceAll("\\\\", "/"));
        }
        if (url.contains("%player%")) {
            url = url.replace("%player%", class_310.method_1551().method_1548().method_1676());
        }
        if (url.contains("%uuid%")) {
            url = url.replace("%uuid%", class_310.method_1551().method_1548().method_44717() + "");
        }
        if (url.contains("%lang%")) {
            url = url.replace("%lang%",
                    class_310.method_1551().method_1526().method_4669().split("_")[0].toLowerCase());
        }

        return url;
    }

    /** Carpetas (relativas a config/mediaplayer) donde se buscan medios por nombre limpio. */
    private static final String[] MEDIA_DIRS = {
            "videos", "audio", "images",
            "overlays_player/videos", "overlays_player/songs", "overlays_player/audio"
    };

    /**
     * Busca, en las carpetas de medios, un archivo cuyo nombre base (sin extension, ignorando
     * {@code .enc} y mayusculas/minusculas) coincida con {@code name}. Devuelve {@code null} si no
     * hay coincidencia. Permite que el usuario escriba solo "intro" en lugar de "videos/intro.mp4".
     */
    private static File findLocalMediaByName(File mediaRoot, String name) {
        String target = stripExtension(name).toLowerCase(java.util.Locale.ROOT);
        for (String dir : MEDIA_DIRS) {
            File found = searchByBaseName(new File(mediaRoot, dir), target, 8);
            if (found != null) return found;
        }
        return null;
    }

    private static File searchByBaseName(File dir, String target, int depth) {
        if (depth < 0 || !dir.isDirectory()) return null;
        File[] entries = dir.listFiles();
        if (entries == null) return null;
        for (File f : entries) {
            if (f.isFile() && stripExtension(f.getName()).toLowerCase(java.util.Locale.ROOT).equals(target)) {
                return f;
            }
        }
        for (File f : entries) {
            if (f.isDirectory()) {
                File found = searchByBaseName(f, target, depth - 1);
                if (found != null) return found;
            }
        }
        return null;
    }

    private static String stripExtension(String name) {
        String n = name;
        if (n.toLowerCase(java.util.Locale.ROOT).endsWith(FileEncryption.EXTENSION)) {
            n = n.substring(0, n.length() - FileEncryption.EXTENSION.length());
        }
        int dot = n.lastIndexOf('.');
        return dot > 0 ? n.substring(0, dot) : n;
    }

    public static @NotNull URL loadUrl(String urlString) throws MalformedURLException {
        URL url;
        if (urlString.startsWith("local://")) {
            url = new File(urlString.substring(8)).toURI().toURL();
        } else if (urlString.startsWith("http://") || urlString.startsWith("https://")) {
            url = URI.create(urlString).toURL();
        } else {
            url = Paths.get(urlString).toUri().toURL();
        }
        return url;
    }

    public static @NotNull URI loadUri(String urlString) throws MalformedURLException, URISyntaxException {
        return loadUrl(fixUrl(urlString)).toURI();
    }
}
