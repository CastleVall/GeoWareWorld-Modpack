package me.elb.mediaplayermod.client;

import me.elb.mediaplayermod.client.camera.CameraTransition;
import me.elb.mediaplayermod.model.media.Camera;
import me.elb.mediaplayermod.utils.CoordinateUtils;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_5498;
import net.minecraft.class_746;
import lombok.Getter;
import org.joml.Vector2f;
import org.joml.Vector3f;

import java.util.EnumMap;
import java.util.Map;

public class CameraHandler {
    @Getter
    private final CameraTransition<Camera.Movement> cameraTransition = new CameraTransition<>() {
        @Override
        protected Camera.Movement getCurrentFrom() {
            if (!cameraTransition.isLoading()) {
                return cameraTransition.getTo();
            }
            if (cameraTransition.getFrom() == null) {
                cameraTransition.setFrom(getPlayerDefaultCamera());
            }
            float percent = cameraTransition.getLoadPercent();
            Camera.Movement from = cameraTransition.getFrom();
            Camera.Movement to = cameraTransition.getTo();
            return new Camera.Movement(true,
                    from.x() + (to.x() - from.x()) * percent,
                    from.y() + (to.y() - from.y()) * percent,
                    from.z() + (to.z() - from.z()) * percent,
                    CoordinateUtils.interpolateYaw(from.yaw(), to.yaw(), percent),
                    CoordinateUtils.interpolatePitch(from.pitch(), to.pitch(), percent),
                    false, 0);
        }
    };
    @Getter
    private final CameraTransition<Float> yawTransition = new CameraTransition<>() {
        @Override
        protected Float getCurrentFrom() {
            if (yawTransition.isEnabled()) {
                if (!yawTransition.isLoading()) {
                    return yawTransition.getTo();
                }
                return CoordinateUtils.interpolateYaw(yawTransition.getFrom(), yawTransition.getTo(), yawTransition.getLoadPercent());
            }
            if (cameraTransition.isEnabled()) {
                Camera.Movement from = cameraTransition.getFrom();
                Camera.Movement to = cameraTransition.getTo();
                if (!cameraTransition.isLoading()) {
                    return to.yaw();
                } else if (from != null) {
                    return CoordinateUtils.interpolateYaw(from.yaw(), to.yaw(), cameraTransition.getLoadPercent());
                }
            }
            class_746 player = class_310.method_1551().field_1724;
            if (player != null) {
                return player.method_36454();
            }
            return 0f;
        }
    };
    @Getter
    private final CameraTransition<Float> pitchTransition = new CameraTransition<>() {
        @Override
        protected Float getCurrentFrom() {
            if (pitchTransition.isEnabled()) {
                if (!pitchTransition.isLoading()) {
                    return pitchTransition.getTo();
                }
                return CoordinateUtils.interpolatePitch(pitchTransition.getFrom(), pitchTransition.getTo(), pitchTransition.getLoadPercent());
            }
            if (cameraTransition.isEnabled()) {
                Camera.Movement from = cameraTransition.getFrom();
                Camera.Movement to = cameraTransition.getTo();
                if (!cameraTransition.isLoading()) {
                    return to.pitch();
                } else if (from != null) {
                    return CoordinateUtils.interpolatePitch(from.pitch(), to.pitch(), cameraTransition.getLoadPercent());
                }
            }
            class_746 player = class_310.method_1551().field_1724;
            if (player != null) {
                return player.method_36455();
            }
            return 0f;
        }
    };

    private final Map<Camera.Coordinate, Camera.Limit> limitMap = new EnumMap<>(Camera.Coordinate.class);
    private int limitingFlagX;
    private int limitingFlagY;
    private int limitingFlagZ;

    public boolean isEnabled() {
        return cameraTransition.isEnabled() || yawTransition.isEnabled() || pitchTransition.isEnabled();
    }

    public boolean isDetached() {
        return cameraTransition.isLoading() || (cameraTransition.getTo() != null && cameraTransition.getTo().detached());
    }

    public boolean isLimiting() {
        return limitingFlagX != 0 || limitingFlagY != 0 || limitingFlagZ != 0;
    }

    public Camera.Movement getFixedFrom(boolean detached) {
        if (cameraTransition.getFrom() == null) {
            cameraTransition.setFrom(getPlayerDefaultCamera());
        }
        if (detached) {
            if (!cameraTransition.getFrom().detached()) {
                cameraTransition.setFrom(getCurrentCameraPosition(cameraTransition.getFrom()));
            }
            return cameraTransition.getFrom();
        }
        if (cameraTransition.getFrom().detached()) {
            return getRelativeCameraPosition(cameraTransition.getFrom());
        }
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            throw new IllegalStateException("Player can't be null");
        }
        Camera.Movement from = cameraTransition.getFrom();
        return new Camera.Movement(false, from.x(), from.y(), from.z(),
                client.field_1724.method_36454() + from.yaw(), client.field_1724.method_36455() + from.pitch(),
                from.inverted(), 0);
    }

    private static Camera.Movement getCurrentCameraPosition(Camera.Movement camera) {
        if (camera.detached()) {
            return camera;
        }
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            throw new IllegalStateException("Player is null");
        }
        double playerX = client.field_1724.method_23317();
        double playerY = client.field_1724.method_23318();
        double playerZ = client.field_1724.method_23321();
        float playerYaw = client.field_1724.method_36454();
        float playerPitch = client.field_1724.method_36455();
        double yawRad = Math.toRadians(playerYaw - 90);
        double pitchRad = Math.toRadians(playerPitch);
        Vector3f movement = new Vector3f((float) camera.x(), (float) camera.y(), (float) -camera.z());
        float sinYaw = class_3532.method_15374((float) yawRad);
        float cosYaw = class_3532.method_15362((float) yawRad);
        movement.rotateY((float) yawRad);
        movement.rotateZ((float) (-pitchRad * cosYaw));
        movement.mul(-1.0f, 1.0f, 1.0f);
        movement.rotateX((float) (-pitchRad * sinYaw));
        return new Camera.Movement(true, playerX + movement.x, playerY + movement.y + 1.6, playerZ + movement.z,
                playerYaw, playerPitch, false, 0);
    }

    private static Camera.Movement getRelativeCameraPosition(Camera.Movement camera) {
        if (!camera.detached()) {
            return camera;
        }
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            throw new IllegalStateException("Player is null");
        }

        double playerX = client.field_1724.method_23317();
        double playerY = client.field_1724.method_23318();
        double playerZ = client.field_1724.method_23321();
        float playerYaw = client.field_1724.method_36454();
        float playerPitch = client.field_1724.method_36455();

        double yawRad = Math.toRadians(playerYaw - 90);
        double pitchRad = Math.toRadians(playerPitch);

        Vector3f relativePos = new Vector3f(
                (float) (camera.x() - playerX),
                (float) (camera.y() - (playerY + 1.6)),
                (float) (camera.z() - playerZ)
        );
        float sinYaw = class_3532.method_15374((float) yawRad);
        float cosYaw = class_3532.method_15362((float) yawRad);
        relativePos.rotateX((float) (pitchRad * sinYaw));
        relativePos.mul(-1.0f, 1.0f, 1.0f);
        relativePos.rotateZ((float) (pitchRad * cosYaw));
        relativePos.rotateY((float) -yawRad);
        return new Camera.Movement(false, relativePos.x, relativePos.y, -relativePos.z,
                camera.yaw(), camera.pitch(), false, 0);
    }

    private static Camera.Movement getPlayerDefaultCamera() {
        class_310 client = class_310.method_1551();
        class_5498 perspective = client.field_1690.method_31044();
        return switch (perspective) {
            case field_26666 -> new Camera.Movement(false, 4, 0, 0, 0, 0, false, 0);
            case field_26665 -> new Camera.Movement(false, -4, 0, 0, 0, 0, false, 0);
            default -> new Camera.Movement(false, -0.5, 0, 0, 0, 0, false, 0);
        };
    }

    public void reset() {
        cameraTransition.reset(getPlayerDefaultCamera());
        yawTransition.reset(null);
        pitchTransition.reset(null);
        resetLimits();
    }

    public void resetLimits() {
        this.limitMap.clear();
    }

    public Camera getCurrentCameraPosition() {
        if (!cameraTransition.isLoading()) {
            return cameraTransition.getTo();
        }
        if (cameraTransition.getFrom() == null) {
            cameraTransition.setFrom(getPlayerDefaultCamera());
        }
        float percent = cameraTransition.getLoadPercent();
        Camera.Movement from = cameraTransition.getFrom();
        Camera.Movement to = cameraTransition.getTo();
        return new Camera.Movement(true,
                from.x() + (to.x() - from.x()) * percent,
                from.y() + (to.y() - from.y()) * percent,
                from.z() + (to.z() - from.z()) * percent,
                CoordinateUtils.interpolateYaw(from.yaw(), to.yaw(), percent),
                CoordinateUtils.interpolatePitch(from.pitch(), to.pitch(), percent),
                false, 0);
    }

    public void setLimit(Camera.Limit limit) {
        limitMap.put(limit.coordinate(), limit);
    }

    public Vector3f limitPosition(double x, double y, double z) {
        return new Vector3f(limitSinglePosition(Camera.Coordinate.X, x),
                limitSinglePosition(Camera.Coordinate.Y, y),
                limitSinglePosition(Camera.Coordinate.Z, z));
    }

    private float limitSinglePosition(Camera.Coordinate coordinate, double playerCoordinate) {
        float result = (float) playerCoordinate;
        int limiting = 0;
        Camera.Limit limit = limitMap.get(coordinate);
        if (limit != null) {
            Double min = limit.min();
            Double max = limit.max();
            if (min != null && playerCoordinate < min) {
                result = min.floatValue();
                limiting = -1;
            } else if (max != null && playerCoordinate > max) {
                result = max.floatValue();
                limiting = 1;
            }
        }
        if (coordinate == Camera.Coordinate.X) {
            limitingFlagX = limiting;
        } else if (coordinate == Camera.Coordinate.Y) {
            limitingFlagY = limiting;
        } else if (coordinate == Camera.Coordinate.Z) {
            limitingFlagZ = limiting;
        }
        return result;
    }

    public Vector2f limitRotation(float finalYaw, float finalPitch) {
        return new Vector2f(limitSingleRotation(Camera.Coordinate.YAW, limitMap.get(Camera.Coordinate.YAW), finalYaw),
                limitSingleRotation(Camera.Coordinate.PITCH, limitMap.get(Camera.Coordinate.PITCH), finalPitch));
    }

    private float limitSingleRotation(Camera.Coordinate coordinate, Camera.Limit limit, float finalValue) {
        if (limit == null) {
            if (coordinate == Camera.Coordinate.YAW) {
                if (limitingFlagX > 0) {
                    if (limitingFlagZ > 0) {
                        return -45;
                    } else if (limitingFlagZ < 0) {
                        return -135;
                    } else {
                        return -90;
                    }
                } else if (limitingFlagX < 0) {
                    if (limitingFlagZ > 0) {
                        return 45;
                    } else if (limitingFlagZ < 0) {
                        return 135;
                    } else {
                        return 90;
                    }
                } else {
                    if (limitingFlagZ > 0) {
                        return 0;
                    } else if (limitingFlagZ < 0) {
                        return 180;
                    }
                }
            } else if (coordinate == Camera.Coordinate.PITCH) {
                if (limitingFlagY > 0) {
                    return -90;
                } else if (limitingFlagY < 0) {
                    return 90;
                } else if (limitingFlagX != 0 || limitingFlagZ != 0) {
                    return 0;
                }
            }
            return finalValue;
        }
        Double min = limit.min();
        Double max = limit.max();
        if (min != null && finalValue < min) {
            return min.floatValue();
        } else if (max != null && finalValue > max) {
            return max.floatValue();
        }
        return finalValue;
    }
}
