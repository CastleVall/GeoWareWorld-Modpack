package me.elb.mediaplayermod.payload;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteStreams;
import me.elb.mediaplayermod.networking.PacketTCP;
import me.elb.mediaplayermod.networking.packet.Packet;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import me.elb.mediaplayermod.MediaPlayerMod;
import io.netty.buffer.ByteBuf;

public record MediaPayload(Packet packet) implements class_8710 {
    public static final class_9154<MediaPayload> ID = new class_9154<>(class_2960.method_60655(MediaPlayerMod.MOD_ID, "channel"));
    public static final class_9139<class_9129, MediaPayload> CODEC = class_9139.method_56434(
            new class_9139<ByteBuf, Packet>() {
                public Packet decode(ByteBuf byteBuf) {
                    try {
                        byte[] data = new byte[byteBuf.readableBytes()];
                        byteBuf.readBytes(data);
                        ByteArrayDataInput in = ByteStreams.newDataInput(data);
                        return PacketTCP.read(in);
                    } catch (Exception e) {
                        MediaPlayerMod.LOGGER.error("Failed to decode packet", e);
                        return null;
                    }
                }

                public void encode(ByteBuf byteBuf, Packet packet) {
                    byteBuf.writeBytes(PacketTCP.write(packet));
                }
            },
            MediaPayload::packet, MediaPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
