package me.elb.mediaplayermod.model.fog;

public class NoFogConfig implements FogConfig {
    @Override
    public FogType fogType() {
        return FogType.NONE;
    }
}
