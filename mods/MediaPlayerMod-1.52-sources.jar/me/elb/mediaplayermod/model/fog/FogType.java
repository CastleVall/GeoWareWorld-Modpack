package me.elb.mediaplayermod.model.fog;

public enum FogType {
    LINEAR,
    EXPONENTIAL,
    EXPONENTIAL_TWO,
    NONE
}
