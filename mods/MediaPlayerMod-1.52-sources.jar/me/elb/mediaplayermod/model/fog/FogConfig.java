package me.elb.mediaplayermod.model.fog;

public interface FogConfig {
    FogType fogType();
}
