package me.elb.mediaplayermod.model.fog;

public record ExponentialFogConfig(FogType fogType, float multiplier) implements FogConfig {
}
