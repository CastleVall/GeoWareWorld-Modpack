package me.elb.mediaplayermod.model.fog;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum Fog {
    UNIVERSAL(0.25, 1,5, 5, false),
    WATER(0.25, 1, 2, 0.05, false),
    POWDER_SNOW(0, 1.4, 85, 9800.05, false);

    private final double defaultLinearStartMultiplier;
    private final double defaultLinearEndMultiplier;
    private final double defaultExpMultiplier;
    private final double defaultExpTwoMultiplier;
    private final boolean defaultCylinderFog;
}
