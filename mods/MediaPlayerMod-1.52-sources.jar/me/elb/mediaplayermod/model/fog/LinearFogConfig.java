package me.elb.mediaplayermod.model.fog;

public record LinearFogConfig(float startMultiplier, float endMultiplier) implements FogConfig {
    @Override
    public FogType fogType() {
        return FogType.LINEAR;
    }
}
