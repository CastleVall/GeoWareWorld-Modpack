package me.elb.mediaplayermod.model.option;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record PerspectiveOption(Perspectives perspective) implements ClientOption {
    @Override
    public ClientOptions getType() {
        return ClientOptions.PERSPECTIVE;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeInt(perspective.ordinal());
    }

    public static ClientOption readPacket(final ByteArrayDataInput buf) {
        return new PerspectiveOption(Perspectives.fromId(buf.readInt()));
    }

    public enum Perspectives {
        FIRST_PERSON,
        THIRD_PERSON_BACK,
        THIRD_PERSON_FRONT;

        public static Perspectives fromId(int id) {
            for (Perspectives type : values()) {
                if (type.ordinal() == id) {
                    return type;
                }
            }
            return FIRST_PERSON;
        }
    }
}
