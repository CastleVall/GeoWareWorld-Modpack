package me.elb.mediaplayermod.model.option;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record ChatOpacityOption(float chatOpacity, float textBackgroundOpacity) implements ClientOption {
    @Override
    public ClientOptions getType() {
        return ClientOptions.CHAT_OPACITY;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeFloat(this.chatOpacity());
        buf.writeFloat(this.textBackgroundOpacity());
    }

    public static ClientOption readPacket(final ByteArrayDataInput buf) {
        return new ChatOpacityOption(buf.readFloat(), buf.readFloat());
    }

}
