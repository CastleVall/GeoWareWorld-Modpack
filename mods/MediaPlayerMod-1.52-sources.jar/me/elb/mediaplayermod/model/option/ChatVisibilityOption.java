package me.elb.mediaplayermod.model.option;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record ChatVisibilityOption(boolean visible) implements ClientOption {
    @Override
    public ClientOptions getType() {
        return ClientOptions.CHAT_VISIBILITY;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeBoolean(this.visible());
    }

    public static ClientOption readPacket(final ByteArrayDataInput buf) {
        return new ChatVisibilityOption(buf.readBoolean());
    }
}
