package me.elb.mediaplayermod.model.option;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record VolumeOption(String soundCategory, float volume) implements ClientOption {
    @Override
    public ClientOptions getType() {
        return ClientOptions.VOLUME;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeUTF(this.soundCategory());
        buf.writeFloat(this.volume());
    }

    public static ClientOption readPacket(final ByteArrayDataInput buf) {
        return new VolumeOption(buf.readUTF(), buf.readFloat());
    }
}
