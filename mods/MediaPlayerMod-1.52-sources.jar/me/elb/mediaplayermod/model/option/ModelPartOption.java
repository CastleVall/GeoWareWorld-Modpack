package me.elb.mediaplayermod.model.option;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record ModelPartOption(Parts modelPart, boolean enabled) implements ClientOption {
    @Override
    public ClientOptions getType() {
        return ClientOptions.MODEL_PART;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeInt(modelPart.ordinal());
        buf.writeBoolean(enabled);
    }

    public static ClientOption readPacket(final ByteArrayDataInput buf) {
        return new ModelPartOption(Parts.fromId(buf.readInt()), buf.readBoolean());
    }

    public enum Parts {
        CAPE,
        HAT,
        JACKET,
        LEFT_PANTS_LEG,
        LEFT_SLEEVE,
        RIGHT_PANTS_LEG,
        RIGHT_SLEEVE;

        public static Parts fromId(int id) {
            for (Parts type : values()) {
                if (type.ordinal() == id) {
                    return type;
                }
            }
            return CAPE;
        }
    }
}
