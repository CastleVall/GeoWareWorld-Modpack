package me.elb.mediaplayermod.model.option;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record ShaderOption(Shaders shader) implements ClientOption {
    @Override
    public ClientOptions getType() {
        return ClientOptions.SHADERS;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeInt(shader.ordinal());
    }

    public static ClientOption readPacket(final ByteArrayDataInput buf) {
        return new ShaderOption(Shaders.fromId(buf.readInt()));
    }

    public enum Shaders {
        NONE,
        NOTCH,
        FXAA,
        ART,
        BUMPY,
        BUCKSHOT,
        BLOBS2,
        PENCIL,
        COLOR_CONVOLVE,
        DECONVERGE,
        FLIP,
        INVERT,
        NTSC,
        OUTLINE,
        PHOSPHOR,
        SCAN_PINCUSHION,
        SOBEL,
        BITS,
        DESATURATE,
        GREEN,
        BLUR,
        WOBBLE,
        BLOBS,
        ANTIALIAS,
        CREEPER,
        SPIDER,
        COMPARE,
        FLASHLIGHT,
        FOCUS_FAR,
        FOCUS_NEAR,
        MIX,
        VIGNETTE,
        VIGNETTE_INVERTED,
        WINDOW;

        public static Shaders fromId(int id) {
            for (Shaders type : values()) {
                if (type.ordinal() == id) {
                    return type;
                }
            }
            return NONE;
        }

        public String getPath() {
            return "shaders/post/" + name().toLowerCase() + ".json";
        }
    }
}
