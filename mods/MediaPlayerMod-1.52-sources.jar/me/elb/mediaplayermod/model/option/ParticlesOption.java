package me.elb.mediaplayermod.model.option;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record ParticlesOption(Particles particle) implements ClientOption {
    @Override
    public ClientOptions getType() {
        return ClientOptions.PARTICLES;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeInt(particle.ordinal());
    }

    public static ClientOption readPacket(final ByteArrayDataInput buf) {
        return new ParticlesOption(Particles.fromId(buf.readInt()));
    }

    public enum Particles {
        ALL,
        DECREASED,
        MINIMAL;

        public static Particles fromId(int id) {
            for (Particles type : values()) {
                if (type.ordinal() == id) {
                    return type;
                }
            }
            return ALL;
        }
    }
}
