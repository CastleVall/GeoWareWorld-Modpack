package me.elb.mediaplayermod.model.option;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record CloudsOption(Clouds clouds) implements ClientOption {
    @Override
    public ClientOptions getType() {
        return ClientOptions.CLOUDS;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeInt(clouds.ordinal());
    }

    public static ClientOption readPacket(final ByteArrayDataInput buf) {
        return new CloudsOption(Clouds.fromId(buf.readInt()));
    }

    public enum Clouds {
        OFF,
        FAST,
        FANCY;

        public static Clouds fromId(int id) {
            for (Clouds type : values()) {
                if (type.ordinal() == id) {
                    return type;
                }
            }
            return OFF;
        }
    }
}
