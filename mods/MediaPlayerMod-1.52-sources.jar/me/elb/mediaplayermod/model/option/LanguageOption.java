package me.elb.mediaplayermod.model.option;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record LanguageOption(String code) implements ClientOption {
    @Override
    public ClientOptions getType() {
        return ClientOptions.LANGUAGE;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeUTF(code);
    }

    public static ClientOption readPacket(final ByteArrayDataInput buf) {
        return new LanguageOption(buf.readUTF());
    }

}
