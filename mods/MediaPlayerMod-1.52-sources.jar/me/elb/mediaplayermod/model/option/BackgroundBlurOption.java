package me.elb.mediaplayermod.model.option;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record BackgroundBlurOption(int value) implements ClientOption {
    @Override
    public ClientOptions getType() {
        return ClientOptions.BACKGROUND_BLUR;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeInt(value);
    }

    public static ClientOption readPacket(final ByteArrayDataInput buf) {
        return new BackgroundBlurOption(buf.readInt());
    }
}
