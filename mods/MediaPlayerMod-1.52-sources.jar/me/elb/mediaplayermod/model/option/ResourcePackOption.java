package me.elb.mediaplayermod.model.option;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record ResourcePackOption(String profileId, boolean enabled) implements ClientOption {
    @Override
    public ClientOptions getType() {
        return ClientOptions.RESOURCE_PACK;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeUTF(profileId);
        buf.writeBoolean(enabled);
    }

    public static ClientOption readPacket(final ByteArrayDataInput buf) {
        return new ResourcePackOption(buf.readUTF(), buf.readBoolean());
    }
}
