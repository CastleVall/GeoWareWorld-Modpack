package me.elb.mediaplayermod.model.option;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record FovOption(int value) implements ClientOption {
    @Override
    public ClientOptions getType() {
        return ClientOptions.FOV;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeInt(value);
    }

    public static ClientOption readPacket(final ByteArrayDataInput buf) {
        return new FovOption(buf.readInt());
    }

}
