package me.elb.mediaplayermod.model.option;

import com.google.common.io.ByteArrayDataOutput;

public interface ClientOption {
    ClientOptions getType();
    void writePacket(ByteArrayDataOutput buf);
}
