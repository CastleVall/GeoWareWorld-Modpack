package me.elb.mediaplayermod.model.option;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

/**
 * Ajuste de Simple Voice Chat en el cliente (modo de microfono, tecla de hablar, volumen,
 * ganancia...). El cliente lo ignora si no tiene el mod "voicechat" instalado.
 *
 * <p>La distancia de escucha NO viaja por aqui: se resuelve en el servidor filtrando los paquetes
 * de voz (ver {@code VoiceDistanceManager}).
 */
public record VoicechatOption(String setting, String value) implements ClientOption {
    @Override
    public ClientOptions getType() {
        return ClientOptions.VOICECHAT;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeUTF(this.setting());
        buf.writeUTF(this.value());
    }

    public static ClientOption readPacket(final ByteArrayDataInput buf) {
        return new VoicechatOption(buf.readUTF(), buf.readUTF());
    }
}
