package me.elb.mediaplayermod.model.option;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record ViewDistanceOption(int distance) implements ClientOption {
    @Override
    public ClientOptions getType() {
        return ClientOptions.VIEW_DISTANCE;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeInt(distance);
    }

    public static ClientOption readPacket(final ByteArrayDataInput buf) {
        return new ViewDistanceOption(buf.readInt());
    }
}
