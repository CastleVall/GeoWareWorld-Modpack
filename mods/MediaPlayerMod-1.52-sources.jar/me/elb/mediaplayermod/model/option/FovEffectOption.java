package me.elb.mediaplayermod.model.option;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record FovEffectOption(double value) implements ClientOption {
    @Override
    public ClientOptions getType() {
        return ClientOptions.FOV_EFFECT;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeDouble(value);
    }

    public static ClientOption readPacket(final ByteArrayDataInput buf) {
        return new FovEffectOption(buf.readDouble());
    }

}
