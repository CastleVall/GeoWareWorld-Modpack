package me.elb.mediaplayermod.model.option;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record GuiScaleOption(int scale) implements ClientOption {
    @Override
    public ClientOptions getType() {
        return ClientOptions.GUI_SCALE;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeInt(scale);
    }

    public static ClientOption readPacket(final ByteArrayDataInput buf) {
        return new GuiScaleOption(buf.readInt());
    }

}
