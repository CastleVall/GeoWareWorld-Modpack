package me.elb.mediaplayermod.model.option;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum ClientOptions {
    CLOUDS(1, CloudsOption.class),
    GUI_SCALE(2, GuiScaleOption.class),
    GAMMA(3, GammaOption.class),
    VIEW_DISTANCE(4, ViewDistanceOption.class),
    PARTICLES(5, ParticlesOption.class),
    LANGUAGE(6, LanguageOption.class),
    FOV(7, FovOption.class),
    CHAT_VISIBILITY(8, ChatVisibilityOption.class),
    PERSPECTIVE(9, PerspectiveOption.class),
    SHADERS(10, ShaderOption.class),
    CHAT_OPACITY(11, ChatOpacityOption.class),
    VOLUME(12, VolumeOption.class),
    MODEL_PART(13, ModelPartOption.class),
    RESOURCE_PACK(14, ResourcePackOption.class),
    BACKGROUND_BLUR(15, BackgroundBlurOption.class),
    FOV_EFFECT(16, FovEffectOption.class),
    VOICECHAT(17, VoicechatOption.class);

    private final int id;
    private final Class<? extends ClientOption> clazz;

    public static ClientOptions fromId(int id) {
        for (ClientOptions clientOption : values()) {
            if (clientOption.id == id) {
                return clientOption;
            }
        }
        throw new IllegalArgumentException("Invalid client option id: " + id);
    }
}
