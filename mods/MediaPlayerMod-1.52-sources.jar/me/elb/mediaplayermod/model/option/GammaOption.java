package me.elb.mediaplayermod.model.option;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record GammaOption(float value) implements ClientOption {
    @Override
    public ClientOptions getType() {
        return ClientOptions.GAMMA;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeFloat(this.value());
    }

    public static ClientOption readPacket(final ByteArrayDataInput buf) {
        return new GammaOption(buf.readFloat());
    }

}
