package me.elb.mediaplayermod.model.media;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record ProjectionOperation(String id, Op op, String url) implements Media {

    public enum Op {
        STOP, PAUSE, RESUME, LOOP_ON, LOOP_OFF, SET_URL, REMOVE, SEEK
    }

    public ProjectionOperation(String id, Op op) {
        this(id, op, "");
    }

    @Override
    public MediaType getType() {
        return MediaType.PROJECTION_OP;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeUTF(this.id());
        buf.writeInt(this.op().ordinal());
        buf.writeUTF(this.url());
    }

    public static Media readPacket(final ByteArrayDataInput buf) {
        String id = buf.readUTF();
        Op op = Op.values()[buf.readInt()];
        String url = buf.readUTF();
        return new ProjectionOperation(id, op, url);
    }
}
