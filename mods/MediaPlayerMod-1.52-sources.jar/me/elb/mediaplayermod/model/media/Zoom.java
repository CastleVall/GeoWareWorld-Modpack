package me.elb.mediaplayermod.model.media;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record Zoom(float value, long loadTime) implements Media {

    @Override
    public MediaType getType() {
        return MediaType.ZOOM;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeFloat(this.value());
        buf.writeLong(this.loadTime());
    }

    public static Media readPacket(final ByteArrayDataInput buf) {
        return new Zoom(buf.readFloat(), buf.readLong());
    }
}
