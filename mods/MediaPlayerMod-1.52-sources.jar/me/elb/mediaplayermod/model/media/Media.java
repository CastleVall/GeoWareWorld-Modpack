package me.elb.mediaplayermod.model.media;

import com.google.common.io.ByteArrayDataOutput;

public interface Media {
    MediaType getType();
    void writePacket(ByteArrayDataOutput buf);
}
