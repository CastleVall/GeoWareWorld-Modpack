package me.elb.mediaplayermod.model.media;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record Projection(String id, String url, int x1, int y1, int z1, int x2, int y2, int z2,
                          int rotX, int rotY, int rotZ,
                          boolean chromaKey, int chromaColor, float chromaTolerance) implements Media {

    public Projection(String id, String url, int x1, int y1, int z1, int x2, int y2, int z2,
                      int rotX, int rotY, int rotZ) {
        this(id, url, x1, y1, z1, x2, y2, z2, rotX, rotY, rotZ, false, 0x00FF00, 0.25f);
    }

    public Projection(String id, String url, int x1, int y1, int z1, int x2, int y2, int z2) {
        this(id, url, x1, y1, z1, x2, y2, z2, 0, 0, 0);
    }

    @Override
    public MediaType getType() {
        return MediaType.PROJECTION;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeUTF(this.id());
        buf.writeUTF(this.url());
        buf.writeInt(this.x1());
        buf.writeInt(this.y1());
        buf.writeInt(this.z1());
        buf.writeInt(this.x2());
        buf.writeInt(this.y2());
        buf.writeInt(this.z2());
        buf.writeInt(this.rotX());
        buf.writeInt(this.rotY());
        buf.writeInt(this.rotZ());
        buf.writeBoolean(this.chromaKey());
        buf.writeInt(this.chromaColor());
        buf.writeFloat(this.chromaTolerance());
    }

    public static Media readPacket(final ByteArrayDataInput buf) {
        String id = buf.readUTF();
        String url = buf.readUTF();
        int x1 = buf.readInt(), y1 = buf.readInt(), z1 = buf.readInt();
        int x2 = buf.readInt(), y2 = buf.readInt(), z2 = buf.readInt();
        int rotX = buf.readInt(), rotY = buf.readInt(), rotZ = buf.readInt();
        boolean chromaKey = buf.readBoolean();
        int chromaColor = buf.readInt();
        float chromaTolerance = buf.readFloat();
        return new Projection(id, url, x1, y1, z1, x2, y2, z2, rotX, rotY, rotZ,
                chromaKey, chromaColor, chromaTolerance);
    }
}
