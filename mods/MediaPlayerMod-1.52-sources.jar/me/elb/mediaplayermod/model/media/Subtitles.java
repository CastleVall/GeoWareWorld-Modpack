package me.elb.mediaplayermod.model.media;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

import java.awt.Color;

public record Subtitles(String url, String fontName, double size, Color color, Background background) implements Media {
    @Override
    public MediaType getType() {
        return MediaType.SUBTITLES;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeUTF(this.url());
        buf.writeUTF(this.fontName());
        buf.writeDouble(this.size());
        buf.writeInt(this.color().getRGB());
        buf.writeUTF(this.background().name());
    }

    public static Media readPacket(final ByteArrayDataInput buf) {
        return new Subtitles(buf.readUTF(), buf.readUTF(), buf.readDouble(), new Color(buf.readInt()),
                Background.valueOf(buf.readUTF().toUpperCase()));
    }

    public enum Background {
        NONE,
        FADED,
        BUBBLE,
        KARAOKE
    }
}
