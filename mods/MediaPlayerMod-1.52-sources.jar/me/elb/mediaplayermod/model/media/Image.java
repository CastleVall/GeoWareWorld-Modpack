package me.elb.mediaplayermod.model.media;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record Image(String url, float size, float xOffset, float yOffset, long fadeIn, long duration, long fadeOut) implements Media {
    @Override
    public MediaType getType() {
        return MediaType.IMAGE;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeUTF(this.url());
        buf.writeFloat(this.size());
        buf.writeFloat(this.xOffset());
        buf.writeFloat(this.yOffset());
        buf.writeLong(this.fadeIn());
        buf.writeLong(this.duration());
        buf.writeLong(this.fadeOut());
    }

    public static Media readPacket(final ByteArrayDataInput buf) {
        return new Image(buf.readUTF(), buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readLong(), buf.readLong(), buf.readLong());
    }
}
