package me.elb.mediaplayermod.model.media;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum MediaType {
    ANY(0, GenericMedia.class),
    VIDEO(1, Video.class),
    AUDIO(2, Audio.class),
    PLAYLIST(3, Playlist.class),
    IMAGE(4, Image.class),
    FADE(5, Fade.class),
    GLOW(6, Glow.class),
    BLINK(7, Blink.class),
    COLOR(8, Color.class),
    PROJECTION(9, Projection.class),
    SUBTITLES(10, Subtitles.class),
    ZOOM(11, Zoom.class),
    CAMERA(12, Camera.Movement.class),
    TEXT(13, Text.class),
    CAMERA_LIMIT(14, Camera.Limit.class),
    CAMERA_ROTATION(15, Camera.Rotation.class),
    CINEMATIC(16, Cinematic.class),
    PROJECTION_OP(17, ProjectionOperation.class),
    ANIMATION(18, Animation.class),
    INTERACTIVE_IMAGE(19, InteractiveImage.class);

    private final int id;
    private final Class<? extends Media> clazz;

    public static MediaType fromId(int id) {
        for (MediaType mediaType : values()) {
            if (mediaType.id == id) {
                return mediaType;
            }
        }
        throw new IllegalArgumentException("Invalid media type id: " + id);
    }
}
