package me.elb.mediaplayermod.model.media;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record Color(int color, long duration, float opacity) implements Media {
    @Override
    public MediaType getType() {
        return MediaType.COLOR;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeInt(this.color());
        buf.writeLong(this.duration());
        buf.writeFloat(this.opacity());
    }

    public static Media readPacket(final ByteArrayDataInput buf) {
        return new Color(buf.readInt(), buf.readLong(), buf.readFloat());
    }
}
