package me.elb.mediaplayermod.model.media;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.LinkedList;
import java.util.List;

@RequiredArgsConstructor
@Getter
public abstract class Playlist implements Media {
    private final String id;
    private final int subtype;

    @Override
    public MediaType getType() {
        return MediaType.PLAYLIST;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeInt(this.subtype);
        buf.writeUTF(this.id);
    }

    public static Media readPacket(final ByteArrayDataInput buf) {
        int subtype = buf.readInt();
        return switch (subtype) {
            case 0 -> Delete.readPacket(buf);
            case 1 -> Tracks.readPacket(buf);
            case 2 -> Add.readPacket(buf);
            case 3 -> Remove.readPacket(buf);
            case 4 -> Paused.readPacket(buf);
            case 5 -> Loop.readPacket(buf);
            case 6 -> Shuffled.readPacket(buf);
            case 7 -> Move.readPacket(buf);
            case 8 -> Skip.readPacket(buf);
            case 9 -> Jump.readPacket(buf);
            case 10 -> Volume.readPacket(buf);
            default -> throw new IllegalArgumentException("Unknown playlist subtype: " + subtype);
        };
    }

    public static class Delete extends Playlist {
        public Delete(String id) {
            super(id, 0);
        }

        public static Media readPacket(final ByteArrayDataInput buf) {
            String id = buf.readUTF();
            return new Delete(id);
        }
    }

    @Getter
    public static class Tracks extends Playlist {
        private final List<Audio> list;
        private final boolean paused;
        private final boolean loop;
        private final boolean shuffle;

        public Tracks(String id, List<Audio> list, boolean paused, boolean loop, boolean shuffle) {
            super(id, 1);
            this.list = list;
            this.paused = paused;
            this.loop = loop;
            this.shuffle = shuffle;
        }

        @Override
        public void writePacket(ByteArrayDataOutput buf) {
            super.writePacket(buf);
            buf.writeInt(this.list.size());
            for (Audio audio : this.list) {
                audio.writePacket(buf);
            }
            buf.writeBoolean(this.paused);
            buf.writeBoolean(this.loop);
            buf.writeBoolean(this.shuffle);
        }

        public static Media readPacket(final ByteArrayDataInput buf) {
            String id = buf.readUTF();
            int size = buf.readInt();
            LinkedList<Audio> list = new LinkedList<>();
            for (int i = 0; i < size; i++) {
                list.add((Audio) Audio.readPacket(buf));
            }
            boolean paused = buf.readBoolean();
            boolean loop = buf.readBoolean();
            boolean shuffle = buf.readBoolean();
            return new Tracks(id, list, paused, loop, shuffle);
        }
    }

    @Getter
    public static class Add extends Playlist {
        private final Audio audio;

        public Add(String id, Audio audio) {
            super(id, 2);
            this.audio = audio;
        }

        @Override
        public void writePacket(ByteArrayDataOutput buf) {
            super.writePacket(buf);
            this.audio.writePacket(buf);
        }

        public static Media readPacket(final ByteArrayDataInput buf) {
            String id = buf.readUTF();
            Audio audio = (Audio) Audio.readPacket(buf);
            return new Add(id, audio);
        }
    }

    @Getter
    public static class Remove extends Playlist {
        private final int index;

        public Remove(String id, int index) {
            super(id, 3);
            this.index = index;
        }

        @Override
        public void writePacket(ByteArrayDataOutput buf) {
            super.writePacket(buf);
            buf.writeInt(this.index);
        }

        public static Media readPacket(final ByteArrayDataInput buf) {
            String id = buf.readUTF();
            int index = buf.readInt();
            return new Remove(id, index);
        }
    }

    @Getter
    public static class Paused extends Playlist {
        private final boolean paused;

        public Paused(String id, boolean paused) {
            super(id, 4);
            this.paused = paused;
        }

        @Override
        public void writePacket(ByteArrayDataOutput buf) {
            super.writePacket(buf);
            buf.writeBoolean(this.paused);
        }

        public static Media readPacket(final ByteArrayDataInput buf) {
            String id = buf.readUTF();
            boolean paused = buf.readBoolean();
            return new Paused(id, paused);
        }
    }

    @Getter
    public static class Loop extends Playlist {
        private final boolean loop;

        public Loop(String id, boolean loop) {
            super(id, 5);
            this.loop = loop;
        }

        @Override
        public void writePacket(ByteArrayDataOutput buf) {
            super.writePacket(buf);
            buf.writeBoolean(this.loop);
        }

        public static Media readPacket(final ByteArrayDataInput buf) {
            String id = buf.readUTF();
            boolean loop = buf.readBoolean();
            return new Loop(id, loop);
        }
    }

    @Getter
    public static class Shuffled extends Playlist {
        private final boolean shuffle;

        public Shuffled(String id, boolean shuffle) {
            super(id, 6);
            this.shuffle = shuffle;
        }

        @Override
        public void writePacket(ByteArrayDataOutput buf) {
            super.writePacket(buf);
            buf.writeBoolean(this.shuffle);
        }

        public static Media readPacket(final ByteArrayDataInput buf) {
            String id = buf.readUTF();
            boolean shuffle = buf.readBoolean();
            return new Shuffled(id, shuffle);
        }
    }

    @Getter
    public static class Move extends Playlist {
        private final int fromIndex;
        private final int toIndex;

        public Move(String id, int fromIndex, int toIndex) {
            super(id, 7);
            this.fromIndex = fromIndex;
            this.toIndex = toIndex;
        }

        @Override
        public void writePacket(ByteArrayDataOutput buf) {
            super.writePacket(buf);
            buf.writeInt(this.fromIndex);
            buf.writeInt(this.toIndex);
        }

        public static Media readPacket(final ByteArrayDataInput buf) {
            String id = buf.readUTF();
            int fromIndex = buf.readInt();
            int toIndex = buf.readInt();
            return new Move(id, fromIndex, toIndex);
        }
    }

    @Getter
    public static class Skip extends Playlist {
        private final int direction;

        public Skip(String id, int direction) {
            super(id, 8);
            this.direction = direction;
        }

        @Override
        public void writePacket(ByteArrayDataOutput buf) {
            super.writePacket(buf);
            buf.writeInt(this.direction);
        }

        public static Media readPacket(final ByteArrayDataInput buf) {
            String id = buf.readUTF();
            int direction = buf.readInt();
            return new Skip(id, direction);
        }
    }

    @Getter
    public static class Jump extends Playlist {
        private final int index;

        public Jump(String id, int index) {
            super(id, 9);
            this.index = index;
        }

        @Override
        public void writePacket(ByteArrayDataOutput buf) {
            super.writePacket(buf);
            buf.writeInt(this.index);
        }

        public static Media readPacket(final ByteArrayDataInput buf) {
            String id = buf.readUTF();
            int index = buf.readInt();
            return new Jump(id, index);
        }
    }

    @Getter
    public static class Volume extends Playlist {
        private final int volume;

        public Volume(String id, int volume) {
            super(id, 10);
            this.volume = volume;
        }

        @Override
        public void writePacket(ByteArrayDataOutput buf) {
            super.writePacket(buf);
            buf.writeInt(this.volume);
        }

        public static Media readPacket(final ByteArrayDataInput buf) {
            String id = buf.readUTF();
            int volume = buf.readInt();
            return new Volume(id, volume);
        }
    }

}
