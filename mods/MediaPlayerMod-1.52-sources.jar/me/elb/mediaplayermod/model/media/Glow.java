package me.elb.mediaplayermod.model.media;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record Glow(long fadeIn, long duration, long fadeOut, float radius, float opacity, int color) implements Media {
    @Override
    public MediaType getType() {
        return MediaType.GLOW;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeLong(this.fadeIn());
        buf.writeLong(this.duration());
        buf.writeLong(this.fadeOut());
        buf.writeFloat(this.radius());
        buf.writeFloat(this.opacity());
        buf.writeInt(this.color());
    }

    public static Media readPacket(final ByteArrayDataInput buf) {
        return new Glow(buf.readLong(), buf.readLong(), buf.readLong(), buf.readFloat(), buf.readFloat(), buf.readInt());
    }
}
