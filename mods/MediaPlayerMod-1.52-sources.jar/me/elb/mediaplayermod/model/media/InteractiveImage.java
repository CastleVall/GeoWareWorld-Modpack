package me.elb.mediaplayermod.model.media;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

/**
 * Imagen interactiva ({@code /playinteractiveimage}): se abre en el inspeccionador estilo
 * Resident Evil en lugar de dibujarse como overlay. {@code backUrl} es la imagen del reverso
 * (cadena vacia = sin reverso, se muestra el dorso generico). {@code bilinear} elige el filtrado
 * al escalar: true = suavizado bilineal; false = vecino mas cercano (pixel art nitido).
 */
public record InteractiveImage(String url, String backUrl, boolean bilinear) implements Media {
    @Override
    public MediaType getType() {
        return MediaType.INTERACTIVE_IMAGE;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeUTF(this.url());
        buf.writeUTF(this.backUrl() == null ? "" : this.backUrl());
        buf.writeBoolean(this.bilinear());
    }

    public static Media readPacket(final ByteArrayDataInput buf) {
        return new InteractiveImage(buf.readUTF(), buf.readUTF(), buf.readBoolean());
    }
}
