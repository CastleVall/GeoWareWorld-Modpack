package me.elb.mediaplayermod.model.media;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record Fade(long fadeIn, long duration, long fadeOut, int color, boolean freezeScreen,
                   Style style) implements Media {

    /**
     * Como se cubre la pantalla: fundido clasico de opacidad, o barras opacas tipo cine que se
     * cierran hasta toparse en el medio (barver = desde arriba y abajo, barhor = desde los lados).
     * fadeIn = tiempo en cerrarse, duration = pantalla cubierta, fadeOut = tiempo en abrirse.
     */
    public enum Style {
        FULL(0),
        BAR_VERTICAL(1),
        BAR_HORIZONTAL(2);

        private final int id;

        Style(int id) {
            this.id = id;
        }

        public int getId() {
            return id;
        }

        public static Style fromId(int id) {
            for (Style style : values()) {
                if (style.id == id) {
                    return style;
                }
            }
            return FULL;
        }
    }

    @Override
    public MediaType getType() {
        return MediaType.FADE;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeLong(this.fadeIn());
        buf.writeLong(this.duration());
        buf.writeLong(this.fadeOut());
        buf.writeInt(this.color());
        buf.writeBoolean(this.freezeScreen());
        buf.writeInt(this.style().getId());
    }

    public static Media readPacket(final ByteArrayDataInput buf) {
        return new Fade(buf.readLong(), buf.readLong(), buf.readLong(), buf.readInt(), buf.readBoolean(),
                Style.fromId(buf.readInt()));
    }
}
