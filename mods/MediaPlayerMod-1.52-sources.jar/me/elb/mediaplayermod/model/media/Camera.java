package me.elb.mediaplayermod.model.media;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public interface Camera extends Media {
    long loadTime();

    enum Coordinate {
        X, Y, Z, YAW, PITCH
    }

    record Movement(boolean detached, double x, double y, double z,
                           float yaw, float pitch, boolean inverted, long loadTime) implements Camera {
        @Override
        public MediaType getType() {
            return MediaType.CAMERA;
        }

        @Override
        public void writePacket(ByteArrayDataOutput buf) {
            buf.writeBoolean(detached);
            buf.writeDouble(x);
            buf.writeDouble(y);
            buf.writeDouble(z);
            buf.writeFloat(yaw);
            buf.writeFloat(pitch);
            buf.writeBoolean(inverted);
            buf.writeLong(loadTime);
        }

        public static Media readPacket(final ByteArrayDataInput buf) {
            return new Movement(buf.readBoolean(), buf.readDouble(), buf.readDouble(), buf.readDouble(),
                    buf.readFloat(), buf.readFloat(), buf.readBoolean(), buf.readLong());
        }
    }

    record Limit(Coordinate coordinate, Double min, Double max) implements Media {
        public Limit(Coordinate coordinate) {
            this(coordinate, null, null);
        }

        @Override
        public MediaType getType() {
            return MediaType.CAMERA_LIMIT;
        }

        @Override
        public void writePacket(ByteArrayDataOutput buf) {
            buf.writeUTF(coordinate.name());
            if (min == null) {
                buf.writeBoolean(true);
            } else {
                buf.writeBoolean(false);
                buf.writeDouble(min);
                buf.writeDouble(max);
            }
        }

        public static Media readPacket(final ByteArrayDataInput buf) {
            Coordinate coordinate = Coordinate.valueOf(buf.readUTF());
            if (buf.readBoolean()) {
                return new Limit(coordinate);
            }
            return new Limit(coordinate, buf.readDouble(), buf.readDouble());
        }
    }

    record Rotation(boolean horizontal, float value, long loadTime) implements Camera {
        @Override
        public MediaType getType() {
            return MediaType.CAMERA_ROTATION;
        }

        @Override
        public void writePacket(ByteArrayDataOutput buf) {
            buf.writeBoolean(horizontal);
            buf.writeFloat(value);
            buf.writeLong(loadTime);
        }

        public static Media readPacket(final ByteArrayDataInput buf) {
            return new Rotation(buf.readBoolean(), buf.readFloat(), buf.readLong());
        }
    }
}
