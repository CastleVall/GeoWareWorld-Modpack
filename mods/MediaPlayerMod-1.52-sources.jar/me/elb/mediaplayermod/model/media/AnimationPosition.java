package me.elb.mediaplayermod.model.media;

import java.util.Locale;

/**
 * Zona de la pantalla donde se dibuja una animacion.
 *
 * <ul>
 *   <li>{@link #CENTER}: grande y centrada, como un title.</li>
 *   <li>{@link #TOP}: arriba, donde va la bossbar.</li>
 *   <li>{@link #BOTTOM}: abajo, donde va la actionbar.</li>
 * </ul>
 */
public enum AnimationPosition {
    CENTER(0),
    TOP(1),
    BOTTOM(2);

    private final int id;

    AnimationPosition(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public static AnimationPosition fromId(int id) {
        for (AnimationPosition position : values()) {
            if (position.id == id) {
                return position;
            }
        }
        return CENTER;
    }

    public static AnimationPosition fromName(String name) {
        if (name != null) {
            for (AnimationPosition position : values()) {
                if (position.name().equalsIgnoreCase(name)) {
                    return position;
                }
            }
        }
        return CENTER;
    }

    public String lowerName() {
        return name().toLowerCase(Locale.ROOT);
    }
}
