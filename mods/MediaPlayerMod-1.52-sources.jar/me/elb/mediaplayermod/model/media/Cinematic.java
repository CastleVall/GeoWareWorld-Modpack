package me.elb.mediaplayermod.model.media;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

import java.util.LinkedList;

public record Cinematic(LinkedList<Camera> cameras) implements Media {
    @Override
    public MediaType getType() {
        return MediaType.CINEMATIC;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeInt(cameras.size());
        for (Camera camera : cameras) {
            if (camera instanceof Camera.Movement) {
                buf.writeByte(0);
            } else if (camera instanceof Camera.Rotation) {
                buf.writeByte(1);
            } else {
                throw new IllegalArgumentException("Unknown camera type: " + camera.getClass());
            }
            camera.writePacket(buf);
        }
    }

    public static Media readPacket(final ByteArrayDataInput buf) {
        int size = buf.readInt();
        LinkedList<Camera> cameras = new LinkedList<>();
        for (int i = 0; i < size; i++) {
            int type = buf.readByte();
            if (type == 0) {
                cameras.add((Camera) Camera.Movement.readPacket(buf));
            } else if (type == 1) {
                cameras.add((Camera) Camera.Rotation.readPacket(buf));
            } else {
                throw new IllegalArgumentException("Unknown camera type: " + type);
            }
        }
        return new Cinematic(cameras);
    }
}
