package me.elb.mediaplayermod.model.media;

import lombok.experimental.UtilityClass;

@UtilityClass
public class MediaConstants {
    public static final String[] FONTS = {"minecraft", "Arial", "Helvetica", "Saw.otf", "Verdana", "Minecraft.otf", "Poppins"};
}
