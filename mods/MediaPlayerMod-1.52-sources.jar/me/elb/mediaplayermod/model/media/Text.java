package me.elb.mediaplayermod.model.media;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

import java.awt.Color;

public record Text(String string, double size, String fontName, Color color, float xOffset, float yOffset, long fadeIn, long duration, long fadeOut) implements Media {
    @Override
    public MediaType getType() {
        return MediaType.TEXT;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeUTF(this.string());
        buf.writeDouble(this.size());
        buf.writeUTF(this.fontName());
        buf.writeInt(this.color().getRGB());
        buf.writeFloat(this.xOffset());
        buf.writeFloat(this.yOffset());
        buf.writeLong(this.fadeIn());
        buf.writeLong(this.duration());
        buf.writeLong(this.fadeOut());
    }

    public static Media readPacket(final ByteArrayDataInput buf) {
        return new Text(buf.readUTF(), buf.readDouble(), buf.readUTF(), new Color(buf.readInt()), buf.readFloat(),
                buf.readFloat(), buf.readLong(), buf.readLong(), buf.readLong());
    }
}
