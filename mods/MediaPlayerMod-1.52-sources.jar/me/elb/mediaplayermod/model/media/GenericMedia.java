package me.elb.mediaplayermod.model.media;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record GenericMedia(String url) implements Media {
    @Override
    public MediaType getType() {
        return MediaType.ANY;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeUTF(this.url());
    }

    public static Media readPacket(final ByteArrayDataInput buf) {
        return new GenericMedia(buf.readUTF());
    }
}
