package me.elb.mediaplayermod.model.media;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record Blink(long fadeIn, long duration, long fadeOut) implements Media {
    @Override
    public MediaType getType() {
        return MediaType.BLINK;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeLong(this.fadeIn());
        buf.writeLong(this.duration());
        buf.writeLong(this.fadeOut());
    }

    public static Media readPacket(final ByteArrayDataInput buf) {
        return new Blink(buf.readLong(), buf.readLong(), buf.readLong());
    }
}
