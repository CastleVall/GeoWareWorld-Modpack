package me.elb.mediaplayermod.model.media;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

/**
 * Animacion reproducida fotograma a fotograma a partir de una carpeta de imagenes
 * dentro de {@code config/mediaplayer/images/<folder>}.
 *
 * <p>No hay fundidos. {@code fps} indica los fotogramas por segundo (velocidad de reproduccion).
 * {@code firstFrame}/{@code lastFrame} son los numeros de fotograma (inclusive) a reproducir;
 * si {@code firstFrame} es negativo se reproducen TODOS los fotogramas de la carpeta en orden.
 */
public record Animation(String folder, AnimationPosition position, int fps, int firstFrame, int lastFrame)
        implements Media {

    /** Sentinela para "todos los fotogramas de la carpeta". */
    public static final int ALL_FRAMES = -1;

    @Override
    public MediaType getType() {
        return MediaType.ANIMATION;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeUTF(this.folder());
        buf.writeInt(this.position().getId());
        buf.writeInt(this.fps());
        buf.writeInt(this.firstFrame());
        buf.writeInt(this.lastFrame());
    }

    public static Media readPacket(final ByteArrayDataInput buf) {
        String folder = buf.readUTF();
        AnimationPosition position = AnimationPosition.fromId(buf.readInt());
        int fps = buf.readInt();
        int firstFrame = buf.readInt();
        int lastFrame = buf.readInt();
        return new Animation(folder, position, fps, firstFrame, lastFrame);
    }
}
