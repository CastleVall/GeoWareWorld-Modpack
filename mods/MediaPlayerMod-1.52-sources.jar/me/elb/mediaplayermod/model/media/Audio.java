package me.elb.mediaplayermod.model.media;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

public record Audio(String url, String backupUrl, String name, String lyricsUrl, long startOffset) implements Media {
    public Audio(String url, String backupUrl) {
        this(url, backupUrl, null, null, 0L);
    }

    public Audio(String url, String backupUrl, String name) {
        this(url, backupUrl, name, null, 0L);
    }

    public Audio(String url, String backupUrl, String name, String lyricsUrl) {
        this(url, backupUrl, name, lyricsUrl, 0L);
    }

    @Override
    public MediaType getType() {
        return MediaType.AUDIO;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeUTF(this.url());
        buf.writeUTF(this.backupUrl() == null ? "" : this.backupUrl());
        buf.writeUTF(this.name() == null ? "" : this.name());
        buf.writeUTF(this.lyricsUrl() == null ? "" : this.lyricsUrl());
        buf.writeLong(this.startOffset());
    }

    public static Media readPacket(final ByteArrayDataInput buf) {
        String url = buf.readUTF();
        String backupUrl = buf.readUTF();
        String name = buf.readUTF();
        String lyricsUrl = buf.readUTF();
        long startOffset = buf.readLong();
        return new Audio(
                url,
                backupUrl.isEmpty() ? null : backupUrl,
                name.isEmpty() ? null : name,
                lyricsUrl.isEmpty() ? null : lyricsUrl,
                startOffset
        );
    }
}
