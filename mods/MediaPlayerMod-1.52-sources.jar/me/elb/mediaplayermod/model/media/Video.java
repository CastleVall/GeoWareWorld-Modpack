package me.elb.mediaplayermod.model.media;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

/**
 * Modelo de un vídeo a reproducir.
 *
 * Campos de región (regionX, regionY, regionW, regionH) en coordenadas normalizadas
 * 0..1 de la pantalla escalada: (0,0) = esquina superior izquierda, (1,1) = inferior derecha.
 * El vídeo se ajusta (letterbox) dentro de ese rectángulo manteniendo su relación de aspecto.
 * background = si se pinta un fondo negro detrás del vídeo dentro de la región
 * (false = transparente, ideal para superponer sobre un overlay como Setsumeisho).
 */
public record Video(String url, String backupUrl, FadeMode fadeMode,
                    long fadeIn, long fadeOut, boolean freezeScreen,
                    float regionX, float regionY, float regionW, float regionH,
                    boolean background,
                    boolean chromaKey, int chromaColor, float chromaTolerance) implements Media {

    /** Constructor de compatibilidad: sin chroma key. */
    public Video(String url, String backupUrl, FadeMode fadeMode,
                 long fadeIn, long fadeOut, boolean freezeScreen,
                 float regionX, float regionY, float regionW, float regionH,
                 boolean background) {
        this(url, backupUrl, fadeMode, fadeIn, fadeOut, freezeScreen,
                regionX, regionY, regionW, regionH, background, false, 0x00FF00, 0.25f);
    }

    /** Constructor de compatibilidad: pantalla completa con fondo negro (comportamiento clásico). */
    public Video(String url, String backupUrl, FadeMode fadeMode,
                 long fadeIn, long fadeOut, boolean freezeScreen) {
        this(url, backupUrl, fadeMode, fadeIn, fadeOut, freezeScreen,
                0f, 0f, 1f, 1f, true);
    }

    @Override
    public MediaType getType() {
        return MediaType.VIDEO;
    }

    @Override
    public void writePacket(ByteArrayDataOutput buf) {
        buf.writeUTF(this.url());
        buf.writeUTF(this.backupUrl() == null ? "" : this.backupUrl());
        buf.writeUTF(this.fadeMode().name());
        buf.writeLong(this.fadeIn());
        buf.writeLong(this.fadeOut());
        buf.writeBoolean(this.freezeScreen());
        buf.writeFloat(this.regionX());
        buf.writeFloat(this.regionY());
        buf.writeFloat(this.regionW());
        buf.writeFloat(this.regionH());
        buf.writeBoolean(this.background());
        buf.writeBoolean(this.chromaKey());
        buf.writeInt(this.chromaColor());
        buf.writeFloat(this.chromaTolerance());
    }

    public static Media readPacket(final ByteArrayDataInput buf) {
        String url = buf.readUTF();
        String backupUrl = buf.readUTF();
        FadeMode fadeMode = FadeMode.valueOf(buf.readUTF());
        long fadeIn = buf.readLong();
        long fadeOut = buf.readLong();
        boolean freezeScreen = buf.readBoolean();
        float regionX = buf.readFloat();
        float regionY = buf.readFloat();
        float regionW = buf.readFloat();
        float regionH = buf.readFloat();
        boolean background = buf.readBoolean();
        boolean chromaKey = buf.readBoolean();
        int chromaColor = buf.readInt();
        float chromaTolerance = buf.readFloat();
        return new Video(url, backupUrl, fadeMode, fadeIn, fadeOut, freezeScreen,
                regionX, regionY, regionW, regionH, background, chromaKey, chromaColor, chromaTolerance);
    }

    public enum FadeMode {
        NONE,
        BLACK,
        WHITE,
        TRANSPARENT
    }

    /**
     * Posiciones predefinidas en coordenadas normalizadas (x, y, ancho, alto).
     * Útil para colocar el vídeo rápido sin escribir coordenadas a mano.
     */
    public enum VideoRegion {
        FULLSCREEN   (0.000f, 0.000f, 1.000f, 1.000f, true),
        LEFT         (0.000f, 0.000f, 0.500f, 1.000f, false),
        RIGHT        (0.500f, 0.000f, 0.500f, 1.000f, false),
        TOP          (0.000f, 0.000f, 1.000f, 0.500f, false),
        BOTTOM       (0.000f, 0.500f, 1.000f, 0.500f, false),
        TOPLEFT      (0.000f, 0.000f, 0.500f, 0.500f, false),
        TOPRIGHT     (0.500f, 0.000f, 0.500f, 0.500f, false),
        BOTTOMLEFT   (0.000f, 0.500f, 0.500f, 0.500f, false),
        BOTTOMRIGHT  (0.500f, 0.500f, 0.500f, 0.500f, false),
        CENTER       (0.200f, 0.200f, 0.600f, 0.600f, false),
        // Coincide aproximadamente con el recuadro negro del overlay HEXA / Setsumeisho.
        // Afínalo con el modo "custom" si tu overlay cambia.
        HEXA         (0.408f, 0.180f, 0.487f, 0.560f, false);

        public final float x;
        public final float y;
        public final float w;
        public final float h;
        public final boolean background;

        VideoRegion(float x, float y, float w, float h, boolean background) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.background = background;
        }

        public static VideoRegion fromName(String name) {
            if (name == null) return FULLSCREEN;
            try {
                return VideoRegion.valueOf(name.trim().toUpperCase());
            } catch (IllegalArgumentException ex) {
                return FULLSCREEN;
            }
        }
    }
}
