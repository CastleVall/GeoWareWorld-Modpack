package me.elb.mediaplayermod.util;

import lombok.experimental.UtilityClass;

import java.awt.*;
import java.lang.reflect.Field;
import java.util.Random;

@UtilityClass
public class ColorUtil {
    private static final Random RANDOM = new Random();

    public static Color fromString(String color) {
        try {
            Field field = Class.forName("java.awt.Color").getField(color.toUpperCase());
            return (Color)field.get(null);
        } catch (Exception e) {
            try {
                return hexToColor(color);
            } catch (Exception e2) {
                try {
                    return new Color(Integer.parseInt(color));
                } catch (Exception e3) {
                    return new Color(RANDOM.nextInt(0xFFFFFF));
                }
            }
        }
    }

    public static Color hexToColor(String hex) {
        hex = hex.trim().replace("0x", "").replace("#", "");
        int red = Integer.parseInt(hex.substring(0, 2), 16);
        int green = Integer.parseInt(hex.substring(2, 4), 16);
        int blue = Integer.parseInt(hex.substring(4, 6), 16);
        return new Color(red, green, blue);
    }
}
