package me.elb.mediaplayermod.util;

import java.util.Locale;

/**
 * Parsea el prefijo de chroma key opcional en una url de video:
 *
 * <pre>
 *   chroma:&lt;color&gt;[:&lt;tolerancia&gt;]:&lt;url-real&gt;
 * </pre>
 *
 * Ejemplos:
 * <pre>
 *   chroma:green:videos/personaje.mov
 *   chroma:00ff00:videos/personaje.mov
 *   chroma:00ff00:0.3:videos/personaje.mov
 * </pre>
 *
 * Si no hay prefijo, devuelve {@code enabled=false} y la url tal cual. El color admite nombres
 * (green, magenta, blue, cyan, red, white, black) o hex de 6 digitos (con o sin '#').
 */
public final class ChromaUtil {
    private ChromaUtil() {}

    public record Spec(boolean enabled, int color, float tolerance, String url) {}

    private static final String PREFIX = "chroma:";
    public static final int DEFAULT_COLOR = 0x00FF00;
    public static final float DEFAULT_TOLERANCE = 0.25f;

    public static Spec parse(String raw) {
        if (raw == null || !raw.regionMatches(true, 0, PREFIX, 0, PREFIX.length())) {
            return new Spec(false, DEFAULT_COLOR, DEFAULT_TOLERANCE, raw);
        }
        String rest = raw.substring(PREFIX.length());
        int firstColon = rest.indexOf(':');
        if (firstColon <= 0) {
            // Mal formado: tratar como url normal sin chroma.
            return new Spec(false, DEFAULT_COLOR, DEFAULT_TOLERANCE, raw);
        }
        String colorStr = rest.substring(0, firstColon);
        String after = rest.substring(firstColon + 1);

        float tolerance = DEFAULT_TOLERANCE;
        String url = after;
        // Tolerancia opcional: solo si el primer segmento ANTES del proximo ':' es un numero.
        int nextColon = after.indexOf(':');
        if (nextColon > 0) {
            String maybeTol = after.substring(0, nextColon);
            try {
                tolerance = Float.parseFloat(maybeTol);
                url = after.substring(nextColon + 1);
            } catch (NumberFormatException ignored) {
                // No era tolerancia (p.ej. "https"): la url conserva todo 'after'.
            }
        }
        return new Spec(true, parseColor(colorStr), tolerance, url);
    }

    private static int parseColor(String s) {
        if (s == null) return DEFAULT_COLOR;
        String c = s.trim().toLowerCase(Locale.ROOT);
        switch (c) {
            case "green": case "verde": return 0x00FF00;
            case "magenta": case "pink": case "rosa": return 0xFF00FF;
            case "blue": case "azul": return 0x0000FF;
            case "cyan": case "celeste": return 0x00FFFF;
            case "red": case "rojo": return 0xFF0000;
            case "white": case "blanco": return 0xFFFFFF;
            case "black": case "negro": return 0x000000;
            default:
                if (c.startsWith("#")) c = c.substring(1);
                try {
                    return (int) (Long.parseLong(c, 16) & 0xFFFFFF);
                } catch (NumberFormatException e) {
                    return DEFAULT_COLOR;
                }
        }
    }
}
