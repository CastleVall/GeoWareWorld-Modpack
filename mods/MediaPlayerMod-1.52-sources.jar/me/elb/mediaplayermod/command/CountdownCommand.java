package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.command.provider.EnumerationSuggestionProvider;
import me.elb.mediaplayermod.model.media.Animation;
import me.elb.mediaplayermod.model.media.AnimationPosition;
import me.elb.mediaplayermod.model.media.Audio;
import me.elb.mediaplayermod.networking.packet.ServerPlayMediaPacket;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.Collection;
import java.util.List;

import static com.mojang.brigadier.arguments.IntegerArgumentType.getInteger;
import static com.mojang.brigadier.arguments.IntegerArgumentType.integer;
import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static com.mojang.brigadier.arguments.StringArgumentType.word;
import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2186.method_9312;
import static net.minecraft.class_2186.method_9308;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/**
 * {@code /countdown <targets> <segundos> [<position>]} (segundos 1..10)
 *
 * <p>Lanza a la vez la animacion por defecto "countdown" (fotograma a fotograma) y su audio,
 * reutilizando el sistema de animaciones y el de audio. El audio dura ~11&nbsp;s (los numeros
 * 10..1 mas un "GO" final) y esta timeado a 24&nbsp;fps; por eso la animacion se reproduce a esa
 * velocidad para no desfasarse. Si se piden menos de 10 segundos, tanto la animacion como el
 * audio arrancan en el punto exacto del numero pedido para que los pitidos cuadren.
 */
@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class CountdownCommand {

    /** Nombre de la carpeta de fotogramas (config/mediaplayer/images/countdown). */
    private static final String FOLDER = "countdown";
    /** Ruta local del audio (config/mediaplayer/audio/Countdown_SFX.wav). */
    private static final String AUDIO_URL = "audio/Countdown_SFX.wav";
    /** Ultimo fotograma de la animacion (la animacion va de 000 a 270). */
    private static final int LAST_FRAME = 270;
    /** Fotogramas por numero (cada numero dura 1 segundo a 24 fps). */
    private static final int FRAMES_PER_NUMBER = 24;
    /** Velocidad de reproduccion: el audio esta hecho a 24 fps. */
    private static final int FPS = 24;

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                method_9247("countdown")
                        .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "countdown", 2))
                        .then(method_9244("targets", method_9308())
                                .then(method_9244("segundos", integer(1, 10))
                                .executes(context -> execute(context.getSource(),
                                        method_9312(context, "targets"),
                                        getInteger(context, "segundos"),
                                        AnimationPosition.CENTER))
                                .then(method_9244("position", word())
                                .suggests(EnumerationSuggestionProvider.ANIMATION_POSITION_PROVIDER)
                                .executes(context -> execute(context.getSource(),
                                        method_9312(context, "targets"),
                                        getInteger(context, "segundos"),
                                        AnimationPosition.fromName(getString(context, "position"))))))));
    }

    /**
     * Fotograma en el que aparece cada numero. El "10" arranca en el 0 y cada numero siguiente
     * cae 24 fotogramas despues, comenzando en su destello (frames 25, 49, 73, ...).
     */
    private static int startFrameFor(int seconds) {
        if (seconds >= 10) {
            return 0;
        }
        return (10 - seconds) * FRAMES_PER_NUMBER + 1;
    }

    private static int execute(class_2168 source, Collection<class_3222> targets,
                               int seconds, AnimationPosition position) {
        if (targets == null || targets.isEmpty()) {
            class_3222 player = source.method_44023();
            if (player == null) {
                source.method_9213(class_2561.method_30163("Este comando debe ejecutarlo un jugador o indicar targets"));
                return 0;
            }
            targets = List.of(player);
        }
        int startFrame = startFrameFor(seconds);
        // Offset del audio = momento (ms) que corresponde a ese fotograma a 24 fps.
        long audioOffsetMs = Math.round(startFrame * 1000.0 / FPS);

        MediaPlayerMod mod = MediaPlayerMod.getInstance();
        // Animacion fotograma a fotograma desde el numero pedido hasta el final.
        mod.sendPacket(targets, new ServerPlayMediaPacket(
                new Animation(FOLDER, position, FPS, startFrame, LAST_FRAME)));
        // Audio sincronizado al mismo punto.
        mod.sendPacket(targets, new ServerPlayMediaPacket(
                new Audio(AUDIO_URL, null, "Countdown", null, audioOffsetMs)));

        int count = targets.size();
        source.method_9226(() -> class_2561.method_30163("Cuenta atras de " + seconds + " segundos para "
                + count + " jugadores"), false);
        return count;
    }
}
