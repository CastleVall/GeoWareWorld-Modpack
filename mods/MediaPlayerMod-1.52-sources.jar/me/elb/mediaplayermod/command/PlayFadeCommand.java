package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.model.media.Fade;
import me.elb.mediaplayermod.networking.packet.Packet;
import me.elb.mediaplayermod.networking.packet.ServerPlayMediaPacket;
import me.elb.mediaplayermod.util.ColorUtil;
import me.elb.mediaplayermod.command.provider.EnumerationSuggestionProvider;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.awt.*;
import java.util.Collection;
import java.util.List;

import static com.mojang.brigadier.arguments.BoolArgumentType.bool;
import static com.mojang.brigadier.arguments.BoolArgumentType.getBool;
import static com.mojang.brigadier.arguments.DoubleArgumentType.doubleArg;
import static com.mojang.brigadier.arguments.DoubleArgumentType.getDouble;
import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static com.mojang.brigadier.arguments.StringArgumentType.word;
import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2186.method_9312;
import static net.minecraft.class_2186.method_9308;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class PlayFadeCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        // Ademas del fundido clasico, "barver"/"barhor" son barras opacas tipo cine que se cierran
        // hasta toparse en el medio (barver = desde arriba y abajo, barhor = desde los lados) con
        // los mismos parametros: fadein = cerrarse, duration = pantalla cubierta, fadeout = abrirse.
        dispatcher.register(
                method_9247("playfade")
                        .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "playimage", 2))
                        .then(method_9244("targets", method_9308())
                                .then(method_9247("barver").then(fadeArgs(Fade.Style.BAR_VERTICAL)))
                                .then(method_9247("barhor").then(fadeArgs(Fade.Style.BAR_HORIZONTAL)))
                                .then(fadeArgs(Fade.Style.FULL))));
    }

    private static com.mojang.brigadier.builder.RequiredArgumentBuilder<class_2168, String> fadeArgs(Fade.Style style) {
        return method_9244("color", word())
                .suggests(EnumerationSuggestionProvider.COLOR_FADE_PROVIDER)
                .then(method_9244("fadein", doubleArg())
                .then(method_9244("duration", doubleArg())
                .then(method_9244("fadeout", doubleArg())
                .then(method_9244("freezeScreen", bool())
                .executes(context -> executePlayFade(context.getSource(), method_9312(context, "targets"),
                        getString(context, "color"), getDouble(context, "fadein"),
                        getDouble(context, "duration"), getDouble(context, "fadeout"),
                        getBool(context, "freezeScreen"), style))))));
    }

    private static int executePlayFade(class_2168 source, Collection<class_3222> targets, String colorString,
                                       double fadein, double duration, double fadeout, boolean freezeScreen, Fade.Style style) {
        if (targets == null) {
            class_3222 player = source.method_44023();
            if (player == null)
                return 0;
            targets = List.of(player);
        }
        if (targets.isEmpty())
            return 0;
        if (duration < 0 || duration > 60) {
            source.method_9226(() -> class_2561.method_30163("Duration must be between 0 and 60"), false);
            return 0;
        }
        Color color = ColorUtil.fromString(colorString);
        Packet packet = new ServerPlayMediaPacket(new Fade((long) (fadein * 1000), (long) (duration * 1000),
                (long) (fadeout * 1000), color.getRGB(), freezeScreen, style));
        MediaPlayerMod.getInstance().sendPacket(targets, packet);
        int count = targets.size();
        String styleName = switch (style) {
            case BAR_VERTICAL -> "barver ";
            case BAR_HORIZONTAL -> "barhor ";
            default -> "";
        };
        source.method_9226(() -> class_2561.method_30163("Playing fade " + styleName + colorString + " for " + count + " players"), false);
        return targets.size();
    }
}
