package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.command.provider.EnumerationSuggestionProvider;
import me.elb.mediaplayermod.model.media.Camera;
import me.elb.mediaplayermod.networking.packet.ServerPlayMediaPacket;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2277;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.Collection;

import static com.mojang.brigadier.arguments.BoolArgumentType.*;
import static com.mojang.brigadier.arguments.DoubleArgumentType.*;
import static com.mojang.brigadier.arguments.FloatArgumentType.*;
import static com.mojang.brigadier.arguments.StringArgumentType.*;
import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2186.method_9312;
import static net.minecraft.class_2186.method_9308;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class PlayCameraCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                method_9247("playcamera")
                        .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "playcamera", 2))
                        .then(method_9244("targets", method_9308())
                                .then(method_9247("attached")
                                        .then(movementArgs(false)))
                                .then(method_9247("detached")
                                        .then(movementArgs(true)))
                                .then(method_9247("limit")
                                        .then(method_9244("coordinate", word())
                                                .suggests(EnumerationSuggestionProvider.CAMERA_COORDINATE_PROVIDER)
                                                .then(method_9247("clear")
                                                        .executes(ctx -> executeLimitClear(ctx.getSource(),
                                                                method_9312(ctx, "targets"),
                                                                getString(ctx, "coordinate"))))
                                                .then(method_9244("min", doubleArg())
                                                        .executes(ctx -> executeLimit(ctx.getSource(),
                                                                method_9312(ctx, "targets"),
                                                                getString(ctx, "coordinate"),
                                                                getDouble(ctx, "min"),
                                                                getDouble(ctx, "min")))
                                                        .then(method_9244("max", doubleArg())
                                                                .executes(ctx -> executeLimit(ctx.getSource(),
                                                                        method_9312(ctx, "targets"),
                                                                        getString(ctx, "coordinate"),
                                                                        getDouble(ctx, "min"),
                                                                        getDouble(ctx, "max")))))))
                                .then(method_9247("rotate")
                                        .then(method_9247("yaw")
                                                .then(method_9244("yaw_value", floatArg(-360, 360))
                                                .then(method_9244("yaw_load_time", doubleArg(0))
                                                        .executes(ctx -> executeRotation(ctx.getSource(),
                                                                method_9312(ctx, "targets"), true,
                                                                getFloat(ctx, "yaw_value"),
                                                                getDouble(ctx, "yaw_load_time"))))))
                                        .then(method_9247("pitch")
                                                .then(method_9244("pitch_value", floatArg(-90, 90))
                                                .then(method_9244("pitch_load_time", doubleArg(0))
                                                        .executes(ctx -> executeRotation(ctx.getSource(),
                                                                method_9312(ctx, "targets"), false,
                                                                getFloat(ctx, "pitch_value"),
                                                                getDouble(ctx, "pitch_load_time")))))))));
    }

    private static com.mojang.brigadier.builder.RequiredArgumentBuilder<class_2168, Double> movementArgs(boolean detached) {
        var inverted = method_9244("inverted", bool())
                .executes(ctx -> {
                    class_243 p = class_2277.method_9736(ctx, "pos");
                    return executeMovement(ctx.getSource(),
                            method_9312(ctx, "targets"), detached,
                            getDouble(ctx, "load_time"),
                            p.field_1352, p.field_1351, p.field_1350,
                            getFloat(ctx, "yaw"), getFloat(ctx, "pitch"),
                            getBool(ctx, "inverted"));
                });

        var pitch = method_9244("pitch", floatArg(-90, 90))
                .executes(ctx -> {
                    class_243 p = class_2277.method_9736(ctx, "pos");
                    return executeMovement(ctx.getSource(),
                            method_9312(ctx, "targets"), detached,
                            getDouble(ctx, "load_time"),
                            p.field_1352, p.field_1351, p.field_1350,
                            getFloat(ctx, "yaw"), getFloat(ctx, "pitch"), false);
                })
                .then(inverted);

        var yaw = method_9244("yaw", floatArg(-180, 180))
                .then(pitch);

        var pos = method_9244("pos", class_2277.method_9737())
                .executes(ctx -> {
                    class_243 p = class_2277.method_9736(ctx, "pos");
                    return executeMovement(ctx.getSource(),
                            method_9312(ctx, "targets"), detached,
                            getDouble(ctx, "load_time"),
                            p.field_1352, p.field_1351, p.field_1350,
                            0, 0, false);
                })
                .then(yaw);

        return method_9244("load_time", doubleArg(0))
                .then(pos);
    }

    private static int executeMovement(class_2168 source, Collection<class_3222> targets,
                                       boolean detached, double loadTime,
                                       double x, double y, double z,
                                       float yaw, float pitch, boolean inverted) {
        long lt = (long) (loadTime * 1000L);
        MediaPlayerMod.getInstance().sendPacket(targets,
                new ServerPlayMediaPacket(new Camera.Movement(detached, x, y, z, yaw, pitch, inverted, lt)));
        int count = targets.size();
        String mode = detached ? "detached" : "attached";
        source.method_9226(() -> class_2561.method_30163("Playing camera " + mode + " for " + count + " players"), false);
        return count;
    }

    private static int executeLimit(class_2168 source, Collection<class_3222> targets,
                                    String coordinateStr, double min, double max) {
        Camera.Coordinate coordinate = Camera.Coordinate.valueOf(coordinateStr.toUpperCase());
        if (min > max) {
            source.method_9213(class_2561.method_30163("min must be <= max"));
            return 0;
        }
        MediaPlayerMod.getInstance().sendPacket(targets,
                new ServerPlayMediaPacket(new Camera.Limit(coordinate, min, max)));
        int count = targets.size();
        source.method_9226(() -> class_2561.method_30163("Set camera limit " + coordinateStr + " for " + count + " players"), false);
        return count;
    }

    private static int executeLimitClear(class_2168 source, Collection<class_3222> targets,
                                         String coordinateStr) {
        Camera.Coordinate coordinate = Camera.Coordinate.valueOf(coordinateStr.toUpperCase());
        MediaPlayerMod.getInstance().sendPacket(targets,
                new ServerPlayMediaPacket(new Camera.Limit(coordinate)));
        int count = targets.size();
        source.method_9226(() -> class_2561.method_30163("Cleared camera limit " + coordinateStr + " for " + count + " players"), false);
        return count;
    }

    private static int executeRotation(class_2168 source, Collection<class_3222> targets,
                                       boolean horizontal, float value, double loadTime) {
        long lt = (long) (loadTime * 1000L);
        MediaPlayerMod.getInstance().sendPacket(targets,
                new ServerPlayMediaPacket(new Camera.Rotation(horizontal, value, lt)));
        int count = targets.size();
        String axis = horizontal ? "yaw" : "pitch";
        source.method_9226(() -> class_2561.method_30163("Rotating camera " + axis + " for " + count + " players"), false);
        return count;
    }
}
