package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.model.media.Blink;
import me.elb.mediaplayermod.networking.packet.ServerPlayMediaPacket;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.Collection;

import static com.mojang.brigadier.arguments.DoubleArgumentType.*;
import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2186.method_9312;
import static net.minecraft.class_2186.method_9308;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class PlayBlinkCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                method_9247("playblink")
                        .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "playblink", 2))
                        .then(method_9244("targets", method_9308())
                                .then(method_9244("in", doubleArg(0))
                                .then(method_9244("duration", doubleArg(0))
                                .then(method_9244("out", doubleArg(0))
                                        .executes(ctx -> execute(ctx.getSource(),
                                                method_9312(ctx, "targets"),
                                                getDouble(ctx, "in"),
                                                getDouble(ctx, "duration"),
                                                getDouble(ctx, "out"))))))));
    }

    private static int execute(class_2168 source, Collection<class_3222> targets,
                               double in, double duration, double out) {
        long fadeIn = (long) (Math.max(0, in) * 1000L);
        long dur = duration == 0 ? -1 : (long) (duration * 1000L);
        long fadeOut = (long) (Math.max(0, out) * 1000L);
        MediaPlayerMod.getInstance().sendPacket(targets, new ServerPlayMediaPacket(new Blink(fadeIn, dur, fadeOut)));
        int count = targets.size();
        source.method_9226(() -> class_2561.method_30163("Playing blink for " + count + " players"), false);
        return count;
    }
}
