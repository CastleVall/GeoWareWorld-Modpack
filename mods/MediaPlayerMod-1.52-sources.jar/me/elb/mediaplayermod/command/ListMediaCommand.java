package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.server.MediaPlayerInfo;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.List;

import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2186.method_9315;
import static net.minecraft.class_2186.method_9305;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class ListMediaCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                method_9247("listmedia")
                        .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "listmedia", 2))
                        .executes(ctx -> execute(ctx.getSource(), ctx.getSource().method_44023()))
                        .then(method_9244("target", method_9305())
                                .executes(ctx -> execute(ctx.getSource(), method_9315(ctx, "target")))));
    }

    private static int execute(class_2168 source, class_3222 target) {
        if (target == null) {
            source.method_9213(class_2561.method_30163("Must specify a player or run as a player"));
            return 0;
        }
        List<MediaPlayerInfo<class_3222>> list = MediaPlayerMod.getInstance().getPlayerInfoMap().get(target);
        if (list == null || list.isEmpty()) {
            source.method_9226(() -> class_2561.method_30163(target.method_5477().getString() + " is not playing any media"), false);
            return 0;
        }
        StringBuilder sb = new StringBuilder(target.method_5477().getString() + "'s media:");
        for (MediaPlayerInfo<class_3222> info : list) {
            sb.append("\n - ").append(info.getUuid()).append(" (").append(info.getType()).append(")");
        }
        String msg = sb.toString();
        source.method_9226(() -> class_2561.method_30163(msg), false);
        return list.size();
    }
}
