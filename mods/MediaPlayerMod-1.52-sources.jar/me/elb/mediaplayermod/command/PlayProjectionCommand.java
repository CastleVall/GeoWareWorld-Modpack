package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.model.media.Projection;
import me.elb.mediaplayermod.model.media.ProjectionOperation;
import me.elb.mediaplayermod.networking.packet.Packet;
import me.elb.mediaplayermod.networking.packet.ServerPlayMediaPacket;
import me.elb.mediaplayermod.server.ProjectionWandManager;
import me.elb.mediaplayermod.server.ServerProjectionManager;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2262;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import static com.mojang.brigadier.arguments.BoolArgumentType.*;
import static com.mojang.brigadier.arguments.IntegerArgumentType.*;
import static com.mojang.brigadier.arguments.StringArgumentType.*;
import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class PlayProjectionCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
            method_9247("playprojection")
                .requires(src -> Permissions.check(src, COMMAND_PERMISSION + "playprojection", 2))

                .then(method_9247("create")
                    .then(method_9244("id", word())
                    .then(method_9244("pos1", class_2262.method_9698())
                    .then(method_9244("pos2", class_2262.method_9698())

                        .executes(ctx -> create(ctx.getSource(),
                            getString(ctx,"id"),
                            class_2262.method_48299(ctx,"pos1"),
                            class_2262.method_48299(ctx,"pos2"),
                            0, 0, 0, ""))

                        .then(method_9244("url", greedyString())
                            .executes(ctx -> create(ctx.getSource(),
                                getString(ctx,"id"),
                                class_2262.method_48299(ctx,"pos1"),
                                class_2262.method_48299(ctx,"pos2"),
                                0, 0, 0, getString(ctx,"url"))))

                        .then(method_9244("rotX", integer())
                        .then(method_9244("rotY", integer())
                        .then(method_9244("rotZ", integer())

                            .executes(ctx -> create(ctx.getSource(),
                                getString(ctx,"id"),
                                class_2262.method_48299(ctx,"pos1"),
                                class_2262.method_48299(ctx,"pos2"),
                                getInteger(ctx,"rotX"), getInteger(ctx,"rotY"), getInteger(ctx,"rotZ"), ""))

                            .then(method_9244("url", greedyString())
                                .executes(ctx -> create(ctx.getSource(),
                                    getString(ctx,"id"),
                                    class_2262.method_48299(ctx,"pos1"),
                                    class_2262.method_48299(ctx,"pos2"),
                                    getInteger(ctx,"rotX"), getInteger(ctx,"rotY"), getInteger(ctx,"rotZ"),
                                    getString(ctx,"url")))))))))))

                .then(method_9247("place")
                    .then(method_9244("id", word())

                        .executes(ctx -> createFromSelection(ctx.getSource(), getString(ctx,"id"), ""))

                        .then(method_9244("url", greedyString())
                            .executes(ctx -> createFromSelection(ctx.getSource(),
                                getString(ctx,"id"), getString(ctx,"url"))))))

                .then(method_9247("play")
                    .then(method_9244("id", word())
                        .suggests(PlayProjectionCommand::suggestIds)
                        .then(method_9244("url", greedyString())
                            .executes(ctx -> playOnScreen(ctx.getSource(),
                                getString(ctx,"id"), getString(ctx,"url"))))))

                .then(method_9247("stop")
                    .then(method_9244("id", word())
                        .suggests(PlayProjectionCommand::suggestIds)
                        .executes(ctx -> control(ctx.getSource(),
                            getString(ctx,"id"), ProjectionOperation.Op.STOP))))

                .then(method_9247("stopall")
                    .executes(ctx -> stopAll(ctx.getSource())))

                .then(method_9247("remove")
                    .then(method_9244("id", word())
                        .suggests(PlayProjectionCommand::suggestIds)
                        .executes(ctx -> removeScreen(ctx.getSource(), getString(ctx,"id")))))

                .then(method_9247("removeall")
                    .executes(ctx -> removeAll(ctx.getSource())))

                .then(method_9247("pause")
                    .then(method_9244("id", word())
                        .suggests(PlayProjectionCommand::suggestIds)
                        .executes(ctx -> control(ctx.getSource(),
                            getString(ctx,"id"), ProjectionOperation.Op.PAUSE))))
                .then(method_9247("resume")
                    .then(method_9244("id", word())
                        .suggests(PlayProjectionCommand::suggestIds)
                        .executes(ctx -> control(ctx.getSource(),
                            getString(ctx,"id"), ProjectionOperation.Op.RESUME))))

                .then(method_9247("loop")
                    .then(method_9244("id", word())
                        .suggests(PlayProjectionCommand::suggestIds)
                        .then(method_9244("value", bool())
                            .executes(ctx -> control(ctx.getSource(), getString(ctx,"id"),
                                    getBool(ctx,"value") ? ProjectionOperation.Op.LOOP_ON
                                                         : ProjectionOperation.Op.LOOP_OFF)))))

                .then(method_9247("wand")
                    .executes(ctx -> giveWand(ctx.getSource())))
                .then(method_9247("pos")
                    .executes(ctx -> showPos(ctx.getSource())))

                .then(method_9247("list")
                    .executes(ctx -> list(ctx.getSource())))
        );
    }

    private static CompletableFuture<Suggestions> suggestIds(CommandContext<class_2168> ctx, SuggestionsBuilder b) {
        ServerProjectionManager.listIds().forEach(b::suggest);
        return b.buildFuture();
    }

    private static void sendToAll(Packet packet) {
        MediaPlayerMod mod = MediaPlayerMod.getInstance();
        if (mod.getServer() != null) {
            List<class_3222> players = mod.getServer().getPlayerManager().getPlayerList();
            mod.sendPacket(players, packet);
        }
    }

    private static int giveWand(class_2168 source) {
        try {
            class_3222 player = source.method_9207();
            player.method_31548().method_7398(ProjectionWandManager.createWand());
            source.method_9226(() -> class_2561.method_30163("[Projection] Wand entregado. Clic izquierdo = pos1, clic derecho = pos2"), false);
            return 1;
        } catch (Exception e) {
            source.method_9213(class_2561.method_30163("[Projection] Solo jugadores pueden recibir el wand"));
            return 0;
        }
    }

    private static int showPos(class_2168 source) {
        try {
            class_3222 player = source.method_9207();
            class_2338 p1 = ProjectionWandManager.getPos1(player.method_5667());
            class_2338 p2 = ProjectionWandManager.getPos2(player.method_5667());
            String s1 = p1 != null ? p1.method_23854() : "no seleccionado";
            String s2 = p2 != null ? p2.method_23854() : "no seleccionado";
            source.method_9226(() -> class_2561.method_30163("[Projection] Pos1: " + s1 + "  |  Pos2: " + s2), false);
            return 1;
        } catch (Exception e) {
            source.method_9213(class_2561.method_30163("[Projection] Solo jugadores pueden ver la seleccion"));
            return 0;
        }
    }

    private static int createFromSelection(class_2168 source, String id, String url) {
        try {
            class_3222 player = source.method_9207();
            if (!ProjectionWandManager.hasSelection(player.method_5667())) {
                source.method_9213(class_2561.method_30163("[Projection] Sin seleccion. Usa /playprojection wand y selecciona dos bloques"));
                return 0;
            }
            class_2338[] pair = orientedPair(
                    ProjectionWandManager.getPos1(player.method_5667()),
                    ProjectionWandManager.getPos2(player.method_5667()),
                    player.method_5735());
            class_2338 p1 = pair[0], p2 = pair[1];
            return create(source, id, p1, p2, 0, 0, 0, url);
        } catch (Exception e) {
            source.method_9213(class_2561.method_30163("[Projection] Solo jugadores pueden usar la seleccion del wand"));
            return 0;
        }
    }

    private static int create(class_2168 source, String id,
                               class_2338 pos1, class_2338 pos2,
                               int rotX, int rotY, int rotZ, String url) {
        int x1 = pos1.method_10263(), y1 = pos1.method_10264(), z1 = pos1.method_10260();
        int x2 = pos2.method_10263(), y2 = pos2.method_10264(), z2 = pos2.method_10260();
        me.elb.mediaplayermod.util.ChromaUtil.Spec chroma = me.elb.mediaplayermod.util.ChromaUtil.parse(url);
        Projection projection = new Projection(id, chroma.url(), x1, y1, z1, x2, y2, z2, rotX, rotY, rotZ,
                chroma.enabled(), chroma.color(), chroma.tolerance());
        ServerProjectionManager.add(projection);
        if (chroma.url() != null && !chroma.url().isEmpty()) {
            ServerProjectionManager.markStarted(id);
        }
        sendToAll(new ServerPlayMediaPacket(projection));
        String urlInfo = (chroma.url() == null || chroma.url().isEmpty()) ? "sin video"
                : chroma.url() + (chroma.enabled() ? " (chroma)" : "");
        source.method_9226(() -> class_2561.method_30163("[Projection] Pantalla '" + id + "' creada en ("
                + x1 + "," + y1 + "," + z1 + ") -> (" + x2 + "," + y2 + "," + z2
                + ") rotX=" + rotX + " rotY=" + rotY + " rotZ=" + rotZ
                + " | " + urlInfo), false);
        return 1;
    }

    private static int playOnScreen(class_2168 source, String id, String url) {
        if (!ServerProjectionManager.has(id)) {
            source.method_9213(class_2561.method_30163("[Projection] Pantalla no encontrada: '" + id + "'. Crea una con /playprojection create"));
            return 0;
        }

        ServerProjectionManager.getAll().stream()
                .filter(p -> p.id().equals(id)).findFirst()
                .ifPresent(old -> {
                    me.elb.mediaplayermod.util.ChromaUtil.Spec chroma = me.elb.mediaplayermod.util.ChromaUtil.parse(url);
                    Projection updated = new Projection(id, chroma.url(), old.x1(), old.y1(), old.z1(),
                            old.x2(), old.y2(), old.z2(), old.rotX(), old.rotY(), old.rotZ(),
                            chroma.enabled(), chroma.color(), chroma.tolerance());
                    ServerProjectionManager.add(updated);
                    ServerProjectionManager.markStarted(id);
                    sendToAll(new ServerPlayMediaPacket(updated));
                });
        source.method_9226(() -> class_2561.method_30163("[Projection] Reproduciendo en '" + id + "': " + url), false);
        return 1;
    }

    private static int control(class_2168 source, String id, ProjectionOperation.Op op) {
        switch (op) {
            case STOP -> ServerProjectionManager.markStopped(id);
            case PAUSE -> ServerProjectionManager.markPaused(id);
            case RESUME -> ServerProjectionManager.markResumed(id);
            case LOOP_ON -> ServerProjectionManager.setLoop(id, true);
            case LOOP_OFF -> ServerProjectionManager.setLoop(id, false);
            default -> { }
        }
        sendToAll(new ServerPlayMediaPacket(new ProjectionOperation(id, op)));
        source.method_9226(() -> class_2561.method_30163("[Projection] " + op.name().toLowerCase() + " -> '" + id + "'"), false);
        return 1;
    }

    private static int stopAll(class_2168 source) {
        List<String> ids = ServerProjectionManager.listIds();

        ServerProjectionManager.markAllStopped();
        ids.forEach(id -> sendToAll(new ServerPlayMediaPacket(new ProjectionOperation(id, ProjectionOperation.Op.STOP))));
        source.method_9226(() -> class_2561.method_30163("[Projection] Video detenido en " + ids.size() + " pantalla(s) (las pantallas permanecen)"), false);
        return ids.size();
    }

    private static int removeScreen(class_2168 source, String id) {
        if (!ServerProjectionManager.has(id)) {
            source.method_9213(class_2561.method_30163("[Projection] Pantalla no encontrada: '" + id + "'"));
            return 0;
        }
        sendToAll(new ServerPlayMediaPacket(new ProjectionOperation(id, ProjectionOperation.Op.REMOVE)));
        ServerProjectionManager.remove(id);
        source.method_9226(() -> class_2561.method_30163("[Projection] Pantalla '" + id + "' eliminada"), false);
        return 1;
    }

    private static int removeAll(class_2168 source) {
        List<String> ids = ServerProjectionManager.listIds();
        ids.forEach(id -> sendToAll(new ServerPlayMediaPacket(new ProjectionOperation(id, ProjectionOperation.Op.REMOVE))));
        ServerProjectionManager.removeAll();
        source.method_9226(() -> class_2561.method_30163("[Projection] Eliminadas " + ids.size() + " pantalla(s)"), false);
        return ids.size();
    }

    private static int list(class_2168 source) {
        List<String> ids = ServerProjectionManager.listIds();
        if (ids.isEmpty()) {
            source.method_9226(() -> class_2561.method_30163("[Projection] Sin pantallas activas"), false);
        } else {
            source.method_9226(() -> class_2561.method_30163("[Projection] Pantallas: " + String.join(", ", ids)), false);
        }
        return ids.size();
    }

    private static class_2338[] orientedPair(class_2338 p1, class_2338 p2, class_2350 facing) {
        double dx = p2.method_10263() - p1.method_10263();
        double dz = p2.method_10260() - p1.method_10260();
        double dot = (-dz) * facing.method_10148() + dx * facing.method_10165();
        return dot > 0 ? new class_2338[]{p2, p1} : new class_2338[]{p1, p2};
    }
}
