package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import me.elb.mediaplayermod.screenhandler.ModScreenHandlers;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2186.method_9315;
import static net.minecraft.class_2186.method_9305;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/** /seeinv <jugador>: abre el inventario compartido del jugador objetivo para el admin. */
@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class SeeInvCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(method_9247("seeinv")
                .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "seeinv", 2))
                .then(method_9244("target", method_9305())
                        .executes(ctx -> {
                            class_3222 admin = ctx.getSource().method_9207();
                            class_3222 target = method_9315(ctx, "target");
                            ModScreenHandlers.open(admin, target);
                            ctx.getSource().method_9226(
                                    () -> class_2561.method_43470("Abriendo inventario de " + target.method_5477().getString()), false);
                            return 1;
                        })));
    }
}
