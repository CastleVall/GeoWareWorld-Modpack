package me.elb.mediaplayermod.command.provider;

import com.mojang.brigadier.suggestion.SuggestionProvider;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.utils.FileEncryption;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_2960;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Stream;

/**
 * Sugerencias de autocompletado de archivos locales (videos, audio, subtitulos, tutoriales,
 * animaciones) que muestran SOLO el nombre limpio del archivo (sin ruta ni extension).
 *
 * <p>Todas se registran con {@link net.minecraft.class_2321} para que
 * el <b>cliente</b> las resuelva localmente contra su propia carpeta {@code config/mediaplayer}.
 * Asi el autocompletado tambien funciona dentro de servidores (antes se resolvian en el servidor,
 * que no tiene los archivos locales del jugador, por eso no aparecia nada).
 */
public final class MediaSuggestions {

    private MediaSuggestions() {}

    private static final Set<String> VIDEO_EXTS = Set.of("mp4", "mov", "avi", "mkv", "wmv", "flv", "webm");
    private static final Set<String> AUDIO_EXTS = Set.of("mp3", "wav", "flac", "ogg");
    private static final Set<String> YML_EXTS = Set.of("yml", "yaml");
    private static final Set<String> MEDIA_EXTS = new TreeSet<>() {{
        addAll(VIDEO_EXTS);
        addAll(AUDIO_EXTS);
    }};

    /** Carpetas (relativas a config/mediaplayer) donde buscar cada tipo de archivo. */
    private static final List<String> VIDEO_DIRS = List.of("videos", "overlays_player/videos");
    private static final List<String> AUDIO_DIRS = List.of("audio", "overlays_player/songs", "overlays_player/audio");
    private static final List<String> MEDIA_DIRS = List.of("videos", "audio", "overlays_player/videos", "overlays_player/songs", "overlays_player/audio");

    public static SuggestionProvider<class_2168> VIDEOS;
    public static SuggestionProvider<class_2168> AUDIO;
    public static SuggestionProvider<class_2168> MEDIA;
    public static SuggestionProvider<class_2168> SUBTITLES;
    public static SuggestionProvider<class_2168> TUTORIALS;
    public static SuggestionProvider<class_2168> ANIMATIONS;
    public static SuggestionProvider<class_2168> IMAGES;

    private static boolean registered = false;

    /**
     * Registra todas las sugerencias. Debe llamarse una sola vez al iniciar el mod, en AMBOS lados
     * (cliente y servidor), por eso se invoca desde {@code onInitialize()} y no al registrar comandos.
     */
    public static synchronized void register() {
        if (registered) return;
        registered = true;

        VIDEOS = reg("local_videos", (ctx, builder) ->
                class_2172.method_9265(cleanNames(VIDEO_DIRS, VIDEO_EXTS), builder));
        AUDIO = reg("local_audio", (ctx, builder) ->
                class_2172.method_9265(cleanNames(AUDIO_DIRS, AUDIO_EXTS), builder));
        MEDIA = reg("local_media", (ctx, builder) ->
                class_2172.method_9265(cleanNames(MEDIA_DIRS, MEDIA_EXTS), builder));
        SUBTITLES = reg("local_subtitles", (ctx, builder) ->
                class_2172.method_9265(cleanNames(List.of("subtitulos"), YML_EXTS), builder));
        TUTORIALS = reg("local_tutorials", (ctx, builder) ->
                class_2172.method_9265(cleanNames(List.of("tutorial"), YML_EXTS), builder));
        ANIMATIONS = reg("local_animations", (ctx, builder) ->
                class_2172.method_9265(subfolders("images"), builder));
        IMAGES = reg("local_images", (ctx, builder) ->
                class_2172.method_9265(imageNames(), builder));
    }

    private static SuggestionProvider<class_2168> reg(String id, SuggestionProvider<class_2172> provider) {
        return net.minecraft.class_2321.method_10022(
                class_2960.method_60655(MediaPlayerMod.MOD_ID, id), provider);
    }

    private static Path base() {
        return FabricLoader.getInstance().getConfigDir().resolve("mediaplayer");
    }

    /** Nombres limpios (sin ruta ni extension) de los archivos con las extensiones dadas. */
    private static Iterable<String> cleanNames(List<String> folders, Set<String> extensions) {
        Set<String> names = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        Path base = base();
        for (String folder : folders) {
            Path dir = base.resolve(folder);
            if (!Files.isDirectory(dir)) continue;
            try (Stream<Path> walk = Files.walk(dir, 8)) {
                walk.filter(Files::isRegularFile)
                        .filter(p -> accept(p, extensions))
                        .map(p -> stripExtension(p.getFileName().toString()))
                        .forEach(names::add);
            } catch (Exception ignored) {
            }
        }
        return names;
    }

    private static final Set<String> IMAGE_EXTS = Set.of("png", "jpg", "jpeg", "gif", "bmp");

    /**
     * Nombres limpios de las imagenes directamente dentro de {@code config/mediaplayer/images}.
     * A proposito NO recorre las subcarpetas: son fotogramas de animaciones ({@code /playanimation})
     * y llenarian el autocompletado con cientos de entradas.
     */
    private static Iterable<String> imageNames() {
        Set<String> names = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        Path dir = base().resolve("images");
        if (Files.isDirectory(dir)) {
            try (Stream<Path> list = Files.list(dir)) {
                list.filter(Files::isRegularFile)
                        .filter(p -> accept(p, IMAGE_EXTS))
                        .map(p -> stripExtension(p.getFileName().toString()))
                        .forEach(names::add);
            } catch (Exception ignored) {
            }
        }
        return names;
    }

    /** Nombres de las subcarpetas de {@code config/mediaplayer/<folder>} (animaciones). */
    private static Iterable<String> subfolders(String folder) {
        Set<String> names = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        Path dir = base().resolve(folder);
        if (Files.isDirectory(dir)) {
            try (Stream<Path> list = Files.list(dir)) {
                list.filter(Files::isDirectory)
                        .map(p -> p.getFileName().toString())
                        .forEach(names::add);
            } catch (Exception ignored) {
            }
        }
        return names;
    }

    private static boolean accept(Path p, Set<String> extensions) {
        String name = p.getFileName().toString().toLowerCase(Locale.ROOT);
        if (name.endsWith(FileEncryption.EXTENSION)) return true; // archivos cifrados .enc
        int dot = name.lastIndexOf('.');
        return dot >= 0 && extensions.contains(name.substring(dot + 1));
    }

    /** Quita la extension {@code .enc} (si existe) y la extension real del nombre. */
    private static String stripExtension(String name) {
        String n = name;
        if (n.toLowerCase(Locale.ROOT).endsWith(FileEncryption.EXTENSION)) {
            n = n.substring(0, n.length() - FileEncryption.EXTENSION.length());
        }
        int dot = n.lastIndexOf('.');
        return dot > 0 ? n.substring(0, dot) : n;
    }
}
