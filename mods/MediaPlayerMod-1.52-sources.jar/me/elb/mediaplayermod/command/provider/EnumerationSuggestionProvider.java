package me.elb.mediaplayermod.command.provider;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import me.elb.mediaplayermod.client.sound.MediaSoundCategory;
import me.elb.mediaplayermod.model.media.Camera;
import me.elb.mediaplayermod.model.media.MediaConstants;
import me.elb.mediaplayermod.model.media.Subtitles;
import me.elb.mediaplayermod.model.media.Video;
import me.elb.mediaplayermod.model.option.ClientOptions;
import net.minecraft.class_2168;
import net.minecraft.class_3419;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class EnumerationSuggestionProvider implements SuggestionProvider<class_2168> {

    public static final SuggestionProvider<class_2168> VIDEO_FADE_PROVIDER =
            new EnumerationSuggestionProvider(Video.FadeMode.values());

    public static final SuggestionProvider<class_2168> COLOR_FADE_PROVIDER =
            new EnumerationSuggestionProvider(List.of("black", "white", "red", "green").toArray());

    public static final SuggestionProvider<class_2168> COLORS_PROVIDER =
            new EnumerationSuggestionProvider(new Object[]{"white", "black", "red", "green", "blue", "yellow", "orange"});

    public static final SuggestionProvider<class_2168> FONTS_PROVIDER =
            new EnumerationSuggestionProvider(MediaConstants.FONTS);

    public static final SuggestionProvider<class_2168> SUBTITLES_BACKGROUND_PROVIDER =
            new EnumerationSuggestionProvider(Subtitles.Background.values());

    public static final SuggestionProvider<class_2168> CAMERA_COORDINATE_PROVIDER =
            new EnumerationSuggestionProvider(Camera.Coordinate.values());

    public static final SuggestionProvider<class_2168> CLIENT_OPTIONS_PROVIDER =
            new EnumerationSuggestionProvider(ClientOptions.values());

    public static final SuggestionProvider<class_2168> ANIMATION_POSITION_PROVIDER =
            new EnumerationSuggestionProvider(me.elb.mediaplayermod.model.media.AnimationPosition.values());

    public static final SuggestionProvider<class_2168> SOUND_CATEGORIES_PROVIDER;

    static {
        if (net.fabricmc.loader.api.FabricLoader.getInstance().getEnvironmentType() == net.fabricmc.api.EnvType.CLIENT) {
            Object[] soundCategories = new Object[class_3419.values().length + 3];
            System.arraycopy(class_3419.values(), 0, soundCategories, 0, class_3419.values().length);
            soundCategories[soundCategories.length - 3] = MediaSoundCategory.VIDEO;
            soundCategories[soundCategories.length - 2] = MediaSoundCategory.AUDIO;
            soundCategories[soundCategories.length - 1] = MediaSoundCategory.PROJECTION;
            SOUND_CATEGORIES_PROVIDER = new EnumerationSuggestionProvider(soundCategories);
        } else {
            Object[] soundCategories = new Object[class_3419.values().length + 3];
            System.arraycopy(class_3419.values(), 0, soundCategories, 0, class_3419.values().length);
            soundCategories[soundCategories.length - 3] = "video";
            soundCategories[soundCategories.length - 2] = "audio";
            soundCategories[soundCategories.length - 1] = "projection";
            SOUND_CATEGORIES_PROVIDER = new EnumerationSuggestionProvider(soundCategories);
        }
    }

    private final Object[] values;

    public EnumerationSuggestionProvider(Object[] values) {
        this.values = values;
    }

    @Override
    public CompletableFuture<Suggestions> getSuggestions(CommandContext<class_2168> context, SuggestionsBuilder builder) {
        for (Object object : values) {
            builder.suggest(object.toString().toLowerCase());
        }
        return builder.buildFuture();
    }
}
