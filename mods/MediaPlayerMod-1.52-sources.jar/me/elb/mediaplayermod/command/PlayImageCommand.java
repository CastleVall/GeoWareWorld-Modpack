package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.model.media.Image;
import me.elb.mediaplayermod.networking.packet.Packet;
import me.elb.mediaplayermod.networking.packet.ServerPlayMediaPacket;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.Collection;
import java.util.List;

import static com.mojang.brigadier.arguments.DoubleArgumentType.doubleArg;
import static com.mojang.brigadier.arguments.DoubleArgumentType.getDouble;
import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static com.mojang.brigadier.arguments.StringArgumentType.greedyString;
import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2186.method_9312;
import static net.minecraft.class_2186.method_9308;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class PlayImageCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                method_9247("playimage")
                        .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "playimage", 2))
                        .then(method_9244("targets", method_9308())
                                .then(method_9244("size", doubleArg())
                                        .then(method_9244("x_offset", doubleArg())
                                        .then(method_9244("y_offset", doubleArg())
                                        .then(method_9244("fade_in", doubleArg())
                                        .then(method_9244("duration", doubleArg())
                                        .then(method_9244("fade_out", doubleArg())
                                        .then(method_9244("url", greedyString())
                                        .executes(context -> executePlayImage(context.getSource(), getString(context, "url"),
                                                method_9312(context, "targets"), getDouble(context, "size"),
                                                getDouble(context, "x_offset"), getDouble(context, "y_offset"),
                                                getDouble(context, "fade_in"), getDouble(context, "duration"),
                                                getDouble(context, "fade_out"))))))))))));
    }

    private static int executePlayImage(class_2168 source, String url, Collection<class_3222> targets, double size,
                                        double x, double y, double fadeIn, double duration, double fadeOut) {
        if (targets == null) {
            class_3222 player = source.method_44023();
            if (player == null)
                return 0;
            targets = List.of(player);
        }
        if (url == null || targets.isEmpty())
            return 0;
        Packet packet = new ServerPlayMediaPacket(new Image(url, (float) (size / 100f), (float) (x / 100f), (float) (y / 100f),
                (long) (Math.max(0, fadeIn) * 1000L), (long) (Math.max(0, duration) * 1000L), (long) (Math.max(0, fadeOut) * 1000L)));
        MediaPlayerMod.getInstance().sendPacket(targets, packet);
        int count = targets.size();
        source.method_9226(() -> class_2561.method_30163("Playing image " + url + " for " + count + " players"), false);
        return targets.size();
    }
}
