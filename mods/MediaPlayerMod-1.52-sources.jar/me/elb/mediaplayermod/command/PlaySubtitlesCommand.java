package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.command.provider.EnumerationSuggestionProvider;
import me.elb.mediaplayermod.command.provider.MediaSuggestions;
import me.elb.mediaplayermod.model.media.Subtitles;
import me.elb.mediaplayermod.networking.packet.ServerPlayMediaPacket;
import me.elb.mediaplayermod.util.ColorUtil;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.awt.*;
import java.util.Collection;

import static com.mojang.brigadier.arguments.IntegerArgumentType.*;
import static com.mojang.brigadier.arguments.StringArgumentType.*;
import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2186.method_9312;
import static net.minecraft.class_2186.method_9308;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class PlaySubtitlesCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                method_9247("playsubtitles")
                        .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "playsubtitles", 2))
                        .then(method_9244("targets", method_9308())
                                .then(method_9244("font", word())
                                        .suggests(EnumerationSuggestionProvider.FONTS_PROVIDER)
                                        .then(method_9244("size", integer(1, 128))
                                        .then(method_9244("color", word())
                                                .suggests(EnumerationSuggestionProvider.COLORS_PROVIDER)
                                        .then(method_9244("background", word())
                                                .suggests(EnumerationSuggestionProvider.SUBTITLES_BACKGROUND_PROVIDER)
                                        .then(method_9244("url", greedyString())
                                                .suggests(MediaSuggestions.SUBTITLES)
                                                .executes(ctx -> execute(ctx.getSource(),
                                                        method_9312(ctx, "targets"),
                                                        getString(ctx, "font"),
                                                        getInteger(ctx, "size"),
                                                        getString(ctx, "color"),
                                                        getString(ctx, "background"),
                                                        getString(ctx, "url"))))))))));
    }

    private static int execute(class_2168 source, Collection<class_3222> targets,
                               String font, int size, String colorStr, String backgroundStr, String url) {
        Color color = ColorUtil.fromString(colorStr);
        Subtitles.Background background = Subtitles.Background.valueOf(backgroundStr.toUpperCase());
        MediaPlayerMod.getInstance().sendPacket(targets,
                new ServerPlayMediaPacket(new Subtitles(url, font, size, color, background)));
        int count = targets.size();
        source.method_9226(() -> class_2561.method_30163("Playing subtitles " + url + " for " + count + " players"), false);
        return count;
    }
}
