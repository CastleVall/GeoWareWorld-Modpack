package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.playlist.ServerPlaylist;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.Collection;
import java.util.List;

import static com.mojang.brigadier.arguments.BoolArgumentType.*;
import static com.mojang.brigadier.arguments.IntegerArgumentType.*;
import static com.mojang.brigadier.arguments.StringArgumentType.*;
import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2186.method_9315;
import static net.minecraft.class_2186.method_9312;
import static net.minecraft.class_2186.method_9305;
import static net.minecraft.class_2186.method_9308;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class PlayListCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                method_9247("playlist")
                        .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "playlist", 2))
                        .then(method_9247("create")
                                .then(method_9244("id", word())
                                        .executes(ctx -> executeCreate(ctx.getSource(), getString(ctx, "id")))))
                        .then(method_9247("delete")
                                .then(method_9244("id", word())
                                        .suggests((ctx, builder) -> {
                                            MediaPlayerMod.getInstance().getPlaylists().forEach(p -> builder.suggest(p.getId()));
                                            return builder.buildFuture();
                                        })
                                        .executes(ctx -> executeDelete(ctx.getSource(), getString(ctx, "id")))))
                        .then(method_9247("add")
                                .then(method_9244("id", word())
                                        .suggests((ctx, builder) -> {
                                            MediaPlayerMod.getInstance().getPlaylists().forEach(p -> builder.suggest(p.getId()));
                                            return builder.buildFuture();
                                        })
                                        .then(method_9244("url", string())
                                                .executes(ctx -> executeAdd(ctx.getSource(),
                                                        getString(ctx, "id"), getString(ctx, "url"), null, null))
                                                .then(method_9244("name", greedyString())
                                                        .executes(ctx -> executeAdd(ctx.getSource(),
                                                                getString(ctx, "id"), getString(ctx, "url"), getString(ctx, "name"), null))))))
                        .then(method_9247("addwithlyrics")
                                .then(method_9244("id", word())
                                        .suggests((ctx, builder) -> {
                                            MediaPlayerMod.getInstance().getPlaylists().forEach(p -> builder.suggest(p.getId()));
                                            return builder.buildFuture();
                                        })
                                        .then(method_9244("url", string())
                                                .then(method_9244("lyricsUrl", string())
                                                        .executes(ctx -> executeAdd(ctx.getSource(),
                                                                getString(ctx, "id"), getString(ctx, "url"), null, getString(ctx, "lyricsUrl")))
                                                        .then(method_9244("name", greedyString())
                                                                .executes(ctx -> executeAdd(ctx.getSource(),
                                                                        getString(ctx, "id"), getString(ctx, "url"), getString(ctx, "name"), getString(ctx, "lyricsUrl"))))))))
                        .then(method_9247("setlyrics")
                                .then(method_9244("id", word())
                                        .suggests((ctx, builder) -> {
                                            MediaPlayerMod.getInstance().getPlaylists().forEach(p -> builder.suggest(p.getId()));
                                            return builder.buildFuture();
                                        })
                                        .then(method_9244("index", integer(0))
                                                .then(method_9244("lyricsUrl", string())
                                                        .executes(ctx -> executeSetLyrics(ctx.getSource(),
                                                                getString(ctx, "id"), getInteger(ctx, "index"), getString(ctx, "lyricsUrl")))))))
                        .then(method_9247("remove")
                                .then(method_9244("id", word())
                                        .suggests((ctx, builder) -> {
                                            MediaPlayerMod.getInstance().getPlaylists().forEach(p -> builder.suggest(p.getId()));
                                            return builder.buildFuture();
                                        })
                                        .then(method_9244("index", integer(0))
                                                .executes(ctx -> executeRemove(ctx.getSource(),
                                                        getString(ctx, "id"), getInteger(ctx, "index"))))))
                        .then(method_9247("move")
                                .then(method_9244("id", word())
                                        .suggests((ctx, builder) -> {
                                            MediaPlayerMod.getInstance().getPlaylists().forEach(p -> builder.suggest(p.getId()));
                                            return builder.buildFuture();
                                        })
                                        .then(method_9244("from", integer(0))
                                                .then(method_9244("to", integer(0))
                                                        .executes(ctx -> executeMove(ctx.getSource(),
                                                                getString(ctx, "id"),
                                                                getInteger(ctx, "from"),
                                                                getInteger(ctx, "to")))))))
                        .then(method_9247("list")
                                .executes(ctx -> executeListAll(ctx.getSource()))
                                .then(method_9244("id", word())
                                        .suggests((ctx, builder) -> {
                                            MediaPlayerMod.getInstance().getPlaylists().forEach(p -> builder.suggest(p.getId()));
                                            return builder.buildFuture();
                                        })
                                        .executes(ctx -> executeListOne(ctx.getSource(), getString(ctx, "id")))))
                        .then(method_9247("setplayers")
                                .then(method_9244("id", word())
                                        .suggests((ctx, builder) -> {
                                            MediaPlayerMod.getInstance().getPlaylists().forEach(p -> builder.suggest(p.getId()));
                                            return builder.buildFuture();
                                        })
                                        .then(method_9244("targets", method_9308())
                                                .executes(ctx -> executeSetPlayers(ctx.getSource(),
                                                        getString(ctx, "id"), method_9312(ctx, "targets"))))))
                        .then(method_9247("removeplayer")
                                .then(method_9244("id", word())
                                        .suggests((ctx, builder) -> {
                                            MediaPlayerMod.getInstance().getPlaylists().forEach(p -> builder.suggest(p.getId()));
                                            return builder.buildFuture();
                                        })
                                        .then(method_9244("target", method_9305())
                                                .executes(ctx -> executeRemovePlayer(ctx.getSource(),
                                                        getString(ctx, "id"), method_9315(ctx, "target"))))))
                        .then(method_9247("pause")
                                .then(method_9244("id", word())
                                        .suggests((ctx, builder) -> {
                                            MediaPlayerMod.getInstance().getPlaylists().forEach(p -> builder.suggest(p.getId()));
                                            return builder.buildFuture();
                                        })
                                        .executes(ctx -> executePause(ctx.getSource(), getString(ctx, "id"), true))))
                        .then(method_9247("play")
                                .then(method_9244("id", word())
                                        .suggests((ctx, builder) -> {
                                            MediaPlayerMod.getInstance().getPlaylists().forEach(p -> builder.suggest(p.getId()));
                                            return builder.buildFuture();
                                        })
                                        .executes(ctx -> executePause(ctx.getSource(), getString(ctx, "id"), false))))
                        .then(method_9247("playtrack")
                                .then(method_9244("id", word())
                                        .suggests((ctx, builder) -> {
                                            MediaPlayerMod.getInstance().getPlaylists().forEach(p -> builder.suggest(p.getId()));
                                            return builder.buildFuture();
                                        })
                                        .then(method_9244("index", integer(0))
                                                .executes(ctx -> executePlayTrack(ctx.getSource(),
                                                        getString(ctx, "id"), getInteger(ctx, "index"))))))
                        .then(method_9247("next")
                                .then(method_9244("id", word())
                                        .suggests((ctx, builder) -> {
                                            MediaPlayerMod.getInstance().getPlaylists().forEach(p -> builder.suggest(p.getId()));
                                            return builder.buildFuture();
                                        })
                                        .executes(ctx -> executeSkip(ctx.getSource(), getString(ctx, "id"), 1))))
                        .then(method_9247("prev")
                                .then(method_9244("id", word())
                                        .suggests((ctx, builder) -> {
                                            MediaPlayerMod.getInstance().getPlaylists().forEach(p -> builder.suggest(p.getId()));
                                            return builder.buildFuture();
                                        })
                                        .executes(ctx -> executeSkip(ctx.getSource(), getString(ctx, "id"), -1))))
                        .then(method_9247("shuffle")
                                .then(method_9244("id", word())
                                        .suggests((ctx, builder) -> {
                                            MediaPlayerMod.getInstance().getPlaylists().forEach(p -> builder.suggest(p.getId()));
                                            return builder.buildFuture();
                                        })
                                        .then(method_9244("status", bool())
                                                .executes(ctx -> executeShuffle(ctx.getSource(),
                                                        getString(ctx, "id"), getBool(ctx, "status"))))))
                        .then(method_9247("loop")
                                .then(method_9244("id", word())
                                        .suggests((ctx, builder) -> {
                                            MediaPlayerMod.getInstance().getPlaylists().forEach(p -> builder.suggest(p.getId()));
                                            return builder.buildFuture();
                                        })
                                        .then(method_9244("status", bool())
                                                .executes(ctx -> executeLoop(ctx.getSource(),
                                                        getString(ctx, "id"), getBool(ctx, "status")))))));
    }

    private static ServerPlaylist<class_3222> getPlaylist(class_2168 source, String id) {
        ServerPlaylist<class_3222> playlist = MediaPlayerMod.getInstance().getPlaylist(id);
        if (playlist == null) {
            source.method_9213(class_2561.method_30163("Playlist no encontrada: " + id));
        }
        return playlist;
    }

    private static int executeCreate(class_2168 source, String id) {
        ServerPlaylist<class_3222> playlist = MediaPlayerMod.getInstance().createPlaylist(id);
        if (playlist != null) {
            source.method_9226(() -> class_2561.method_30163("Playlist creada: " + id), false);
            syncAdminScreen(source);
            return 1;
        } else {
            source.method_9213(class_2561.method_30163("La playlist ya existe: " + id));
            return 0;
        }
    }

    private static int executeDelete(class_2168 source, String id) {
        if (MediaPlayerMod.getInstance().deletePlaylist(id)) {
            source.method_9226(() -> class_2561.method_30163("Playlist eliminada: " + id), false);
            syncAdminScreen(source);
            return 1;
        }
        source.method_9213(class_2561.method_30163("Playlist no encontrada: " + id));
        return 0;
    }

    private static int executeAdd(class_2168 source, String id, String url, String name, String lyricsUrl) {
        if (MediaPlayerMod.getInstance().addAudioToPlaylist(id, url, name, lyricsUrl)) {
            source.method_9226(() -> class_2561.method_30163("Cancion agregada a " + id + ": " + url
                    + (lyricsUrl != null ? " [letras]" : "")), false);
            syncAdminScreen(source);
            return 1;
        }
        source.method_9213(class_2561.method_30163("Playlist no encontrada: " + id));
        return 0;
    }

    private static int executeSetLyrics(class_2168 source, String id, int index, String lyricsUrl) {
        if (MediaPlayerMod.getInstance().setLyricsForTrack(id, index, lyricsUrl)) {
            source.method_9226(() -> class_2561.method_30163("Letras asignadas a pista " + index + " de " + id), false);
            syncAdminScreen(source);
            return 1;
        }
        source.method_9213(class_2561.method_30163("Pista no encontrada: " + id + " #" + index));
        return 0;
    }

    private static int executeRemove(class_2168 source, String id, int index) {
        ServerPlaylist<class_3222> playlist = getPlaylist(source, id);
        if (playlist == null) return 0;
        if (MediaPlayerMod.getInstance().removeAudioFromPlaylist(playlist, index)) {
            source.method_9226(() -> class_2561.method_30163("Cancion " + index + " eliminada de " + id), false);
            syncAdminScreen(source);
            return 1;
        }
        source.method_9213(class_2561.method_30163("Indice fuera de rango en " + id + ": " + index));
        return 0;
    }

    private static int executeMove(class_2168 source, String id, int from, int to) {
        ServerPlaylist<class_3222> playlist = getPlaylist(source, id);
        if (playlist == null) return 0;
        if (MediaPlayerMod.getInstance().moveAudioInPlaylist(playlist, from, to)) {
            source.method_9226(() -> class_2561.method_30163("Cancion movida en " + id + ": " + from + " -> " + to), false);
            syncAdminScreen(source);
            return 1;
        }
        source.method_9213(class_2561.method_30163("No se puede mover la cancion " + from + " a " + to + " en " + id));
        return 0;
    }

    private static int executeListAll(class_2168 source) {
        List<ServerPlaylist<class_3222>> playlists = MediaPlayerMod.getInstance().getPlaylists();
        if (playlists.isEmpty()) {
            source.method_9226(() -> class_2561.method_30163("No hay playlists."), false);
            return 0;
        }
        StringBuilder sb = new StringBuilder("Playlists:");
        for (ServerPlaylist<class_3222> p : playlists) {
            sb.append("\n - ").append(p.getId()).append(" (").append(p.getAudios().size()).append(" pistas)");
        }
        String msg = sb.toString();
        source.method_9226(() -> class_2561.method_30163(msg), false);
        return playlists.size();
    }

    private static int executeListOne(class_2168 source, String id) {
        ServerPlaylist<class_3222> playlist = getPlaylist(source, id);
        if (playlist == null) return 0;
        StringBuilder sb = new StringBuilder("Playlist " + id + ":");
        for (int i = 0; i < playlist.getAudios().size(); i++) {
            sb.append("\n - ").append(i).append(": ").append(playlist.getAudios().get(i).url());
        }
        String msg = sb.toString();
        source.method_9226(() -> class_2561.method_30163(msg), false);
        return playlist.getAudios().size();
    }

    private static int executeSetPlayers(class_2168 source, String id, Collection<class_3222> targets) {
        ServerPlaylist<class_3222> playlist = getPlaylist(source, id);
        if (playlist == null) return 0;
        boolean broadcastToEveryone = source.method_9211() != null
                && source.method_9211().method_3760().method_14571().size() == targets.size();
        @SuppressWarnings("unchecked")
        class_3222[] arr = targets.toArray(new class_3222[0]);
        MediaPlayerMod.getInstance().setPlaylistToPlayers(playlist, arr, broadcastToEveryone);
        int count = targets.size();
        source.method_9226(() -> class_2561.method_30163("Playlist " + id + " asignada a " + count + " jugador(es)"), false);
        syncAdminScreen(source);
        return count;
    }

    private static int executeRemovePlayer(class_2168 source, String id, class_3222 target) {
        ServerPlaylist<class_3222> playlist = getPlaylist(source, id);
        if (playlist == null) return 0;
        MediaPlayerMod.getInstance().removePlayerFromPlaylist(playlist, target);
        source.method_9226(() -> class_2561.method_30163("Jugador eliminado de " + id + ": " + target.method_5477().getString()), false);
        syncAdminScreen(source);
        return 1;
    }

    private static int executePause(class_2168 source, String id, boolean paused) {
        ServerPlaylist<class_3222> playlist = getPlaylist(source, id);
        if (playlist == null) return 0;
        if (!paused) playlist.setStopped(false);
        MediaPlayerMod.getInstance().pausePlaylist(playlist, paused);
        String action = paused ? "Pausada" : "Reanudada";
        source.method_9226(() -> class_2561.method_30163(action + " playlist " + id), false);
        syncAdminScreen(source);
        return 1;
    }

    private static int executePlayTrack(class_2168 source, String id, int index) {
        ServerPlaylist<class_3222> playlist = getPlaylist(source, id);
        if (playlist == null) return 0;
        if (MediaPlayerMod.getInstance().jumpPlaylistToTrack(playlist, index)) {
            source.method_9226(() -> class_2561.method_30163("Reproduciendo cancion " + index + " de " + id), false);
            return 1;
        }
        source.method_9213(class_2561.method_30163("Indice fuera de rango en " + id + ": " + index));
        return 0;
    }

    private static int executeSkip(class_2168 source, String id, int direction) {
        ServerPlaylist<class_3222> playlist = getPlaylist(source, id);
        if (playlist == null) return 0;
        MediaPlayerMod.getInstance().skipPlaylist(playlist, direction);
        source.method_9226(() -> class_2561.method_30163((direction < 0 ? "Cancion anterior" : "Siguiente cancion") + " para " + id), false);
        return 1;
    }

    private static int executeShuffle(class_2168 source, String id, boolean shuffle) {
        ServerPlaylist<class_3222> playlist = getPlaylist(source, id);
        if (playlist == null) return 0;
        MediaPlayerMod.getInstance().shufflePlaylist(playlist, shuffle);
        source.method_9226(() -> class_2561.method_30163("Mezcla=" + shuffle + " para " + id), false);
        syncAdminScreen(source);
        return 1;
    }

    private static int executeLoop(class_2168 source, String id, boolean loop) {
        ServerPlaylist<class_3222> playlist = getPlaylist(source, id);
        if (playlist == null) return 0;
        MediaPlayerMod.getInstance().loopPlaylist(playlist, loop);
        source.method_9226(() -> class_2561.method_30163("Bucle=" + loop + " para " + id), false);
        syncAdminScreen(source);
        return 1;
    }

    private static void syncAdminScreen(class_2168 source) {
        MediaPlayerMod.getInstance().sendPlaylistAdminSyncToAdmins();
    }
}
