package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.cameraplayer.StreamScreenEntity;
import me.elb.mediaplayermod.cameraplayer.ScreenNetworkPayloads;
import me.elb.mediaplayermod.cameraplayer.ScreenNetworkPayloads.SyncStreamPayload;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2168;
import net.minecraft.class_2186;
import net.minecraft.class_2262;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class PlayCameraProjectionCommand {

    private static final SuggestionProvider<class_2168> SCREEN_NAME_SUGGESTIONS = (ctx, builder) -> {
        var server = ctx.getSource().method_9211();
        if (server != null) {
            java.util.Set<String> seen = new java.util.HashSet<>();
            for (net.minecraft.class_3218 world : server.method_3738()) {
                for (net.minecraft.class_1297 e : world.method_27909()) {
                    if (e instanceof StreamScreenEntity screen) {
                        String n = screen.getScreenName();
                        if (n != null && !n.isEmpty() && seen.add(n.toLowerCase())) {
                            builder.suggest(n.contains(" ") ? "\"" + n + "\"" : n);
                        }
                    }
                }
            }
        }
        return builder.buildFuture();
    };

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(method_9247("playcameraprojection")
                .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "playcameraprojection", 2))
                .then(method_9247("create")
                        .then(method_9244("nombre", StringArgumentType.string())
                                .then(method_9244("pos1", class_2262.method_9698())
                                        .then(method_9244("pos2", class_2262.method_9698())
                                                .executes(ctx -> createScreen(
                                                        ctx.getSource(),
                                                        StringArgumentType.getString(ctx, "nombre"),
                                                        class_2262.method_48299(ctx, "pos1"),
                                                        class_2262.method_48299(ctx, "pos2")
                                                ))))))
                .then(method_9247("delete")
                        .then(method_9244("nombre", StringArgumentType.string())
                                .suggests(SCREEN_NAME_SUGGESTIONS)
                                .executes(ctx -> deleteScreen(
                                        ctx.getSource(),
                                        StringArgumentType.getString(ctx, "nombre")
                                ))))
                .then(method_9247("link")
                        .then(method_9244("nombre", StringArgumentType.string())
                                .suggests(SCREEN_NAME_SUGGESTIONS)
                                .then(method_9244("player", class_2186.method_9305())
                                        .executes(ctx -> linkScreen(
                                                ctx.getSource(),
                                                StringArgumentType.getString(ctx, "nombre"),
                                                class_2186.method_9315(ctx, "player")
                                        )))))
                .then(method_9247("unlink")
                        .then(method_9244("nombre", StringArgumentType.string())
                                .suggests(SCREEN_NAME_SUGGESTIONS)
                                .executes(ctx -> unlinkScreen(
                                        ctx.getSource(),
                                        StringArgumentType.getString(ctx, "nombre")
                                ))))
                .then(method_9247("effects")
                        .executes(ctx -> {
                            for (class_3222 p : ctx.getSource().method_9211().method_3760().method_14571()) {
                                ServerPlayNetworking.send(p, new ScreenNetworkPayloads.EffectsPayload());
                            }
                            ctx.getSource().method_9226(() -> class_2561.method_43470("§bTriggered effects for all players"), false);
                            return 1;
                        }))
                .then(method_9247("overlay")
                        .then(method_9244("nombre_del_archivo", StringArgumentType.string())
                                .executes(ctx -> {
                                    String fileName = StringArgumentType.getString(ctx, "nombre_del_archivo");
                                    for (class_3222 p : ctx.getSource().method_9211().method_3760().method_14571()) {
                                        ServerPlayNetworking.send(p, new ScreenNetworkPayloads.OverlayPayload(fileName));
                                    }
                                    ctx.getSource().method_9226(() -> class_2561.method_43470("§bOverlay set to: §f" + fileName), false);
                                    return 1;
                                })))
        );
    }

    private static int createScreen(class_2168 source, String name, class_2338 p1, class_2338 p2) {
        class_3222 player = source.method_44023();
        int minX = Math.min(p1.method_10263(), p2.method_10263()), maxX = Math.max(p1.method_10263(), p2.method_10263());
        int minY = Math.min(p1.method_10264(), p2.method_10264()), maxY = Math.max(p1.method_10264(), p2.method_10264());
        int minZ = Math.min(p1.method_10260(), p2.method_10260()), maxZ = Math.max(p1.method_10260(), p2.method_10260());

        class_2350 facing = player != null ? player.method_5735() : class_2350.field_11043;
        float screenYaw = facing.method_10153().method_10144();
        double height = (maxY - minY) + 1.0;
        double midX = (minX + maxX + 1.0) / 2.0, midY = minY, midZ = (minZ + maxZ + 1.0) / 2.0;

        if (facing == class_2350.field_11043) midZ = maxZ + 1.0;
        else if (facing == class_2350.field_11035) midZ = minZ;
        else if (facing == class_2350.field_11039) midX = maxX + 1.0;
        else if (facing == class_2350.field_11034) midX = minX;

        StreamScreenEntity screenEntity = new StreamScreenEntity(MediaPlayerMod.STREAM_SCREEN_ENTITY, source.method_9225());
        float width = (facing.method_10166() == class_2350.class_2351.field_11048) ? (float) (maxZ - minZ + 1.0) : (float) (maxX - minX + 1.0);

        screenEntity.setScreenName(name);
        screenEntity.setScreenWidth(width);
        screenEntity.setScreenHeight((float) height);
        screenEntity.method_36456(screenYaw);
        screenEntity.setStreamerUuid(null);
        screenEntity.method_5808(midX, midY, midZ, screenYaw, 0);

        source.method_9225().method_8649(screenEntity);
        source.method_9226(() -> class_2561.method_43470("§aCreated screen: §f" + name), false);
        return 1;
    }

    private static int deleteScreen(class_2168 source, String name) {
        int count = 0;
        for (net.minecraft.class_1297 e : source.method_9225().method_27909()) {
            if (e instanceof StreamScreenEntity screen && screen.getScreenName().equalsIgnoreCase(name)) {
                e.method_31472();
                count++;
            }
        }
        if (count > 0) {
            final int finalCount = count;
            source.method_9226(() -> class_2561.method_43470("§aDeleted §f" + finalCount + " §ascreen(s) named: §f" + name), false);
        } else {
            source.method_9213(class_2561.method_43470("No screen found with name: " + name));
        }
        return count;
    }

    private static int linkScreen(class_2168 source, String name, class_3222 target) {
        boolean found = false;
        for (net.minecraft.class_1297 e : source.method_9225().method_27909()) {
            if (e instanceof StreamScreenEntity screen && screen.getScreenName().equalsIgnoreCase(name)) {
                screen.setStreamerUuid(target.method_5667());
                ServerPlayNetworking.send(target, new SyncStreamPayload());
                found = true;
            }
        }
        if (found) {
            source.method_9226(() -> class_2561.method_43470("§aLinked screen §f" + name + " §ato player: §f" + target.method_5477().getString()), false);
        } else {
            source.method_9213(class_2561.method_43470("No screen found with name: " + name));
        }
        return found ? 1 : 0;
    }

    private static int unlinkScreen(class_2168 source, String name) {
        boolean found = false;
        for (net.minecraft.class_1297 e : source.method_9225().method_27909()) {
            if (e instanceof StreamScreenEntity screen && screen.getScreenName().equalsIgnoreCase(name)) {
                screen.setStreamerUuid(null);
                found = true;
            }
        }
        if (found) {
            source.method_9226(() -> class_2561.method_43470("§aUnlinked screen: §f" + name), false);
        } else {
            source.method_9213(class_2561.method_43470("No screen found with name: " + name));
        }
        return found ? 1 : 0;
    }
}
