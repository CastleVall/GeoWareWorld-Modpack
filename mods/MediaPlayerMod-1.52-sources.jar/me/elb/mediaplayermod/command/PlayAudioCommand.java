package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.model.media.Audio;
import me.elb.mediaplayermod.networking.packet.Packet;
import me.elb.mediaplayermod.networking.packet.ServerPlayMediaPacket;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.Collection;

import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static com.mojang.brigadier.arguments.StringArgumentType.greedyString;
import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2186.method_9312;
import static net.minecraft.class_2186.method_9308;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class PlayAudioCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                method_9247("playaudio")
                        .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "playaudio", 2))
                        .then(method_9244("targets", method_9308())
                                .then(method_9244("url", greedyString())
                                .suggests(me.elb.mediaplayermod.command.provider.MediaSuggestions.AUDIO)
                                .executes(context -> executePlayAudio(context.getSource(), getString(context, "url"),
                                        method_9312(context, "targets")))))
        );
    }

    private static int executePlayAudio(class_2168 source, String url, Collection<class_3222> targets) {
        Packet packet = new ServerPlayMediaPacket(new Audio(url, null));
        MediaPlayerMod.getInstance().sendPacket(targets, packet);
        source.method_9226(() -> class_2561.method_30163("Playing audio " + url + " for " + targets.size() + " players"), false);
        return targets.size();
    }
}
