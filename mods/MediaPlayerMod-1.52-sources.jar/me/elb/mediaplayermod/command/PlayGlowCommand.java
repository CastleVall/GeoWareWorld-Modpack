package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.command.provider.EnumerationSuggestionProvider;
import me.elb.mediaplayermod.model.media.Glow;
import me.elb.mediaplayermod.networking.packet.ServerPlayMediaPacket;
import me.elb.mediaplayermod.util.ColorUtil;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.awt.*;
import java.util.Collection;

import static com.mojang.brigadier.arguments.DoubleArgumentType.*;
import static com.mojang.brigadier.arguments.StringArgumentType.*;
import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2186.method_9312;
import static net.minecraft.class_2186.method_9308;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class PlayGlowCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                method_9247("playglow")
                        .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "playglow", 2))
                        .then(method_9244("targets", method_9308())
                                .then(method_9244("color", word())
                                        .suggests(EnumerationSuggestionProvider.COLORS_PROVIDER)
                                        .then(method_9244("in", doubleArg(0))
                                        .then(method_9244("duration", doubleArg(0))
                                        .then(method_9244("out", doubleArg(0))
                                        .then(method_9244("radius", doubleArg(0, 100))
                                        .then(method_9244("opacity", doubleArg(0, 100))
                                                .executes(ctx -> execute(ctx.getSource(),
                                                        method_9312(ctx, "targets"),
                                                        getString(ctx, "color"),
                                                        getDouble(ctx, "in"),
                                                        getDouble(ctx, "duration"),
                                                        getDouble(ctx, "out"),
                                                        getDouble(ctx, "radius"),
                                                        getDouble(ctx, "opacity")))))))))));
    }

    private static int execute(class_2168 source, Collection<class_3222> targets,
                               String colorStr, double in, double duration, double out, double radius, double opacity) {
        Color color = ColorUtil.fromString(colorStr);
        long fadeIn = (long) (Math.max(0, in) * 1000L);
        long dur = (long) (duration * 1000L);
        long fadeOut = (long) (Math.max(0, out) * 1000L);
        float r = (float) Math.clamp(radius / 100.0, 0.0, 1.0);
        float op = (float) Math.clamp(opacity / 100.0, 0.0, 1.0);
        MediaPlayerMod.getInstance().sendPacket(targets, new ServerPlayMediaPacket(new Glow(fadeIn, dur, fadeOut, r, op, color.getRGB())));
        int count = targets.size();
        source.method_9226(() -> class_2561.method_30163("Playing glow for " + count + " players"), false);
        return count;
    }
}
