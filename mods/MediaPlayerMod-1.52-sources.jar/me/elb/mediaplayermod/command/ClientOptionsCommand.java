package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.command.provider.EnumerationSuggestionProvider;
import me.elb.mediaplayermod.model.option.*;
import me.elb.mediaplayermod.networking.packet.ServerGetOptionPacket;
import me.elb.mediaplayermod.networking.packet.ServerReloadChunksPacket;
import me.elb.mediaplayermod.networking.packet.ServerSetOptionPacket;
import me.elb.mediaplayermod.server.voice.VoiceDistanceManager;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.Collection;

import static com.mojang.brigadier.arguments.BoolArgumentType.*;
import static com.mojang.brigadier.arguments.DoubleArgumentType.*;
import static com.mojang.brigadier.arguments.IntegerArgumentType.*;
import static com.mojang.brigadier.arguments.StringArgumentType.*;
import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2186.*;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class ClientOptionsCommand {

    private static final com.mojang.brigadier.suggestion.SuggestionProvider<class_2168> VC_MODES = (ctx, b) -> {
        b.suggest("pushtotalk");
        b.suggest("freevoice");
        return b.buildFuture();
    };

    private static final com.mojang.brigadier.suggestion.SuggestionProvider<class_2168> VC_KEYS = (ctx, b) -> {
        for (String s : new String[]{"v", "b", "n", "m", "r", "c", "x", "caps.lock", "left.alt", "left.control", "mouse4", "mouse5", "none"}) {
            b.suggest(s);
        }
        return b.buildFuture();
    };

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                method_9247("clientoptions")
                        .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "clientoptions", 2))
                        .then(method_9247("get")
                                .then(method_9244("target", method_9305())
                                        .then(method_9244("option", word())
                                                .suggests(EnumerationSuggestionProvider.CLIENT_OPTIONS_PROVIDER)
                                                .executes(ctx -> executeGet(ctx.getSource(),
                                                        method_9315(ctx, "target"),
                                                        getString(ctx, "option"))))))
                        .then(method_9247("reloadchunks")
                                .then(method_9244("targets", method_9308())
                                        .executes(ctx -> executeReloadChunks(ctx.getSource(),
                                                method_9312(ctx, "targets")))))
                        .then(method_9247("set")
                                .then(method_9244("targets", method_9308())
                                        .then(method_9247("volume")
                                                .then(method_9244("sound_category", word())
                                                        .suggests(EnumerationSuggestionProvider.SOUND_CATEGORIES_PROVIDER)
                                                        .then(method_9244("volume", integer(0, 100))
                                                                .executes(ctx -> executeSet(ctx.getSource(),
                                                                        method_9312(ctx, "targets"),
                                                                        new VolumeOption(getString(ctx, "sound_category"),
                                                                                getInteger(ctx, "volume") / 100f))))))
                                        .then(method_9247("clouds")
                                                .then(method_9244("value", word())
                                                        .suggests((ctx, b) -> {
                                                            for (CloudsOption.Clouds v : CloudsOption.Clouds.values()) b.suggest(v.name().toLowerCase());
                                                            return b.buildFuture();
                                                        })
                                                        .executes(ctx -> executeSet(ctx.getSource(),
                                                                method_9312(ctx, "targets"),
                                                                new CloudsOption(CloudsOption.Clouds.valueOf(getString(ctx, "value").toUpperCase()))))))
                                        .then(method_9247("gui_scale")
                                                .then(method_9244("scale", integer(0, 4))
                                                        .executes(ctx -> executeSet(ctx.getSource(),
                                                                method_9312(ctx, "targets"),
                                                                new GuiScaleOption(getInteger(ctx, "scale"))))))
                                        .then(method_9247("gamma")
                                                .then(method_9244("gamma", doubleArg(0, 100))
                                                        .executes(ctx -> executeSet(ctx.getSource(),
                                                                method_9312(ctx, "targets"),
                                                                new GammaOption((float) (getDouble(ctx, "gamma") / 100.0))))))
                                        .then(method_9247("view_distance")
                                                .then(method_9244("distance", integer(2, 32))
                                                        .executes(ctx -> executeSet(ctx.getSource(),
                                                                method_9312(ctx, "targets"),
                                                                new ViewDistanceOption(getInteger(ctx, "distance"))))))
                                        .then(method_9247("particles")
                                                .then(method_9244("value", word())
                                                        .suggests((ctx, b) -> {
                                                            for (ParticlesOption.Particles v : ParticlesOption.Particles.values()) b.suggest(v.name().toLowerCase());
                                                            return b.buildFuture();
                                                        })
                                                        .executes(ctx -> executeSet(ctx.getSource(),
                                                                method_9312(ctx, "targets"),
                                                                new ParticlesOption(ParticlesOption.Particles.valueOf(getString(ctx, "value").toUpperCase()))))))
                                        .then(method_9247("language")
                                                .then(method_9244("code", word())
                                                        .executes(ctx -> executeSet(ctx.getSource(),
                                                                method_9312(ctx, "targets"),
                                                                new LanguageOption(getString(ctx, "code"))))))
                                        .then(method_9247("fov")
                                                .then(method_9244("fov", integer(30, 110))
                                                        .executes(ctx -> executeSet(ctx.getSource(),
                                                                method_9312(ctx, "targets"),
                                                                new FovOption(getInteger(ctx, "fov"))))))
                                        .then(method_9247("chat_visibility")
                                                .then(method_9244("visible", bool())
                                                        .executes(ctx -> executeSet(ctx.getSource(),
                                                                method_9312(ctx, "targets"),
                                                                new ChatVisibilityOption(getBool(ctx, "visible"))))))
                                        .then(method_9247("chat_opacity")
                                                .then(method_9244("opacity", integer(0, 100))
                                                        .then(method_9244("bg_opacity", integer(0, 100))
                                                                .executes(ctx -> executeSet(ctx.getSource(),
                                                                        method_9312(ctx, "targets"),
                                                                        new ChatOpacityOption(
                                                                                getInteger(ctx, "opacity") / 100f,
                                                                                getInteger(ctx, "bg_opacity") / 100f))))))
                                        .then(method_9247("perspective")
                                                .then(method_9244("value", word())
                                                        .suggests((ctx, b) -> {
                                                            for (PerspectiveOption.Perspectives v : PerspectiveOption.Perspectives.values()) b.suggest(v.name().toLowerCase());
                                                            return b.buildFuture();
                                                        })
                                                        .executes(ctx -> executeSet(ctx.getSource(),
                                                                method_9312(ctx, "targets"),
                                                                new PerspectiveOption(PerspectiveOption.Perspectives.valueOf(getString(ctx, "value").toUpperCase()))))))
                                        .then(method_9247("shaders")
                                                .then(method_9244("value", word())
                                                        .suggests((ctx, b) -> {
                                                            for (ShaderOption.Shaders v : ShaderOption.Shaders.values()) b.suggest(v.name().toLowerCase());
                                                            return b.buildFuture();
                                                        })
                                                        .executes(ctx -> executeSet(ctx.getSource(),
                                                                method_9312(ctx, "targets"),
                                                                new ShaderOption(ShaderOption.Shaders.valueOf(getString(ctx, "value").toUpperCase()))))))
                                        .then(method_9247("model_part")
                                                .then(method_9244("part", word())
                                                        .suggests((ctx, b) -> {
                                                            for (ModelPartOption.Parts v : ModelPartOption.Parts.values()) b.suggest(v.name().toLowerCase());
                                                            return b.buildFuture();
                                                        })
                                                        .then(method_9244("enabled", bool())
                                                                .executes(ctx -> executeSet(ctx.getSource(),
                                                                        method_9312(ctx, "targets"),
                                                                        new ModelPartOption(ModelPartOption.Parts.valueOf(getString(ctx, "part").toUpperCase()),
                                                                                getBool(ctx, "enabled")))))))
                                        .then(method_9247("resource_pack")
                                                .then(method_9244("profile", word())
                                                        .then(method_9244("enabled", bool())
                                                                .executes(ctx -> executeSet(ctx.getSource(),
                                                                        method_9312(ctx, "targets"),
                                                                        new ResourcePackOption(getString(ctx, "profile"), getBool(ctx, "enabled")))))))
                                        .then(method_9247("background_blur")
                                                .then(method_9244("value", integer(0, 20))
                                                        .executes(ctx -> executeSet(ctx.getSource(),
                                                                method_9312(ctx, "targets"),
                                                                new BackgroundBlurOption(getInteger(ctx, "value"))))))
                                        .then(method_9247("fov_effect")
                                                .then(method_9244("value", doubleArg(0, 100))
                                                        .executes(ctx -> executeSet(ctx.getSource(),
                                                                method_9312(ctx, "targets"),
                                                                new FovEffectOption(getDouble(ctx, "value") / 100.0)))))
                                        .then(method_9247("voicechat")
                                                .then(method_9247("mode")
                                                        .then(method_9244("value", word()).suggests(VC_MODES)
                                                                .executes(ctx -> executeVoicechatMode(ctx.getSource(),
                                                                        method_9312(ctx, "targets"),
                                                                        getString(ctx, "value")))))
                                                .then(method_9247("key")
                                                        .then(method_9244("value", word()).suggests(VC_KEYS)
                                                                .executes(ctx -> executeVoicechat(ctx.getSource(),
                                                                        method_9312(ctx, "targets"), "key",
                                                                        getString(ctx, "value"),
                                                                        "Tecla de hablar cambiada a '" + getString(ctx, "value") + "'"))))
                                                .then(method_9247("volume")
                                                        .then(method_9244("percent", integer(0, 200))
                                                                .executes(ctx -> executeVoicechat(ctx.getSource(),
                                                                        method_9312(ctx, "targets"), "volume",
                                                                        String.valueOf(getInteger(ctx, "percent")),
                                                                        "Volumen de salida del voicechat: " + getInteger(ctx, "percent") + "% (100 = normal)"))))
                                                .then(method_9247("gain")
                                                        .then(method_9244("percent", integer(0, 400))
                                                                .executes(ctx -> executeVoicechat(ctx.getSource(),
                                                                        method_9312(ctx, "targets"), "gain",
                                                                        String.valueOf(getInteger(ctx, "percent")),
                                                                        "Ganancia del microfono: " + getInteger(ctx, "percent")
                                                                                + "% (100 = normal, 0 = mudo; cambia lo que OTROS escuchan de ese jugador)"))))
                                                .then(method_9247("sensitivity")
                                                        .then(method_9244("db", doubleArg(-127, 0))
                                                                .executes(ctx -> executeVoicechat(ctx.getSource(),
                                                                        method_9312(ctx, "targets"), "sensitivity",
                                                                        String.valueOf(getDouble(ctx, "db")),
                                                                        "Sensibilidad de activacion por voz: " + getDouble(ctx, "db")
                                                                                + " dB (solo aplica en modo freevoice y con vad en false)"))))
                                                .then(method_9247("vad")
                                                        .then(method_9244("value", bool())
                                                                .executes(ctx -> executeVoicechat(ctx.getSource(),
                                                                        method_9312(ctx, "targets"), "vad",
                                                                        String.valueOf(getBool(ctx, "value")),
                                                                        getBool(ctx, "value")
                                                                                ? "Deteccion de voz por IA activada (ignora sensitivity)"
                                                                                : "Deteccion de voz por IA desactivada (ahora manda sensitivity)"))))
                                                .then(method_9247("mute")
                                                        .then(method_9244("value", bool())
                                                                .executes(ctx -> executeVoicechat(ctx.getSource(),
                                                                        method_9312(ctx, "targets"), "mute",
                                                                        String.valueOf(getBool(ctx, "value")),
                                                                        "Microfono " + (getBool(ctx, "value") ? "SILENCIADO" : "abierto")))))
                                                .then(method_9247("enabled")
                                                        .then(method_9244("value", bool())
                                                                .executes(ctx -> executeVoicechat(ctx.getSource(),
                                                                        method_9312(ctx, "targets"), "enabled",
                                                                        String.valueOf(getBool(ctx, "value")),
                                                                        "Voicechat " + (getBool(ctx, "value") ? "activado" : "DESACTIVADO")))))
                                                .then(method_9247("denoiser")
                                                        .then(method_9244("value", bool())
                                                                .executes(ctx -> executeVoicechat(ctx.getSource(),
                                                                        method_9312(ctx, "targets"), "denoiser",
                                                                        String.valueOf(getBool(ctx, "value")),
                                                                        "Reduccion de ruido " + (getBool(ctx, "value") ? "activada" : "desactivada")))))
                                                .then(method_9247("reset")
                                                        .executes(ctx -> executeVoicechat(ctx.getSource(),
                                                                method_9312(ctx, "targets"), "reset", "",
                                                                "Ajustes de voicechat restaurados a los valores por defecto del mod")))
                                                .then(method_9247("distance")
                                                        .then(method_9247("clear")
                                                                .executes(ctx -> executeVoiceDistanceClear(ctx.getSource(),
                                                                        method_9312(ctx, "targets"))))
                                                        .then(method_9244("blocks", doubleArg(1, 512))
                                                                .executes(ctx -> executeVoiceDistance(ctx.getSource(),
                                                                        method_9312(ctx, "targets"),
                                                                        getDouble(ctx, "blocks")))))))));
    }

    private static int executeGet(class_2168 source, class_3222 target, String optionStr) {
        try {
            ClientOptions option = ClientOptions.valueOf(optionStr.toUpperCase());
            MediaPlayerMod.getInstance().sendPacket(target,
                    new ServerGetOptionPacket(source.method_9214(), option));
            source.method_9226(() -> class_2561.method_30163("Requested " + optionStr + " from " + target.method_5477().getString()), false);
            return 1;
        } catch (IllegalArgumentException e) {
            source.method_9213(class_2561.method_30163("Unknown option: " + optionStr));
            return 0;
        }
    }

    private static int executeReloadChunks(class_2168 source, Collection<class_3222> targets) {
        MediaPlayerMod.getInstance().sendPacket(targets, new ServerReloadChunksPacket());
        int count = targets.size();
        source.method_9226(() -> class_2561.method_30163("Reloading chunks for " + count + " players"), false);
        return count;
    }

    private static int executeSet(class_2168 source, Collection<class_3222> targets, ClientOption option) {
        MediaPlayerMod.getInstance().sendPacket(targets, new ServerSetOptionPacket(option));
        int count = targets.size();
        source.method_9226(() -> class_2561.method_30163("Set " + option.getClass().getSimpleName() + " for " + count + " players"), false);
        return count;
    }

    /** Valida el modo de microfono antes de enviarlo (solo pushtotalk o freevoice). */
    private static int executeVoicechatMode(class_2168 source, Collection<class_3222> targets, String mode) {
        String value = mode.toLowerCase();
        if (!value.equals("pushtotalk") && !value.equals("freevoice")) {
            source.method_9213(class_2561.method_30163("Modo desconocido: " + mode + " (usa pushtotalk o freevoice)"));
            return 0;
        }
        return executeVoicechat(source, targets, "mode", value, "Microfono en modo " + (value.equals("freevoice")
                ? "VOZ LIBRE (siempre abierto)" : "PULSAR PARA HABLAR"));
    }

    /**
     * Ajuste de Simple Voice Chat en el cliente. Si el jugador no tiene ese mod, su cliente ignora
     * la opcion sin romper nada.
     */
    private static int executeVoicechat(class_2168 source, Collection<class_3222> targets,
                                        String setting, String value, String msg) {
        MediaPlayerMod.getInstance().sendPacket(targets, new ServerSetOptionPacket(new VoicechatOption(setting, value)));
        int count = targets.size();
        source.method_9226(() -> class_2561.method_30163("[Voicechat] " + msg + " -> " + count + " jugador(es)"), true);
        return count;
    }

    /**
     * Distancia de escucha del chat de proximidad. NO es un ajuste de cliente: se aplica en el
     * servidor descartando los paquetes de voz que vienen de mas lejos, asi que solo recorta el
     * maximo del servidor, no lo extiende.
     */
    private static int executeVoiceDistance(class_2168 source, Collection<class_3222> targets, double blocks) {
        targets.forEach(player -> VoiceDistanceManager.set(player.method_5667(), blocks));
        int count = targets.size();
        source.method_9226(() -> class_2561.method_30163("[Voicechat] Distancia de escucha: " + blocks
                + " bloques -> " + count + " jugador(es) (solo recorta, no extiende el maximo del servidor)"), true);
        return count;
    }

    private static int executeVoiceDistanceClear(class_2168 source, Collection<class_3222> targets) {
        targets.forEach(player -> VoiceDistanceManager.clear(player.method_5667()));
        int count = targets.size();
        source.method_9226(() -> class_2561.method_30163("[Voicechat] Limite de distancia quitado -> " + count + " jugador(es)"), true);
        return count;
    }
}
