package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.model.option.VolumeOption;
import me.elb.mediaplayermod.networking.packet.Packet;
import me.elb.mediaplayermod.command.provider.EnumerationSuggestionProvider;
import me.elb.mediaplayermod.networking.packet.ServerSetOptionPacket;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import java.util.Collection;
import java.util.List;

import static com.mojang.brigadier.arguments.IntegerArgumentType.getInteger;
import static com.mojang.brigadier.arguments.IntegerArgumentType.integer;
import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static com.mojang.brigadier.arguments.StringArgumentType.word;
import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2186.method_9312;
import static net.minecraft.class_2186.method_9308;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class SetVolumeCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                method_9247("setvolume")
                        .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "setvolume", 2))
                        .then(method_9244("targets", method_9308())
                                .then(method_9244("category", word())
                                        .suggests(EnumerationSuggestionProvider.SOUND_CATEGORIES_PROVIDER)
                                        .then(method_9244("volume", integer())
                                        .executes(context -> executeSetVolume(context.getSource(), method_9312(context, "targets"),
                                                getString(context, "category"), getInteger(context, "volume"))))))
        );
    }

    private static int executeSetVolume(class_2168 source, Collection<class_3222> targets, String soundCategoryString, int volume) {
        if (targets == null) {
            class_3222 player = source.method_44023();
            if (player == null)
                return 0;
            targets = List.of(player);
        }
        if (targets.isEmpty())
            return 0;
        try {
            class_3419.valueOf(soundCategoryString);
        } catch (IllegalArgumentException e) {
            if (!soundCategoryString.equals("MEDIA")) {
                source.method_9226(() -> class_2561.method_30163("Invalid sound category: " + soundCategoryString), false);
                return 0;
            }
        }
        Packet packet = new ServerSetOptionPacket(new VolumeOption(soundCategoryString, volume / 100f));
        MediaPlayerMod.getInstance().sendPacket(targets, packet);
        int count = targets.size();
        source.method_9226(() -> class_2561.method_30163("Set volume " + soundCategoryString + " of "
                + count + " player(s) to " + volume), true);
        return targets.size();
    }
}
