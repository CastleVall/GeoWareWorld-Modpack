package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.command.provider.EnumerationSuggestionProvider;
import me.elb.mediaplayermod.networking.packet.ServerPlayMediaPacket;
import me.elb.mediaplayermod.util.ColorUtil;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_3222;
import java.awt.*;
import java.util.Collection;

import static com.mojang.brigadier.arguments.DoubleArgumentType.*;
import static com.mojang.brigadier.arguments.IntegerArgumentType.*;
import static com.mojang.brigadier.arguments.StringArgumentType.*;
import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2186.method_9312;
import static net.minecraft.class_2186.method_9308;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class PlayTextCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                method_9247("playtext")
                        .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "playtext", 2))
                        .then(method_9244("targets", method_9308())
                                .then(method_9244("font", word())
                                        .suggests(EnumerationSuggestionProvider.FONTS_PROVIDER)
                                        .then(method_9244("size", integer(1, 128))
                                        .then(method_9244("color", word())
                                                .suggests(EnumerationSuggestionProvider.COLORS_PROVIDER)
                                        .then(method_9244("x_offset", doubleArg(-100, 100))
                                        .then(method_9244("y_offset", doubleArg(-100, 100))
                                        .then(method_9244("fade_in", doubleArg(0))
                                        .then(method_9244("duration", doubleArg(0))
                                        .then(method_9244("fade_out", doubleArg(0))
                                        .then(method_9244("text", greedyString())
                                                .executes(ctx -> execute(ctx.getSource(),
                                                        method_9312(ctx, "targets"),
                                                        getString(ctx, "font"),
                                                        getInteger(ctx, "size"),
                                                        getString(ctx, "color"),
                                                        getDouble(ctx, "x_offset"),
                                                        getDouble(ctx, "y_offset"),
                                                        getDouble(ctx, "fade_in"),
                                                        getDouble(ctx, "duration"),
                                                        getDouble(ctx, "fade_out"),
                                                        getString(ctx, "text"))))))))))))));
    }

    private static int execute(class_2168 source, Collection<class_3222> targets,
                               String font, int size, String colorStr, double xOffset, double yOffset,
                               double fadeIn, double duration, double fadeOut, String text) {
        Color color = ColorUtil.fromString(colorStr);
        float x = (float) (xOffset / 100.0);
        float y = (float) (yOffset / 100.0);
        long fi = (long) (Math.max(0, fadeIn) * 1000L);
        long dur = duration == 0 ? -1 : (long) (duration * 1000L);
        long fo = (long) (Math.max(0, fadeOut) * 1000L);
        MediaPlayerMod.getInstance().sendPacket(targets,
                new ServerPlayMediaPacket(new me.elb.mediaplayermod.model.media.Text(text, size, font, color, x, y, fi, dur, fo)));
        int count = targets.size();
        source.method_9226(() -> net.minecraft.class_2561.method_30163("Playing text for " + count + " players"), false);
        return count;
    }
}
