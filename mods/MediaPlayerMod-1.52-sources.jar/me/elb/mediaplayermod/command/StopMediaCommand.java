package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.model.media.MediaType;
import me.elb.mediaplayermod.networking.packet.Packet;
import me.elb.mediaplayermod.networking.packet.ServerStopMediaPacket;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.Collection;
import java.util.List;

import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2186.method_9312;
import static net.minecraft.class_2186.method_9308;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class StopMediaCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                method_9247("stopmedia")
                        .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "stopmedia", 2))
                        .executes(context -> executeStopMedia(context.getSource(), null))
                            .then(method_9244("targets", method_9308())
                                .executes(context -> executeStopMedia(context.getSource(), method_9312(context, "targets"))))
        );
    }

    private static int executeStopMedia(class_2168 source, Collection<class_3222> targets) {
        if (targets == null) {
            class_3222 player = source.method_44023();
            if (player == null)
                return 0;
            targets = List.of(player);
        }
        Packet packet = new ServerStopMediaPacket(MediaType.ANY);
        MediaPlayerMod.getInstance().sendPacket(targets, packet);
        // Si el stop abarca a todos los jugadores conectados, las proyecciones quedan detenidas
        // tambien en el servidor para que no revivan al reentrar.
        if (stopsEveryone(targets)) {
            me.elb.mediaplayermod.server.ServerProjectionManager.markAllStopped();
        }
        int count = targets.size();
        source.method_9226(() -> class_2561.method_30163("Stopping media for " + count + " players"), false);
        return targets.size();
    }

    private static boolean stopsEveryone(Collection<class_3222> targets) {
        var server = MediaPlayerMod.getInstance().getServer();
        if (server == null) return false;
        List<class_3222> online = server.getPlayerManager().getPlayerList();
        return !online.isEmpty() && targets.containsAll(online);
    }
}
