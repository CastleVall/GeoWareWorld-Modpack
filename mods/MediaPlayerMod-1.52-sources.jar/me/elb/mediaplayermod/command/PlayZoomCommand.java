package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.model.media.Zoom;
import me.elb.mediaplayermod.networking.packet.ServerPlayMediaPacket;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.Collection;

import static com.mojang.brigadier.arguments.DoubleArgumentType.*;
import static com.mojang.brigadier.arguments.FloatArgumentType.*;
import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2186.method_9312;
import static net.minecraft.class_2186.method_9308;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class PlayZoomCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                method_9247("playzoom")
                        .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "playzoom", 2))
                        .then(method_9244("targets", method_9308())
                                .then(method_9244("value", floatArg(-100, 100))
                                .then(method_9244("load_time", doubleArg(0))
                                        .executes(ctx -> execute(ctx.getSource(),
                                                method_9312(ctx, "targets"),
                                                getFloat(ctx, "value"),
                                                getDouble(ctx, "load_time")))))));
    }

    private static int execute(class_2168 source, Collection<class_3222> targets,
                               float value, double loadTime) {
        long duration = (long) (loadTime * 1000L);
        MediaPlayerMod.getInstance().sendPacket(targets, new ServerPlayMediaPacket(new Zoom(value, duration)));
        int count = targets.size();
        source.method_9226(() -> class_2561.method_30163("Playing zoom " + value + "% for " + count + " players"), false);
        return count;
    }
}
