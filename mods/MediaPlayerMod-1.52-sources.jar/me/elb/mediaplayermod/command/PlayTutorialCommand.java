package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.command.provider.MediaSuggestions;
import me.elb.mediaplayermod.networking.packet.ServerPlayTutorialPacket;
import me.elb.mediaplayermod.networking.packet.ServerStopTutorialPacket;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.Collection;

import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static com.mojang.brigadier.arguments.StringArgumentType.word;
import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2186.method_9312;
import static net.minecraft.class_2186.method_9308;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/**
 * {@code /playtutorial <targets> <nombre>} abre un tutorial bloqueante a los jugadores indicados.
 * {@code /playtutorial stop <targets>} cierra el tutorial activo.
 */
@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class PlayTutorialCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                method_9247("playtutorial")
                        .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "playtutorial", 2))
                        .then(method_9247("stop")
                                .then(method_9244("targets", method_9308())
                                        .executes(ctx -> stop(ctx.getSource(), method_9312(ctx, "targets")))))
                        .then(method_9244("targets", method_9308())
                                .then(method_9244("nombre", word())
                                        .suggests(MediaSuggestions.TUTORIALS)
                                        .executes(ctx -> play(ctx.getSource(),
                                                method_9312(ctx, "targets"),
                                                getString(ctx, "nombre"))))));
    }

    private static int play(class_2168 source, Collection<class_3222> targets, String name) {
        MediaPlayerMod.getInstance().sendPacket(targets, new ServerPlayTutorialPacket(name));
        int count = targets.size();
        source.method_9226(() -> class_2561.method_30163("Showing tutorial '" + name + "' to " + count + " players"), false);
        return count;
    }

    private static int stop(class_2168 source, Collection<class_3222> targets) {
        MediaPlayerMod.getInstance().sendPacket(targets, new ServerStopTutorialPacket());
        int count = targets.size();
        source.method_9226(() -> class_2561.method_30163("Closing tutorial for " + count + " players"), false);
        return count;
    }
}
