package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.command.provider.MediaSuggestions;
import me.elb.mediaplayermod.model.media.InteractiveImage;
import me.elb.mediaplayermod.networking.packet.Packet;
import me.elb.mediaplayermod.networking.packet.ServerPlayMediaPacket;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.Collection;
import java.util.List;

import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static com.mojang.brigadier.arguments.StringArgumentType.greedyString;
import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2186.method_9312;
import static net.minecraft.class_2186.method_9308;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/**
 * {@code /playinteractiveimage <targets> <url> [bilinear]} — Abre el inspeccionador de imagenes
 * estilo Resident Evil en los clientes objetivo. La url se resuelve en cada cliente igual que en
 * {@code /playimage} (nombre limpio, ruta de config/mediaplayer, absoluta o http). Para dar
 * tambien la imagen del reverso se separan las dos con {@code |}:
 * {@code /playinteractiveimage @a carta | carta_dorso}.
 *
 * <p>Al final puede ir {@code true}/{@code false} para el escalado bilineal (por defecto true).
 * Con {@code false} se usa vecino mas cercano, que muestra pixel art en su definicion nativa:
 * {@code /playinteractiveimage @a mapa_pixel false}.</p>
 */
@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class PlayInteractiveImageCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                method_9247("playinteractiveimage")
                        .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "playinteractiveimage", 2))
                        .then(method_9244("targets", method_9308())
                                .then(method_9244("url", greedyString())
                                        .suggests(MediaSuggestions.IMAGES)
                                        .executes(context -> executePlayInteractiveImage(context.getSource(),
                                                getString(context, "url"), method_9312(context, "targets"))))));
    }

    private static int executePlayInteractiveImage(class_2168 source, String url,
                                                   Collection<class_3222> targets) {
        if (targets == null) {
            class_3222 player = source.method_44023();
            if (player == null)
                return 0;
            targets = List.of(player);
        }
        if (url == null || url.isBlank() || targets.isEmpty())
            return 0;
        // Flag opcional al final: "true"/"false" como ultima palabra activa/desactiva el escalado
        // bilineal (por defecto true). El argumento url es greedy, asi que no puede ser un argumento
        // brigadier aparte. Solo se trata como flag si no es la unica palabra (una imagen podria
        // llamarse "true").
        boolean bilinear = true;
        String trimmed = url.trim();
        int lastSpace = trimmed.lastIndexOf(' ');
        if (lastSpace > 0) {
            String lastWord = trimmed.substring(lastSpace + 1);
            if (lastWord.equalsIgnoreCase("true") || lastWord.equalsIgnoreCase("false")) {
                bilinear = Boolean.parseBoolean(lastWord);
                trimmed = trimmed.substring(0, lastSpace).trim();
            }
        }
        // "frente | reverso": el separador | es opcional; sin el no hay imagen de reverso.
        String front = trimmed;
        String back = "";
        int separator = trimmed.indexOf('|');
        if (separator >= 0) {
            front = trimmed.substring(0, separator).trim();
            back = trimmed.substring(separator + 1).trim();
        }
        if (front.isBlank())
            return 0;
        Packet packet = new ServerPlayMediaPacket(new InteractiveImage(front, back, bilinear));
        MediaPlayerMod.getInstance().sendPacket(targets, packet);
        int count = targets.size();
        String finalFront = front;
        source.method_9226(() -> class_2561.method_30163("Inspecting image " + finalFront + " for " + count + " players"), false);
        return targets.size();
    }
}
