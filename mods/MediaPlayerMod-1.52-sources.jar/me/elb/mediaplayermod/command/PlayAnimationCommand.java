package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.command.provider.EnumerationSuggestionProvider;
import me.elb.mediaplayermod.command.provider.MediaSuggestions;
import me.elb.mediaplayermod.model.media.Animation;
import me.elb.mediaplayermod.model.media.AnimationPosition;
import me.elb.mediaplayermod.networking.packet.ServerPlayMediaPacket;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.Collection;
import java.util.List;

import static com.mojang.brigadier.arguments.IntegerArgumentType.getInteger;
import static com.mojang.brigadier.arguments.IntegerArgumentType.integer;
import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static com.mojang.brigadier.arguments.StringArgumentType.string;
import static com.mojang.brigadier.arguments.StringArgumentType.word;
import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2186.method_9312;
import static net.minecraft.class_2186.method_9308;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/**
 * {@code /playanimation <targets> <nombre> <position> <fps> [<first_frame> <last_frame>]}
 *
 * <p>Reproduce, fotograma a fotograma (sin fundidos), la animacion guardada en la carpeta
 * {@code config/mediaplayer/images/<nombre>}. El nombre se autocompleta con las carpetas
 * registradas dentro de {@code images}. {@code position} indica la zona de la pantalla
 * (center/top/bottom) y {@code fps} la velocidad de reproduccion. Si no se indican
 * {@code first_frame}/{@code last_frame}, se reproducen TODOS los fotogramas de principio a fin.
 */
@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class PlayAnimationCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                method_9247("playanimation")
                        .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "playanimation", 2))
                        .then(method_9244("targets", method_9308())
                                .then(method_9244("nombre", string())
                                .suggests(MediaSuggestions.ANIMATIONS)
                                .then(method_9244("position", word())
                                .suggests(EnumerationSuggestionProvider.ANIMATION_POSITION_PROVIDER)
                                .then(method_9244("fps", integer(1, 120))
                                .executes(context -> execute(context.getSource(),
                                        method_9312(context, "targets"),
                                        getString(context, "nombre"),
                                        getString(context, "position"),
                                        getInteger(context, "fps"),
                                        Animation.ALL_FRAMES, Animation.ALL_FRAMES))
                                .then(method_9244("first_frame", integer(0))
                                .then(method_9244("last_frame", integer(0))
                                .executes(context -> execute(context.getSource(),
                                        method_9312(context, "targets"),
                                        getString(context, "nombre"),
                                        getString(context, "position"),
                                        getInteger(context, "fps"),
                                        getInteger(context, "first_frame"),
                                        getInteger(context, "last_frame"))))))))));
    }

    private static int execute(class_2168 source, Collection<class_3222> targets,
                               String name, String positionStr, int fps, int firstFrame, int lastFrame) {
        if (targets == null || targets.isEmpty()) {
            class_3222 player = source.method_44023();
            if (player == null) {
                source.method_9213(class_2561.method_30163("Este comando debe ejecutarlo un jugador o indicar targets"));
                return 0;
            }
            targets = List.of(player);
        }
        if (firstFrame >= 0 && lastFrame >= 0 && lastFrame < firstFrame) {
            source.method_9213(class_2561.method_30163("last_frame debe ser mayor o igual que first_frame"));
            return 0;
        }
        AnimationPosition position = AnimationPosition.fromName(positionStr);
        MediaPlayerMod.getInstance().sendPacket(targets,
                new ServerPlayMediaPacket(new Animation(name, position, fps, firstFrame, lastFrame)));
        int count = targets.size();
        String range = (firstFrame < 0 || lastFrame < 0) ? "todos los fotogramas" : (firstFrame + ".." + lastFrame);
        source.method_9226(() -> class_2561.method_30163("Reproduciendo animacion '" + name + "' (" + range + ", "
                + fps + " fps, " + position.lowerName() + ") para " + count + " jugadores"), false);
        return count;
    }
}
