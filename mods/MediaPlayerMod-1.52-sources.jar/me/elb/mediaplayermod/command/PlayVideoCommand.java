package me.elb.mediaplayermod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import me.elb.mediaplayermod.MediaPlayerMod;
import me.elb.mediaplayermod.model.media.Video;
import me.elb.mediaplayermod.networking.packet.Packet;
import me.elb.mediaplayermod.networking.packet.ServerPlayMediaPacket;
import me.elb.mediaplayermod.command.provider.EnumerationSuggestionProvider;
import lombok.NoArgsConstructor;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.Collection;
import java.util.List;

import static com.mojang.brigadier.arguments.BoolArgumentType.bool;
import static com.mojang.brigadier.arguments.BoolArgumentType.getBool;
import static com.mojang.brigadier.arguments.DoubleArgumentType.doubleArg;
import static com.mojang.brigadier.arguments.DoubleArgumentType.getDouble;
import static com.mojang.brigadier.arguments.StringArgumentType.*;
import static me.elb.mediaplayermod.MediaPlayerMod.COMMAND_PERMISSION;
import static net.minecraft.class_2186.method_9312;
import static net.minecraft.class_2186.method_9308;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

@NoArgsConstructor(access = lombok.AccessLevel.PRIVATE)
public class PlayVideoCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        LiteralArgumentBuilder<class_2168> root = method_9247("playvideo")
                .requires(source -> Permissions.check(source, COMMAND_PERMISSION + "playvideo", 2));

        // playvideo <targets> <mode> <fade_in> <fade_out> <freeze_screen> ...
        root.then(method_9244("targets", method_9308())
                .then(method_9244("mode", word())
                        .suggests(EnumerationSuggestionProvider.VIDEO_FADE_PROVIDER)
                        .then(method_9244("fade_in", doubleArg())
                        .then(method_9244("fade_out", doubleArg())
                        .then(method_9244("freeze_screen", bool())
                                // 1) Clásico: ... <url>  -> pantalla completa (sin cambios)
                                .then(method_9244("url", greedyString())
                                        .suggests(me.elb.mediaplayermod.command.provider.MediaSuggestions.VIDEOS)
                                        .executes(ctx -> run(ctx.getSource(), getString(ctx, "url"),
                                                method_9312(ctx, "targets"), getDouble(ctx, "fade_in"),
                                                getDouble(ctx, "fade_out"), getString(ctx, "mode"),
                                                getBool(ctx, "freeze_screen"),
                                                Video.VideoRegion.FULLSCREEN.x, Video.VideoRegion.FULLSCREEN.y,
                                                Video.VideoRegion.FULLSCREEN.w, Video.VideoRegion.FULLSCREEN.h,
                                                Video.VideoRegion.FULLSCREEN.background)))
                                // 2) Preset: ... <preset> <url>
                                .then(literalPreset("fullscreen", Video.VideoRegion.FULLSCREEN))
                                .then(literalPreset("left", Video.VideoRegion.LEFT))
                                .then(literalPreset("right", Video.VideoRegion.RIGHT))
                                .then(literalPreset("top", Video.VideoRegion.TOP))
                                .then(literalPreset("bottom", Video.VideoRegion.BOTTOM))
                                .then(literalPreset("topleft", Video.VideoRegion.TOPLEFT))
                                .then(literalPreset("topright", Video.VideoRegion.TOPRIGHT))
                                .then(literalPreset("bottomleft", Video.VideoRegion.BOTTOMLEFT))
                                .then(literalPreset("bottomright", Video.VideoRegion.BOTTOMRIGHT))
                                .then(literalPreset("center", Video.VideoRegion.CENTER))
                                .then(literalPreset("hexa", Video.VideoRegion.HEXA))
                                // 3) Custom: ... custom <x> <y> <w> <h> <background> <url>
                                .then(method_9247("custom")
                                        .then(method_9244("x", doubleArg(0.0, 1.0))
                                        .suggests(hint("0.25", "X = posicion horizontal (0 = izquierda, 1 = derecha)"))
                                        .then(method_9244("y", doubleArg(0.0, 1.0))
                                        .suggests(hint("0.25", "Y = posicion vertical (0 = arriba, 1 = abajo)"))
                                        .then(method_9244("w", doubleArg(0.0, 1.0))
                                        .suggests(hint("0.5", "W = ANCHO del video (aqui defines el tamano). 1 = todo el ancho, 0.5 = mitad"))
                                        .then(method_9244("h", doubleArg(0.0, 1.0))
                                        .suggests(hint("0.5", "H = ALTO del video (aqui defines el tamano). 1 = todo el alto, 0.5 = mitad"))
                                        .then(method_9244("background", bool())
                                        .then(method_9244("url", greedyString())
                                        .suggests(me.elb.mediaplayermod.command.provider.MediaSuggestions.VIDEOS)
                                                .executes(ctx -> run(ctx.getSource(), getString(ctx, "url"),
                                                        method_9312(ctx, "targets"), getDouble(ctx, "fade_in"),
                                                        getDouble(ctx, "fade_out"), getString(ctx, "mode"),
                                                        getBool(ctx, "freeze_screen"),
                                                        (float) getDouble(ctx, "x"), (float) getDouble(ctx, "y"),
                                                        (float) getDouble(ctx, "w"), (float) getDouble(ctx, "h"),
                                                        getBool(ctx, "background")))))))))))))));

        dispatcher.register(root);
    }

    /** Sugerencia de autocompletado con un valor recomendado y una descripcion (tooltip). */
    private static com.mojang.brigadier.suggestion.SuggestionProvider<class_2168> hint(String value, String tooltip) {
        return (ctx, builder) -> {
            builder.suggest(value, class_2561.method_30163(tooltip));
            return builder.buildFuture();
        };
    }

    /** Construye la rama de un preset: literal <nombre> .then(url). */
    private static LiteralArgumentBuilder<class_2168> literalPreset(String name, Video.VideoRegion region) {
        return method_9247(name).then(method_9244("url", greedyString())
                                        .suggests(me.elb.mediaplayermod.command.provider.MediaSuggestions.VIDEOS)
                .executes(ctx -> run(ctx.getSource(), getString(ctx, "url"),
                        method_9312(ctx, "targets"), getDouble(ctx, "fade_in"),
                        getDouble(ctx, "fade_out"), getString(ctx, "mode"),
                        getBool(ctx, "freeze_screen"),
                        region.x, region.y, region.w, region.h, region.background)));
    }

    private static int run(class_2168 source, String url, Collection<class_3222> targets,
                           double fadeIn, double fadeOut, String fadeMode, boolean freezeScreen,
                           float rx, float ry, float rw, float rh, boolean background) {
        if (targets == null) {
            class_3222 player = source.method_44023();
            if (player == null)
                return 0;
            targets = List.of(player);
        }
        if (url == null || targets.isEmpty())
            return 0;
        me.elb.mediaplayermod.util.ChromaUtil.Spec chroma = me.elb.mediaplayermod.util.ChromaUtil.parse(url);
        url = chroma.url();
        Video.FadeMode mode = Video.FadeMode.NONE;
        if (fadeMode != null) {
            try {
                mode = Video.FadeMode.valueOf(fadeMode.toUpperCase());
                fadeIn = Math.max(0, fadeIn);
                fadeOut = Math.max(0, fadeOut);
            } catch (IllegalArgumentException ignored) { }
        }
        // Clamp defensivo de la región.
        rw = Math.max(0.01f, Math.min(1f, rw));
        rh = Math.max(0.01f, Math.min(1f, rh));
        rx = Math.max(0f, Math.min(1f - rw, rx));
        ry = Math.max(0f, Math.min(1f - rh, ry));

        Video video;
        if (chroma.enabled()) {
            // Chroma key = transparente sobre el mundo: overlay (sin freeze) y sin fondo negro.
            video = new Video(url, null, mode,
                    (long) (fadeIn * 1000L), (long) (fadeOut * 1000L), false,
                    rx, ry, rw, rh, false, true, chroma.color(), chroma.tolerance());
        } else {
            video = new Video(url, null, mode,
                    (long) (fadeIn * 1000L), (long) (fadeOut * 1000L), freezeScreen,
                    rx, ry, rw, rh, background);
        }
        Packet packet = new ServerPlayMediaPacket(video);
        MediaPlayerMod.getInstance().sendPacket(targets, packet);
        int count = targets.size();
        String urlFinal = url;
        source.method_9226(() -> class_2561.method_30163("Playing video " + urlFinal + " for " + count + " players"), false);
        return targets.size();
    }
}
