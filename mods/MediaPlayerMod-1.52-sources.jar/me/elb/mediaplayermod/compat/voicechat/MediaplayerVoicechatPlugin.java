package me.elb.mediaplayermod.compat.voicechat;

import de.maxhenkel.voicechat.api.VoicechatConnection;
import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.events.EntitySoundPacketEvent;
import de.maxhenkel.voicechat.api.events.EventRegistration;
import de.maxhenkel.voicechat.api.events.LocationalSoundPacketEvent;
import de.maxhenkel.voicechat.api.events.SoundPacketEvent;
import me.elb.mediaplayermod.server.voice.VoiceDistanceManager;
import net.minecraft.class_3222;

/**
 * Plugin de Simple Voice Chat (entrypoint "voicechat"): Fabric solo lo instancia si ese mod esta
 * instalado, asi que sus clases nunca se cargan sin el. Limita por jugador la distancia a la que
 * escucha el chat de proximidad cancelando los paquetes de voz que vienen de mas lejos; los grupos
 * y los canales de plugins no se tocan.
 */
public class MediaplayerVoicechatPlugin implements VoicechatPlugin {

    @Override
    public String getPluginId() {
        return "mediaplayermod";
    }

    @Override
    public void registerEvents(EventRegistration registration) {
        // SVC despacha por clase EXACTA y nunca dispara SoundPacketEvent a secas: la voz de
        // jugadores llega como EntitySoundPacketEvent y el audio posicional como
        // LocationalSoundPacketEvent. Registrarse a la clase padre = no recibir nada.
        registration.registerEvent(EntitySoundPacketEvent.class, this::onSoundPacket);
        registration.registerEvent(LocationalSoundPacketEvent.class, this::onSoundPacket);
    }

    private void onSoundPacket(SoundPacketEvent<?> event) {
        if (VoiceDistanceManager.isEmpty() || !SoundPacketEvent.SOURCE_PROXIMITY.equals(event.getSource())) {
            return;
        }
        VoicechatConnection receiverConn = event.getReceiverConnection();
        VoicechatConnection senderConn = event.getSenderConnection();
        if (receiverConn == null || senderConn == null) {
            return;
        }
        Double maxSq = VoiceDistanceManager.squaredDistance(receiverConn.getPlayer().getUuid());
        if (maxSq == null) {
            return;
        }
        if (receiverConn.getPlayer().getPlayer() instanceof class_3222 receiver
                && senderConn.getPlayer().getPlayer() instanceof class_3222 sender
                && (receiver.method_37908() != sender.method_37908() || receiver.method_5858(sender) > maxSq)) {
            event.cancel();
        }
    }
}
