package me.elb.mediaplayermod.utils;

import me.elb.mediaplayermod.MediaPlayerMod;
import lombok.experimental.UtilityClass;
import org.jetbrains.annotations.NotNull;
import org.watermedia.api.image.decoders.GifDecoder;

import javax.imageio.*;
import javax.imageio.stream.ImageInputStream;
import javax.imageio.stream.MemoryCacheImageOutputStream;
import java.awt.*;
import java.awt.font.TextLayout;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@UtilityClass
public class ImageUtils {

    public static boolean isGifImage(ImageInputStream imageInputStream) {
        try {
            Iterator<ImageReader> readers = ImageIO.getImageReaders(imageInputStream);
            while (readers.hasNext()) {
                ImageReader reader = readers.next();
                if (reader.getFormatName().equalsIgnoreCase("gif")) {
                    return true;
                }
            }
        } catch (IOException e) {
            MediaPlayerMod.LOGGER.error("Error checking if image is a GIF", e);
        }
        return false;
    }

    public static GifDecoder scaleGif(GifDecoder originalGif, float scale) throws IOException {
        ImageWriter gifWriter = ImageIO.getImageWritersByFormatName("gif").next();
        ImageWriteParam imageWriteParam = gifWriter.getDefaultWriteParam();
        imageWriteParam.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
        imageWriteParam.setCompressionType("LZW");
        imageWriteParam.setCompressionQuality(0.5f);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        gifWriter.setOutput(new MemoryCacheImageOutputStream(outputStream));
        gifWriter.prepareWriteSequence(null);
        for (int i = 0; i < originalGif.getFrameCount(); i++) {
            BufferedImage frame = originalGif.getFrame(i);
            BufferedImage scaledFrame = scaleImage(frame, scale);
            gifWriter.writeToSequence(new IIOImage(scaledFrame, null, null), imageWriteParam);
        }
        gifWriter.endWriteSequence();
        outputStream.close();
        byte[] gifBytes = outputStream.toByteArray();
        ByteArrayInputStream inputStream = new ByteArrayInputStream(gifBytes);
        GifDecoder scaledGif = new GifDecoder();
        scaledGif.read(inputStream);
        inputStream.close();
        return scaledGif;
    }

    public static BufferedImage scaleImage(BufferedImage originalImage, float scale) {
        if (scale == 1) {
            return originalImage;
        }
        int newWidth = (int) (originalImage.getWidth() * scale);
        int newHeight = (int) (originalImage.getHeight() * scale);
        // ImageIO puede devolver TYPE_CUSTOM (0), que el constructor de BufferedImage rechaza.
        int type = originalImage.getType() == BufferedImage.TYPE_CUSTOM
                ? BufferedImage.TYPE_INT_ARGB : originalImage.getType();
        BufferedImage scaledImage = new BufferedImage(newWidth, newHeight, type);
        Graphics2D g2d = scaledImage.createGraphics();
        g2d.drawImage(originalImage, 0, 0, newWidth, newHeight, null);
        g2d.dispose();
        return scaledImage;
    }

    public static @NotNull BufferedImage createTextImage(int width, int height, String text, Font font, Color color) {
        BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = bufferedImage.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
        g2d.setColor(new Color(0, 0, 0, 0));
        g2d.fillRect(0, 0, width, height);
        g2d.setFont(font);
        FontMetrics metrics = g2d.getFontMetrics(font);
        List<String> lines = new ArrayList<>();
        String[] initialLines = text.split("\n");
        for (String initialLine : initialLines) {
            String[] words = initialLine.split(" ");
            StringBuilder currentLine = new StringBuilder();
            for (String word : words) {
                String testLine = currentLine + (currentLine.isEmpty() ? "" : " ") + word;
                if (metrics.stringWidth(testLine) > width) {
                    lines.add(currentLine.toString());
                    currentLine = new StringBuilder(word);
                } else {
                    currentLine.append(currentLine.isEmpty() ? "" : " ").append(word);
                }
            }
            if (!currentLine.isEmpty()) {
                lines.add(currentLine.toString());
            }
        }
        int lineHeight = metrics.getHeight();
        int totalTextHeight = lineHeight * lines.size();
        int y = ((height - totalTextHeight) / 2) + metrics.getAscent();

        Stroke outlineStroke = new BasicStroke(3.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
        for (String line : lines) {
            if (line.isEmpty()) { y += lineHeight; continue; }
            int x = (width - metrics.stringWidth(line)) / 2;
            TextLayout textLayout = new TextLayout(line, font, g2d.getFontRenderContext());
            AffineTransform at = AffineTransform.getTranslateInstance(x, y);
            Shape outline = textLayout.getOutline(at);

            g2d.setColor(new Color(0, 0, 0, 230));
            g2d.setStroke(outlineStroke);
            g2d.draw(outline);

            g2d.setColor(color);
            g2d.fill(outline);
            y += lineHeight;
        }
        g2d.dispose();
        return bufferedImage;
    }
}
