package me.elb.mediaplayermod.utils;

import lombok.experimental.UtilityClass;
import org.lwjgl.opengl.GL11;

@UtilityClass
public class GLUtil {
    public static void makeColorTransparent(int textureID, int colorToMakeTransparent) {
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureID);

        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

        int width = GL11.glGetTexLevelParameteri(GL11.GL_TEXTURE_2D, 0, GL11.GL_TEXTURE_WIDTH);
        int height = GL11.glGetTexLevelParameteri(GL11.GL_TEXTURE_2D, 0, GL11.GL_TEXTURE_HEIGHT);
        int[] pixels = new int[width * height];
        GL11.glGetTexImage(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, pixels);

        for (int i = 0; i < pixels.length; i++) {
            if (pixels[i] == colorToMakeTransparent || pixels[i] == 0) {
                pixels[i] = 0x00000000;
            }
        }

        GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA, width, height, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, pixels);

        GL11.glBindTexture(GL11.GL_TEXTURE_2D, 0);
    }

    public static float calculateAlpha(long start, long fadeIn, long duration, long fadeOut) {
        long startDiff = System.currentTimeMillis() - start;
        if (startDiff < fadeIn) {
            return startDiff / (1F * fadeIn);
        } else if (startDiff < fadeIn + duration) {
            return 1;
        } else {
            long endDiff = startDiff - fadeIn - duration;
            return 1 - endDiff / (1F * fadeOut);
        }
    }
}
