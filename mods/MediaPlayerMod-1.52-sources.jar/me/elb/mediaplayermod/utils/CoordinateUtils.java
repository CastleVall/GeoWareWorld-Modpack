package me.elb.mediaplayermod.utils;

import lombok.experimental.UtilityClass;

@UtilityClass
public class CoordinateUtils {
    public static float interpolateYaw(double fromYaw, double toYaw, double percent) {
        if (fromYaw == toYaw) {
            return (float) fromYaw;
        }
        fromYaw = normalizeAngle(fromYaw, 360);
        toYaw = normalizeAngle(toYaw, 360);

        double deltaYaw = toYaw - fromYaw;
        if (deltaYaw > 180) {
            deltaYaw -= 360;
        } else if (deltaYaw < -180) {
            deltaYaw += 360;
        }
        double interpolatedYaw = fromYaw + deltaYaw * percent;
        return (float) normalizeAngle(interpolatedYaw, 360);
    }

    private static double normalizeAngle(double angle, int max) {
        angle %= max;
        if (angle < 0) {
            angle += max;
        }
        return angle;
    }

    public static float interpolatePitch(double fromPitch, double toPitch, double percent) {
        if (fromPitch == toPitch) {
            return (float) fromPitch;
        }
        fromPitch = normalizeAngle(fromPitch + 90, 360);
        toPitch = normalizeAngle(toPitch + 90, 360);

        double deltaPitch = toPitch - fromPitch;
        if (deltaPitch > 90) {
            deltaPitch -= 180;
        } else if (deltaPitch < -90) {
            deltaPitch += 180;
        }
        double interpolatedPitch = fromPitch + deltaPitch * percent;
        return (float) normalizeAngle(interpolatedPitch, 180) - 90;
    }
}
