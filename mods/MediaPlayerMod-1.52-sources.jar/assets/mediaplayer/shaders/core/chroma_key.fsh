#version 150

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform vec3 ChromaKey;     // color de fondo a eliminar (RGB 0..1)
uniform vec2 ChromaParams;  // x = tolerancia, y = suavizado del borde

in vec2 texCoord0;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0);

    // Distancia del pixel al color clave; cuanto mas cerca, mas transparente.
    float dist = distance(color.rgb, ChromaKey);
    float edge = max(ChromaParams.y, 0.0001);
    float keyAlpha = smoothstep(ChromaParams.x, ChromaParams.x + edge, dist);

    color.a *= keyAlpha;
    fragColor = color * ColorModulator;

    if (fragColor.a <= 0.001) discard;
}
