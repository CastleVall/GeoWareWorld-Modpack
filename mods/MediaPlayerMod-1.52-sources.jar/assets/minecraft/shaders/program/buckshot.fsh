#version 120

varying vec4 texcoord;
uniform sampler2D gcolor;

// Número de tonos
float nColors = 4.0;

// Interpolación entre colores (solo para vec3)
vec3 lerp(vec3 colorone, vec3 colortwo, float value) {
    return (colorone + value * (colortwo - colorone));
}

// Conversión RGB a HSV
vec3 RGBToHSV(vec3 RGB) {
    vec4 k = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = RGB.g < RGB.b ? vec4(RGB.b, RGB.g, k.w, k.z) : vec4(RGB.gb, k.xy);
    vec4 q = RGB.r < p.x ? vec4(p.x, p.y, p.w, RGB.r) : vec4(RGB.r, p.yzx);
    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}

// Conversión HSV a RGB
vec3 HSVToRGB(vec3 HSV) {
    vec4 k = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(HSV.xxx + k.xyz) * 6.0 - k.www);
    return HSV.z * lerp(k.xxx, clamp(p - k.xxx, 0.0, 1.0), HSV.y);
}

void main() {
    // Obtener el color del píxel
    vec2 point = texcoord.st;
    vec3 color = texture2D(gcolor, point).rgb;

    // Convertir a HSV y quantizar
    vec3 hsv = RGBToHSV(color);
    float cutColor = 1.0 / nColors;
    vec2 target_c = cutColor * floor(hsv.gb / cutColor);

    // Limitar el brillo mínimo
    target_c.y = max(target_c.y, 0.025);

    // AJUSTE 1: Modificar el tono (hue) para colores específicos
    // hsv.x es el tono (0.0 a 1.0). Ejemplo: reducir intensidad del amarillo
    if (hsv.x >= 0.1 && hsv.x <= 0.2) { // Rango del amarillo
        // Interpolación manual para float (en vez de lerp)
        float newHue = 0.15; // Tono objetivo
        float mixAmount = 0.3; // Fuerza de la mezcla (0.0 a 1.0)
        hsv.x = hsv.x + (newHue - hsv.x) * mixAmount;
        target_c.x = hsv.x;
    }

    // Reconstruir el color quantizado
    vec3 celColor = HSVToRGB(vec3(hsv.r, target_c));

    // AJUSTE 2: Mezcla con el color original
    celColor = lerp(color, celColor, 0.7); // 70% Cel Shading, 30% original

    // AJUSTE 3: Ajuste final de colores en RGB
    celColor.r = celColor.r; // Menos rojo
    celColor.g = celColor.g; // Menos verde
    celColor.b = celColor.b; // Menos azul
    celColor = clamp(celColor, 0.0, 1.0); // Mantener valores válidos

    // Contraste restaurado a tu versión anterior
    celColor = celColor * 0.5;
    celColor = clamp(celColor, 0.0, 1.0);

    gl_FragColor = vec4(celColor, 1.0);
}